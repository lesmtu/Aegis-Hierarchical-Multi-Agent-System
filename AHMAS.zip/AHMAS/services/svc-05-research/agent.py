import json

from shared.worker_base.base_worker import BaseWorkerAgent


class ResearchAgent(BaseWorkerAgent):
    """
    SVC-05 Worker Agent — Research
    contracts.json SVC-05:
    - agent_type: "research"
    - primary_tools: ["web_search", "document_reader", "url_fetcher"]
    - llm: mid_tier
    """

    AGENT_TYPE = "research"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []

        available_tools = self.tools.list_available_tools("research")

        prompt = f"""Research task: {dispatch_payload['sub_task_description']}

Context from memory:
{chr(10).join(rag_ctx.context_chunks)}

Previous attempt guidance: {dispatch_payload.get('correction_guidance', 'None')}

Research this topic thoroughly. Use available tools if needed.
Return a comprehensive research summary."""

        web_search_tool = next((t for t in available_tools if "web_search" in t.name), None)
        if web_search_tool:
            search_result = self.tools.invoke_tool(
                web_search_tool.tool_id,
                {"query": dispatch_payload["sub_task_description"]},
            )
            if search_result.success:
                tools_used.append(web_search_tool.tool_id)
                prompt += f"\n\nSearch results: {json.dumps(search_result.output)}"

        response = await self.llm.complete(prompt)
        return response.text, tools_used
