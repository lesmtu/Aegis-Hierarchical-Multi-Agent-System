"""
Generic Worker Agent — used by SVC-05 through SVC-10.

contracts.json: task.dispatched  →  payload.agent_type filter
                task.result      ← produce after execution
                task.confidence  ← co-emit alongside task.result

AGENT_TYPE env var (set per container in docker-compose):
  research | logic | media | code | tool_builder | validation

LLM_API_BASE / LLM_API_KEY / LLM_MODEL — OpenAI-compatible endpoint.

SVC-19 self-registration:
  On startup each worker POSTs its capability to SVC-19 Capability Registry
  (system_spec.md §1.4 explicit allowed REST exception: agent services → SVC-19).
  Uses stable agent_id="static-{AGENT_TYPE}-agent" for idempotent restart.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import httpx
from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.kafka_loop import AioKafkaBackend, SimpleConsumerLoop

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Env ────────────────────────────────────────────────────────────────────────
_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
_AGENT_TYPE    = os.getenv("AGENT_TYPE", "research")          # matches task.dispatched payload.agent_type
_SERVICE_MAP   = {
    "research":     ("SVC-05", "svc-05-worker"),
    "logic":        ("SVC-06", "svc-06-worker"),
    "media":        ("SVC-07", "svc-07-worker"),
    "code":         ("SVC-08", "svc-08-worker"),
    "tool_builder": ("SVC-09", "svc-09-worker"),
    "validation":   ("SVC-10", "svc-10-worker"),
}
_SERVICE_ID, _GROUP_ID = _SERVICE_MAP.get(_AGENT_TYPE, ("SVC-05", "svc-05-worker"))
_TOPICS = ["task.dispatched"]

_LLM_API_BASE   = os.getenv("LLM_API_BASE", "https://api.openai.com/v1")
_LLM_API_KEY    = os.getenv("LLM_API_KEY", "")
_LLM_MODEL      = os.getenv("LLM_MODEL", "gpt-4o")
_LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "2048"))
_LLM_TEMP       = float(os.getenv("LLM_TEMPERATURE", "0.2"))

_SVC19_BASE_URL = os.getenv("SVC19_BASE_URL", "http://svc-19:8000")

# ── Model tier mapping (contracts.json CapabilityRegistryEntry.model_tier) ─────
_AGENT_MODEL_TIER: dict[str, str] = {
    "research":     "mid_tier",
    "logic":        "mid_tier",
    "media":        "mid_tier",
    "code":         "mid_tier",
    "tool_builder": "mid_tier",
    "validation":   "lightweight",
}


# ── LLM client (OpenAI-compatible) ────────────────────────────────────────────
class _LLMClient:
    def __init__(self):
        import httpx
        self._http  = httpx.AsyncClient(timeout=120.0)
        self._base  = _LLM_API_BASE.rstrip("/")
        self._key   = _LLM_API_KEY
        self._model = _LLM_MODEL

    async def complete(self, system: str, user: str) -> str:
        headers = {"Authorization": f"Bearer {self._key}", "Content-Type": "application/json"}
        body = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            "max_tokens": _LLM_MAX_TOKENS,
            "temperature": _LLM_TEMP,
        }
        resp = await self._http.post(f"{self._base}/chat/completions", json=body, headers=headers)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    async def aclose(self):
        await self._http.aclose()


# ── Worker logic: task.dispatched → LLM → task.result + task.confidence ───────
async def _handle_dispatched(
    message: dict,
    backend: AioKafkaBackend,
    llm: _LLMClient,
) -> None:
    payload = message.get("payload", {})

    # contracts.json: filter by agent_type (each worker only processes its own)
    if payload.get("agent_type") != _AGENT_TYPE:
        return

    node_id    = payload.get("node_id", str(uuid4()))
    task_id    = payload.get("task_id", "")
    input_data = payload.get("input", "")
    corr_id    = message.get("correlation_id", task_id)
    trace_id   = message.get("trace_id", str(uuid4()))

    system_prompt = (
        f"You are an AI worker agent of type '{_AGENT_TYPE}' in the Aegis HMAS system. "
        "Execute the given sub-task and respond with a clear, structured result. "
        "Be concise and accurate. Return only the result, no commentary."
    )

    try:
        output_text = await llm.complete(system=system_prompt, user=str(input_data))
        confidence  = 0.85
        success     = True
    except Exception as exc:
        logger.error("LLM call failed for node=%s: %s", node_id, exc, exc_info=True)
        output_text = f"Worker execution failed: {exc}"
        confidence  = 0.0
        success     = False

    now = datetime.now(timezone.utc).isoformat()

    # ── task.result  (contracts.json: producers=[SVC-05..10], consumers=[SVC-12]) ──
    result_payload = {
        "node_id":       node_id,
        "task_id":       task_id,
        "agent_id":      _SERVICE_ID,
        "agent_type":    _AGENT_TYPE,
        "input":         str(input_data),
        "output":        output_text,
        "confidence":    confidence,
        "needs_review":  not success or confidence < 0.75,
        "retry_count":   payload.get("retry_count", 0),
        "execution_time_ms": 0,
        "created_at":    now,
    }

    result_env = AegisCanonicalEventEnvelope.create(
        event_type="task.result",
        source_service=_SERVICE_ID,
        payload=result_payload,
        correlation_id=corr_id,
        trace_id=trace_id,
        status="success" if success else "error",
        error={"error_code": "INTERNAL_ERROR", "error_type": "system",
               "retryable": True, "message": output_text} if not success else None,
    )
    backend.send("task.result", result_env.to_dict())

    # ── task.confidence  (contracts.json: co-emitted alongside task.result) ──
    confidence_payload = {
        "node_id":    node_id,
        "task_id":    task_id,
        "agent_id":   _SERVICE_ID,
        "confidence": confidence,
        "created_at": now,
    }
    conf_env = AegisCanonicalEventEnvelope.create(
        event_type="task.confidence",
        source_service=_SERVICE_ID,
        payload=confidence_payload,
        correlation_id=corr_id,
        trace_id=trace_id,
    )
    backend.send("task.confidence", conf_env.to_dict())

    logger.info("Worker %s processed node=%s confidence=%.2f", _SERVICE_ID, node_id, confidence)


# ── SVC-19 Self-Registration ──────────────────────────────────────────────────
async def _register_capability_with_retry() -> None:
    """
    Register this worker's capability into SVC-19 Capability Registry at startup.

    system_spec.md §1.4: REST calls from agent services → SVC-19 are an
    explicit permitted exception to the event-driven rule.

    contracts.json CapabilityRegistryEntry required fields:
        agent_id, agent_type, capability_type, model_tier, llm_config,
        tool_ids, health_status, trust_score, version, is_dynamic, registered_at
    """
    agent_id   = f"static-{_AGENT_TYPE}-agent"   # stable, idempotent across restarts
    model_tier = _AGENT_MODEL_TIER.get(_AGENT_TYPE, "mid_tier")
    payload = {
        "agent_id":        agent_id,
        "agent_type":      _AGENT_TYPE,
        "capability_type": _AGENT_TYPE,
        "model_tier":      model_tier,
        "llm_config": {
            "model_tier":   model_tier,
            "max_tokens":   _LLM_MAX_TOKENS,
            "temperature":  _LLM_TEMP,
        },
        "tool_ids":        [],
        "health_status":   "healthy",
        "trust_score":     1.0,
        "version":         "1.0.0",
        "is_dynamic":      False,
        "registered_at":   datetime.now(timezone.utc).isoformat(),
    }

    delays = [2, 4, 8]
    async with httpx.AsyncClient(timeout=10.0) as client:
        for attempt, delay in enumerate(delays, start=1):
            try:
                resp = await client.post(
                    f"{_SVC19_BASE_URL}/capabilities/register",
                    json=payload,
                )
                if resp.status_code == 201:
                    logger.info("%s registered capability '%s' in SVC-19 (agent_id=%s)",
                                _SERVICE_ID, _AGENT_TYPE, agent_id)
                    return
                if resp.status_code == 409:
                    # Already registered — idempotent, treat as success
                    logger.info("%s capability '%s' already registered in SVC-19 (agent_id=%s)",
                                _SERVICE_ID, _AGENT_TYPE, agent_id)
                    return
                logger.warning("%s SVC-19 registration attempt %d/%d returned HTTP %s",
                               _SERVICE_ID, attempt, len(delays), resp.status_code)
            except Exception as exc:
                logger.warning("%s SVC-19 registration attempt %d/%d failed: %s",
                               _SERVICE_ID, attempt, len(delays), exc)

            if attempt < len(delays):
                await asyncio.sleep(delay)

    logger.error("%s could not register capability '%s' in SVC-19 after %d attempts. "
                 "SVC-03 will emit capability.missing — tool generation loop will handle it.",
                 _SERVICE_ID, _AGENT_TYPE, len(delays))


# ── Lifespan ───────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    backend = AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    # Register capability in SVC-19 so SVC-03 can find this worker
    # (system_spec.md §1.4 — explicit permitted REST exception)
    await _register_capability_with_retry()

    llm = _LLMClient()

    async def process(topic: str, message: dict) -> None:
        await _handle_dispatched(message, backend, llm)

    loop = SimpleConsumerLoop(
        bootstrap_servers=_KAFKA_BROKERS,
        group_id=_GROUP_ID,
        topics=_TOPICS,
        process_fn=process,
    )
    await loop.start()
    logger.info("%s fully started — agent_type=%s LLM_MODEL=%s LLM_API_BASE=%s",
                _SERVICE_ID, _AGENT_TYPE, _LLM_MODEL, _LLM_API_BASE)
    yield
    await loop.stop()
    await backend.stop()
    await llm.aclose()
    logger.info("%s shutdown complete", _SERVICE_ID)


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title=f"Aegis HMAS {_SERVICE_ID} Worker Agent — {_AGENT_TYPE.title()}",
    version="1.0.0",
    separate_input_output_schemas=False,
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict:
    return {
        "service_id": _SERVICE_ID,
        "status": "healthy",
        "version": "1.0.0",
        "agent_type": _AGENT_TYPE,
        "llm_model": _LLM_MODEL,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return ""
