from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    service_id: str = "SVC-12"
    service_version: str = "1.0.0"
    svc19_base_url: str = os.getenv("SVC12_SVC19_BASE_URL", "http://svc-19-capability-registry")


settings = Settings()
