from __future__ import annotations


class QualityControllerKafkaConsumer:
    topic = "task.validated"

    def __init__(self, quality_controller):
        self.quality_controller = quality_controller

    async def consume(self, envelope) -> None:
        await self.quality_controller.handle_task_validated(envelope)
