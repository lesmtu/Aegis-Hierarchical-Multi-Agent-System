from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

import httpx

logger = logging.getLogger(__name__)


@dataclass
class QualityEnvelope:
    event_id: str
    idempotency_key: str
    correlation_id: str
    trace_id: str
    payload: dict[str, Any]


class QualityController:
    TRUST_DELTA_PASS = 0.05
    TRUST_DELTA_FAIL = -0.10

    def __init__(self, svc19_base_url, producer, idempotency, http_client: httpx.AsyncClient | None = None):
        self.svc19_url = svc19_base_url.rstrip("/")
        self.producer = producer
        self.idempotency = idempotency
        self.http = http_client or httpx.AsyncClient(timeout=10.0)
        self._metrics_store: dict[str, dict[str, float | int]] = {}

    async def handle_task_validated(self, envelope: QualityEnvelope) -> None:
        if not self.idempotency.check_and_set(envelope.idempotency_key, envelope.event_id):
            return

        try:
            payload = envelope.payload
            agent_id = payload["agent_id"]
            validation_status = payload["validation_status"]

            await self._update_trust_score(agent_id, validation_status)
            self._aggregate_metrics(payload)

            if validation_status == "passed":
                await self._emit_result_ready(payload, envelope)
                await self._emit_notification_out(payload, envelope)

            self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)
        except Exception:
            self.idempotency.mark_failed(envelope.idempotency_key, envelope.event_id)
            raise

    async def _update_trust_score(self, agent_id: str, validation_status: str) -> None:
        delta = self.TRUST_DELTA_PASS if validation_status == "passed" else self.TRUST_DELTA_FAIL
        try:
            response = await self.http.patch(
                f"{self.svc19_url}/capabilities/{agent_id}/trust_score",
                json={"trust_score_delta": delta},
            )
            if response.status_code >= 400:
                logger.error(
                    "SVC-12: trust score update failed for agent %s with status %s",
                    agent_id,
                    response.status_code,
                )
        except Exception as exc:  # pragma: no cover
            logger.error("SVC-12: SVC-19 call failed (non-critical): %s", exc)

    async def _emit_result_ready(self, payload: dict[str, Any], envelope: QualityEnvelope) -> None:
        result_ready_payload = {
            "task_id": payload["task_id"],
            "dag_id": payload["dag_id"],
            "user_id": payload["user_id"],
            "session_id": payload["session_id"],
            "channel": payload["channel"],
            "synthesized_output": payload["result_summary"],
            "reflection_score": payload["confidence"],
            "aggregation_metadata": {
                "total_nodes": payload.get("total_nodes", 1),
                "conflict_resolutions": payload.get("conflict_resolutions", 0),
                "sources_used": payload.get("sources_used", []),
            },
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        if payload["channel"] == "telegram" and payload.get("telegram_chat_id"):
            result_ready_payload["telegram_chat_id"] = payload["telegram_chat_id"]
        if payload["channel"] == "webui" and payload.get("webui_connection_id"):
            result_ready_payload["webui_connection_id"] = payload["webui_connection_id"]
        if payload["channel"] == "openclaw":
            if payload.get("openclaw_conversation_id"):
                result_ready_payload["openclaw_conversation_id"] = payload["openclaw_conversation_id"]
            if payload.get("openclaw_message_id"):
                result_ready_payload["openclaw_message_id"] = payload["openclaw_message_id"]
            if payload.get("openclaw_source_channel"):
                result_ready_payload["openclaw_source_channel"] = payload["openclaw_source_channel"]

        await self.producer.produce_envelope(
            topic="result.ready",
            payload=result_ready_payload,
            source_service="SVC-12",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
        )

    async def _emit_notification_out(self, payload: dict[str, Any], envelope: QualityEnvelope) -> None:
        notification_payload = {
            "notification_id": str(uuid4()),
            "task_id": payload["task_id"],
            "user_id": payload["user_id"],
            "session_id": payload["session_id"],
            "channel": payload["channel"],
            "message_type": "result",
            "message_content": payload["result_summary"],
            "delivery_status": "pending",
            "retry_count": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        if payload["channel"] == "telegram" and payload.get("telegram_chat_id"):
            notification_payload["telegram_chat_id"] = payload["telegram_chat_id"]
        if payload["channel"] == "webui" and payload.get("webui_connection_id"):
            notification_payload["webui_connection_id"] = payload["webui_connection_id"]
        if payload["channel"] == "openclaw":
            if payload.get("openclaw_conversation_id"):
                notification_payload["openclaw_conversation_id"] = payload["openclaw_conversation_id"]
            if payload.get("openclaw_message_id"):
                notification_payload["openclaw_message_id"] = payload["openclaw_message_id"]
            if payload.get("openclaw_source_channel"):
                notification_payload["openclaw_source_channel"] = payload["openclaw_source_channel"]

        await self.producer.produce_envelope(
            topic="notification.out",
            payload=notification_payload,
            source_service="SVC-12",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
        )

    def _aggregate_metrics(self, payload: dict[str, Any]) -> None:
        agent_type = payload["agent_type"]
        if agent_type not in self._metrics_store:
            self._metrics_store[agent_type] = {
                "total": 0,
                "passed": 0,
                "failed": 0,
                "escalated": 0,
                "confidence_sum": 0.0,
            }

        metrics = self._metrics_store[agent_type]
        metrics["total"] += 1
        metrics[payload["validation_status"]] += 1
        metrics["confidence_sum"] += payload["confidence"]
