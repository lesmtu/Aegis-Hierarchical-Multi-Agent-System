from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

SERVICE_ROOT = Path("/home/g/AHMAS/services/svc-12-quality-controller")
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
if "/home/g/AHMAS" not in sys.path:
    sys.path.insert(0, "/home/g/AHMAS")

from app.services.quality_controller import QualityController, QualityEnvelope  # noqa: E402


class FakeProducer:
    def __init__(self):
        self.produced = []

    async def produce_envelope(self, topic, payload, source_service, correlation_id, trace_id):
        @dataclass
        class ProducedEvent:
            event_type: str
            payload: dict
            source_service: str
            correlation_id: str
            trace_id: str

        self.produced.append(ProducedEvent(topic, payload, source_service, correlation_id, trace_id))


class FakeIdempotency:
    def __init__(self):
        self.seen = set()
        self.completed = []
        self.failed = []

    def check_and_set(self, idempotency_key, event_id):
        key = (idempotency_key, event_id)
        if key in self.seen:
            return False
        self.seen.add(key)
        return True

    def mark_completed(self, idempotency_key, event_id):
        self.completed.append((idempotency_key, event_id))

    def mark_failed(self, idempotency_key, event_id):
        self.failed.append((idempotency_key, event_id))


class FakeResponse:
    def __init__(self, status_code=200, json_body=None):
        self.status_code = status_code
        self._json = json_body or {"agent_id": "agent-1", "new_trust_score": 0.5}

    def json(self):
        return self._json


class FakeSvc19Client:
    def __init__(self, status_code=200):
        self.status_code = status_code
        self.patch_calls = []

    async def patch(self, url, json):
        self.patch_calls.append({"url": url, "json": json})
        return FakeResponse(status_code=self.status_code)


def validated_payload(validation_status="passed", **overrides):
    payload = {
        "task_id": str(uuid4()),
        "dag_id": str(uuid4()),
        "node_id": str(uuid4()),
        "agent_id": "agent-1",
        "agent_type": "code",
        "validation_status": validation_status,
        "confidence": 0.91,
        "user_id": "user-1",
        "session_id": str(uuid4()),
        "channel": "webui",
        "webui_connection_id": "conn-1",
        "result_summary": "Validation passed and result is ready.",
        "sources_used": ["memory:1"],
        "total_nodes": 1,
        "conflict_resolutions": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    payload.update(overrides)
    return payload


def build_envelope(payload):
    return QualityEnvelope(
        event_id=str(uuid4()),
        idempotency_key=str(uuid4()),
        correlation_id=payload["task_id"],
        trace_id=str(uuid4()),
        payload=payload,
    )


def build_qc(status_code=200):
    producer = FakeProducer()
    idempotency = FakeIdempotency()
    svc19_mock = FakeSvc19Client(status_code=status_code)
    qc = QualityController(
        svc19_base_url="http://svc-19",
        producer=producer,
        idempotency=idempotency,
        http_client=svc19_mock,
    )
    return qc, producer, idempotency, svc19_mock


def test_trust_score_delta_on_pass():
    """contracts.json: trust_score_delta_on_pass = +0.05"""
    qc, _, _, svc19_mock = build_qc()
    passed_envelope = build_envelope(validated_payload(validation_status="passed"))
    asyncio.run(qc.handle_task_validated(passed_envelope))
    patch_call = svc19_mock.patch_calls[0]
    assert patch_call["json"]["trust_score_delta"] == 0.05


def test_trust_score_delta_on_fail():
    """contracts.json: trust_score_delta_on_fail = -0.10"""
    qc, _, _, svc19_mock = build_qc()
    failed_envelope = build_envelope(validated_payload(validation_status="failed"))
    asyncio.run(qc.handle_task_validated(failed_envelope))
    patch_call = svc19_mock.patch_calls[0]
    assert patch_call["json"]["trust_score_delta"] == -0.10


def test_trust_score_delta_on_escalated():
    """escalated same delta as fail: -0.10"""
    qc, _, _, svc19_mock = build_qc()
    escalated_envelope = build_envelope(validated_payload(validation_status="escalated"))
    asyncio.run(qc.handle_task_validated(escalated_envelope))
    patch_call = svc19_mock.patch_calls[0]
    assert patch_call["json"]["trust_score_delta"] == -0.10


def test_result_ready_emitted_only_on_passed():
    """result.ready ONLY on passed — not failed, not escalated"""
    qc, producer, _, _ = build_qc()
    failed_envelope = build_envelope(validated_payload(validation_status="failed"))
    asyncio.run(qc.handle_task_validated(failed_envelope))
    events = [e.event_type for e in producer.produced]
    assert "result.ready" not in events


def test_trust_score_update_always_called():
    """PATCH /capabilities/{agent_id}/trust_score called for passed AND failed"""
    qc, _, _, svc19_mock = build_qc()
    passed_envelope = build_envelope(validated_payload(validation_status="passed"))
    failed_envelope = build_envelope(validated_payload(validation_status="failed"))
    asyncio.run(qc.handle_task_validated(passed_envelope))
    assert len(svc19_mock.patch_calls) == 1
    asyncio.run(qc.handle_task_validated(failed_envelope))
    assert len(svc19_mock.patch_calls) == 2


def test_notification_out_emitted_on_completion_for_passed_flow():
    qc, producer, _, _ = build_qc()
    passed_envelope = build_envelope(validated_payload(validation_status="passed"))
    asyncio.run(qc.handle_task_validated(passed_envelope))
    events = [e.event_type for e in producer.produced]
    assert "notification.out" in events
    notification = [e for e in producer.produced if e.event_type == "notification.out"][0]
    assert notification.payload["message_type"] == "result"
    assert notification.payload["delivery_status"] == "pending"
    assert notification.payload["retry_count"] == 0


def test_idempotency_enforced_on_task_validated():
    qc, _, idempotency, svc19_mock = build_qc()
    envelope = build_envelope(validated_payload(validation_status="passed"))
    asyncio.run(qc.handle_task_validated(envelope))
    asyncio.run(qc.handle_task_validated(envelope))
    assert len(svc19_mock.patch_calls) == 1
    assert len(idempotency.completed) == 1


def test_metrics_aggregate_per_agent_type():
    qc, _, _, _ = build_qc()
    asyncio.run(qc.handle_task_validated(build_envelope(validated_payload(validation_status="passed", confidence=0.8))))
    asyncio.run(qc.handle_task_validated(build_envelope(validated_payload(validation_status="failed", confidence=0.2))))
    metrics = qc._metrics_store["code"]
    assert metrics["total"] == 2
    assert metrics["passed"] == 1
    assert metrics["failed"] == 1
    assert metrics["escalated"] == 0
    assert metrics["confidence_sum"] == 1.0


def test_svc19_failure_does_not_break_pipeline(caplog):
    qc, producer, _, _ = build_qc(status_code=503)
    passed_envelope = build_envelope(validated_payload(validation_status="passed"))
    asyncio.run(qc.handle_task_validated(passed_envelope))
    events = [e.event_type for e in producer.produced]
    assert "result.ready" in events
    assert "notification.out" in events
    assert "trust score update failed" in caplog.text


def test_openclaw_route_metadata_passes_through():
    qc, producer, _, _ = build_qc()
    payload = validated_payload(
        validation_status="passed",
        channel="openclaw",
        webui_connection_id=None,
        openclaw_conversation_id="conv-1",
        openclaw_message_id="msg-1",
        openclaw_source_channel="telegram",
    )
    asyncio.run(qc.handle_task_validated(build_envelope(payload)))
    result_ready = [e for e in producer.produced if e.event_type == "result.ready"][0]
    notification = [e for e in producer.produced if e.event_type == "notification.out"][0]
    assert result_ready.payload["openclaw_conversation_id"] == "conv-1"
    assert notification.payload["openclaw_source_channel"] == "telegram"
