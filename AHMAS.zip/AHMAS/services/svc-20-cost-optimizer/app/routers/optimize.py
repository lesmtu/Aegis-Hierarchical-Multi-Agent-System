from __future__ import annotations

from fastapi import APIRouter, Request

from ..models.optimize import APIErrorResponse, CostOptimizeRequest, CostOptimizeResponse, PricingResponse

router = APIRouter(tags=["optimizer"])


@router.post(
    "/optimize",
    response_model=CostOptimizeResponse,
    responses={400: {"model": APIErrorResponse, "description": "Invalid request payload"}},
)
async def optimize(request: Request, payload: CostOptimizeRequest) -> CostOptimizeResponse:
    return request.app.state.optimizer.optimize(payload)


@router.get("/pricing", response_model=PricingResponse)
async def pricing(request: Request) -> PricingResponse:
    return request.app.state.optimizer.get_pricing()
