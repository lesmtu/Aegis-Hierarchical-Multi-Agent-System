from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from starlette.exceptions import HTTPException as StarletteHTTPException

from .routers.health import router as health_router
from .routers.optimize import router as optimize_router
from .services.errors import build_error_response, request_id_from
from .services.kafka_consumer import CostOptimizerKafkaConsumer
from .services.metrics import REQUEST_COUNT, REQUEST_LATENCY
from .services.optimizer import CostOptimizer

SERVICE_ID = "SVC-20"
SERVICE_VERSION = "1.0.0"
SERVICE_TITLE = "Aegis HMAS SVC-20 Cost Optimizer"

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    optimizer = CostOptimizer()
    kafka_consumer = CostOptimizerKafkaConsumer(optimizer=optimizer)
    app.state.optimizer = optimizer
    app.state.kafka_consumer = kafka_consumer
    LOGGER.info("SVC-20 started with %s routing entries", len(optimizer.routing_table))
    yield


app = FastAPI(
    title=SERVICE_TITLE,
    version=SERVICE_VERSION,
    lifespan=lifespan,
    separate_input_output_schemas=False,
)
app.include_router(optimize_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = uuid4()
    path = request.url.path
    method = request.method
    started = perf_counter()
    response = None
    try:
        response = await call_next(request)
    finally:
        REQUEST_LATENCY.labels(method=method, path=path).observe(perf_counter() - started)
    if response is not None:
        REQUEST_COUNT.labels(method=method, path=path, status_code=response.status_code).inc()
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return build_error_response(
        status_code=400,
        error_code="INVALID_PAYLOAD",
        message="Request validation failed",
        request_id=request_id_from(request),
        details={"errors": exc.errors()},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404:
        error_code = "INVALID_PAYLOAD"
        message = "Route not found"
    else:
        error_code = "INVALID_PAYLOAD"
        message = exc.detail if isinstance(exc.detail, str) else "HTTP error"
    return build_error_response(
        status_code=exc.status_code,
        error_code=error_code,
        message=message,
        request_id=request_id_from(request),
        details=None if isinstance(exc.detail, str) else {"detail": exc.detail},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    LOGGER.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return build_error_response(
        status_code=500,
        error_code="INTERNAL_ERROR",
        message="Internal server error",
        request_id=request_id_from(request),
        details={"reason": str(exc)},
    )
