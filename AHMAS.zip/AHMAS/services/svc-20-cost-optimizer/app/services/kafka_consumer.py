from __future__ import annotations

import logging

from ..models.optimize import AegisCanonicalEventEnvelope, TaskConfidencePayload
from .metrics import KAFKA_MESSAGES
from .optimizer import CostOptimizer

LOGGER = logging.getLogger(__name__)


class CostOptimizerKafkaConsumer:
    def __init__(self, optimizer: CostOptimizer):
        self.optimizer = optimizer

    async def consume(self, envelope: AegisCanonicalEventEnvelope) -> None:
        if envelope.event_type != "task.confidence":
            raise ValueError(f"Unsupported event_type {envelope.event_type}")
        payload = TaskConfidencePayload.model_validate(envelope.payload)
        self.optimizer.record_feedback(payload)
        KAFKA_MESSAGES.labels(topic="task.confidence", result="processed").inc()
        LOGGER.info(
            "Processed task.confidence for task_id=%s model_used=%s confidence=%s",
            payload.task_id,
            payload.model_used,
            payload.confidence,
        )
