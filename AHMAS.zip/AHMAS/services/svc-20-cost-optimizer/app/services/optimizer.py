from __future__ import annotations

from datetime import datetime, timezone

from ..models.optimize import CostOptimizeRequest, CostOptimizeResponse, ModelTier, PricingResponse, PricingTable, TaskConfidencePayload

ROUTING_TABLE: dict[str, ModelTier] = {
    "low_cheap": ModelTier.LIGHTWEIGHT,
    "low_medium": ModelTier.LIGHTWEIGHT,
    "low_expensive": ModelTier.MID_TIER,
    "medium_cheap": ModelTier.LIGHTWEIGHT,
    "medium_medium": ModelTier.MID_TIER,
    "medium_expensive": ModelTier.MID_TIER,
    "high_cheap": ModelTier.MID_TIER,
    "high_medium": ModelTier.MID_TIER,
    "high_expensive": ModelTier.HEAVY_REASONING,
}

PRICING_TABLE = PricingTable(
    lightweight=0.001,
    mid_tier=0.01,
    heavy_reasoning=0.05,
)


class CostOptimizer:
    def __init__(self):
        self.routing_table = ROUTING_TABLE.copy()
        self.pricing_table = PRICING_TABLE
        self.last_updated = datetime.now(timezone.utc)
        self.last_feedback: TaskConfidencePayload | None = None

    def optimize(self, request: CostOptimizeRequest) -> CostOptimizeResponse:
        key = f"{request.complexity.value}_{request.cost_tier.value}"
        model_tier = self.routing_table.get(key, ModelTier.MID_TIER)
        estimated_cost = getattr(self.pricing_table, model_tier.value)
        reasoning = (
            f"Routing {request.complexity.value}/{request.cost_tier.value} to "
            f"{model_tier.value} using the SVC-20 routing table and pricing data"
        )
        return CostOptimizeResponse(
            sub_task_id=request.sub_task_id,
            recommended_model_tier=model_tier,
            estimated_cost_usd=estimated_cost,
            reasoning=reasoning,
        )

    def get_pricing(self) -> PricingResponse:
        return PricingResponse(pricing_table=self.pricing_table, last_updated=self.last_updated)

    def record_feedback(self, payload: TaskConfidencePayload) -> None:
        self.last_feedback = payload
