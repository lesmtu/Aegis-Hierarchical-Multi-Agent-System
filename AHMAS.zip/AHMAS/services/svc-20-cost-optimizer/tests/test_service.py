from __future__ import annotations

from uuid import uuid4

from fastapi.testclient import TestClient

from app.main import app


def make_client() -> TestClient:
    return TestClient(app)


def optimize_payload(complexity: str, cost_tier: str) -> dict[str, str]:
    return {
        "sub_task_id": str(uuid4()),
        "complexity": complexity,
        "cost_tier": cost_tier,
        "required_capability": "research",
    }


def test_routing_table_matches_contracts_exactly():
    expected = {
        "low_cheap": "lightweight",
        "low_medium": "lightweight",
        "low_expensive": "mid_tier",
        "medium_cheap": "lightweight",
        "medium_medium": "mid_tier",
        "medium_expensive": "mid_tier",
        "high_cheap": "mid_tier",
        "high_medium": "mid_tier",
        "high_expensive": "heavy_reasoning",
    }
    with make_client() as client:
        for key, expected_tier in expected.items():
            complexity, cost_tier = key.split("_", 1)
            response = client.post("/optimize", json=optimize_payload(complexity, cost_tier))
            assert response.status_code == 200
            assert response.json()["recommended_model_tier"] == expected_tier


def test_cost_optimize_response_contains_all_required_fields():
    with make_client() as client:
        response = client.post("/optimize", json=optimize_payload("high", "expensive"))
    assert response.status_code == 200
    assert {
        "sub_task_id",
        "recommended_model_tier",
        "estimated_cost_usd",
        "reasoning",
    } <= set(response.json())


def test_pricing_returns_all_required_tiers():
    with make_client() as client:
        response = client.get("/pricing")
    assert response.status_code == 200
    body = response.json()
    assert set(body["pricing_table"]) == {"lightweight", "mid_tier", "heavy_reasoning"}
    assert "last_updated" in body


def test_health_response_schema():
    with make_client() as client:
        response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["service_id"] == "SVC-20"
    assert body["status"] in ["healthy", "degraded", "unhealthy"]


def test_metrics_prometheus_format():
    with make_client() as client:
        response = client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]
    assert "aegis_cost_optimizer_requests_total" in response.text
