from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class Channel(str, Enum):
    TELEGRAM = "telegram"
    WEBUI = "webui"
    OPENCLAW = "openclaw"


class IntentType(str, Enum):
    QUERY = "query"
    TASK = "task"
    COMMAND = "command"
    CLARIFICATION = "clarification"


class ErrorType(str, Enum):
    SYSTEM = "system"
    AGENT = "agent"
    VALIDATION = "validation"
    TIMEOUT = "timeout"


class ErrorCode(str, Enum):
    WORKER_TIMEOUT = "WORKER_TIMEOUT"
    VALIDATION_FAILED = "VALIDATION_FAILED"
    MEMORY_UNAVAILABLE = "MEMORY_UNAVAILABLE"
    TOOL_SANDBOX_FAILED = "TOOL_SANDBOX_FAILED"
    PLAN_REFLECTION_BELOW_THRESHOLD = "PLAN_REFLECTION_BELOW_THRESHOLD"
    DAG_NODE_RETRY_EXHAUSTED = "DAG_NODE_RETRY_EXHAUSTED"
    HITL_TIMEOUT_EXCEEDED = "HITL_TIMEOUT_EXCEEDED"
    SCHEMA_VERSION_MISMATCH = "SCHEMA_VERSION_MISMATCH"
    IDEMPOTENCY_KEY_DUPLICATE = "IDEMPOTENCY_KEY_DUPLICATE"
    CAPABILITY_NOT_FOUND = "CAPABILITY_NOT_FOUND"
    RULE_BLOCKED = "RULE_BLOCKED"
    REPLAN_LIMIT_EXCEEDED = "REPLAN_LIMIT_EXCEEDED"
    META_AGENT_KILL_SWITCH_ACTIVE = "META_AGENT_KILL_SWITCH_ACTIVE"
    META_AGENT_RATE_LIMIT_EXCEEDED = "META_AGENT_RATE_LIMIT_EXCEEDED"
    TOOL_GENERATION_FAILED = "TOOL_GENERATION_FAILED"
    META_AGENT_CREATION_FAILED = "META_AGENT_CREATION_FAILED"
    NOTIFICATION_DELIVERY_FAILED = "NOTIFICATION_DELIVERY_FAILED"
    MEMORY_STORE_FAILED = "MEMORY_STORE_FAILED"
    MEMORY_RETRIEVE_FAILED = "MEMORY_RETRIEVE_FAILED"
    INVALID_PAYLOAD = "INVALID_PAYLOAD"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    HITL_ALREADY_RESPONDED = "HITL_ALREADY_RESPONDED"
    AGENT_TRUST_SCORE_TOO_LOW = "AGENT_TRUST_SCORE_TOO_LOW"
    OPENCLAW_TRANSLATION_FAILED = "OPENCLAW_TRANSLATION_FAILED"
    CYCLIC_DEPENDENCY_IN_PLAN = "CYCLIC_DEPENDENCY_IN_PLAN"


class ErrorSchema(StrictBaseModel):
    error_code: ErrorCode
    error_type: ErrorType
    retryable: bool
    message: str = Field(min_length=1)
    details: dict[str, Any] | None = None


class APIErrorResponse(StrictBaseModel):
    error: ErrorSchema
    request_id: UUID
    timestamp: datetime


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class DependencyHealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class HealthCheckResponse(StrictBaseModel):
    service_id: str = Field(pattern=r"^SVC-[0-9]{2}$")
    status: HealthStatus
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    dependencies: dict[str, DependencyHealthStatus] | None = None
    timestamp: datetime


class UserInputPayload(StrictBaseModel):
    user_id: str = Field(min_length=1)
    session_id: UUID
    channel: Channel
    raw_input: str = Field(min_length=1, max_length=131072)
    timestamp: datetime
    telegram_chat_id: str | None = None
    telegram_message_id: int | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None

    @model_validator(mode="after")
    def validate_route_fields(self) -> "UserInputPayload":
        if self.channel == Channel.TELEGRAM and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == Channel.WEBUI and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == Channel.OPENCLAW:
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_message_id:
                raise ValueError("openclaw_message_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class TaskContext(StrictBaseModel):
    task_id: UUID
    user_id: str = Field(min_length=1)
    session_id: UUID
    channel: Channel
    raw_input: str = Field(min_length=1, max_length=131072)
    parsed_intent: str = Field(min_length=1)
    intent_type: IntentType
    context_chunks: list[str] = Field(default_factory=list, max_length=10)
    rag_source_ids: list[str] = Field(default_factory=list)
    preliminary_confidence: float = Field(ge=0.0, le=1.0)
    is_ambiguous: bool
    pii_detected: bool
    created_at: datetime
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None


class HITLTriggerReason(str, Enum):
    LOW_CONFIDENCE = "low_confidence"
    HIGH_RISK = "high_risk"
    AMBIGUOUS_INTENT = "ambiguous_intent"
    PLANNER_FAILURE = "planner_failure"
    AUDIT_ESCALATION = "audit_escalation"
    META_AGENT_FAILURE = "meta_agent_failure"


class RiskClassification(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HITLAction(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    MODIFY = "modify"
    CLARIFY = "clarify"


class HITLRequestPayload(StrictBaseModel):
    hitl_id: UUID
    task_id: UUID
    node_id: UUID | None = None
    user_id: str = Field(min_length=1)
    session_id: UUID
    trigger_reason: HITLTriggerReason
    risk_classification: RiskClassification
    context: str = Field(min_length=1)
    current_output: str | None = None
    confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    available_actions: list[HITLAction] = Field(min_length=1)
    timeout_hours: int = Field(ge=1)
    created_at: datetime


class NotificationMessageType(str, Enum):
    RESULT = "result"
    HITL_REQUEST = "hitl_request"
    PROGRESS_UPDATE = "progress_update"
    ERROR = "error"


class DeliveryStatus(str, Enum):
    DELIVERED = "delivered"
    FAILED = "failed"
    PENDING = "pending"


class NotificationOutPayload(StrictBaseModel):
    notification_id: UUID
    task_id: UUID
    user_id: str = Field(min_length=1)
    session_id: UUID
    channel: Channel
    message_type: NotificationMessageType
    message_content: str = Field(min_length=1)
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None
    delivery_status: DeliveryStatus
    retry_count: int = Field(ge=0, le=5)
    created_at: datetime

    @model_validator(mode="after")
    def validate_route_fields(self) -> "NotificationOutPayload":
        if self.channel == Channel.TELEGRAM and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == Channel.WEBUI and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == Channel.OPENCLAW:
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class TelegramWebhookResponse(StrictBaseModel):
    ok: bool


class WebsocketInboundMessage(StrictBaseModel):
    type: str
    session_id: UUID
    content: str = Field(min_length=1)
    hitl_id: UUID | None = None
    hitl_decision: HITLAction | None = None

    @model_validator(mode="after")
    def validate_by_type(self) -> "WebsocketInboundMessage":
        if self.type not in {"user_message", "hitl_response"}:
            raise ValueError("type must be 'user_message' or 'hitl_response'")
        if self.type == "hitl_response":
            if self.hitl_id is None or self.hitl_decision is None:
                raise ValueError("hitl_response requires hitl_id and hitl_decision")
        return self


class HITLRespondRequest(StrictBaseModel):
    decision: HITLAction
    modified_output: str | None = None
    clarification_text: str | None = None
    responded_by: str = Field(min_length=1)


class OpenClawMessage(StrictBaseModel):
    openclaw_message_id: str
    direction: str
    event: dict[str, Any]


class OpenClawWebhookResponse(StrictBaseModel):
    ok: bool


class OpenClawWebhookEvent(StrictBaseModel):
    type: str
    user_id: str = Field(min_length=1)
    session_id: UUID
    conversation_id: str = Field(min_length=1)
    message_id: str = Field(min_length=1)
    source_channel: str = Field(min_length=1)
    content: str | None = None
    hitl_id: UUID | None = None
    hitl_decision: HITLAction | None = None
    responded_by: str | None = None

    @model_validator(mode="after")
    def validate_by_type(self) -> "OpenClawWebhookEvent":
        if self.type not in {"user_message", "hitl_response"}:
            raise ValueError("type must be 'user_message' or 'hitl_response'")
        if self.type == "user_message" and not self.content:
            raise ValueError("user_message requires content")
        if self.type == "hitl_response":
            if self.hitl_id is None or self.hitl_decision is None:
                raise ValueError("hitl_response requires hitl_id and hitl_decision")
        return self
