from __future__ import annotations

from shared.events.envelope import AegisCanonicalEventEnvelope

from ..models.common import ErrorCode, ErrorSchema, ErrorType, OpenClawMessage


class OpenClawTranslationError(ValueError):
    pass


class OpenClawAdapter:
    def to_cloud_envelope(
        self,
        *,
        event_type: str,
        source_service: str,
        payload: dict,
        correlation_id: str,
        trace_id: str,
        idempotency_key: str | None = None,
    ) -> AegisCanonicalEventEnvelope:
        try:
            return AegisCanonicalEventEnvelope.create(
                event_type=event_type,
                source_service=source_service,
                payload=payload,
                correlation_id=correlation_id,
                trace_id=trace_id,
                idempotency_key=idempotency_key,
            )
        except Exception as exc:  # pragma: no cover - defensive conversion
            raise OpenClawTranslationError(str(exc)) from exc

    def from_cloud_envelope(self, envelope: dict) -> OpenClawMessage:
        try:
            canonical = AegisCanonicalEventEnvelope(**envelope)
            canonical.validate()
            return OpenClawMessage(
                openclaw_message_id=canonical.event_id,
                direction="cloud_to_local",
                event=canonical.to_dict(),
            )
        except Exception as exc:
            raise OpenClawTranslationError(str(exc)) from exc

    def error_schema(self, message: str, details: dict | None = None) -> ErrorSchema:
        return ErrorSchema(
            error_code=ErrorCode.OPENCLAW_TRANSLATION_FAILED,
            error_type=ErrorType.SYSTEM,
            retryable=True,
            message=message,
            details=details,
        )

