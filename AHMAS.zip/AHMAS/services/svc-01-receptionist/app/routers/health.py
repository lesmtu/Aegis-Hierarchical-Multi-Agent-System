from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter

from ..config import settings
from ..models.common import DependencyHealthStatus, HealthCheckResponse, HealthStatus
from ..services.metrics import metrics_response

router = APIRouter()


@router.get("/health", response_model=HealthCheckResponse)
async def health_check() -> HealthCheckResponse:
    return HealthCheckResponse(
        service_id=settings.service_id,
        status=HealthStatus.HEALTHY,
        version=settings.service_version,
        dependencies={
            "SVC-15": DependencyHealthStatus.UNKNOWN,
            "SVC-16": DependencyHealthStatus.UNKNOWN,
            "kafka": DependencyHealthStatus.UNKNOWN,
            "openclaw": DependencyHealthStatus.HEALTHY,
        },
        timestamp=datetime.now(timezone.utc),
    )


@router.get("/metrics")
async def metrics():
    return metrics_response()

