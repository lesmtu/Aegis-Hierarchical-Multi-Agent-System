from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect

from ..dependencies import get_connection_manager, get_hitl_forwarder, get_kafka_producer
from ..models.common import UserInputPayload, WebsocketInboundMessage
from ..services.metrics import WEBSOCKET_MESSAGES

router = APIRouter()


@router.websocket("/ws/ui")
async def websocket_endpoint(
    websocket: WebSocket,
    producer=Depends(get_kafka_producer),
    hitl_forwarder=Depends(get_hitl_forwarder),
    connection_manager=Depends(get_connection_manager),
):
    await websocket.accept()
    connection_id = str(uuid4())
    connection_manager.add(connection_id, websocket)
    try:
        while True:
            inbound = WebsocketInboundMessage.model_validate(await websocket.receive_json())
            WEBSOCKET_MESSAGES.labels(direction="inbound", message_type=inbound.type).inc()

            if inbound.type == "user_message":
                task_id = uuid4()
                payload = UserInputPayload(
                    user_id=str(inbound.session_id),
                    session_id=inbound.session_id,
                    channel="webui",
                    raw_input=inbound.content,
                    timestamp=datetime.now(timezone.utc),
                    webui_connection_id=connection_id,
                )
                producer.produce(
                    topic="user.input",
                    payload=payload.model_dump(mode="json"),
                    correlation_id=str(task_id),
                    trace_id=str(uuid4()),
                )
            else:
                await hitl_forwarder.forward(
                    hitl_id=str(inbound.hitl_id),
                    decision=inbound.hitl_decision,
                    responded_by=str(inbound.session_id),
                    content=inbound.content,
                )
    except WebSocketDisconnect:
        connection_manager.remove(connection_id)

