from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, Request

from ..dependencies import get_hitl_forwarder, get_kafka_producer
from ..models.common import ErrorCode, OpenClawWebhookEvent, OpenClawWebhookResponse, UserInputPayload
from ..services.errors import build_error_response, request_id_from

router = APIRouter()


@router.post("/webhook/openclaw", response_model=OpenClawWebhookResponse)
async def openclaw_webhook(
    request: Request,
    producer=Depends(get_kafka_producer),
    hitl_forwarder=Depends(get_hitl_forwarder),
):
    try:
        event = OpenClawWebhookEvent.model_validate(await request.json())
    except Exception as exc:
        return build_error_response(
            status_code=400,
            error_code=ErrorCode.INVALID_PAYLOAD,
            message="Malformed OpenClaw event",
            request_id=request_id_from(request),
            details={"reason": str(exc)},
            retryable=False,
        )

    if event.type == "user_message":
        task_id = uuid4()
        payload = UserInputPayload(
            user_id=event.user_id,
            session_id=event.session_id,
            channel="openclaw",
            raw_input=event.content or "",
            timestamp=datetime.now(timezone.utc),
            openclaw_conversation_id=event.conversation_id,
            openclaw_message_id=event.message_id,
            openclaw_source_channel=event.source_channel,
        )
        producer.produce(
            topic="user.input",
            payload=payload.model_dump(mode="json", exclude_none=True),
            correlation_id=str(task_id),
            trace_id=str(uuid4()),
        )
        return OpenClawWebhookResponse(ok=True)

    await hitl_forwarder.forward(
        hitl_id=str(event.hitl_id),
        decision=event.hitl_decision,
        responded_by=event.responded_by or event.user_id,
        content=event.content,
    )
    return OpenClawWebhookResponse(ok=True)
