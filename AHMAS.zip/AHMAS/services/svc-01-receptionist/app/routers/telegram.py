from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from ..dependencies import get_hitl_forwarder, get_kafka_producer
from ..models.common import ErrorCode, HITLAction, TelegramWebhookResponse, UserInputPayload
from ..services.errors import build_error_response, request_id_from

router = APIRouter()


@router.post("/webhook/telegram", response_model=TelegramWebhookResponse)
async def telegram_webhook(
    request: Request,
    producer=Depends(get_kafka_producer),
    hitl_forwarder=Depends(get_hitl_forwarder),
):
    try:
        update = await request.json()
    except Exception as exc:
        return build_error_response(
            status_code=400,
            error_code=ErrorCode.INVALID_PAYLOAD,
            message="Malformed Telegram update",
            request_id=request_id_from(request),
            details={"reason": str(exc)},
            retryable=False,
        )

    if "message" in update:
        msg = update["message"]
        try:
            payload = UserInputPayload(
                user_id=str(msg["from"]["id"]),
                session_id=uuid4(),
                channel="telegram",
                raw_input=msg["text"],
                timestamp=datetime.now(timezone.utc),
                telegram_chat_id=str(msg["chat"]["id"]),
                telegram_message_id=msg["message_id"],
            )
            task_id = uuid4()
            producer.produce(
                topic="user.input",
                payload=payload.model_dump(mode="json"),
                correlation_id=str(task_id),
                trace_id=str(uuid4()),
            )
        except Exception as exc:
            return build_error_response(
                status_code=400,
                error_code=ErrorCode.INVALID_PAYLOAD,
                message="Malformed Telegram update",
                request_id=request_id_from(request),
                details={"reason": str(exc)},
                retryable=False,
            )
        return TelegramWebhookResponse(ok=True)

    if "callback_query" in update:
        try:
            callback_query = update["callback_query"]
            raw_data = callback_query["data"]
            prefix, hitl_id, decision = raw_data.split(":", 2)
            if prefix != "hitl":
                raise ValueError("callback_query.data must use hitl:{hitl_id}:{decision}")
            await hitl_forwarder.forward(
                hitl_id=hitl_id,
                decision=HITLAction(decision),
                responded_by=str(callback_query["from"]["id"]),
                content=None,
            )
            return TelegramWebhookResponse(ok=True)
        except Exception as exc:
            return build_error_response(
                status_code=400,
                error_code=ErrorCode.INVALID_PAYLOAD,
                message="Malformed Telegram update",
                request_id=request_id_from(request),
                details={"reason": str(exc)},
                retryable=False,
            )

    return build_error_response(
        status_code=400,
        error_code=ErrorCode.INVALID_PAYLOAD,
        message="Malformed Telegram update",
        request_id=request_id_from(request),
        details={"reason": "Expected message or callback_query"},
        retryable=False,
    )

