from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from libs.lib02_rag.context import RAGContext

from shared.idempotency.client import IdempotencyClient

from .config import settings
from .openclaw.adapter import OpenClawAdapter
from .services.connection_manager import ConnectionManager
from .services.hitl_forwarder import HITLForwarder
from .services.intent_parser import IntentParser
from .services.kafka_backends import AioKafkaProducerBackend
from .services.kafka_consumer import ReceptionistKafkaConsumer
from .services.kafka_consumer_loop import ReceptionistConsumerLoop
from .services.kafka_producer import ReceptionistKafkaProducer
from .services.notification_router import NotificationRouter
from .services.rag_enricher import RAGEnricher
from .services.runtime import (
    InMemoryKafkaProducerBackend,
    InMemoryRedis,
    OpenClawDeliveryBackend,
    RecordedHTTPClient,
    StubLightweightLLM,
    TelegramDeliveryBackend,
)


class StubRAGEnricher(RAGEnricher):
    def __init__(self):
        pass

    def enrich(self, *, query: str, session_id: str, task_id: str):
        return RAGContext(
            context_chunks=[f"memory:{query[:32]}"],
            source_ids=[task_id],
            retrieval_scores=[0.8],
            degraded_mode=False,
        )


# ---------------------------------------------------------------------------
# Real production backends
# ---------------------------------------------------------------------------

# Real aiokafka producer backend (start/stop managed by lifespan in main.py)
_real_kafka_backend = AioKafkaProducerBackend(settings.kafka_bootstrap_servers)

# Real Redis for idempotency
def _build_real_redis():
    try:
        import redis as redis_lib
        return redis_lib.Redis(
            host=settings.redis_host,
            port=settings.redis_port,
            decode_responses=True,
            socket_connect_timeout=5,
        )
    except Exception:
        return None

_real_redis = _build_real_redis()

# ---------------------------------------------------------------------------
# Shared / common singletons (used in both production and tests via DI)
# ---------------------------------------------------------------------------

_adapter = OpenClawAdapter()
_connection_manager = ConnectionManager()
_openclaw_backend = OpenClawDeliveryBackend()
_http_client = RecordedHTTPClient()
_hitl_forwarder = HITLForwarder(_http_client, settings.svc15_base_url)

# ---------------------------------------------------------------------------
# Production wiring — real Redis idempotency + real Kafka producer
# ---------------------------------------------------------------------------

_real_idempotency = IdempotencyClient(_real_redis, settings.service_id) if _real_redis else None

_real_producer = ReceptionistKafkaProducer(
    _real_kafka_backend, _adapter, service_id=settings.service_id
)

_notification_router = NotificationRouter(
    TelegramDeliveryBackend(), _connection_manager, _openclaw_backend
)
_intent_parser = IntentParser(llm_client=StubLightweightLLM(), rag_enricher=StubRAGEnricher())

_real_consumer = ReceptionistKafkaConsumer(
    idempotency_client=_real_idempotency or IdempotencyClient(InMemoryRedis(), settings.service_id),
    producer=_real_producer,
    intent_parser=_intent_parser,
    notification_router=_notification_router,
    adapter=_adapter,
)

_consumer_loop = ReceptionistConsumerLoop(
    bootstrap_servers=settings.kafka_bootstrap_servers,
    group_id=settings.kafka_consumer_group_id,
    topics=settings.kafka_consumer_topics,
    auto_offset_reset=settings.kafka_auto_offset_reset,
    consumer=_real_consumer,
)

# ---------------------------------------------------------------------------
# InMemory singletons for unit tests (reset_runtime_state() targets these)
# ---------------------------------------------------------------------------

_redis = InMemoryRedis()
_kafka_backend = InMemoryKafkaProducerBackend()
_telegram_backend = TelegramDeliveryBackend()
_test_producer = ReceptionistKafkaProducer(_kafka_backend, _adapter, service_id=settings.service_id)
_test_consumer = ReceptionistKafkaConsumer(
    idempotency_client=IdempotencyClient(_redis, settings.service_id),
    producer=_test_producer,
    intent_parser=_intent_parser,
    notification_router=NotificationRouter(_telegram_backend, _connection_manager, _openclaw_backend),
    adapter=_adapter,
)

# ---------------------------------------------------------------------------
# Dependency accessors
# ---------------------------------------------------------------------------


def get_adapter() -> OpenClawAdapter:
    return _adapter


def get_kafka_producer() -> ReceptionistKafkaProducer:
    """Production router/websocket DI — uses real Kafka backend."""
    return _real_producer


def get_kafka_consumer_loop() -> ReceptionistConsumerLoop:
    return _consumer_loop


def get_real_kafka_backend() -> AioKafkaProducerBackend:
    return _real_kafka_backend


# ---------------------------------------------------------------------------
# Test-only accessors (used by test_service.py)
# ---------------------------------------------------------------------------


def get_kafka_backend() -> InMemoryKafkaProducerBackend:
    return _kafka_backend


def get_kafka_consumer() -> ReceptionistKafkaConsumer:
    return _test_consumer


def get_connection_manager() -> ConnectionManager:
    return _connection_manager


def get_hitl_forwarder() -> HITLForwarder:
    return _hitl_forwarder


def get_telegram_backend() -> TelegramDeliveryBackend:
    return _telegram_backend


def get_http_client() -> RecordedHTTPClient:
    return _http_client


def get_openclaw_backend() -> OpenClawDeliveryBackend:
    return _openclaw_backend


def reset_runtime_state() -> None:
    """Reset InMemory state for unit tests."""
    _redis.store.clear()
    _kafka_backend.messages.clear()
    _kafka_backend.ordered_messages.clear()
    _telegram_backend.delivered_messages.clear()
    _openclaw_backend.delivered_messages.clear()
    _http_client.requests.clear()
    _connection_manager.connections.clear()
