from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SVC01_", extra="ignore")

    service_id: str = "SVC-01"
    service_version: str = "1.0.0"
    log_level: str = "INFO"
    svc15_base_url: str = "http://svc-15:8000"
    svc16_base_url: str = "http://svc-16:8000"
    openclaw_base_url: str = Field(
        default="http://host.docker.internal:18791",
        validation_alias=AliasChoices("SVC01_OPENCLAW_BASE_URL", "OPENCLAW_URL"),
    )
    openclaw_reply_path: str = Field(
        default="/api/messages/reply",
        validation_alias=AliasChoices("SVC01_OPENCLAW_REPLY_PATH"),
    )
    telegram_bot_token: str = ""
    telegram_api_base_url: str = "https://api.telegram.org"
    rag_timeout_seconds: float = Field(default=10.0, gt=0)
    hitl_timeout_hours: int = Field(default=1, ge=1)

    # Kafka — read from KAFKA_BOOTSTRAP_SERVERS injected by docker-compose x-common-env
    kafka_bootstrap_servers: str = Field(
        default="localhost:9092",
        validation_alias=AliasChoices("SVC01_KAFKA_BOOTSTRAP_SERVERS", "KAFKA_BOOTSTRAP_SERVERS"),
    )
    kafka_consumer_group_id: str = Field(
        default="svc-01-receptionist",
        validation_alias=AliasChoices("SVC01_KAFKA_CONSUMER_GROUP_ID"),
    )
    kafka_consumer_topics: list[str] = Field(default=["user.input", "notification.out"])
    kafka_auto_offset_reset: str = "earliest"

    # Redis — for real idempotency store
    redis_host: str = Field(
        default="localhost",
        validation_alias=AliasChoices("SVC01_REDIS_HOST", "REDIS_HOST"),
    )
    redis_port: int = Field(
        default=6379,
        validation_alias=AliasChoices("SVC01_REDIS_PORT", "REDIS_PORT"),
    )


settings = Settings()
