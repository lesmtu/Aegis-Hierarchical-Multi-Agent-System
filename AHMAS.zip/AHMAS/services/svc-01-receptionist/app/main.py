from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from starlette.exceptions import HTTPException as StarletteHTTPException

from .config import settings
from .dependencies import get_kafka_consumer_loop, get_real_kafka_backend
from .routers.health import router as health_router
from .routers.openclaw import router as openclaw_router
from .routers.telegram import router as telegram_router
from .routers.websocket import router as websocket_router
from .services.errors import build_error_response, request_id_from
from .services.metrics import REQUEST_COUNT, REQUEST_LATENCY
from .models.common import ErrorCode

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
LOGGER = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Production startup/shutdown lifecycle.

    Startup sequence:
      1. Start real aiokafka producer (connects to Kafka broker)
      2. Start Kafka consumer loop (subscribes to user.input + notification.out)

    Shutdown sequence (reverse order, graceful):
      1. Stop consumer loop (cancel background task, commit pending offsets)
      2. Stop producer (flush in-flight messages, close connection)
    """
    kafka_producer_backend = get_real_kafka_backend()
    consumer_loop = get_kafka_consumer_loop()

    LOGGER.info(
        "SVC-01 starting up — Kafka broker: %s | consumer group: %s | topics: %s",
        settings.kafka_bootstrap_servers,
        settings.kafka_consumer_group_id,
        settings.kafka_consumer_topics,
    )

    kafka_started = False
    try:
        await kafka_producer_backend.start()
        await consumer_loop.start()
        kafka_started = True
        LOGGER.info("SVC-01 fully started — Kafka producer and consumer loop running")
    except Exception as exc:
        LOGGER.critical(
            "SVC-01 failed to start Kafka integration: %s — running in HTTP-only mode (no consumer loop)",
            exc,
            exc_info=True,
        )
        # Do NOT raise — keep the HTTP server up so health/webhook endpoints are available.
        # The consumer loop will not run; operator must investigate Kafka connectivity.

    yield  # Service is running

    LOGGER.info("SVC-01 shutting down")
    if kafka_started:
        await consumer_loop.stop()
        await kafka_producer_backend.stop()
    LOGGER.info("SVC-01 shutdown complete")


app = FastAPI(
    title="Aegis HMAS SVC-01 Receptionist Service",
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)
app.include_router(telegram_router)
app.include_router(openclaw_router)
app.include_router(websocket_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = uuid4()
    started = perf_counter()
    response = None
    try:
        response = await call_next(request)
    finally:
        REQUEST_LATENCY.labels(method=request.method, path=request.url.path).observe(perf_counter() - started)
    if response is not None:
        REQUEST_COUNT.labels(method=request.method, path=request.url.path, status_code=response.status_code).inc()
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return build_error_response(
        status_code=400,
        error_code=ErrorCode.INVALID_PAYLOAD,
        message="Request validation failed",
        request_id=request_id_from(request),
        details={"errors": exc.errors()},
        retryable=False,
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return build_error_response(
        status_code=exc.status_code,
        error_code=ErrorCode.INVALID_PAYLOAD,
        message=exc.detail if isinstance(exc.detail, str) else "HTTP error",
        request_id=request_id_from(request),
        details=None if isinstance(exc.detail, str) else {"detail": exc.detail},
        retryable=False,
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    LOGGER.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return build_error_response(
        status_code=500,
        error_code=ErrorCode.INTERNAL_ERROR,
        message="Internal server error",
        request_id=request_id_from(request),
        details={"reason": str(exc)},
    )
