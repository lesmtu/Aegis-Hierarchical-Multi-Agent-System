"""
Real Kafka consumer loop for SVC-01 Receptionist — production mode.

Subscribes to `user.input` and `notification.out` topics.
Delegates each message to ReceptionistKafkaConsumer.process().
"""
from __future__ import annotations

import asyncio
import json
import logging

from aiokafka import AIOKafkaConsumer, TopicPartition
from aiokafka.errors import KafkaError

logger = logging.getLogger(__name__)

# How long to wait before retrying after a fatal consumer error
_RESTART_DELAY_SECONDS = 5


class ReceptionistConsumerLoop:
    """
    Long-running async task that polls Kafka topics and dispatches messages
    to the application-level ReceptionistKafkaConsumer.process() handler.
    """

    def __init__(
        self,
        *,
        bootstrap_servers: str,
        group_id: str,
        topics: list[str],
        auto_offset_reset: str,
        consumer,  # ReceptionistKafkaConsumer instance
    ) -> None:
        self._bootstrap_servers = bootstrap_servers
        self._group_id = group_id
        self._topics = topics
        self._auto_offset_reset = auto_offset_reset
        self._consumer = consumer
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        """Start the consumer loop as a background asyncio task."""
        self._running = True
        self._task = asyncio.create_task(self._run_with_restart(), name="svc01-kafka-consumer")
        logger.info(
            "ReceptionistConsumerLoop started — topics=%s group=%s brokers=%s",
            self._topics,
            self._group_id,
            self._bootstrap_servers,
        )

    async def stop(self) -> None:
        """Signal the loop to stop and wait for clean shutdown."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        logger.info("ReceptionistConsumerLoop stopped")

    async def _run_with_restart(self) -> None:
        """Restart the consumer loop automatically on transient errors."""
        while self._running:
            try:
                await self._run()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(
                    "Consumer loop crashed: %s. Restarting in %ds",
                    exc,
                    _RESTART_DELAY_SECONDS,
                    exc_info=True,
                )
                if self._running:
                    await asyncio.sleep(_RESTART_DELAY_SECONDS)

    async def _run(self) -> None:
        """Core poll loop — connect, consume, process, commit."""
        kafka_consumer = AIOKafkaConsumer(
            *self._topics,
            bootstrap_servers=self._bootstrap_servers,
            group_id=self._group_id,
            auto_offset_reset=self._auto_offset_reset,
            enable_auto_commit=False,  # manual commit after successful processing
            value_deserializer=lambda raw: json.loads(raw.decode("utf-8")),
            session_timeout_ms=30_000,
            heartbeat_interval_ms=10_000,
            max_poll_interval_ms=300_000,
            max_poll_records=10,
        )

        try:
            await kafka_consumer.start()
            logger.info(
                "AIOKafkaConsumer connected — topics=%s group=%s",
                self._topics,
                self._group_id,
            )
            async for msg in kafka_consumer:
                if not self._running:
                    break
                await self._handle_message(kafka_consumer, msg)
        finally:
            await kafka_consumer.stop()

    async def _handle_message(self, kafka_consumer: AIOKafkaConsumer, msg) -> None:
        topic = msg.topic
        try:
            message_dict = msg.value
            logger.debug(
                "Received message topic=%s partition=%d offset=%d event_id=%s",
                topic,
                msg.partition,
                msg.offset,
                message_dict.get("event_id", "?"),
            )
            await self._consumer.process(topic, message_dict)
        except Exception as exc:
            # Log but do NOT crash the loop. Message stays in DLQ via idempotency failure.
            logger.error(
                "Failed to process message topic=%s offset=%d: %s",
                topic,
                msg.offset,
                exc,
                exc_info=True,
            )
        finally:
            # Always commit offset — even on processing failure.
            # Error handling (idempotency, DLQ) is done inside consumer.process().
            tp = TopicPartition(msg.topic, msg.partition)
            await kafka_consumer.commit({tp: msg.offset + 1})
