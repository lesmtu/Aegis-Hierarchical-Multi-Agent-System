from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


class InMemoryLuaScript:
    def __init__(self, redis_client: "InMemoryRedis"):
        self.redis_client = redis_client

    def __call__(self, *, keys: list[str], args: list[str]) -> int:
        key = keys[0]
        value = args[0]
        if key in self.redis_client.store:
            return 0
        self.redis_client.store[key] = value
        return 1


class InMemoryRedis:
    def __init__(self):
        self.store: dict[str, str] = {}

    def register_script(self, _script: str) -> InMemoryLuaScript:
        return InMemoryLuaScript(self)

    def get(self, key: str) -> str | None:
        return self.store.get(key)

    def set(self, key: str, value: str, xx: bool = False, keepttl: bool = False) -> bool:
        if xx and key not in self.store:
            return False
        self.store[key] = value
        return True

    def delete(self, key: str) -> None:
        self.store.pop(key, None)


@dataclass
class InMemoryKafkaProducerBackend:
    messages: dict[str, list[dict[str, Any]]] = field(default_factory=dict)
    ordered_messages: list[tuple[str, dict[str, Any]]] = field(default_factory=list)

    def send(self, topic: str, payload: dict[str, Any]) -> None:
        self.messages.setdefault(topic, []).append(payload)
        self.ordered_messages.append((topic, payload))


@dataclass
class TelegramDeliveryBackend:
    delivered_messages: list[dict[str, Any]] = field(default_factory=list)

    async def send_message(self, chat_id: str, text: str) -> None:
        self.delivered_messages.append({"chat_id": chat_id, "text": text})


@dataclass
class OpenClawDeliveryBackend:
    delivered_messages: list[dict[str, Any]] = field(default_factory=list)

    async def send_message(
        self,
        *,
        conversation_id: str,
        message_content: str,
        source_channel: str,
        reply_to_message_id: str | None,
        notification: dict[str, Any],
    ) -> None:
        self.delivered_messages.append(
            {
                "conversation_id": conversation_id,
                "message_content": message_content,
                "source_channel": source_channel,
                "reply_to_message_id": reply_to_message_id,
                "notification": notification,
            }
        )


class StubLightweightLLM:
    async def classify(self, raw_input: str, context_chunks: list[str]) -> dict[str, Any]:
        lowered = raw_input.lower()
        intent_type = "query" if "?" in raw_input else "task"
        if lowered.startswith(("clarify", "clarification")):
            intent_type = "clarification"
        elif lowered.startswith(("run", "execute", "do", "create")):
            intent_type = "command"
        is_ambiguous = any(token in lowered for token in ("maybe", "unclear", "ambiguous", "not sure"))
        confidence = 0.42 if is_ambiguous else 0.91
        if len(raw_input.split()) <= 2:
            confidence = min(confidence, 0.55)
        summary = raw_input.strip()
        if context_chunks:
            summary = f"{summary} | context: {context_chunks[0][:120]}"
        return {
            "parsed_intent": summary,
            "intent_type": intent_type,
            "confidence": confidence,
            "is_ambiguous": is_ambiguous or confidence < 0.6,
        }


@dataclass
class RecordedHTTPClient:
    requests: list[dict[str, Any]] = field(default_factory=list)

    async def post(self, url: str, json_body: dict[str, Any]) -> dict[str, Any]:
        self.requests.append(
            {
                "url": url,
                "json": json.loads(json.dumps(json_body)),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )
        return {"accepted": True}
