from __future__ import annotations

import re
from datetime import datetime, timezone
from uuid import UUID

from ..models.common import IntentType, TaskContext, UserInputPayload
from .rag_enricher import RAGEnricher
from .runtime import StubLightweightLLM


class IntentParser:
    def __init__(self, llm_client: StubLightweightLLM | None = None, rag_enricher: RAGEnricher | None = None):
        self.llm = llm_client or StubLightweightLLM()
        self.rag_enricher = rag_enricher or RAGEnricher()

    async def parse_and_build_context(self, user_input: UserInputPayload, task_id: UUID) -> TaskContext:
        rag_context = self.rag_enricher.enrich(
            query=user_input.raw_input,
            session_id=str(user_input.session_id),
            task_id=str(task_id),
        )
        intent_result = await self.llm.classify(user_input.raw_input, rag_context.context_chunks[:10])
        return TaskContext(
            task_id=task_id,
            user_id=user_input.user_id,
            session_id=user_input.session_id,
            channel=user_input.channel,
            raw_input=user_input.raw_input,
            parsed_intent=intent_result["parsed_intent"],
            intent_type=IntentType(intent_result["intent_type"]),
            context_chunks=rag_context.context_chunks[:10],
            rag_source_ids=rag_context.source_ids,
            preliminary_confidence=float(intent_result["confidence"]),
            is_ambiguous=bool(intent_result["is_ambiguous"]),
            pii_detected=self._detect_pii(user_input.raw_input),
            created_at=datetime.now(timezone.utc),
            telegram_chat_id=user_input.telegram_chat_id,
            webui_connection_id=user_input.webui_connection_id,
            openclaw_conversation_id=user_input.openclaw_conversation_id,
            openclaw_message_id=user_input.openclaw_message_id,
            openclaw_source_channel=user_input.openclaw_source_channel,
        )

    def _detect_pii(self, raw_input: str) -> bool:
        email = re.search(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", raw_input, re.I)
        phone = re.search(r"\b(?:\+?\d[\d -]{7,}\d)\b", raw_input)
        return bool(email or phone)
