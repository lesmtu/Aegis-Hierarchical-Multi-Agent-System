from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID

from fastapi.responses import JSONResponse

from ..models.common import APIErrorResponse, ErrorCode, ErrorSchema, ErrorType


ERROR_TYPE_BY_CODE: dict[ErrorCode, ErrorType] = {
    ErrorCode.INVALID_PAYLOAD: ErrorType.VALIDATION,
    ErrorCode.INTERNAL_ERROR: ErrorType.SYSTEM,
    ErrorCode.OPENCLAW_TRANSLATION_FAILED: ErrorType.SYSTEM,
    ErrorCode.NOTIFICATION_DELIVERY_FAILED: ErrorType.SYSTEM,
    ErrorCode.MEMORY_UNAVAILABLE: ErrorType.SYSTEM,
    ErrorCode.IDEMPOTENCY_KEY_DUPLICATE: ErrorType.VALIDATION,
}


def build_error_response(
    *,
    status_code: int,
    error_code: ErrorCode,
    message: str,
    request_id: UUID,
    details: dict | None = None,
    retryable: bool | None = None,
) -> JSONResponse:
    resolved_retryable = retryable if retryable is not None else status_code >= 500
    body = APIErrorResponse(
        error=ErrorSchema(
            error_code=error_code,
            error_type=ERROR_TYPE_BY_CODE.get(error_code, ErrorType.SYSTEM),
            retryable=resolved_retryable,
            message=message,
            details=details,
        ),
        request_id=request_id,
        timestamp=datetime.now(timezone.utc),
    )
    return JSONResponse(status_code=status_code, content=body.model_dump(mode="json"))


def request_id_from(request) -> UUID:
    return request.state.request_id

