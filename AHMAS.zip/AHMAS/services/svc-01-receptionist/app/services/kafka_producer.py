from __future__ import annotations

from shared.events.producer import KafkaEventProducer

from ..openclaw.adapter import OpenClawAdapter


class ReceptionistKafkaProducer:
    def __init__(self, backend, adapter: OpenClawAdapter, service_id: str = "SVC-01"):
        self.backend = backend
        self.adapter = adapter
        self.service_id = service_id
        self.producer = KafkaEventProducer(backend)

    def produce(
        self,
        *,
        topic: str,
        payload: dict,
        correlation_id: str,
        trace_id: str,
        idempotency_key: str | None = None,
    ) -> dict:
        envelope = self.adapter.to_cloud_envelope(
            event_type=topic,
            source_service=self.service_id,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            idempotency_key=idempotency_key,
        )
        return self.producer.send(topic, envelope)

