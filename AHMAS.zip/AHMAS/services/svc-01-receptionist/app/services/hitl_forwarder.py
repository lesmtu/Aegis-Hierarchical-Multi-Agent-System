from __future__ import annotations

from ..models.common import HITLAction, HITLRespondRequest


class HITLForwarder:
    def __init__(self, http_client, svc15_base_url: str):
        self.http_client = http_client
        self.base_url = svc15_base_url.rstrip("/")

    async def forward(
        self,
        *,
        hitl_id: str,
        decision: HITLAction,
        responded_by: str,
        content: str | None = None,
    ) -> dict:
        body = HITLRespondRequest(
            decision=decision,
            modified_output=content if decision == HITLAction.MODIFY else None,
            clarification_text=content if decision == HITLAction.CLARIFY else None,
            responded_by=responded_by,
        )
        return await self.http_client.post(
            f"{self.base_url}/hitl/{hitl_id}/respond",
            json_body=body.model_dump(mode="json", exclude_none=True),
        )

