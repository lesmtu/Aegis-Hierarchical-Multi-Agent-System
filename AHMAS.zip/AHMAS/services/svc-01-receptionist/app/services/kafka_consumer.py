from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID, uuid4

from shared.events.consumer import KafkaEventConsumer
from shared.idempotency.client import IdempotencyClient

from ..config import settings
from ..models.common import (
    HITLAction,
    HITLRequestPayload,
    HITLTriggerReason,
    NotificationOutPayload,
    RiskClassification,
    TaskContext,
    UserInputPayload,
)
from ..openclaw.adapter import OpenClawAdapter
from .intent_parser import IntentParser
from .metrics import KAFKA_MESSAGES
from .notification_router import NotificationRouter


class ReceptionistKafkaConsumer:
    def __init__(
        self,
        *,
        idempotency_client: IdempotencyClient,
        producer,
        intent_parser: IntentParser,
        notification_router: NotificationRouter,
        adapter: OpenClawAdapter,
    ):
        self.idempotency = idempotency_client
        self.producer = producer
        self.intent_parser = intent_parser
        self.notification_router = notification_router
        self.adapter = adapter
        self.consumer = KafkaEventConsumer()

    async def process(self, topic: str, message: dict) -> bool:
        should_process, route_topic, _envelope_payload = self.consumer.consume(message)
        if not should_process:
            KAFKA_MESSAGES.labels(topic=topic, result="schema_rejected").inc()
            return False
        if route_topic:
            KAFKA_MESSAGES.labels(topic=topic, result="rejected").inc()
            return False
        if not self.idempotency.check_and_set(message["idempotency_key"], message["event_id"]):
            KAFKA_MESSAGES.labels(topic=topic, result="duplicate").inc()
            return False
        try:
            if topic == "user.input":
                await self._handle_user_input(message)
            elif topic == "notification.out":
                await self._handle_notification_out(message)
            else:
                raise ValueError(f"Unsupported topic: {topic}")
        except Exception:
            self.idempotency.mark_failed(message["idempotency_key"], message["event_id"])
            KAFKA_MESSAGES.labels(topic=topic, result="failed").inc()
            raise
        self.idempotency.mark_completed(message["idempotency_key"], message["event_id"])
        KAFKA_MESSAGES.labels(topic=topic, result="processed").inc()
        return True

    async def _handle_user_input(self, envelope: dict) -> None:
        user_input = UserInputPayload.model_validate(envelope["payload"])
        task_id = UUID(envelope["correlation_id"])
        task_context = await self.intent_parser.parse_and_build_context(user_input, task_id=task_id)

        if task_context.is_ambiguous:
            hitl_request = HITLRequestPayload(
                hitl_id=uuid4(),
                task_id=task_context.task_id,
                node_id=None,
                user_id=task_context.user_id,
                session_id=task_context.session_id,
                trigger_reason=HITLTriggerReason.AMBIGUOUS_INTENT,
                risk_classification=RiskClassification.MEDIUM,
                context=self._build_hitl_context(task_context),
                current_output=None,
                confidence_score=task_context.preliminary_confidence,
                available_actions=[HITLAction.CLARIFY, HITLAction.APPROVE, HITLAction.REJECT],
                timeout_hours=settings.hitl_timeout_hours,
                created_at=datetime.now(timezone.utc),
            )
            self.producer.produce(
                topic="hitl.request",
                payload=hitl_request.model_dump(mode="json", exclude_none=True),
                correlation_id=str(task_context.task_id),
                trace_id=envelope["trace_id"],
            )

        self.producer.produce(
            topic="task.received",
            payload=TaskContext.model_validate(task_context).model_dump(mode="json", exclude_none=True),
            correlation_id=str(task_context.task_id),
            trace_id=envelope["trace_id"],
        )

    async def _handle_notification_out(self, envelope: dict) -> None:
        self.adapter.from_cloud_envelope(envelope)
        payload = NotificationOutPayload.model_validate(envelope["payload"])
        await self.notification_router.route(payload)

    def _build_hitl_context(self, task_context: TaskContext) -> str:
        return (
            f"Ambiguous intent for task {task_context.task_id}. "
            f"raw_input={task_context.raw_input!r}; "
            f"parsed_intent={task_context.parsed_intent!r}; "
            f"context_chunks={task_context.context_chunks[:3]!r}"
        )
