from __future__ import annotations

from ..models.common import Channel, NotificationOutPayload
from .connection_manager import ConnectionManager


class NotificationRouter:
    def __init__(self, telegram_backend, connection_manager: ConnectionManager, openclaw_backend):
        self.telegram_backend = telegram_backend
        self.connection_manager = connection_manager
        self.openclaw_backend = openclaw_backend

    async def route(self, payload: NotificationOutPayload) -> None:
        if payload.channel == Channel.TELEGRAM:
            await self.telegram_backend.send_message(payload.telegram_chat_id or "", payload.message_content)
            return
        if payload.channel == Channel.OPENCLAW:
            await self.openclaw_backend.send_message(
                conversation_id=payload.openclaw_conversation_id or "",
                message_content=payload.message_content,
                source_channel=payload.openclaw_source_channel or "",
                reply_to_message_id=payload.openclaw_message_id,
                notification=payload.model_dump(mode="json", exclude_none=True),
            )
            return
        await self.connection_manager.send_json(payload.webui_connection_id or "", payload.model_dump(mode="json"))
