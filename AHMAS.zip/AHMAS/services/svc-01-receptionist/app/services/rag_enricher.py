from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from libs.lib02_rag.pipeline import RAGPipeline

from ..config import settings


class RAGEnricher:
    def __init__(self, pipeline: RAGPipeline | None = None):
        self.pipeline = pipeline or RAGPipeline(
            svc16_base_url=settings.svc16_base_url,
            timeout_seconds=settings.rag_timeout_seconds,
        )

    def enrich(self, *, query: str, session_id: str, task_id: str):
        return self.pipeline.retrieve_and_inject(
            query=query,
            session_id=session_id,
            task_id=task_id,
            top_k=5,
        )
