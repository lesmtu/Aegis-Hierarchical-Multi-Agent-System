from __future__ import annotations

import httpx


class OpenClawDeliveryClient:
    def __init__(self, base_url: str, reply_path: str):
        self.base_url = base_url.rstrip("/")
        self.reply_path = reply_path if reply_path.startswith("/") else f"/{reply_path}"
        self.http = httpx.AsyncClient(timeout=10.0)

    async def send_message(
        self,
        *,
        conversation_id: str,
        message_content: str,
        source_channel: str,
        reply_to_message_id: str | None,
        notification: dict,
    ) -> dict:
        response = await self.http.post(
            f"{self.base_url}{self.reply_path}",
            json={
                "conversation_id": conversation_id,
                "source_channel": source_channel,
                "reply_to_message_id": reply_to_message_id,
                "content": message_content,
                "notification": notification,
            },
        )
        response.raise_for_status()
        return response.json()
