from __future__ import annotations

from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        self.connections: dict[str, WebSocket] = {}

    def add(self, connection_id: str, websocket: WebSocket) -> None:
        self.connections[connection_id] = websocket

    def remove(self, connection_id: str) -> None:
        self.connections.pop(connection_id, None)

    async def send_json(self, connection_id: str, payload: dict) -> None:
        websocket = self.connections.get(connection_id)
        if websocket is None:
            raise KeyError(connection_id)
        await websocket.send_json(payload)

