"""
Real Kafka producer and idempotency backends for production use.

Replaces the InMemory stubs used in unit tests.
- AioKafkaProducerBackend: aiokafka-based async producer
- RedisIdempotencyBackend: real Redis-backed idempotency store
"""
from __future__ import annotations

import json
import logging

from aiokafka import AIOKafkaProducer

logger = logging.getLogger(__name__)


class AioKafkaProducerBackend:
    """
    Production Kafka producer backend.

    Matches the interface expected by KafkaEventProducer:
        backend.send(topic: str, payload: dict) -> None
    """

    def __init__(self, bootstrap_servers: str) -> None:
        self._bootstrap_servers = bootstrap_servers
        self._producer: AIOKafkaProducer | None = None

    async def start(self) -> None:
        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            # Durability: wait for leader ack
            acks="all",
            # Retry on transient errors
            max_batch_size=16384,
            linger_ms=5,
        )
        await self._producer.start()
        logger.info("AioKafkaProducerBackend started — brokers: %s", self._bootstrap_servers)

    async def stop(self) -> None:
        if self._producer:
            await self._producer.stop()
            logger.info("AioKafkaProducerBackend stopped")

    def send(self, topic: str, payload: dict) -> None:
        """
        Synchronous-style send called by KafkaEventProducer.send().

        AIOKafkaProducer.send() is a coroutine. We schedule it as a
        fire-and-forget asyncio task on the running event loop.
        """
        import asyncio

        if self._producer is None:
            raise RuntimeError("AioKafkaProducerBackend not started. Call await start() first.")

        key = payload.get("correlation_id") or payload.get("event_id")
        producer = self._producer

        async def _do_send() -> None:
            try:
                await producer.send(topic, value=payload, key=key)
                logger.debug("Sent topic=%s event_id=%s", topic, payload.get("event_id"))
            except Exception as exc:
                logger.error(
                    "Failed to send topic=%s event_id=%s: %s",
                    topic, payload.get("event_id"), exc, exc_info=True,
                )

        asyncio.ensure_future(_do_send())
