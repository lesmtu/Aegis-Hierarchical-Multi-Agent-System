from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# ---------------------------------------------------------------------------
# Override FastAPI dependency injection for unit tests.
# Routers use Depends(get_kafka_producer) and Depends(get_hitl_forwarder).
# In tests we replace them with the InMemory-backed test singletons so that
# no real Kafka connection is attempted.
# ---------------------------------------------------------------------------

from app.dependencies import (  # noqa: E402
    get_hitl_forwarder,
    get_kafka_producer,
    _test_producer,
    _hitl_forwarder,
)
from app.main import app  # noqa: E402

app.dependency_overrides[get_kafka_producer] = lambda: _test_producer
app.dependency_overrides[get_hitl_forwarder] = lambda: _hitl_forwarder
