from __future__ import annotations

from uuid import uuid4

from fastapi.testclient import TestClient

from app.dependencies import (
    get_http_client,
    get_kafka_backend,
    get_kafka_consumer,
    get_openclaw_backend,
    get_telegram_backend,
    reset_runtime_state,
)
from app.main import app


def make_client() -> TestClient:
    reset_runtime_state()
    return TestClient(app)


def test_telegram_webhook_publishes_user_input():
    with make_client() as client:
        response = client.post(
            "/webhook/telegram",
            json={
                "update_id": 1,
                "message": {
                    "message_id": 10,
                    "text": "Plan a deployment",
                    "from": {"id": 123},
                    "chat": {"id": 456},
                },
            },
        )
    assert response.status_code == 200
    body = response.json()
    assert body == {"ok": True}
    messages = get_kafka_backend().messages["user.input"]
    assert len(messages) == 1
    envelope = messages[0]
    assert envelope["event_type"] == "user.input"
    assert envelope["payload"]["channel"] == "telegram"
    assert envelope["payload"]["telegram_chat_id"] == "456"


def test_callback_query_forwards_hitl_response_to_svc15():
    hitl_id = str(uuid4())
    with make_client() as client:
        response = client.post(
            "/webhook/telegram",
            json={
                "update_id": 1,
                "callback_query": {
                    "data": f"hitl:{hitl_id}:approve",
                    "from": {"id": 123},
                },
            },
        )
    assert response.status_code == 200
    requests = get_http_client().requests
    assert requests[0]["url"].endswith(f"/hitl/{hitl_id}/respond")
    assert requests[0]["json"] == {"decision": "approve", "responded_by": "123"}


def test_openclaw_webhook_publishes_user_input():
    session_id = str(uuid4())
    with make_client() as client:
        response = client.post(
            "/webhook/openclaw",
            json={
                "type": "user_message",
                "user_id": "admin-1",
                "session_id": session_id,
                "conversation_id": "conv-1",
                "message_id": "msg-1",
                "source_channel": "telegram",
                "content": "Plan via OpenClaw",
            },
        )
    assert response.status_code == 200
    envelope = get_kafka_backend().messages["user.input"][0]
    assert envelope["payload"]["channel"] == "openclaw"
    assert envelope["payload"]["openclaw_conversation_id"] == "conv-1"
    assert envelope["payload"]["openclaw_source_channel"] == "telegram"


def test_openclaw_hitl_response_forwards_to_svc15():
    session_id = str(uuid4())
    hitl_id = str(uuid4())
    with make_client() as client:
        response = client.post(
            "/webhook/openclaw",
            json={
                "type": "hitl_response",
                "user_id": "admin-1",
                "session_id": session_id,
                "conversation_id": "conv-1",
                "message_id": "msg-1",
                "source_channel": "telegram",
                "content": "please continue",
                "hitl_id": hitl_id,
                "hitl_decision": "clarify",
            },
        )
    assert response.status_code == 200
    requests = get_http_client().requests
    assert requests[0]["url"].endswith(f"/hitl/{hitl_id}/respond")
    assert requests[0]["json"]["clarification_text"] == "please continue"


def test_user_input_consumer_builds_task_context_with_all_required_fields():
    with make_client():
        kafka_backend = get_kafka_backend()
        consumer = get_kafka_consumer()
        session_id = str(uuid4())
        task_id = str(uuid4())
        producer_envelope = {
            "event_id": str(uuid4()),
            "event_type": "user.input",
            "schema_version": "1.0.0",
            "payload_version": "1.0.0",
            "timestamp": "2026-03-30T00:00:00+00:00",
            "source_service": "SVC-01",
            "correlation_id": task_id,
            "trace_id": str(uuid4()),
            "idempotency_key": str(uuid4()),
            "status": "success",
            "payload": {
                "user_id": "user-1",
                "session_id": session_id,
                "channel": "webui",
                "raw_input": "maybe deploy this today",
                "timestamp": "2026-03-30T00:00:00+00:00",
                "webui_connection_id": "conn-1",
            },
            "error": None,
        }
        assert client_run(consumer.process("user.input", producer_envelope)) is True

    produced = kafka_backend.messages
    ordered_topics = [topic for topic, _payload in kafka_backend.ordered_messages]
    assert ordered_topics[-2:] == ["hitl.request", "task.received"]
    assert [message["event_type"] for message in produced["hitl.request"]] == ["hitl.request"]
    assert [message["event_type"] for message in produced["task.received"]] == ["task.received"]
    hitl_envelope = produced["hitl.request"][0]
    task_envelope = produced["task.received"][0]
    assert hitl_envelope["correlation_id"] == task_id
    assert task_envelope["correlation_id"] == task_id
    assert list(task_envelope["payload"]) == [
        "task_id",
        "user_id",
        "session_id",
        "channel",
        "raw_input",
        "parsed_intent",
        "intent_type",
        "context_chunks",
        "rag_source_ids",
        "preliminary_confidence",
        "is_ambiguous",
        "pii_detected",
        "created_at",
        "webui_connection_id",
    ]
    assert task_envelope["payload"]["task_id"] == task_id
    assert len(task_envelope["payload"]["context_chunks"]) <= 10


def test_notification_out_consumer_routes_to_telegram_with_idempotency():
    with make_client():
        consumer = get_kafka_consumer()
        envelope = {
            "event_id": str(uuid4()),
            "event_type": "notification.out",
            "schema_version": "1.0.0",
            "payload_version": "1.0.0",
            "timestamp": "2026-03-30T00:00:00+00:00",
            "source_service": "SVC-14",
            "correlation_id": str(uuid4()),
            "trace_id": str(uuid4()),
            "idempotency_key": str(uuid4()),
            "status": "success",
            "payload": {
                "notification_id": str(uuid4()),
                "task_id": str(uuid4()),
                "user_id": "user-1",
                "session_id": str(uuid4()),
                "channel": "telegram",
                "message_type": "result",
                "message_content": "done",
                "telegram_chat_id": "444",
                "delivery_status": "pending",
                "retry_count": 0,
                "created_at": "2026-03-30T00:00:00+00:00",
            },
            "error": None,
        }
        assert client_run(consumer.process("notification.out", envelope)) is True
        assert client_run(consumer.process("notification.out", envelope)) is False

    delivered = get_telegram_backend().delivered_messages
    assert delivered == [{"chat_id": "444", "text": "done"}]


def test_notification_out_consumer_routes_to_openclaw():
    with make_client():
        consumer = get_kafka_consumer()
        envelope = {
            "event_id": str(uuid4()),
            "event_type": "notification.out",
            "schema_version": "1.0.0",
            "payload_version": "1.0.0",
            "timestamp": "2026-03-30T00:00:00+00:00",
            "source_service": "SVC-14",
            "correlation_id": str(uuid4()),
            "trace_id": str(uuid4()),
            "idempotency_key": str(uuid4()),
            "status": "success",
            "payload": {
                "notification_id": str(uuid4()),
                "task_id": str(uuid4()),
                "user_id": "user-1",
                "session_id": str(uuid4()),
                "channel": "openclaw",
                "message_type": "result",
                "message_content": "done",
                "openclaw_conversation_id": "conv-1",
                "openclaw_message_id": "msg-1",
                "openclaw_source_channel": "telegram",
                "delivery_status": "pending",
                "retry_count": 0,
                "created_at": "2026-03-30T00:00:00+00:00",
            },
            "error": None,
        }
        assert client_run(consumer.process("notification.out", envelope)) is True

    delivered = get_openclaw_backend().delivered_messages
    assert delivered[0]["conversation_id"] == "conv-1"
    assert delivered[0]["reply_to_message_id"] == "msg-1"


def test_websocket_user_message_and_hitl_response_paths():
    session_id = str(uuid4())
    hitl_id = str(uuid4())
    with make_client() as client:
        with client.websocket_connect("/ws/ui") as websocket:
            websocket.send_json({"type": "user_message", "session_id": session_id, "content": "run diagnostics"})
            websocket.send_json(
                {
                    "type": "hitl_response",
                    "session_id": session_id,
                    "content": "more detail",
                    "hitl_id": hitl_id,
                    "hitl_decision": "clarify",
                }
            )
    messages = get_kafka_backend().messages["user.input"]
    assert messages[0]["payload"]["channel"] == "webui"
    requests = get_http_client().requests
    assert requests[0]["url"].endswith(f"/hitl/{hitl_id}/respond")
    assert requests[0]["json"]["clarification_text"] == "more detail"


def test_health_and_metrics_endpoints():
    with make_client() as client:
        health = client.get("/health")
        metrics = client.get("/metrics")
    assert health.status_code == 200
    assert health.json()["service_id"] == "SVC-01"
    assert metrics.status_code == 200
    assert "aegis_receptionist_requests_total" in metrics.text


def client_run(awaitable):
    import asyncio

    return asyncio.run(awaitable)
