from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .config import settings
from .routers.health import router as health_router
from .routers.prompt import router as prompt_router
from .routers.ready import router as ready_router
from .services.errors import build_error_response, request_id_from
from .services.runtime import ServiceContainer

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)


async def _load_embedding_with_retry(app: FastAPI) -> None:
    container = app.state.container
    while True:
        try:
            LOGGER.info("Loading %s model", container.embedding.model_name)
            await container.embedding.load()
            container.startup_state.bge_m3_loaded = True
            LOGGER.info("Embedding model ready")
            return
        except Exception as exc:
            container.startup_state.bge_m3_loaded = False
            LOGGER.warning("Embedding warmup failed: %s", exc)
            await asyncio.sleep(1)


@asynccontextmanager
async def lifespan(app: FastAPI):
    container = ServiceContainer()
    app.state.container = container
    embedding_load_task = asyncio.create_task(_load_embedding_with_retry(app))
    app.state.embedding_load_task = embedding_load_task
    try:
        await asyncio.wait_for(container.reindex.run(trigger="startup"), timeout=float(settings.startup_reindex_timeout_seconds))
    except asyncio.TimeoutError:
        LOGGER.warning("ReindexWorker startup hit 120s timeout")
        asyncio.create_task(container.reindex.complete_background())
    container.startup_state.reindex_worker_complete = True
    container.scheduler.add_job(container.sync.run_once, "interval", hours=settings.prompt_sync_interval_hours, id="external_sync_worker")
    container.scheduler.add_job(container.reindex.run, "interval", hours=settings.reindex_interval_hours, id="reindex_worker", kwargs={"trigger": "scheduled"})
    container.scheduler.start()
    yield
    embedding_load_task.cancel()
    try:
        await embedding_load_task
    except asyncio.CancelledError:
        pass
    container.scheduler.shutdown()


app = FastAPI(
    title="Aegis HMAS SVC-21 Prompt Intelligence Service",
    version=settings.service_version,
    lifespan=lifespan,
    separate_input_output_schemas=False,
)
app.include_router(prompt_router)
app.include_router(ready_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return schema


app.openapi = custom_openapi


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = uuid4()
    started = perf_counter()
    if hasattr(request.app.state, "container"):
        startup_state = request.app.state.container.startup_state
        if request.url.path not in {"/ready", "/health", "/metrics"} and not startup_state.ready:
            payload = build_error_response(
                status_code=503,
                error_code="SERVICE_INITIALIZING",
                message="Service initializing",
                request_id=request.state.request_id,
            )
            payload.headers["Retry-After"] = "10"
            return payload
    response = await call_next(request)
    response.headers.setdefault("X-Process-Time", f"{perf_counter() - started:.6f}")
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return build_error_response(
        status_code=400,
        error_code="INVALID_PAYLOAD",
        message="Request validation failed",
        request_id=request_id_from(request),
        details={"errors": exc.errors()},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return build_error_response(
        status_code=exc.status_code,
        error_code="INVALID_PAYLOAD" if exc.status_code < 500 else "INTERNAL_ERROR",
        message=exc.detail if isinstance(exc.detail, str) else "HTTP error",
        request_id=request_id_from(request),
        details=None if isinstance(exc.detail, str) else {"detail": exc.detail},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    LOGGER.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return build_error_response(
        status_code=500,
        error_code="INTERNAL_ERROR",
        message="Internal server error",
        request_id=request_id_from(request),
        details={"reason": str(exc)},
    )
