from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class APIError(BaseModel):
    error_code: str
    message: str
    details: dict[str, Any] | None = None


class APIErrorResponse(StrictBaseModel):
    error: APIError
    request_id: UUID
    timestamp: datetime


class HealthCheckResponse(StrictBaseModel):
    service_id: str = Field(pattern=r"^SVC-[0-9]{2}$")
    status: HealthStatus
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    dependencies: dict[str, str] | None = None
    timestamp: datetime


def utc_now() -> datetime:
    return datetime.now(timezone.utc)

