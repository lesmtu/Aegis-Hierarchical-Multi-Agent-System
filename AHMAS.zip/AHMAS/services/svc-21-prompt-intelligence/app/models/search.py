from __future__ import annotations

from pydantic import Field

from .common import StrictBaseModel
from .template import PromptTemplateEntry


class PromptSearchRequest(StrictBaseModel):
    query: str = Field(min_length=1)
    required_capability: str = Field(pattern=r"^(research|logic|media|code|tool_builder|validation)$")
    top_k: int = Field(default=3, ge=1, le=10)
    similarity_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    prefer_verified: bool = True


class PromptSearchResponse(StrictBaseModel):
    prompt_templates: list[PromptTemplateEntry]
    best_match_score: float = Field(ge=0.0, le=1.0)
    found_in: str = Field(pattern=r"^(local_vault|external_cache|on_demand_pull|none)$")

