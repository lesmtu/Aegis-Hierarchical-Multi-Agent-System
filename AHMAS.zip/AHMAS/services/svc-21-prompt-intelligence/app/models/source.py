from __future__ import annotations

from pydantic import Field, HttpUrl

from .common import StrictBaseModel


class SourceStatusEntry(StrictBaseModel):
    source_url: HttpUrl
    source_type: str = Field(pattern=r"^(github|url)$")
    last_sync_at: str | None = None
    last_sync_status: str = Field(pattern=r"^(success|failed|never_synced|in_progress)$")
    template_count: int = Field(ge=0)
    sync_interval_hours: int = Field(ge=1)
    next_sync_at: str | None = None


class LocalVaultStats(StrictBaseModel):
    total_templates: int = Field(ge=0)
    by_source: dict[str, int]
    filesystem_healthy: bool
    qdrant_healthy: bool


class PromptSourcesResponse(StrictBaseModel):
    sources: list[SourceStatusEntry]
    local_vault_stats: LocalVaultStats


class UsageUpdateRequest(StrictBaseModel):
    outcome_delta: float
    task_id: str | None = None


class UsageUpdateResponse(StrictBaseModel):
    prompt_id: str
    new_usage_score: float = Field(ge=0.0, le=1.0)

