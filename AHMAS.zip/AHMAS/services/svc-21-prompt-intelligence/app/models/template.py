from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import Field, HttpUrl

from .common import StrictBaseModel


CapabilityType = str
SourceType = str


class PromptTemplateEntry(StrictBaseModel):
    prompt_id: UUID
    description: str = Field(min_length=1)
    template: str = Field(min_length=1)
    capability_type: str = Field(pattern=r"^(research|logic|media|code|tool_builder|validation)$")
    tags: list[str]
    usage_score: float = Field(ge=0.0, le=1.0)
    source: str = Field(pattern=r"^(local_vault|github|url|generated)$")
    source_url: HttpUrl | None = None
    source_repo: str | None = None
    is_agent_template: bool
    agent_spec: dict[str, Any] | None = None
    is_verified: bool
    saved_by: str | None = Field(default=None, pattern=r"^SVC-[0-9]{2}$")
    last_synced_at: str | None = None
    last_used_at: str | None = None
    created_at: str


class PromptSaveRequest(StrictBaseModel):
    description: str = Field(min_length=1)
    template: str = Field(min_length=1)
    capability_type: str = Field(pattern=r"^(research|logic|media|code|tool_builder|validation)$")
    tags: list[str] = Field(default_factory=list)
    source: str = Field(pattern=r"^generated$")
    is_agent_template: bool = False
    agent_spec: dict[str, Any] | None = None
    saved_by: str = Field(pattern=r"^SVC-[0-9]{2}$")
    task_id: UUID | None = None
    is_verified: bool = False


class PromptSaveResponse(StrictBaseModel):
    prompt_id: UUID
    saved_to: str
    indexed: bool
    created_at: str


class PromptSyncResponse(StrictBaseModel):
    synced_count: int = Field(ge=0)
    new_count: int = Field(ge=0)
    updated_count: int = Field(ge=0)
    failed_sources: list[str]
    synced_at: str


class PromptIngestRequest(StrictBaseModel):
    source_type: str = Field(pattern=r"^(github|url)$")
    source_url: HttpUrl
    branch: str = "main"
    template_path: str = "templates/"


class PromptIngestResponse(StrictBaseModel):
    source_url: HttpUrl
    source_type: str = Field(pattern=r"^(github|url)$")
    ingested_count: int = Field(ge=0)
    new_count: int = Field(ge=0)
    updated_count: int = Field(ge=0)
    indexed: bool
    ingested_at: str

