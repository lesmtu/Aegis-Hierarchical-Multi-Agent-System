from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse

from ..models.common import APIError, APIErrorResponse, utc_now


def request_id_from(request: Request):
    return request.state.request_id


def build_error_response(status_code: int, error_code: str, message: str, request_id, details=None) -> JSONResponse:
    payload = APIErrorResponse(
        error=APIError(error_code=error_code, message=message, details=details),
        request_id=request_id,
        timestamp=utc_now(),
    )
    return JSONResponse(status_code=status_code, content=payload.model_dump(mode="json"))

