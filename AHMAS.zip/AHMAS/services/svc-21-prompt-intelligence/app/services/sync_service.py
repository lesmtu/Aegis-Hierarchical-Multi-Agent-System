from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from uuid import UUID, uuid4

import httpx

from ..config import Settings, SyncSource
from ..metrics import prometheus as metrics
from ..models.common import utc_now
from ..models.source import SourceStatusEntry
from ..models.template import PromptIngestRequest, PromptIngestResponse, PromptSyncResponse, PromptTemplateEntry
from .qdrant_service import QdrantService
from .vault_service import VaultService

LOGGER = logging.getLogger(__name__)


@dataclass
class SyncRunResult:
    synced_count: int = 0
    new_count: int = 0
    updated_count: int = 0
    failed_sources: list[str] | None = None

    def __post_init__(self) -> None:
        if self.failed_sources is None:
            self.failed_sources = []


class SyncService:
    def __init__(self, settings: Settings, vault: VaultService, qdrant: QdrantService) -> None:
        self.settings = settings
        self.vault = vault
        self.qdrant = qdrant
        self.running = False
        self.source_status: dict[str, dict[str, object]] = {
            source.url: {
                "source_url": source.url,
                "source_type": source.source_type,
                "last_sync_at": None,
                "last_sync_status": "never_synced",
                "template_count": 0,
                "sync_interval_hours": source.sync_interval_hours,
                "next_sync_at": None,
            }
            for source in settings.sync_sources()
        }
        self.fetch_override: dict[str, list[dict] | Exception] = {}

    async def run_once(self, sources: list[str] | None = None) -> PromptSyncResponse:
        if self.running:
            raise RuntimeError("sync already running")
        self.running = True
        try:
            configured = [source for source in self.settings.sync_sources() if not sources or source.url in sources]
            result = SyncRunResult()
            if not configured:
                return PromptSyncResponse(
                    synced_count=0,
                    new_count=0,
                    updated_count=0,
                    failed_sources=[],
                    synced_at=utc_now().isoformat(),
                )
            tasks = [self._sync_source(source) for source in configured]
            source_results = await asyncio.gather(*tasks, return_exceptions=True)
            for source, source_result in zip(configured, source_results):
                if isinstance(source_result, Exception):
                    LOGGER.error("sync failed for %s", source.url, exc_info=source_result)
                    metrics.sync_failed_total.labels(source_url=source.url, error_type=self._error_type(source_result)).inc()
                    self._mark_source(source, "failed", 0)
                    result.failed_sources.append(source.url)
                    continue
                result.synced_count += source_result["synced_count"]
                result.new_count += source_result["new_count"]
                result.updated_count += source_result["updated_count"]
            return PromptSyncResponse(
                synced_count=result.synced_count,
                new_count=result.new_count,
                updated_count=result.updated_count,
                failed_sources=result.failed_sources,
                synced_at=utc_now().isoformat(),
            )
        finally:
            self.running = False

    async def ingest(self, request: PromptIngestRequest) -> PromptIngestResponse:
        source = SyncSource(source_type=request.source_type, url=str(request.source_url), branch=request.branch, template_path=request.template_path)
        result = await self._sync_source(source)
        return PromptIngestResponse(
            source_url=request.source_url,
            source_type=request.source_type,
            ingested_count=result["synced_count"],
            new_count=result["new_count"],
            updated_count=result["updated_count"],
            indexed=True,
            ingested_at=utc_now().isoformat(),
        )

    async def list_sources(self) -> list[SourceStatusEntry]:
        entries = []
        for source_url, data in self.source_status.items():
            entries.append(SourceStatusEntry(**data))
        return entries

    async def _sync_source(self, source: SyncSource) -> dict[str, int]:
        now = utc_now()
        self._mark_source(source, "in_progress", self.source_status.get(source.url, {}).get("template_count", 0))
        templates = await self._fetch_source(source)
        synced_count = 0
        new_count = 0
        updated_count = 0
        for raw in templates:
            prompt_id = UUID(raw["prompt_id"]) if raw.get("prompt_id") else uuid4()
            existing = await self.qdrant.get(prompt_id)
            entry = PromptTemplateEntry(
                prompt_id=prompt_id,
                description=raw["description"],
                template=raw["template"],
                capability_type=raw["capability_type"],
                tags=raw.get("tags", []),
                usage_score=raw.get("usage_score", 0.5),
                source=source.source_type,
                source_url=source.url,
                source_repo=self._source_repo(source.url) if source.source_type == "github" else None,
                is_agent_template=raw.get("is_agent_template", False),
                agent_spec=raw.get("agent_spec"),
                is_verified=raw.get("is_verified", False),
                saved_by=raw.get("saved_by"),
                last_synced_at=now.isoformat(),
                last_used_at=raw.get("last_used_at"),
                created_at=raw.get("created_at", now.isoformat()),
            )
            await self.qdrant.upsert(entry)
            self.vault.save_template(entry, self.settings.cached_dir)
            synced_count += 1
            if existing is None:
                new_count += 1
                metrics.sync_templates_total.labels(source_type=source.source_type, outcome="new").inc()
            else:
                updated_count += 1
                metrics.sync_templates_total.labels(source_type=source.source_type, outcome="updated").inc()
        metrics.sync_duration.labels(source_type=source.source_type).observe(0)
        metrics.sync_last_success.labels(source_url=source.url).set(now.timestamp())
        self._mark_source(source, "success", synced_count)
        return {"synced_count": synced_count, "new_count": new_count, "updated_count": updated_count}

    async def _fetch_source(self, source: SyncSource) -> list[dict]:
        override = self.fetch_override.get(source.url)
        if isinstance(override, Exception):
            raise override
        if isinstance(override, list):
            return override
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(source.url)
            response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and "templates" in data:
            return data["templates"]
        raise ValueError("parse_error")

    def _mark_source(self, source: SyncSource, status: str, template_count: int) -> None:
        next_sync = utc_now() + timedelta(hours=source.sync_interval_hours)
        self.source_status[source.url] = {
            "source_url": source.url,
            "source_type": source.source_type,
            "last_sync_at": None if status == "in_progress" else utc_now().isoformat(),
            "last_sync_status": status,
            "template_count": template_count,
            "sync_interval_hours": source.sync_interval_hours,
            "next_sync_at": next_sync.isoformat(),
        }

    @staticmethod
    def _error_type(exc: Exception) -> str:
        message = str(exc).lower()
        if "401" in message or "403" in message:
            return "auth_error"
        if "git" in message:
            return "git_error"
        if "parse" in message or "json" in message:
            return "parse_error"
        return "network_timeout"

    @staticmethod
    def _source_repo(url: str) -> str | None:
        if "github.com/" not in url:
            return None
        tail = url.split("github.com/", 1)[1].strip("/")
        return "/".join(tail.split("/")[:2]) if tail else None

