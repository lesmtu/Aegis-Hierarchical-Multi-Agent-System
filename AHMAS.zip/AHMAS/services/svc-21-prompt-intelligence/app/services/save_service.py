from __future__ import annotations

from time import perf_counter
from uuid import uuid4

from ..config import Settings
from ..metrics import prometheus as metrics
from ..models.common import utc_now
from ..models.template import PromptSaveRequest, PromptSaveResponse, PromptTemplateEntry
from .qdrant_service import QdrantService
from .vault_service import VaultService


class SaveService:
    def __init__(self, settings: Settings, vault: VaultService, qdrant: QdrantService) -> None:
        self.settings = settings
        self.vault = vault
        self.qdrant = qdrant

    async def save(self, request: PromptSaveRequest) -> PromptSaveResponse:
        started = perf_counter()
        prompt_id = uuid4()
        created_at = utc_now().isoformat()
        entry = PromptTemplateEntry(
            prompt_id=prompt_id,
            description=request.description,
            template=request.template,
            capability_type=request.capability_type,
            tags=request.tags,
            usage_score=0.5,
            source="generated",
            source_url=None,
            source_repo=None,
            is_agent_template=request.is_agent_template,
            agent_spec=request.agent_spec,
            is_verified=request.is_verified,
            saved_by=request.saved_by,
            last_synced_at=None,
            last_used_at=None,
            created_at=created_at,
        )
        saved_path = self.vault.save_template(entry, self.settings.generated_dir)
        indexed = True
        try:
            await self.qdrant.upsert(entry)
        except Exception:
            indexed = False
        metrics.save_total.labels(caller=request.saved_by, capability_type=request.capability_type, indexed=str(indexed).lower()).inc()
        metrics.save_latency.labels(caller=request.saved_by).observe(perf_counter() - started)
        return PromptSaveResponse(prompt_id=prompt_id, saved_to=str(saved_path), indexed=indexed, created_at=created_at)

