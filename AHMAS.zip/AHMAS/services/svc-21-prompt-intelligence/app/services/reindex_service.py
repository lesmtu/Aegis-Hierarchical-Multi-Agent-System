from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from ..metrics import prometheus as metrics
from ..models.common import utc_now
from ..models.template import PromptTemplateEntry
from .qdrant_service import QdrantService
from .vault_service import VaultService

LOGGER = logging.getLogger(__name__)


class ReindexService:
    def __init__(self, vault: VaultService, qdrant: QdrantService) -> None:
        self.vault = vault
        self.qdrant = qdrant
        self.complete = False

    async def run(self, trigger: str) -> int:
        indexed = 0
        seen = set(self.vault.index_ids())
        for path, entry in self.vault.load_all_templates():
            if str(entry.prompt_id) in seen and await self.qdrant.get(entry.prompt_id) is not None:
                continue
            try:
                await self._upsert_with_retry(entry)
                indexed += 1
                seen.add(str(entry.prompt_id))
            except Exception as exc:
                LOGGER.warning("failed to index %s", path, exc_info=exc)
                continue
        self.vault.update_index(list(seen))
        metrics.reindex_duration.labels(trigger=trigger).observe(0)
        metrics.reindex_indexed_total.labels(trigger=trigger).inc(indexed)
        self.complete = True
        return indexed

    async def complete_background(self) -> None:
        await self.run(trigger="startup")

    async def _upsert_with_retry(self, entry: PromptTemplateEntry) -> None:
        delay = 0.1
        for attempt in range(5):
            try:
                await self.qdrant.rehydrate(entry)
                return
            except Exception:
                if attempt == 4:
                    raise
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60)

