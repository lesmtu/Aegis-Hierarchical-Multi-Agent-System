from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from uuid import UUID

from ..config import Settings
from ..models.template import PromptTemplateEntry


class VaultService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        for path in [settings.prompt_vault_path, settings.generated_dir, settings.cached_dir, settings.curated_dir]:
            path.mkdir(parents=True, exist_ok=True)
        if not settings.index_path.exists():
            self._atomic_write_json(settings.index_path, [])

    def _atomic_write_json(self, path: Path, payload) -> None:
        tmp_path = path.with_name(path.name + ".tmp")
        with tmp_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        os.replace(tmp_path, path)

    def _read_json(self, path: Path, default):
        try:
            with path.open(encoding="utf-8") as handle:
                return json.load(handle)
        except (FileNotFoundError, json.JSONDecodeError):
            return default

    def index_ids(self) -> list[str]:
        return list(self._read_json(self.settings.index_path, []))

    def update_index(self, prompt_ids: list[str]) -> None:
        current = set(self.index_ids())
        current.update(prompt_ids)
        self._atomic_write_json(self.settings.index_path, sorted(current))

    def save_template(self, entry: PromptTemplateEntry, target_dir: Path) -> Path:
        path = target_dir / f"{entry.prompt_id}.json"
        self._atomic_write_json(path, entry.model_dump(mode="json"))
        self.update_index([str(entry.prompt_id)])
        return path

    def load_all_templates(self) -> list[tuple[Path, PromptTemplateEntry]]:
        templates: list[tuple[Path, PromptTemplateEntry]] = []
        for path in sorted(self.settings.prompt_vault_path.rglob("*.json")):
            if path.name == ".index.json":
                continue
            try:
                payload = self._read_json(path, None)
                if payload is None:
                    continue
                templates.append((path, PromptTemplateEntry.model_validate(payload)))
            except Exception:
                continue
        return templates

    def load_template(self, prompt_id: UUID) -> PromptTemplateEntry | None:
        for _, entry in self.load_all_templates():
            if entry.prompt_id == prompt_id:
                return entry
        return None

    def promote_to_local_vault(self, prompt_id: UUID) -> None:
        source_file = None
        for path, entry in self.load_all_templates():
            if entry.prompt_id == prompt_id:
                source_file = path
                break
        if source_file is None:
            return
        target = self.settings.curated_dir / source_file.name
        if source_file != target:
            shutil.copy2(source_file, target)

    def filesystem_healthy(self) -> bool:
        try:
            self.settings.prompt_vault_path.mkdir(parents=True, exist_ok=True)
            self.settings.health_check_file.write_text("ok", encoding="utf-8")
            self.index_ids()
            return True
        except Exception:
            return False

