from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Any
from uuid import UUID

from ..metrics import prometheus as metrics
from ..models.template import PromptTemplateEntry
from ..services.embedding_service import EmbeddingService


@dataclass
class StoredTemplate:
    entry: PromptTemplateEntry
    embedding: list[float]


class QdrantService:
    def __init__(self, embedding_service: EmbeddingService) -> None:
        self.embedding_service = embedding_service
        self.templates: dict[str, StoredTemplate] = {}
        self.available = True

    async def upsert(self, entry: PromptTemplateEntry) -> None:
        embedding = await self.embedding_service.embed(f"{entry.description}\n{entry.template}")
        self.templates[str(entry.prompt_id)] = StoredTemplate(entry=entry, embedding=embedding)
        self._refresh_metrics()

    async def search(self, embedding: list[float], capability_type: str, source_filter: list[str] | None, top_k: int, prefer_verified: bool) -> list[Any]:
        if not self.available:
            raise RuntimeError("qdrant unavailable")
        results = []
        for stored in self.templates.values():
            entry = stored.entry
            if entry.capability_type != capability_type:
                continue
            if source_filter is not None and entry.source not in source_filter:
                continue
            score = self._cosine(embedding, stored.embedding)
            boost = entry.usage_score * 0.05
            if prefer_verified and entry.is_verified:
                boost += 0.01
            results.append(type("SearchHit", (), {"score": min(1.0, score + boost), **entry.model_dump(mode="python")})())
        results.sort(key=lambda item: item.score, reverse=True)
        return results[:top_k]

    async def get(self, prompt_id: UUID) -> PromptTemplateEntry | None:
        stored = self.templates.get(str(prompt_id))
        return stored.entry if stored else None

    async def update_source(self, prompt_id: UUID, source: str) -> None:
        stored = self.templates[str(prompt_id)]
        stored.entry.source = source
        self._refresh_metrics()

    async def increment_usage_score(self, prompt_id: UUID, delta: float) -> float:
        stored = self.templates[str(prompt_id)]
        stored.entry.usage_score = max(0.0, min(1.0, stored.entry.usage_score + delta))
        return stored.entry.usage_score

    async def update_last_used_at(self, prompt_id: UUID, timestamp: str) -> None:
        self.templates[str(prompt_id)].entry.last_used_at = timestamp

    async def set_last_synced_at(self, prompt_id: UUID, timestamp: str) -> None:
        self.templates[str(prompt_id)].entry.last_synced_at = timestamp

    async def health(self) -> bool:
        return self.available

    async def rehydrate(self, entry: PromptTemplateEntry) -> None:
        await self.upsert(entry)

    async def count_by_source(self) -> dict[str, int]:
        counts = {"local_vault": 0, "github": 0, "url": 0, "generated": 0}
        for stored in self.templates.values():
            counts[stored.entry.source] = counts.get(stored.entry.source, 0) + 1
        return counts

    def _refresh_metrics(self) -> None:
        counts = {"local_vault": 0, "github": 0, "url": 0, "generated": 0}
        for stored in self.templates.values():
            counts[stored.entry.source] = counts.get(stored.entry.source, 0) + 1
        for source, count in counts.items():
            metrics.vault_size.labels(source=source).set(count)

    @staticmethod
    def _cosine(left: list[float], right: list[float]) -> float:
        numerator = sum(a * b for a, b in zip(left, right))
        left_norm = sqrt(sum(a * a for a in left))
        right_norm = sqrt(sum(b * b for b in right))
        if left_norm == 0 or right_norm == 0:
            return 0.0
        return numerator / (left_norm * right_norm)

