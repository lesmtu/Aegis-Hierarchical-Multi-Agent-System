from __future__ import annotations

import hashlib

import httpx

from ..config import settings


class EmbeddingService:
    def __init__(self) -> None:
        self.loaded = False
        self.backend = settings.embedding_backend.lower()
        self.model_name = settings.embedding_model_name
        self.base_url = settings.embedding_api_base_url.rstrip("/")
        self.api_path = settings.embedding_api_path if settings.embedding_api_path.startswith("/") else f"/{settings.embedding_api_path}"
        self.api_key = settings.embedding_api_key

    async def load(self) -> None:
        if self.backend == "http":
            await self.embed("warmup")
        self.loaded = True

    async def embed(self, text: str) -> list[float]:
        if self.backend == "http":
            return await self._embed_via_http(text)
        if not self.loaded:
            raise RuntimeError("bge-m3 not loaded")
        values: list[float] = []
        for idx in range(32):
            digest = hashlib.sha256(f"{idx}:{text}".encode("utf-8")).digest()
            values.append(int.from_bytes(digest[:4], "big") / 2**32)
        return values

    async def _embed_via_http(self, text: str) -> list[float]:
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = self._build_request_payload(text)
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}{self.api_path}",
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
        embedding = self._extract_embedding(response.json())
        if not isinstance(embedding, list) or not embedding:
            raise ValueError("Embedding response must contain a non-empty embedding list")
        return [float(value) for value in embedding]

    def _build_request_payload(self, text: str) -> dict[str, str]:
        if self.api_path == "/api/embeddings":
            return {"model": self.model_name, "prompt": text}
        return {"model": self.model_name, "input": text}

    @staticmethod
    def _extract_embedding(body: object) -> list[float]:
        if not isinstance(body, dict):
            raise ValueError("Invalid embedding response payload")
        embedding = body.get("embedding")
        if embedding is None:
            try:
                embedding = body["data"][0]["embedding"]
            except (KeyError, IndexError, TypeError) as exc:
                raise ValueError("Invalid embedding response payload") from exc
        return embedding
