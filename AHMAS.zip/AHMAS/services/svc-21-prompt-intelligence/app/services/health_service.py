from __future__ import annotations

from ..config import Settings
from ..metrics import prometheus as metrics
from ..models.common import HealthCheckResponse, HealthStatus, utc_now
from .embedding_service import EmbeddingService
from .qdrant_service import QdrantService
from .vault_service import VaultService


class HealthService:
    def __init__(self, settings: Settings, vault: VaultService, qdrant: QdrantService, embedding: EmbeddingService) -> None:
        self.settings = settings
        self.vault = vault
        self.qdrant = qdrant
        self.embedding = embedding

    async def health(self) -> HealthCheckResponse:
        fs_ok = self.vault.filesystem_healthy()
        qdrant_ok = await self.qdrant.health()
        metrics.filesystem_healthy.set(1 if fs_ok else 0)
        metrics.qdrant_healthy.set(1 if qdrant_ok else 0)
        if fs_ok and qdrant_ok and self.embedding.loaded:
            status = HealthStatus.HEALTHY
        elif not fs_ok and not qdrant_ok:
            status = HealthStatus.UNHEALTHY
        else:
            status = HealthStatus.DEGRADED
        return HealthCheckResponse(
            service_id=self.settings.service_id,
            status=status,
            version=self.settings.service_version,
            dependencies={
                "qdrant": "healthy" if qdrant_ok else "unhealthy",
                "local_vault_filesystem": "healthy" if fs_ok else "unhealthy",
                "bge_m3_model": "healthy" if self.embedding.loaded else "unhealthy",
            },
            timestamp=utc_now(),
        )

