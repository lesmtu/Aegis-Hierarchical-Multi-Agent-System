from __future__ import annotations

import asyncio
from time import perf_counter

from ..metrics import prometheus as metrics
from ..models.common import utc_now
from ..models.search import PromptSearchRequest, PromptSearchResponse
from ..models.template import PromptTemplateEntry
from ..workers.coalescer import P3PullCoalescer
from .embedding_service import EmbeddingService
from .qdrant_service import QdrantService
from .sync_service import SyncService
from .vault_service import VaultService


class SearchService:
    P3_TIMEOUT_SECONDS = 30

    def __init__(self, qdrant: QdrantService, vault: VaultService, embedding: EmbeddingService, sync: SyncService, coalescer: P3PullCoalescer) -> None:
        self.qdrant = qdrant
        self.vault = vault
        self.embedding = embedding
        self.sync = sync
        self.coalescer = coalescer

    async def search(self, request: PromptSearchRequest) -> PromptSearchResponse:
        started = perf_counter()
        query_embedding = await self.embedding.embed(request.query)

        p1 = await self._safe_search(query_embedding, request.required_capability, ["local_vault"], request.top_k, request.prefer_verified)
        if p1 and p1[0].score >= request.similarity_threshold:
            response = await self._success("local_vault", request, p1)
            metrics.search_latency.labels(found_in="local_vault").observe(perf_counter() - started)
            return response

        p2 = await self._safe_search(query_embedding, request.required_capability, ["github", "url", "generated"], request.top_k, request.prefer_verified)
        if p2 and p2[0].score >= request.similarity_threshold:
            await self.qdrant.update_source(p2[0].prompt_id, "local_vault")
            self.vault.promote_to_local_vault(p2[0].prompt_id)
            response = await self._success("external_cache", request, p2, promoted_from=p2[0].source)
            metrics.search_latency.labels(found_in="external_cache").observe(perf_counter() - started)
            return response

        try:
            await asyncio.wait_for(self.coalescer.run(lambda: self.sync.run_once()), timeout=float(self.P3_TIMEOUT_SECONDS))
            p3 = await self._safe_search(query_embedding, request.required_capability, None, request.top_k, request.prefer_verified)
            if p3 and p3[0].score >= request.similarity_threshold:
                metrics.search_total.labels(found_in="on_demand_pull", capability_type=request.required_capability).inc()
                metrics.search_latency.labels(found_in="on_demand_pull").observe(perf_counter() - started)
                return PromptSearchResponse(
                    prompt_templates=[PromptTemplateEntry.model_validate(hit.__dict__) for hit in p3],
                    best_match_score=p3[0].score,
                    found_in="on_demand_pull",
                )
        except asyncio.TimeoutError:
            metrics.p3_timeout_total.labels(capability_type=request.required_capability).inc()
        except Exception:
            pass

        metrics.search_total.labels(found_in="none", capability_type=request.required_capability).inc()
        metrics.search_latency.labels(found_in="none").observe(perf_counter() - started)
        return PromptSearchResponse(prompt_templates=[], best_match_score=0.0, found_in="none")

    async def _safe_search(self, embedding, capability, sources, top_k, prefer_verified):
        if not await self.qdrant.health():
            return []
        return await self.qdrant.search(embedding=embedding, capability_type=capability, source_filter=sources, top_k=top_k, prefer_verified=prefer_verified)

    async def _success(self, found_in: str, request: PromptSearchRequest, hits, promoted_from: str | None = None) -> PromptSearchResponse:
        await self.qdrant.increment_usage_score(hits[0].prompt_id, 0.01)
        await self.qdrant.update_last_used_at(hits[0].prompt_id, utc_now().isoformat())
        metrics.search_total.labels(found_in=found_in, capability_type=request.required_capability).inc()
        if promoted_from is not None:
            metrics.promotion_total.labels(from_source=promoted_from).inc()
        return PromptSearchResponse(
            prompt_templates=[PromptTemplateEntry.model_validate(hit.__dict__) for hit in hits],
            best_match_score=hits[0].score,
            found_in=found_in,
        )

