from __future__ import annotations

from dataclasses import dataclass

from ..config import settings
from ..services.embedding_service import EmbeddingService
from ..services.health_service import HealthService
from ..services.qdrant_service import QdrantService
from ..services.reindex_service import ReindexService
from ..services.save_service import SaveService
from ..services.search_service import SearchService
from ..services.sync_service import SyncService
from ..services.vault_service import VaultService
from ..workers.coalescer import P3PullCoalescer


@dataclass
class StartupState:
    bge_m3_loaded: bool = False
    reindex_worker_complete: bool = False

    @property
    def ready(self) -> bool:
        return self.bge_m3_loaded and self.reindex_worker_complete


class SchedulerStub:
    def __init__(self) -> None:
        self.jobs: list[dict] = []
        self.started = False

    def add_job(self, func, trigger, **kwargs) -> None:
        self.jobs.append({"func": func, "trigger": trigger, **kwargs})

    def start(self) -> None:
        self.started = True

    def shutdown(self) -> None:
        self.started = False


class ServiceContainer:
    def __init__(self) -> None:
        self.settings = settings
        self.startup_state = StartupState()
        self.scheduler = SchedulerStub()
        self.embedding = EmbeddingService()
        self.vault = VaultService(self.settings)
        self.qdrant = QdrantService(self.embedding)
        self.sync = SyncService(self.settings, self.vault, self.qdrant)
        self.coalescer = P3PullCoalescer()
        self.search = SearchService(self.qdrant, self.vault, self.embedding, self.sync, self.coalescer)
        self.save = SaveService(self.settings, self.vault, self.qdrant)
        self.reindex = ReindexService(self.vault, self.qdrant)
        self.health = HealthService(self.settings, self.vault, self.qdrant, self.embedding)

