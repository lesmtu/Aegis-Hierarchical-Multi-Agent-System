from __future__ import annotations

from starlette.responses import Response

try:
    from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
except ModuleNotFoundError:
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4"

    class _MetricChild:
        def __init__(self, metric, labels):
            self.metric = metric
            self.labels = labels

        def inc(self, amount: float = 1.0) -> None:
            self.metric.values[tuple(sorted(self.labels.items()))] = self.metric.values.get(tuple(sorted(self.labels.items())), 0.0) + amount

        def observe(self, amount: float) -> None:
            self.inc(amount)

        def set(self, amount: float) -> None:
            self.metric.values[tuple(sorted(self.labels.items()))] = amount

    class _Metric:
        def __init__(self, name: str, documentation: str, labelnames=(), buckets=None):
            self.name = name
            self.documentation = documentation
            self.labelnames = tuple(labelnames)
            self.values: dict[tuple[tuple[str, str], ...], float] = {}

        def labels(self, **kwargs):
            return _MetricChild(self, kwargs)

        def inc(self, amount: float = 1.0) -> None:
            self.values[tuple()] = self.values.get(tuple(), 0.0) + amount

        def observe(self, amount: float) -> None:
            self.inc(amount)

        def set(self, amount: float) -> None:
            self.values[tuple()] = amount

    _REGISTRY: list[_Metric] = []

    def Counter(name, documentation, labelnames=()):
        metric = _Metric(name, documentation, labelnames)
        _REGISTRY.append(metric)
        return metric

    def Gauge(name, documentation, labelnames=()):
        metric = _Metric(name, documentation, labelnames)
        _REGISTRY.append(metric)
        return metric

    def Histogram(name, documentation, labelnames=(), buckets=None):
        metric = _Metric(name, documentation, labelnames, buckets=buckets)
        _REGISTRY.append(metric)
        return metric

    def generate_latest() -> bytes:
        lines = []
        for metric in _REGISTRY:
            lines.append(f"# HELP {metric.name} {metric.documentation}")
            lines.append(f"# TYPE {metric.name} untyped")
            if metric.values:
                for labels, value in metric.values.items():
                    if labels:
                        rendered = ",".join(f'{key}="{value_}"' for key, value_ in labels)
                        lines.append(f"{metric.name}{{{rendered}}} {value}")
                    else:
                        lines.append(f"{metric.name} {value}")
            else:
                lines.append(f"{metric.name} 0")
        return ("\n".join(lines) + "\n").encode("utf-8")


search_total = Counter("aegis_prompt_search_total", "Total POST /prompt/search requests completed", ["found_in", "capability_type"])
search_latency = Histogram(
    "aegis_prompt_search_latency_seconds",
    "End-to-end latency of POST /prompt/search",
    ["found_in"],
    buckets=[0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 5.0, 10.0, 30.0, 35.0],
)
save_total = Counter("aegis_prompt_save_total", "Total POST /prompt/save requests successfully processed", ["caller", "capability_type", "indexed"])
save_latency = Histogram(
    "aegis_prompt_save_latency_seconds",
    "End-to-end latency of POST /prompt/save",
    ["caller"],
    buckets=[0.1, 0.25, 0.5, 1.0, 2.0, 5.0],
)
sync_templates_total = Counter("aegis_prompt_sync_templates_total", "Total number of templates processed per sync", ["source_type", "outcome"])
sync_failed_total = Counter("aegis_prompt_sync_failed_total", "Failed sync attempts", ["source_url", "error_type"])
sync_duration = Histogram(
    "aegis_prompt_sync_duration_seconds",
    "Duration of each sync run",
    ["source_type"],
    buckets=[5.0, 15.0, 30.0, 60.0, 120.0, 300.0],
)
sync_last_success = Gauge("aegis_prompt_sync_last_success_timestamp_seconds", "Last successful sync timestamp", ["source_url"])
vault_size = Gauge("aegis_prompt_vault_size", "Current number of templates partitioned by source", ["source"])
reindex_duration = Histogram(
    "aegis_prompt_reindex_duration_seconds",
    "Duration of each ReindexWorker run",
    ["trigger"],
    buckets=[1.0, 5.0, 15.0, 30.0, 60.0, 120.0],
)
reindex_indexed_total = Counter("aegis_prompt_reindex_indexed_total", "Total number of templates indexed by ReindexWorker", ["trigger"])
filesystem_healthy = Gauge("aegis_prompt_filesystem_healthy", "1 if filesystem healthy")
qdrant_healthy = Gauge("aegis_prompt_qdrant_healthy", "1 if qdrant healthy")
p3_timeout_total = Counter("aegis_prompt_p3_timeout_total", "Total number of P3 timeouts", ["capability_type"])
promotion_total = Counter("aegis_prompt_promotion_total", "Total number of promotions to local_vault", ["from_source"])


def metrics_response() -> Response:
    payload = generate_latest()
    if not payload.strip():
        metric_names = [
            search_total.name,
            search_latency.name,
            save_total.name,
            save_latency.name,
            sync_templates_total.name,
            sync_failed_total.name,
            sync_duration.name,
            sync_last_success.name,
            vault_size.name,
            reindex_duration.name,
            reindex_indexed_total.name,
            filesystem_healthy.name,
            qdrant_healthy.name,
            p3_timeout_total.name,
            promotion_total.name,
        ]
        payload = ("\n".join(f"{name} 0" for name in metric_names) + "\n").encode("utf-8")
    return Response(content=payload, media_type=CONTENT_TYPE_LATEST)
