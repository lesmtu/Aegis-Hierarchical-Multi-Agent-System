from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SyncSource:
    source_type: str
    url: str
    branch: str = "main"
    template_path: str = "templates/"
    sync_interval_hours: int = 6


@dataclass
class Settings:
    service_id: str = "SVC-21"
    service_version: str = "1.0.0"
    prompt_vault_path: Path = field(default_factory=lambda: Path(os.getenv("PROMPT_VAULT_PATH", "/data/prompt-vault")))
    embedding_backend: str = os.getenv("SVC21_EMBEDDING_BACKEND", "stub")
    embedding_model_name: str = os.getenv("SVC21_EMBEDDING_MODEL_NAME", "bge-m3:latest")
    embedding_api_base_url: str = os.getenv("SVC21_EMBEDDING_API_BASE_URL", os.getenv("OPENCLAW_URL", "http://host.docker.internal:11434"))
    embedding_api_path: str = os.getenv("SVC21_EMBEDDING_API_PATH", "/api/embeddings")
    embedding_api_key: str = os.getenv("SVC21_EMBEDDING_API_KEY", "")
    qdrant_collection: str = "prompt_templates"
    prompt_sync_interval_hours: int = int(os.getenv("PROMPT_SYNC_INTERVAL_HOURS", "6"))
    reindex_interval_hours: int = 24
    startup_reindex_timeout_seconds: int = 120
    health_check_interval_seconds: int = 30
    sync_sources_config: str = os.getenv("PROMPT_SYNC_SOURCES_CONFIG", "")

    @property
    def generated_dir(self) -> Path:
        return self.prompt_vault_path / "generated"

    @property
    def cached_dir(self) -> Path:
        return self.prompt_vault_path / "cached"

    @property
    def curated_dir(self) -> Path:
        return self.prompt_vault_path / "curated"

    @property
    def index_path(self) -> Path:
        return self.prompt_vault_path / ".index.json"

    @property
    def health_check_file(self) -> Path:
        return self.prompt_vault_path / ".health_check"

    def sync_sources(self) -> list[SyncSource]:
        if not self.sync_sources_config.strip():
            return []
        try:
            raw = json.loads(self.sync_sources_config)
        except json.JSONDecodeError:
            return []
        if isinstance(raw, list):
            return []
        if not isinstance(raw, dict):
            return []
        sources: list[SyncSource] = []
        for item in raw.get("github_repos", []):
            sources.append(
                SyncSource(
                    source_type="github",
                    url=item["url"],
                    branch=item.get("branch", "main"),
                    template_path=item.get("template_path", "templates/"),
                    sync_interval_hours=item.get("sync_interval_hours", self.prompt_sync_interval_hours),
                )
            )
        for item in raw.get("admin_urls", []):
            sources.append(
                SyncSource(
                    source_type="url",
                    url=item["url"],
                    sync_interval_hours=item.get("sync_interval_hours", self.prompt_sync_interval_hours),
                )
            )
        return sources


settings = Settings()
