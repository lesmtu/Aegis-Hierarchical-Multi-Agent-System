from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable


class P3PullCoalescer:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._inflight: asyncio.Task | None = None

    async def run(self, factory: Callable[[], Awaitable[object]]) -> object:
        async with self._lock:
            if self._inflight is None or self._inflight.done():
                self._inflight = asyncio.create_task(factory())
            task = self._inflight
        return await task

