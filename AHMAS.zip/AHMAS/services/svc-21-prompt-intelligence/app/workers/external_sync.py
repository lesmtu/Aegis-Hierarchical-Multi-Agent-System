from ..services.sync_service import SyncService


class ExternalSyncWorker:
    def __init__(self, sync_service: SyncService) -> None:
        self.sync_service = sync_service

    async def run(self):
        return await self.sync_service.run_once()

