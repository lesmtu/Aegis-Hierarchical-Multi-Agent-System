from ..services.reindex_service import ReindexService


class ReindexWorker:
    def __init__(self, reindex_service: ReindexService) -> None:
        self.reindex_service = reindex_service

    async def run(self, trigger: str):
        return await self.reindex_service.run(trigger=trigger)

