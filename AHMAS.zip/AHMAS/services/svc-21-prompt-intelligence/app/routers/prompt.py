from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from ..models.search import PromptSearchRequest, PromptSearchResponse
from ..models.source import PromptSourcesResponse, UsageUpdateRequest, UsageUpdateResponse
from ..models.template import PromptIngestRequest, PromptIngestResponse, PromptSaveRequest, PromptSaveResponse, PromptSyncResponse, PromptTemplateEntry
from ..services.errors import build_error_response, request_id_from
from ..services.runtime import ServiceContainer

router = APIRouter(tags=["prompt"])


def get_container(request: Request) -> ServiceContainer:
    return request.app.state.container


@router.post("/prompt/search", response_model=PromptSearchResponse)
async def search_prompts(request: PromptSearchRequest, container: ServiceContainer = Depends(get_container)) -> PromptSearchResponse:
    health = await container.health.health()
    if health.status.value == "unhealthy":
        raise HTTPException(status_code=503, detail="Both storage backends unavailable")
    return await container.search.search(request)


@router.post("/prompt/save", response_model=PromptSaveResponse, responses={403: {"description": "Forbidden"}})
async def save_prompt(request: PromptSaveRequest, raw_request: Request, container: ServiceContainer = Depends(get_container)):
    if request.saved_by not in ["SVC-11", "SVC-17"]:
        return build_error_response(
            status_code=403,
            error_code="RULE_BLOCKED",
            message=f"POST /prompt/save is only authorized for SVC-11 and SVC-17. Got: {request.saved_by}",
            request_id=request_id_from(raw_request),
        )
    health = await container.health.health()
    if health.dependencies and health.dependencies["qdrant"] == "unhealthy" and health.dependencies["local_vault_filesystem"] == "unhealthy":
        raise HTTPException(status_code=503, detail="Both storage backends unavailable")
    result = await container.save.save(request)
    return JSONResponse(status_code=201 if result.indexed else 202, content=result.model_dump(mode="json"))


@router.post("/prompt/sync", response_model=PromptSyncResponse)
async def sync_prompts(payload: dict | None = None, container: ServiceContainer = Depends(get_container)):
    try:
        sources = (payload or {}).get("sources")
        return await container.sync.run_once(sources=sources)
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/prompt/ingest", response_model=PromptIngestResponse)
async def ingest_prompt(request: PromptIngestRequest, container: ServiceContainer = Depends(get_container)) -> PromptIngestResponse:
    return await container.sync.ingest(request)


@router.get("/prompt/{prompt_id}", response_model=PromptTemplateEntry)
async def get_prompt(prompt_id: UUID, container: ServiceContainer = Depends(get_container)) -> PromptTemplateEntry:
    template = await container.qdrant.get(prompt_id)
    if template is None:
        template = container.vault.load_template(prompt_id)
    if template is None:
        raise HTTPException(status_code=404, detail="Template not found")
    return template


@router.get("/prompt/sources", response_model=PromptSourcesResponse)
async def list_sources(container: ServiceContainer = Depends(get_container)) -> PromptSourcesResponse:
    counts = await container.qdrant.count_by_source()
    fs_ok = container.vault.filesystem_healthy()
    qdrant_ok = await container.qdrant.health()
    return PromptSourcesResponse(
        sources=await container.sync.list_sources(),
        local_vault_stats={
            "total_templates": sum(counts.values()),
            "by_source": counts,
            "filesystem_healthy": fs_ok,
            "qdrant_healthy": qdrant_ok,
        },
    )


@router.patch("/prompt/{prompt_id}/usage", response_model=UsageUpdateResponse)
async def update_usage(prompt_id: UUID, request: UsageUpdateRequest, container: ServiceContainer = Depends(get_container)) -> UsageUpdateResponse:
    existing = await container.qdrant.get(prompt_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Template not found")
    new_score = await container.qdrant.increment_usage_score(prompt_id, request.outcome_delta)
    return UsageUpdateResponse(prompt_id=str(prompt_id), new_usage_score=new_score)
