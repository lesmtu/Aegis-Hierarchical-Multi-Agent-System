from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from ..models.common import utc_now

router = APIRouter(tags=["ready"])


@router.get("/ready")
async def ready(request: Request):
    state = request.app.state.container.startup_state
    payload = {
        "ready": state.ready,
        "startup_conditions": {
            "bge_m3_loaded": state.bge_m3_loaded,
            "reindex_worker_complete": state.reindex_worker_complete,
        },
        "timestamp": utc_now().isoformat(),
    }
    if not state.ready:
        return JSONResponse(status_code=503, headers={"Retry-After": "10"}, content=payload)
    return payload

