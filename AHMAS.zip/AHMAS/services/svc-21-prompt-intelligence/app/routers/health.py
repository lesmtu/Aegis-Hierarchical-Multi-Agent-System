from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response

from ..metrics.prometheus import metrics_response
from ..models.common import HealthCheckResponse, HealthStatus
from ..services.runtime import ServiceContainer

router = APIRouter(tags=["health"])


def get_container(request: Request) -> ServiceContainer:
    return request.app.state.container


@router.get("/health", response_model=HealthCheckResponse, responses={503: {"model": HealthCheckResponse}})
async def health(response: Response, container: ServiceContainer = Depends(get_container)) -> HealthCheckResponse:
    payload = await container.health.health()
    if payload.status == HealthStatus.UNHEALTHY:
        response.status_code = 503
    return payload


@router.get(
    "/metrics",
    response_class=Response,
    responses={200: {"content": {"text/plain; version=0.0.4": {"schema": {"type": "string"}}}}},
)
async def metrics():
    return metrics_response()

