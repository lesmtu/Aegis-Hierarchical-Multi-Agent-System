from __future__ import annotations
from prometheus_client import REGISTRY

import importlib
import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


SERVICE_ROOT = Path("/home/g/AHMAS/services/svc-21-prompt-intelligence")
APP_ROOT = SERVICE_ROOT / "app"
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("PROMPT_VAULT_PATH", str(tmp_path / "prompt-vault"))
    monkeypatch.setenv("PROMPT_SYNC_SOURCES_CONFIG", "[]")
    monkeypatch.setenv("PROMPT_SYNC_INTERVAL_HOURS", "6")
    monkeypatch.setenv("SVC21_EMBEDDING_BACKEND", "stub")
    for name in list(sys.modules):
        if name == "app" or name.startswith("app."):
            sys.modules.pop(name)
            
    # Dọn dẹp Prometheus Registry cũ để tránh lỗi Duplicated timeseries
    collectors = list(REGISTRY._collector_to_names.keys())
    for collector in collectors:
        REGISTRY.unregister(collector)
    # -------------------------
            
    module = importlib.import_module("app.main")
    with TestClient(module.app) as test_client:
        yield test_client
