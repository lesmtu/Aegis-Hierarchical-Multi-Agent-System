from __future__ import annotations

import asyncio
import importlib
import json
import sys
from uuid import uuid4

import httpx
from fastapi.testclient import TestClient
from prometheus_client import REGISTRY

from app.services.search_service import SearchService


def valid_save_payload():
    return {
        "description": "Reusable code generation prompt",
        "template": "Generate Python code for {task}",
        "capability_type": "code",
        "tags": ["python"],
        "source": "generated",
        "saved_by": "SVC-11",
        "is_verified": True,
    }


def test_p3_timeout_hardcoded_30s():
    assert SearchService.P3_TIMEOUT_SECONDS == 30


def test_post_save_403_for_non_svc11_svc17(client):
    response = client.post("/prompt/save", json={**valid_save_payload(), "saved_by": "SVC-03"})
    assert response.status_code == 403


def test_post_save_201_when_indexed(client):
    response = client.post("/prompt/save", json=valid_save_payload())
    assert response.status_code == 201
    assert response.json()["indexed"] is True


def test_post_save_202_when_qdrant_fails(client):
    container = client.app.state.container
    original = container.qdrant.upsert

    async def failing_upsert(entry):
        raise RuntimeError("qdrant failed")

    container.qdrant.upsert = failing_upsert
    try:
        response = client.post("/prompt/save", json=valid_save_payload())
    finally:
        container.qdrant.upsert = original
    assert response.status_code == 202
    assert response.json()["indexed"] is False


def test_ready_returns_503_before_startup(client):
    state = client.app.state.container.startup_state
    state.bge_m3_loaded = False
    state.reindex_worker_complete = False
    response = client.get("/ready")
    assert response.status_code == 503
    assert response.headers["Retry-After"] == "10"
    state.bge_m3_loaded = True
    state.reindex_worker_complete = True


def test_p4_returns_200_not_404(client):
    response = client.post(
        "/prompt/search",
        json={"query": "totally unknown capability", "required_capability": "code", "top_k": 3, "similarity_threshold": 0.999999},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["found_in"] == "none"
    assert body["prompt_templates"] == []
    assert body["best_match_score"] == 0.0


def test_index_json_atomic_update(client):
    response = client.post("/prompt/save", json=valid_save_payload())
    assert response.status_code == 201
    index_path = client.app.state.container.settings.index_path
    tmp_path = index_path.with_name(index_path.name + ".tmp")
    assert index_path.exists()
    assert not tmp_path.exists()
    data = json.loads(index_path.read_text(encoding="utf-8"))
    assert response.json()["prompt_id"] in data


def test_p1_before_p2_before_p3(client):
    container = client.app.state.container
    calls = []
    original_search = container.qdrant.search
    original_run_once = container.sync.run_once

    async def traced_search(**kwargs):
        calls.append(tuple(kwargs["source_filter"]) if kwargs["source_filter"] is not None else None)
        return await original_search(**kwargs)

    async def traced_run_once(sources=None):
        calls.append("p3")
        return await original_run_once(sources=sources)

    container.qdrant.search = traced_search
    container.sync.run_once = traced_run_once
    try:
        client.post(
            "/prompt/search",
            json={"query": "something missing", "required_capability": "code", "top_k": 3, "similarity_threshold": 0.99},
        )
    finally:
        container.qdrant.search = original_search
        container.sync.run_once = original_run_once
    assert calls[0] == ("local_vault",)
    assert calls[1] == ("github", "url", "generated")
    assert calls[2] == "p3"


def test_all_prometheus_metrics_registered(client):
    response = client.get("/metrics")
    assert response.status_code == 200
    required_metrics = [
        "aegis_prompt_search_total",
        "aegis_prompt_search_latency_seconds",
        "aegis_prompt_save_total",
        "aegis_prompt_save_latency_seconds",
        "aegis_prompt_sync_templates_total",
        "aegis_prompt_sync_failed_total",
        "aegis_prompt_sync_duration_seconds",
        "aegis_prompt_sync_last_success_timestamp_seconds",
        "aegis_prompt_vault_size",
        "aegis_prompt_reindex_duration_seconds",
        "aegis_prompt_reindex_indexed_total",
        "aegis_prompt_filesystem_healthy",
        "aegis_prompt_qdrant_healthy",
        "aegis_prompt_p3_timeout_total",
        "aegis_prompt_promotion_total",
    ]
    for metric in required_metrics:
        assert metric in response.text


def test_get_health_503_only_when_both_backends_fail(client):
    container = client.app.state.container
    container.qdrant.available = False
    original_health = container.vault.filesystem_healthy
    container.vault.filesystem_healthy = lambda: True
    response = client.get("/health")
    assert response.status_code == 200
    container.vault.filesystem_healthy = lambda: False
    response = client.get("/health")
    assert response.status_code == 503
    container.vault.filesystem_healthy = original_health
    container.qdrant.available = True


def test_http_embedding_backend_calls_openai_compatible_endpoint(client, monkeypatch):
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["authorization"] = request.headers.get("Authorization")
        return httpx.Response(200, json={"data": [{"embedding": [0.4, 0.5]}]})

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            self.client = httpx.Client(transport=httpx.MockTransport(handler))

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            self.client.close()

        async def post(self, *args, **kwargs):
            return self.client.post(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    embedding = client.app.state.container.embedding
    embedding.backend = "http"
    embedding.base_url = "http://openclaw.local"
    embedding.api_path = "/v1/embeddings"
    embedding.api_key = "secret"

    values = asyncio.run(embedding.embed("hello"))

    assert values == [0.4, 0.5]
    assert captured["url"] == "http://openclaw.local/v1/embeddings"
    assert captured["authorization"] == "Bearer secret"


def test_http_embedding_backend_calls_ollama_embeddings_endpoint(client, monkeypatch):
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["authorization"] = request.headers.get("Authorization")
        captured["json"] = request.read().decode("utf-8")
        return httpx.Response(200, json={"embedding": [0.6, 0.7]})

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            self.client = httpx.Client(transport=httpx.MockTransport(handler))

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            self.client.close()

        async def post(self, *args, **kwargs):
            return self.client.post(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    embedding = client.app.state.container.embedding
    embedding.backend = "http"
    embedding.base_url = "http://ollama.local:11434"
    embedding.api_path = "/api/embeddings"
    embedding.api_key = ""

    values = asyncio.run(embedding.embed("hello"))

    assert values == [0.6, 0.7]
    assert captured["url"] == "http://ollama.local:11434/api/embeddings"
    assert captured["authorization"] is None
    assert '"prompt":"hello"' in captured["json"].replace(" ", "")


def test_startup_survives_embedding_warmup_timeout(monkeypatch):
    from pathlib import Path

    monkeypatch.setenv("PROMPT_VAULT_PATH", str(Path("/tmp") / f"svc21-warmup-{uuid4()}"))
    monkeypatch.setenv("PROMPT_SYNC_SOURCES_CONFIG", "[]")
    monkeypatch.setenv("PROMPT_SYNC_INTERVAL_HOURS", "6")
    monkeypatch.setenv("SVC21_EMBEDDING_BACKEND", "http")
    monkeypatch.setenv("SVC21_EMBEDDING_API_BASE_URL", "http://127.0.0.1:11434")
    monkeypatch.setenv("SVC21_EMBEDDING_API_PATH", "/api/embeddings")
    monkeypatch.setenv("SVC21_EMBEDDING_MODEL_NAME", "bge-m3:latest")
    for name in list(sys.modules):
        if name == "app" or name.startswith("app."):
            sys.modules.pop(name)
    collectors = list(REGISTRY._collector_to_names.keys())
    for collector in collectors:
        REGISTRY.unregister(collector)

    module = importlib.import_module("app.main")
    EmbeddingService = importlib.import_module("app.services.embedding_service").EmbeddingService

    original_load = EmbeddingService.load
    calls = {"count": 0}

    async def flaky_load(self):
        calls["count"] += 1
        if calls["count"] == 1:
            raise httpx.ReadTimeout("warmup timeout")
        self.loaded = True

    monkeypatch.setattr(EmbeddingService, "load", flaky_load)
    try:
        with TestClient(module.app) as test_client:
            ready = test_client.get("/ready")
            assert ready.status_code in {200, 503}
            for _ in range(30):
                ready = test_client.get("/ready")
                if ready.status_code == 200:
                    break
                asyncio.run(asyncio.sleep(0.1))
            assert ready.status_code == 200
            assert calls["count"] >= 2
    finally:
        monkeypatch.setattr(EmbeddingService, "load", original_load)
