import json
import subprocess
import sys
import tempfile

from shared.worker_base.base_worker import BaseWorkerAgent


class CodeAgent(BaseWorkerAgent):
    """
    SVC-08 Worker Agent — Code.
    contracts.json SVC-08.behavior.sandbox_required_for_code_execution=true
    primary_tools: code_executor, linter, test_runner
    """

    AGENT_TYPE = "code"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []

        prompt = f"""Code task: {dispatch_payload['sub_task_description']}

Task context:
{dispatch_payload['input_context']}

Context from memory:
{chr(10).join(rag_ctx.context_chunks)}

Correction guidance: {dispatch_payload.get('correction_guidance', 'None')}

Generate code that solves this task. Include:
1. The complete code
2. Unit tests
3. Usage example"""

        code_response = await self.llm.complete(
            prompt, response_format={"type": "json_object"}
        )
        code_output = json.loads(code_response.text)

        sandbox_result = await self._execute_in_sandbox(code_output.get("code", ""))
        code_output["sandbox_result"] = sandbox_result

        if not sandbox_result["passed"]:
            code_output["sandbox_failure"] = sandbox_result.get("failure_details")

        tools_used.extend(["code_executor", "sandbox"])
        return code_output, tools_used

    async def _execute_in_sandbox(self, code: str) -> dict:
        """Execute code in isolated sandbox environment"""
        try:
            with tempfile.TemporaryDirectory(prefix="svc08-sandbox-") as sandbox_dir:
                result = subprocess.run(
                    [sys.executable, "-I", "-c", code],
                    timeout=30,
                    capture_output=True,
                    text=True,
                    check=False,
                    cwd=sandbox_dir,
                    env={},
                )
                return {
                    "passed": result.returncode == 0,
                    "output": result.stdout,
                    "failure_details": result.stderr if result.returncode != 0 else None,
                }
        except subprocess.TimeoutExpired:
            return {"passed": False, "failure_details": "Execution timeout"}
