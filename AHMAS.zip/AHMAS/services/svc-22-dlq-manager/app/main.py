"""
SVC-22 DLQ Manager — production entry point with Kafka lifespan.
Subscribes to: task.dlq, event.dlq   (contracts.json consumer_groups: svc-22-dlq-processor)
Persists DLQ events to PostgreSQL via DLQService.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.events.error_codes import AegisErrorCode
from shared.kafka_loop import AioKafkaBackend, SimpleConsumerLoop

from app.config import settings
from app.dependencies import (get_dlq_service, get_kafka_consumer,
                               get_kafka_producer, is_runtime_ready,
                               set_runtime_ready)
from app.routers.dlq import router as dlq_router
from app.routers.health import router as health_router
from app.services.errors import DLQConflictError, DLQNotFoundError, DLQUnprocessableError, build_error_response

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
LOGGER = logging.getLogger(__name__)

_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
# contracts.json: consumer_group for both task.dlq and event.dlq is "svc-22-dlq-processor"
_GROUP_ID = "svc-22-dlq-processor"
_TOPICS   = ["task.dlq", "event.dlq"]


def _make_process_fn(dlq_consumer):
    async def process(topic: str, message: dict) -> None:
        # DLQKafkaConsumer.consume() expects the raw envelope dict
        await dlq_consumer.consume(message)
    return process


@asynccontextmanager
async def lifespan(app: FastAPI):
    set_runtime_ready(False)

    backend = AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    # Patch the in-memory producer backend to use real Kafka
    kafka_producer = get_kafka_producer()
    kafka_producer.producer = backend   # replace stub backend with real one

    dlq_consumer = get_kafka_consumer()

    loop = SimpleConsumerLoop(
        bootstrap_servers=_KAFKA_BROKERS,
        group_id=_GROUP_ID,
        topics=_TOPICS,
        process_fn=_make_process_fn(dlq_consumer),
    )
    await loop.start()

    set_runtime_ready(True)
    LOGGER.info("SVC-22 fully started — consuming %s group=%s", _TOPICS, _GROUP_ID)
    yield

    set_runtime_ready(False)
    await loop.stop()
    await backend.stop()
    LOGGER.info("SVC-22 shutdown complete")


app = FastAPI(
    title=settings.service_title,
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)
app.include_router(dlq_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for op in path_item.values():
            op.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.middleware("http")
async def enforce_ready(request: Request, call_next):
    if request.url.path not in {"/health", "/ready", "/metrics"}:
        if not is_runtime_ready():
            resp = build_error_response(503, AegisErrorCode.INTERNAL_ERROR, "Service not ready",
                                        details={"retry_after_seconds": 10})
            resp.headers["Retry-After"] = "10"
            return resp
    return await call_next(request)


@app.exception_handler(RequestValidationError)
async def validation_handler(_req, exc: RequestValidationError):
    return build_error_response(400, AegisErrorCode.INVALID_PAYLOAD, "Validation failed",
                                details={"errors": exc.errors()})


@app.exception_handler(DLQNotFoundError)
async def not_found_handler(_req, exc): return build_error_response(404, AegisErrorCode.INVALID_PAYLOAD, str(exc))

@app.exception_handler(DLQConflictError)
async def conflict_handler(_req, exc): return build_error_response(409, AegisErrorCode.INVALID_PAYLOAD, str(exc))

@app.exception_handler(DLQUnprocessableError)
async def unproc_handler(_req, exc): return build_error_response(422, AegisErrorCode.INVALID_PAYLOAD, str(exc))

@app.exception_handler(Exception)
async def unhandled_handler(_req, exc):
    LOGGER.exception("Unhandled exception")
    return build_error_response(500, AegisErrorCode.INTERNAL_ERROR, "Internal server error",
                                details={"reason": str(exc)})
