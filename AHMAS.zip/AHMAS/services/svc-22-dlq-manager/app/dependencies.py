from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import settings
from app.db.connection import PostgresConnectionManager
from app.db.repository import PostgresDLQRepository
from app.services.alert_service import DLQAlertService
from app.services.dlq_service import DLQService
from app.services.kafka_consumer import DLQKafkaConsumer
from app.services.kafka_producer import DLQKafkaProducer
from app.services.metrics import DLQ_READY
from app.services.runtime import InMemoryDLQRepository, InMemoryProducerBackend

if settings.use_in_memory_repository or not settings.database_url:
    _repository = InMemoryDLQRepository()
else:
    _repository = PostgresDLQRepository(PostgresConnectionManager(settings.database_url))
_producer_backend = InMemoryProducerBackend()
_producer = DLQKafkaProducer(_producer_backend)
_alert_service = DLQAlertService()
_dlq_service = DLQService(_repository, _producer, _alert_service)
_consumer = DLQKafkaConsumer(_dlq_service)
_runtime_ready = True
DLQ_READY.set(1)


def get_repository() -> InMemoryDLQRepository:
    return _repository


def get_kafka_producer() -> DLQKafkaProducer:
    return _producer


def get_alert_service() -> DLQAlertService:
    return _alert_service


def get_dlq_service() -> DLQService:
    return _dlq_service


def get_kafka_consumer() -> DLQKafkaConsumer:
    return _consumer


def is_runtime_ready() -> bool:
    return _runtime_ready


def set_runtime_ready(value: bool) -> None:
    global _runtime_ready
    _runtime_ready = value
    DLQ_READY.set(1 if value else 0)


def reset_runtime_state() -> None:
    if hasattr(_repository, "events"):
        _repository.events.clear()
    if hasattr(_repository, "retry_history"):
        _repository.retry_history.clear()
    if hasattr(_repository, "resolution_log"):
        _repository.resolution_log.clear()
    _producer_backend.messages.clear()
    _producer.produced.clear()
    _alert_service.events.clear()
    _alert_service.alerts.clear()
    set_runtime_ready(True)
