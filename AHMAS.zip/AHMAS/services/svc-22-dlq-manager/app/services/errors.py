from __future__ import annotations

from fastapi.responses import JSONResponse

from shared.events.error_codes import AegisErrorCode, build_error_payload


class DLQNotFoundError(RuntimeError):
    pass


class DLQConflictError(RuntimeError):
    pass


class DLQUnprocessableError(RuntimeError):
    pass


def build_error_response(status_code: int, error_code: AegisErrorCode, message: str, details: dict | None = None) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=build_error_payload(error_code, message, details=details),
    )
