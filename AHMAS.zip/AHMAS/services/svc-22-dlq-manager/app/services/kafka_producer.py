from __future__ import annotations

from copy import deepcopy

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.events.producer import KafkaEventProducer


class DLQKafkaProducer:
    def __init__(self, backend) -> None:
        self.backend = backend
        self.producer = KafkaEventProducer(backend)
        self.produced: list[AegisCanonicalEventEnvelope] = []

    async def republish(self, *, topic: str, envelope: dict) -> dict:
        event = AegisCanonicalEventEnvelope(**deepcopy(envelope))
        payload = self.producer.send(topic, event)
        self.produced.append(event)
        return payload
