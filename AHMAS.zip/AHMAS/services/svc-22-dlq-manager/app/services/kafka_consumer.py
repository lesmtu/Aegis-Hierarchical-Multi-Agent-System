from __future__ import annotations


class DLQKafkaConsumer:
    topics = ("task.dlq", "event.dlq")
    consumer_group = "svc-22-dlq-processor"
    auto_offset_reset = "earliest"

    def __init__(self, dlq_service) -> None:
        self.dlq_service = dlq_service

    async def consume(self, envelope: dict) -> bool:
        return await self.dlq_service.ingest_dlq_event(envelope)
