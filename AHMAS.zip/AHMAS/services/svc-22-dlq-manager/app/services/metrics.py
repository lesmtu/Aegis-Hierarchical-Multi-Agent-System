from __future__ import annotations

try:
    from prometheus_client import CollectorRegistry, Counter, Gauge, generate_latest
except ModuleNotFoundError:
    class _NoopMetric:
        def labels(self, **_kwargs):
            return self

        def inc(self, *_args, **_kwargs):
            return None

        def set(self, *_args, **_kwargs):
            return None

    class CollectorRegistry:  # type: ignore[no-redef]
        pass

    def Counter(*_args, **_kwargs):  # type: ignore[no-redef]
        return _NoopMetric()

    def Gauge(*_args, **_kwargs):  # type: ignore[no-redef]
        return _NoopMetric()

    def generate_latest(_registry):  # type: ignore[no-redef]
        return b""


REGISTRY = CollectorRegistry()
DLQ_EVENTS_RECEIVED_TOTAL = Counter(
    "aegis_dlq_event_received_total",
    "Total DLQ events received by SVC-22",
    ["error_code", "producer_service"],
    registry=REGISTRY,
)
DLQ_ALERT_TOTAL = Counter(
    "aegis_dlq_alert_total",
    "Total DLQ alert triggers",
    ["severity"],
    registry=REGISTRY,
)
DLQ_READY = Gauge(
    "aegis_dlq_ready",
    "SVC-22 readiness state",
    registry=REGISTRY,
)


def render_metrics() -> str:
    return generate_latest(REGISTRY).decode("utf-8")
