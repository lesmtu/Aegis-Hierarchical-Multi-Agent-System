from __future__ import annotations

import logging
from datetime import datetime, timezone
from uuid import UUID

from shared.events.error_codes import AegisErrorCode, ERROR_RETRYABLE

from app.models import DLQEventRecord, DLQListResponse, DLQMetricsResponse, ResolveResponse, RetryRequest, RetryResponse
from app.services.errors import DLQConflictError, DLQNotFoundError, DLQUnprocessableError
from app.services.metrics import DLQ_EVENTS_RECEIVED_TOTAL

LOGGER = logging.getLogger(__name__)


class DLQService:
    def __init__(self, repository, kafka_producer, alert_service) -> None:
        self.repository = repository
        self.kafka_producer = kafka_producer
        self.alert_service = alert_service

    async def ingest_dlq_event(self, envelope: dict) -> bool:
        payload = envelope["payload"]
        error_code = envelope.get("error", {}).get("error_code", "INTERNAL_ERROR")
        now = datetime.now(timezone.utc)
        record = DLQEventRecord(
            dlq_id=payload["dlq_id"],
            origin_topic=envelope["event_type"],
            producer_service=payload["source_service"],
            original_event_id=payload["original_event_id"],
            task_id=envelope.get("correlation_id"),
            error_code=error_code,
            error_details=payload["failure_reason"],
            original_payload=payload["original_payload"],
            retry_count=payload["retry_count"],
            status="pending_retry",
            last_retry_at=None,
            resolved_by=None,
            resolution_notes=None,
            created_at=now,
            updated_at=now,
        )
        inserted = await self.repository.insert_event(record)
        if not inserted:
            LOGGER.warning("duplicate DLQ event suppressed: %s", payload["dlq_id"])
            return False
        DLQ_EVENTS_RECEIVED_TOTAL.labels(error_code=record.error_code, producer_service=record.producer_service).inc()
        await self.alert_service.record_event(error_code=record.error_code, producer_service=record.producer_service)
        return True

    async def list_events(
        self,
        *,
        error_code: str | None,
        service_id: str | None,
        from_timestamp: datetime | None,
        to_timestamp: datetime | None,
        status: str | None,
        page: int,
        page_size: int,
    ) -> DLQListResponse:
        total, events = await self.repository.list_events(
            error_code=error_code,
            service_id=service_id,
            from_timestamp=from_timestamp,
            to_timestamp=to_timestamp,
            status=status,
            page=page,
            page_size=page_size,
        )
        return DLQListResponse(total=total, events=events)

    async def retry_event(self, dlq_id: str, request: RetryRequest) -> RetryResponse:
        record = await self.repository.get_event(dlq_id)
        if record is None:
            raise DLQNotFoundError(dlq_id)
        if record.status == "retried":
            raise DLQConflictError("Event already retried")

        retryable = False
        try:
            retryable = ERROR_RETRYABLE[AegisErrorCode(record.error_code)]
        except Exception:
            retryable = False
        if not retryable:
            raise DLQUnprocessableError(f"Event {dlq_id} is not retryable")

        payload = request.override_payload if request.override_payload is not None else record.original_payload
        envelope = {
            "event_id": str(record.original_event_id),
            "event_type": record.origin_topic,
            "schema_version": "1.0.0",
            "payload_version": "1.0.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_service": "SVC-22",
            "correlation_id": str(record.task_id or UUID(record.dlq_id.hex)),
            "trace_id": str(record.dlq_id),
            "idempotency_key": str(record.dlq_id),
            "status": "error",
            "payload": payload,
            "error": {
                "error_code": record.error_code,
                "error_type": "system",
                "retryable": True,
                "message": record.error_details,
            },
        }
        original_topic = payload.get("original_topic")
        if not original_topic:
            raise DLQUnprocessableError("Missing original_topic for retry")
        await self.kafka_producer.republish(topic=original_topic, envelope=envelope)
        updated = await self.repository.update_for_retry(
            dlq_id=str(record.dlq_id),
            operator_id=request.operator_id,
            retry_justification=request.retry_justification,
            override_payload=request.override_payload,
            republished_to=original_topic,
        )
        return RetryResponse(
            dlq_id=updated.dlq_id,
            status=updated.status,
            republished_to=original_topic,
            retry_count=updated.retry_count,
        )

    async def resolve_event(self, dlq_id: str, *, operator_id: str, resolution_notes: str) -> ResolveResponse:
        record = await self.repository.get_event(dlq_id)
        if record is None:
            raise DLQNotFoundError(dlq_id)
        updated = await self.repository.update_for_resolve(
            dlq_id=str(record.dlq_id),
            operator_id=operator_id,
            resolution_notes=resolution_notes,
        )
        return ResolveResponse(
            dlq_id=updated.dlq_id,
            status=updated.status,
            resolved_by=operator_id,
            resolved_at=updated.updated_at,
        )

    async def metrics(self) -> DLQMetricsResponse:
        return DLQMetricsResponse(**(await self.repository.metrics()))
