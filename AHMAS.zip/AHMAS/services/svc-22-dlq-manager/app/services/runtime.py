from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from uuid import UUID

from app.models import DLQEventRecord


class DuplicateDLQEventError(RuntimeError):
    pass


class InMemoryDLQRepository:
    def __init__(self) -> None:
        self.events: dict[str, DLQEventRecord] = {}
        self.retry_history: list[dict] = []
        self.resolution_log: list[dict] = []

    async def insert_event(self, record: DLQEventRecord) -> bool:
        key = str(record.dlq_id)
        if key in self.events:
            return False
        self.events[key] = record
        return True

    async def get_event(self, dlq_id: str | UUID) -> DLQEventRecord | None:
        record = self.events.get(str(dlq_id))
        return deepcopy(record) if record is not None else None

    async def list_events(
        self,
        *,
        error_code: str | None,
        service_id: str | None,
        from_timestamp: datetime | None,
        to_timestamp: datetime | None,
        status: str | None,
        page: int,
        page_size: int,
    ) -> tuple[int, list[DLQEventRecord]]:
        events = sorted(self.events.values(), key=lambda item: item.created_at, reverse=True)
        filtered: list[DLQEventRecord] = []
        for event in events:
            if error_code is not None and event.error_code != error_code:
                continue
            if service_id is not None and event.producer_service != service_id:
                continue
            if from_timestamp is not None and event.created_at < from_timestamp:
                continue
            if to_timestamp is not None and event.created_at > to_timestamp:
                continue
            if status is not None and event.status != status:
                continue
            filtered.append(deepcopy(event))
        total = len(filtered)
        start = (page - 1) * page_size
        end = start + page_size
        return total, filtered[start:end]

    async def update_for_retry(
        self,
        *,
        dlq_id: str,
        operator_id: str,
        retry_justification: str,
        override_payload: dict | None,
        republished_to: str,
    ) -> DLQEventRecord:
        event = self.events[dlq_id]
        now = datetime.now(timezone.utc)
        updated_payload = deepcopy(override_payload if override_payload is not None else event.original_payload)
        updated = event.model_copy(
            update={
                "original_payload": updated_payload,
                "retry_count": event.retry_count + 1,
                "status": "retried",
                "last_retry_at": now,
                "updated_at": now,
            }
        )
        self.events[dlq_id] = updated
        self.retry_history.append(
            {
                "dlq_id": dlq_id,
                "operator_id": operator_id,
                "retry_justification": retry_justification,
                "override_payload": deepcopy(override_payload),
                "republished_to": republished_to,
                "retried_at": now,
            }
        )
        return deepcopy(updated)

    async def update_for_resolve(self, *, dlq_id: str, operator_id: str, resolution_notes: str) -> DLQEventRecord:
        event = self.events[dlq_id]
        now = datetime.now(timezone.utc)
        updated = event.model_copy(
            update={
                "status": "resolved",
                "resolved_by": operator_id,
                "resolution_notes": resolution_notes,
                "updated_at": now,
            }
        )
        self.events[dlq_id] = updated
        self.resolution_log.append(
            {
                "dlq_id": dlq_id,
                "operator_id": operator_id,
                "resolution_notes": resolution_notes,
                "resolved_at": now,
            }
        )
        return deepcopy(updated)

    async def metrics(self) -> dict:
        now = datetime.now(timezone.utc)
        last_24h = now - timedelta(hours=24)
        last_7d = now - timedelta(days=7)
        by_error_code: dict[str, int] = defaultdict(int)
        by_producer_service: dict[str, int] = defaultdict(int)
        retried = 0
        total_finalized = 0
        for event in self.events.values():
            by_error_code[event.error_code] += 1
            by_producer_service[event.producer_service] += 1
            if event.status in {"retried", "retry_failed"}:
                total_finalized += 1
            if event.status == "retried":
                retried += 1
        return {
            "total_dlq_events_24h": sum(1 for event in self.events.values() if event.created_at >= last_24h),
            "total_dlq_events_7d": sum(1 for event in self.events.values() if event.created_at >= last_7d),
            "by_error_code": dict(by_error_code),
            "by_producer_service": dict(by_producer_service),
            "retry_success_rate": (retried / total_finalized) if total_finalized else 0.0,
        }


class InMemoryProducerBackend:
    def __init__(self) -> None:
        self.messages: list[dict] = []

    def send(self, topic: str, payload: dict) -> None:
        self.messages.append({"topic": topic, "payload": deepcopy(payload)})
