from __future__ import annotations

from collections import deque
from datetime import datetime, timedelta, timezone

from .metrics import DLQ_ALERT_TOTAL


class DLQAlertService:
    def __init__(self, *, threshold: int = 10, window_seconds: int = 60) -> None:
        self.threshold = threshold
        self.window_seconds = window_seconds
        self.events: deque[datetime] = deque()
        self.alerts: list[dict] = []

    async def record_event(self, *, error_code: str, producer_service: str) -> None:
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(seconds=self.window_seconds)
        self.events.append(now)
        while self.events and self.events[0] < cutoff:
            self.events.popleft()
        if len(self.events) >= self.threshold:
            alert = {
                "severity": "critical",
                "error_code": error_code,
                "producer_service": producer_service,
                "triggered_at": now,
            }
            self.alerts.append(alert)
            DLQ_ALERT_TOTAL.labels(severity="critical").inc()
