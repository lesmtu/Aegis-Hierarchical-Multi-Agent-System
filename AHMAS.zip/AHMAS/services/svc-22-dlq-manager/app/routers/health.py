from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Response
from fastapi.responses import PlainTextResponse

from app.config import settings
from app.dependencies import is_runtime_ready
from app.models import HealthResponse
from app.services.metrics import render_metrics

router = APIRouter()


@router.get("/ready", response_model=HealthResponse)
async def ready(response: Response) -> HealthResponse:
    if not is_runtime_ready():
        response.status_code = 503
        response.headers["Retry-After"] = "10"
        status = "unhealthy"
    else:
        status = "healthy"
    return HealthResponse(
        service_id=settings.service_id,
        status=status,
        version=settings.service_version,
        dependencies={"kafka": status, "postgresql": status},
        timestamp=datetime.now(timezone.utc),
    )


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(
        service_id=settings.service_id,
        status="healthy" if is_runtime_ready() else "unhealthy",
        version=settings.service_version,
        dependencies={"kafka": "healthy" if is_runtime_ready() else "unhealthy", "postgresql": "healthy" if is_runtime_ready() else "unhealthy"},
        timestamp=datetime.now(timezone.utc),
    )


@router.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return render_metrics()
