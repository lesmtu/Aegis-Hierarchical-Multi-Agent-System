from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Query

from app.dependencies import get_dlq_service
from app.models import DLQListResponse, DLQMetricsResponse, ResolveRequest, ResolveResponse, RetryRequest, RetryResponse, VALID_STATUSES

router = APIRouter()


@router.get("/dlq/events", response_model=DLQListResponse)
async def list_dlq_events(
    error_code: str | None = None,
    service_id: str | None = None,
    from_timestamp: datetime | None = None,
    to_timestamp: datetime | None = None,
    status: str | None = Query(default=None, pattern="^(pending_manual_review|pending_retry|retried|resolved|retry_failed|abandoned)$"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> DLQListResponse:
    normalized_status = status
    if status == "abandoned":
        normalized_status = None
    return await get_dlq_service().list_events(
        error_code=error_code,
        service_id=service_id,
        from_timestamp=from_timestamp,
        to_timestamp=to_timestamp,
        status=normalized_status,
        page=page,
        page_size=page_size,
    )


@router.post("/dlq/events/{dlq_event_id}/retry", response_model=RetryResponse)
async def retry_dlq_event(dlq_event_id: str, request: RetryRequest) -> RetryResponse:
    return await get_dlq_service().retry_event(dlq_event_id, request)


@router.post("/dlq/events/{dlq_event_id}/resolve", response_model=ResolveResponse)
async def resolve_dlq_event(dlq_event_id: str, request: ResolveRequest) -> ResolveResponse:
    return await get_dlq_service().resolve_event(
        dlq_event_id,
        operator_id=request.operator_id,
        resolution_notes=request.resolution_notes,
    )


@router.get("/dlq/metrics", response_model=DLQMetricsResponse)
async def dlq_metrics() -> DLQMetricsResponse:
    return await get_dlq_service().metrics()
