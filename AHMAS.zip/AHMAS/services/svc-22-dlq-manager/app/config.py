from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    service_id: str = "SVC-22"
    service_title: str = "Aegis HMAS SVC-22 DLQ Manager"
    service_version: str = "1.0.0"
    log_level: str = "INFO"
    database_url: str = ""
    use_in_memory_repository: bool = True

    model_config = SettingsConfigDict(env_prefix="SVC22_", extra="ignore")


settings = Settings()
