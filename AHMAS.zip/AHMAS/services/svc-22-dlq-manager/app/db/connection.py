from __future__ import annotations

from contextlib import asynccontextmanager

try:
    import asyncpg
except ModuleNotFoundError:  # pragma: no cover
    asyncpg = None


class PostgresUnavailableError(RuntimeError):
    pass


class PostgresConnectionManager:
    def __init__(self, database_url: str) -> None:
        self.database_url = database_url
        self.pool = None

    async def initialize(self) -> None:
        if asyncpg is None:
            raise PostgresUnavailableError("asyncpg is not installed")
        if self.pool is None:
            self.pool = await asyncpg.create_pool(self.database_url, min_size=1, max_size=5)

    @asynccontextmanager
    async def acquire(self):
        if self.pool is None:
            await self.initialize()
        async with self.pool.acquire() as connection:
            yield connection
