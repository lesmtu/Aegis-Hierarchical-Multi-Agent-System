from __future__ import annotations

import json
from datetime import datetime
from typing import Any
from uuid import UUID

from app.models import DLQEventRecord


class PostgresDLQRepository:
    def __init__(self, connection_manager) -> None:
        self.connection_manager = connection_manager

    async def insert_event(self, record: DLQEventRecord) -> bool:
        query = """
            INSERT INTO dlq_audit.dlq_events (
                dlq_id,
                origin_topic,
                producer_service,
                original_event_id,
                task_id,
                error_code,
                error_details,
                original_payload,
                retry_count,
                status,
                last_retry_at,
                resolved_by,
                resolution_notes,
                created_at,
                updated_at
            )
            VALUES (
                $1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11,$12,$13,$14,$15
            )
            ON CONFLICT (dlq_id) DO NOTHING
        """
        async with self.connection_manager.acquire() as connection:
            result = await connection.execute(
                query,
                record.dlq_id,
                record.origin_topic,
                record.producer_service,
                record.original_event_id,
                record.task_id,
                record.error_code,
                record.error_details,
                json.dumps(record.original_payload),
                record.retry_count,
                record.status,
                record.last_retry_at,
                record.resolved_by,
                record.resolution_notes,
                record.created_at,
                record.updated_at,
            )
        return result == "INSERT 0 1"

    async def get_event(self, dlq_id: str | UUID) -> DLQEventRecord | None:
        query = "SELECT * FROM dlq_audit.dlq_events WHERE dlq_id = $1"
        async with self.connection_manager.acquire() as connection:
            row = await connection.fetchrow(query, UUID(str(dlq_id)))
        return self._row_to_model(row) if row is not None else None

    async def list_events(
        self,
        *,
        error_code: str | None,
        service_id: str | None,
        from_timestamp: datetime | None,
        to_timestamp: datetime | None,
        status: str | None,
        page: int,
        page_size: int,
    ) -> tuple[int, list[DLQEventRecord]]:
        clauses: list[str] = []
        args: list[Any] = []
        if error_code is not None:
            args.append(error_code)
            clauses.append(f"error_code = ${len(args)}")
        if service_id is not None:
            args.append(service_id)
            clauses.append(f"producer_service = ${len(args)}")
        if from_timestamp is not None:
            args.append(from_timestamp)
            clauses.append(f"created_at >= ${len(args)}")
        if to_timestamp is not None:
            args.append(to_timestamp)
            clauses.append(f"created_at <= ${len(args)}")
        if status is not None:
            args.append(status)
            clauses.append(f"status = ${len(args)}")
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        count_query = f"SELECT COUNT(*) FROM dlq_audit.dlq_events {where_sql}"
        args.extend([page_size, (page - 1) * page_size])
        data_query = f"""
            SELECT * FROM dlq_audit.dlq_events
            {where_sql}
            ORDER BY created_at DESC
            LIMIT ${len(args) - 1}
            OFFSET ${len(args)}
        """
        async with self.connection_manager.acquire() as connection:
            total = await connection.fetchval(count_query, *args[:-2])
            rows = await connection.fetch(data_query, *args)
        return int(total), [self._row_to_model(row) for row in rows]

    async def update_for_retry(
        self,
        *,
        dlq_id: str,
        operator_id: str,
        retry_justification: str,
        override_payload: dict | None,
        republished_to: str,
    ) -> DLQEventRecord:
        async with self.connection_manager.acquire() as connection:
            async with connection.transaction():
                if override_payload is not None:
                    await connection.execute(
                        """
                        UPDATE dlq_audit.dlq_events
                        SET original_payload = $1::jsonb,
                            retry_count = retry_count + 1,
                            status = 'retried',
                            last_retry_at = NOW(),
                            updated_at = NOW()
                        WHERE dlq_id = $2
                        """,
                        json.dumps(override_payload),
                        UUID(dlq_id),
                    )
                else:
                    await connection.execute(
                        """
                        UPDATE dlq_audit.dlq_events
                        SET retry_count = retry_count + 1,
                            status = 'retried',
                            last_retry_at = NOW(),
                            updated_at = NOW()
                        WHERE dlq_id = $1
                        """,
                        UUID(dlq_id),
                    )
                await connection.execute(
                    """
                    INSERT INTO dlq_audit.dlq_retry_history (
                        dlq_id, operator_id, retry_justification, override_payload
                    )
                    VALUES ($1, $2, $3, $4::jsonb)
                    """,
                    UUID(dlq_id),
                    operator_id,
                    retry_justification,
                    json.dumps(override_payload) if override_payload is not None else None,
                )
                row = await connection.fetchrow(
                    "SELECT * FROM dlq_audit.dlq_events WHERE dlq_id = $1",
                    UUID(dlq_id),
                )
        return self._row_to_model(row)

    async def update_for_resolve(self, *, dlq_id: str, operator_id: str, resolution_notes: str) -> DLQEventRecord:
        async with self.connection_manager.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    """
                    UPDATE dlq_audit.dlq_events
                    SET status = 'resolved',
                        resolved_by = $1,
                        resolution_notes = $2,
                        updated_at = NOW()
                    WHERE dlq_id = $3
                    """,
                    operator_id,
                    resolution_notes,
                    UUID(dlq_id),
                )
                await connection.execute(
                    """
                    INSERT INTO dlq_audit.dlq_resolution_log (
                        dlq_id, operator_id, resolution_notes
                    )
                    VALUES ($1, $2, $3)
                    """,
                    UUID(dlq_id),
                    operator_id,
                    resolution_notes,
                )
                row = await connection.fetchrow(
                    "SELECT * FROM dlq_audit.dlq_events WHERE dlq_id = $1",
                    UUID(dlq_id),
                )
        return self._row_to_model(row)

    async def metrics(self) -> dict:
        async with self.connection_manager.acquire() as connection:
            total_24h = await connection.fetchval(
                "SELECT COUNT(*) FROM dlq_audit.dlq_events WHERE created_at >= NOW() - INTERVAL '24 hours'"
            )
            total_7d = await connection.fetchval(
                "SELECT COUNT(*) FROM dlq_audit.dlq_events WHERE created_at >= NOW() - INTERVAL '7 days'"
            )
            error_rows = await connection.fetch(
                "SELECT error_code, COUNT(*) AS count FROM dlq_audit.dlq_events GROUP BY error_code"
            )
            service_rows = await connection.fetch(
                "SELECT producer_service, COUNT(*) AS count FROM dlq_audit.dlq_events GROUP BY producer_service"
            )
            retried = await connection.fetchval(
                "SELECT COUNT(*) FROM dlq_audit.dlq_events WHERE status = 'retried'"
            )
            total_finalized = await connection.fetchval(
                "SELECT COUNT(*) FROM dlq_audit.dlq_events WHERE status IN ('retried', 'retry_failed')"
            )
        return {
            "total_dlq_events_24h": int(total_24h),
            "total_dlq_events_7d": int(total_7d),
            "by_error_code": {row["error_code"]: row["count"] for row in error_rows},
            "by_producer_service": {row["producer_service"]: row["count"] for row in service_rows},
            "retry_success_rate": float(retried / total_finalized) if total_finalized else 0.0,
        }

    @staticmethod
    def _row_to_model(row) -> DLQEventRecord:
        payload = row["original_payload"]
        if isinstance(payload, str):
            payload = json.loads(payload)
        return DLQEventRecord(
            dlq_id=row["dlq_id"],
            origin_topic=row["origin_topic"],
            producer_service=row["producer_service"],
            original_event_id=row["original_event_id"],
            task_id=row["task_id"],
            error_code=row["error_code"],
            error_details=row["error_details"],
            original_payload=payload,
            retry_count=row["retry_count"],
            status=row["status"],
            last_retry_at=row["last_retry_at"],
            resolved_by=row["resolved_by"],
            resolution_notes=row["resolution_notes"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )
