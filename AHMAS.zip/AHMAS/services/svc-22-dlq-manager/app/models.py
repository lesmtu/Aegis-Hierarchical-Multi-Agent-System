from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


VALID_STATUSES = (
    "pending_manual_review",
    "pending_retry",
    "retried",
    "resolved",
    "retry_failed",
)


class DLQEventRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dlq_id: UUID
    origin_topic: str
    producer_service: str
    original_event_id: UUID
    task_id: UUID | None = None
    error_code: str
    error_details: str
    original_payload: dict[str, Any]
    retry_count: int = Field(ge=0)
    status: str
    last_retry_at: datetime | None = None
    resolved_by: str | None = None
    resolution_notes: str | None = None
    created_at: datetime
    updated_at: datetime

    @field_validator("origin_topic")
    @classmethod
    def validate_origin_topic(cls, value: str) -> str:
        if value not in {"task.dlq", "event.dlq"}:
            raise ValueError("origin_topic must be task.dlq or event.dlq")
        return value

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str) -> str:
        if value not in VALID_STATUSES:
            raise ValueError("invalid DLQ status")
        return value


class DLQListResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total: int
    events: list[DLQEventRecord]


class RetryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    operator_id: str
    retry_justification: str = Field(min_length=20)
    override_payload: dict[str, Any] | None = None


class ResolveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    operator_id: str
    resolution_notes: str = Field(min_length=20)


class RetryResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dlq_id: UUID
    status: str
    republished_to: str
    retry_count: int = Field(ge=0)


class ResolveResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dlq_id: UUID
    status: str
    resolved_by: str
    resolved_at: datetime


class DLQMetricsResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total_dlq_events_24h: int
    total_dlq_events_7d: int
    by_error_code: dict[str, int]
    by_producer_service: dict[str, int]
    retry_success_rate: float = Field(ge=0.0, le=1.0)


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    service_id: str
    status: str
    version: str
    dependencies: dict[str, str]
    timestamp: datetime
