from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi.testclient import TestClient

from app.dependencies import get_kafka_consumer, get_kafka_producer, get_repository, reset_runtime_state, set_runtime_ready
from app.main import app


def make_client() -> TestClient:
    return TestClient(app)


def setup_function() -> None:
    reset_runtime_state()


def dlq_envelope(*, topic: str = "task.dlq", error_code: str = "WORKER_TIMEOUT", source_service: str = "SVC-04") -> dict:
    task_id = str(uuid4())
    return {
        "event_id": str(uuid4()),
        "event_type": topic,
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": source_service,
        "correlation_id": task_id,
        "trace_id": str(uuid4()),
        "idempotency_key": str(uuid4()),
        "status": "error",
        "payload": {
            "dlq_id": str(uuid4()),
            "original_topic": "task.received",
            "original_event_id": str(uuid4()),
            "original_payload": {"task_id": task_id, "original_topic": "task.received", "work": "x"},
            "failure_reason": "worker timed out",
            "retry_count": 0,
            "source_service": source_service,
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
        "error": {
            "error_code": error_code,
            "error_type": "timeout",
            "retryable": error_code == "WORKER_TIMEOUT",
            "message": "worker timed out",
        },
    }


def run(coro):
    import asyncio

    return asyncio.run(coro)


def test_consume_persists_event_with_pending_retry_status():
    envelope = dlq_envelope(topic="task.dlq")
    run(get_kafka_consumer().consume(envelope))
    record = run(get_repository().get_event(envelope["payload"]["dlq_id"]))
    assert record is not None
    assert record.origin_topic == "task.dlq"
    assert record.status == "pending_retry"


def test_duplicate_consume_is_idempotent():
    envelope = dlq_envelope()
    run(get_kafka_consumer().consume(envelope))
    run(get_kafka_consumer().consume(envelope))
    total, events = run(get_repository().list_events(
        error_code=None,
        service_id=None,
        from_timestamp=None,
        to_timestamp=None,
        status=None,
        page=1,
        page_size=50,
    ))
    assert total == 1
    assert len(events) == 1


def test_list_endpoint_filters_by_status():
    retriable = dlq_envelope(error_code="WORKER_TIMEOUT")
    non_retryable = dlq_envelope(error_code="HITL_TIMEOUT_EXCEEDED", source_service="SVC-15")
    run(get_kafka_consumer().consume(retriable))
    run(get_kafka_consumer().consume(non_retryable))
    with make_client() as client:
        response = client.get("/dlq/events", params={"status": "pending_retry"})
    assert response.status_code == 200
    assert response.json()["total"] == 2


def test_retry_republishes_retryable_event_to_original_topic():
    envelope = dlq_envelope(error_code="WORKER_TIMEOUT")
    run(get_kafka_consumer().consume(envelope))
    with make_client() as client:
        response = client.post(
            f"/dlq/events/{envelope['payload']['dlq_id']}/retry",
            json={
                "operator_id": "op-1",
                "retry_justification": "Retrying after confirming the downstream dependency is healthy.",
            },
        )
    assert response.status_code == 200
    assert response.json()["status"] == "retried"
    assert get_kafka_producer().backend.messages[0]["topic"] == "task.received"


def test_retry_rejects_non_retryable_event_without_republish():
    envelope = dlq_envelope(error_code="HITL_TIMEOUT_EXCEEDED", source_service="SVC-15")
    run(get_kafka_consumer().consume(envelope))
    with make_client() as client:
        response = client.post(
            f"/dlq/events/{envelope['payload']['dlq_id']}/retry",
            json={
                "operator_id": "op-2",
                "retry_justification": "This justification is long enough but the error is not retryable.",
            },
        )
    assert response.status_code == 422
    assert get_kafka_producer().backend.messages == []


def test_resolve_updates_status_and_audit_log():
    envelope = dlq_envelope(error_code="HITL_TIMEOUT_EXCEEDED", source_service="SVC-15")
    run(get_kafka_consumer().consume(envelope))
    with make_client() as client:
        response = client.post(
            f"/dlq/events/{envelope['payload']['dlq_id']}/resolve",
            json={
                "operator_id": "op-3",
                "resolution_notes": "Manual review completed and no retry action is required here.",
            },
        )
    assert response.status_code == 200
    record = run(get_repository().get_event(envelope["payload"]["dlq_id"]))
    assert record is not None
    assert record.status == "resolved"
    assert record.resolved_by == "op-3"


def test_metrics_aggregate_error_code_and_service_counts():
    first = dlq_envelope(error_code="WORKER_TIMEOUT", source_service="SVC-04")
    second = dlq_envelope(error_code="HITL_TIMEOUT_EXCEEDED", source_service="SVC-15")
    run(get_kafka_consumer().consume(first))
    run(get_kafka_consumer().consume(second))
    with make_client() as client:
        response = client.get("/dlq/metrics")
    assert response.status_code == 200
    body = response.json()
    assert body["total_dlq_events_24h"] == 2
    assert body["by_error_code"]["WORKER_TIMEOUT"] == 1
    assert body["by_producer_service"]["SVC-15"] == 1


def test_ready_returns_503_when_runtime_not_ready():
    set_runtime_ready(False)
    with make_client() as client:
        ready = client.get("/ready")
        blocked = client.get("/dlq/events")
    assert ready.status_code == 503
    assert blocked.status_code == 503
    assert blocked.headers["Retry-After"] == "10"


def test_alert_threshold_triggers_after_ten_events_in_sixty_seconds():
    consumer = get_kafka_consumer()
    for _ in range(10):
        run(consumer.consume(dlq_envelope()))
    from app.dependencies import get_alert_service

    assert len(get_alert_service().alerts) >= 1
