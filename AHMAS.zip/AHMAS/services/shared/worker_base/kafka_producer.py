from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.events.producer import KafkaEventProducer

from .contract_validation import validator_for


TOPIC_TO_SCHEMA = {
    "task.result": validator_for("TaskResultPayload"),
    "task.confidence": validator_for("TaskConfidencePayload"),
}


class WorkerKafkaProducer:
    """task.result + task.confidence co-emission"""

    def __init__(self, producer):
        self.producer = KafkaEventProducer(producer)

    async def produce_envelope(
        self,
        topic: str,
        payload: dict,
        source_service: str,
        correlation_id: str,
        trace_id: str,
        idempotency_key: str | None = None,
    ):
        TOPIC_TO_SCHEMA[topic].validate(payload)
        envelope = AegisCanonicalEventEnvelope.create(
            event_type=topic,
            source_service=source_service,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            idempotency_key=idempotency_key,
        )
        self.producer.send(topic, envelope)
        return envelope

    async def produce_coemitted(
        self,
        events: list[dict],
        source_service: str,
        correlation_id: str,
        trace_id: str,
        idempotency_key: str | None = None,
    ):
        envelopes = []
        for event in events:
            TOPIC_TO_SCHEMA[event["topic"]].validate(event["payload"])
            envelope = AegisCanonicalEventEnvelope.create(
                event_type=event["topic"],
                source_service=source_service,
                payload=event["payload"],
                correlation_id=correlation_id,
                trace_id=trace_id,
                idempotency_key=idempotency_key,
            )
            envelopes.append((event["topic"], envelope))
        for topic, envelope in envelopes:
            self.producer.send(topic, envelope)
        return [envelope for _, envelope in envelopes]
