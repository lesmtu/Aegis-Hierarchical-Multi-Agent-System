import json
from functools import lru_cache
from pathlib import Path

from jsonschema import Draft7Validator, RefResolver


CONTRACTS_PATH = Path(__file__).resolve().parents[3] / "contracts.json"


@lru_cache(maxsize=1)
def _contracts() -> dict:
    with CONTRACTS_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


@lru_cache(maxsize=None)
def validator_for(schema_name: str) -> Draft7Validator:
    contracts = _contracts()
    schema = contracts["global"]["shared_schemas"][schema_name]
    resolver = RefResolver.from_schema(contracts)
    return Draft7Validator(schema, resolver=resolver)
