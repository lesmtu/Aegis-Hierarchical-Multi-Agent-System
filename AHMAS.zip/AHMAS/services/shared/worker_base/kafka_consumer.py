class WorkerKafkaConsumer:
    """task.dispatched consumer with agent_type filter"""

    def __init__(self, agent):
        self.agent = agent

    async def handle(self, envelope) -> None:
        await self.agent.process_dispatched_task(envelope)
