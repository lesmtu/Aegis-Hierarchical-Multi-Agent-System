"""
Base Worker Agent — shared architecture for SVC-05 through SVC-10.
All workers share identical Kafka consumer, reflection, RAG, memory store patterns.
"""
import json
import logging
from datetime import datetime, timezone
from typing import Any

from libs.lib01_reflection import ReflectionEngine, ReflectionResult
from libs.lib02_rag import RAGContext, RAGPipeline
from libs.lib03_tool import ToolInterface
from shared.idempotency import IdempotencyClient

from .contract_validation import validator_for

logger = logging.getLogger(__name__)

REFLECTION_THRESHOLD = 0.75  # contracts.json SVC-05..10 behavior.reflection_threshold
MAX_INTERNAL_RETRIES = 2  # contracts.json SVC-05..10 behavior.max_internal_retries
TASK_DISPATCHED_VALIDATOR = validator_for("TaskDispatchedPayload")


class BaseWorkerAgent:
    """
    Base class for all 6 worker agents (SVC-05 through SVC-10).

    Subclasses MUST implement:
    - AGENT_TYPE: str (research|logic|media|code|tool_builder|validation)
    - execute_task(dispatch_payload, rag_context) → str/dict output
    """

    AGENT_TYPE: str | None = None

    def __init__(
        self,
        llm_client,
        rag_pipeline: RAGPipeline,
        reflection_engine: ReflectionEngine,
        tool_interface: ToolInterface,
        memory_client,
        producer,
        idempotency: IdempotencyClient,
        service_id: str,
    ):
        assert self.AGENT_TYPE is not None, "Subclass must set AGENT_TYPE"
        self.llm = llm_client
        self.rag = rag_pipeline
        self.reflection = reflection_engine
        self.tools = tool_interface
        self.memory = memory_client
        self.producer = producer
        self.idempotency = idempotency
        self.service_id = service_id

    async def process_dispatched_task(self, envelope) -> None:
        """
        Main processing loop for task.dispatched messages.

        Protocol:
        1. Filter by agent_type (only process if matches AGENT_TYPE)
        2. Check idempotency_key
        3. RAG retrieval (LIB-02)
        4. Execute task
        5. Reflection Engine (LIB-01) — max 2 internal retries
        6. Co-emit task.result + task.confidence
        7. Store in episodic memory (SVC-16)
        """
        if envelope.event_type != "task.dispatched":
            return

        payload = envelope.payload
        TASK_DISPATCHED_VALIDATOR.validate(payload)

        if payload["agent_type"] != self.AGENT_TYPE:
            return

        idempotency_key = payload["idempotency_key"]
        if not self.idempotency.check_and_set(idempotency_key, envelope.event_id):
            logger.info("%s: Duplicate task %s, skipping", self.service_id, idempotency_key)
            return

        task_id = payload["task_id"]
        node_id = payload["node_id"]
        agent_id = payload["agent_id"]
        start_time = datetime.now(timezone.utc)

        try:
            rag_query = self._build_rag_query(payload)
            rag_ctx: RAGContext = self.rag.retrieve_and_inject(
                query=rag_query,
                session_id=envelope.correlation_id,
                task_id=task_id,
                top_k=5,
            )
            degraded_mode = bool(rag_ctx.degraded_mode)

            output = None
            confidence = 0.0
            reflection_log: list[str] = []
            needs_review = False
            tools_used: list[str] = []
            correction_guidance = payload.get("correction_guidance")

            for attempt in range(MAX_INTERNAL_RETRIES + 1):
                execution_payload = dict(payload)
                execution_payload["correction_guidance"] = correction_guidance
                output, tools_used = await self.execute_task(execution_payload, rag_ctx)
                reflection: ReflectionResult = self.reflection.evaluate(
                    task_description=payload["sub_task_description"],
                    output=str(output),
                    context={
                        "rag_chunks": rag_ctx.context_chunks,
                        "attempt": attempt,
                        "input_context": payload["input_context"],
                        "correction_guidance": correction_guidance,
                    },
                )

                confidence = reflection.confidence_score
                reflection_log.append(
                    f"Attempt {attempt}: confidence={confidence:.3f}, "
                    f"gaps={reflection.identified_gaps}"
                )

                if confidence >= REFLECTION_THRESHOLD:
                    break

                if attempt == MAX_INTERNAL_RETRIES:
                    needs_review = True
                    reflection_log.append("Max retries reached. Marking needs_review=True")
                    break

                correction_guidance = self._merge_correction_guidance(
                    correction_guidance,
                    reflection.correction_suggestions,
                )
                reflection_log.append(
                    f"Retrying with correction guidance: {correction_guidance}"
                )

            end_time = datetime.now(timezone.utc)
            latency_ms = int((end_time - start_time).total_seconds() * 1000)
            model_used = self._get_model_name()
            created_at = datetime.now(timezone.utc).isoformat()

            result_payload = {
                "task_id": task_id,
                "node_id": node_id,
                "dag_id": payload["dag_id"],
                "agent_id": agent_id,
                "agent_type": self.AGENT_TYPE,
                "input": payload["sub_task_description"],
                "output": output,
                "confidence": confidence,
                "needs_review": needs_review,
                "degraded_mode": degraded_mode,
                "tools_used": tools_used,
                "rag_sources": rag_ctx.source_ids,
                "reflection_log": reflection_log,
                "metadata": {
                    "cost_usd": self._estimate_cost(latency_ms),
                    "latency_ms": latency_ms,
                    "tokens_used": self._count_tokens(str(output)),
                    "model_used": model_used,
                },
                "created_at": created_at,
            }

            confidence_payload = {
                "task_id": task_id,
                "node_id": node_id,
                "dag_id": payload["dag_id"],
                "agent_type": self.AGENT_TYPE,
                "confidence": confidence,
                "needs_review": needs_review,
                "model_used": model_used,
                "created_at": created_at,
            }

            await self.producer.produce_coemitted(
                events=[
                    {"topic": "task.result", "payload": result_payload},
                    {"topic": "task.confidence", "payload": confidence_payload},
                ],
                source_service=self.service_id,
                correlation_id=envelope.correlation_id,
                trace_id=envelope.trace_id,
                idempotency_key=idempotency_key,
            )

            await self._store_in_memory(result_payload, task_id)
            self.idempotency.mark_completed(idempotency_key, envelope.event_id)
        except Exception:
            self.idempotency.mark_failed(idempotency_key, envelope.event_id)
            logger.exception("%s: Task processing failed", self.service_id)
            raise

    async def execute_task(self, dispatch_payload: dict, rag_ctx: RAGContext):
        raise NotImplementedError

    async def _store_in_memory(self, result: dict, task_id: str):
        """contracts.json SVC-05..10 behavior.store_result_in_episodic_memory=True"""
        try:
            await self.memory.store(
                {
                    "content": json.dumps(result),
                    "memory_type": "episodic",
                    "task_id": task_id,
                    "metadata": {
                        "agent_type": self.AGENT_TYPE,
                        "node_id": result["node_id"],
                        "dag_id": result["dag_id"],
                        "confidence": result["confidence"],
                        "degraded_mode": result["degraded_mode"],
                        "outcome_status": (
                            "completed" if not result["needs_review"] else "review_needed"
                        ),
                    },
                }
            )
        except Exception as exc:
            logger.warning("%s: Failed to store in episodic memory: %s", self.service_id, exc)

    def _estimate_cost(self, latency_ms: int) -> float:
        return round(max(self._count_tokens(""), 1) * 0.0 + (latency_ms / 1000.0) * 0.0001, 6)

    def _count_tokens(self, text: str) -> int:
        return len(text.split())

    def _get_model_name(self) -> str:
        return getattr(self.llm, "model_name", getattr(self.llm, "model", "unknown"))

    def _build_rag_query(self, payload: dict[str, Any]) -> str:
        query_parts = [
            payload["sub_task_name"],
            payload["sub_task_description"],
            payload["input_context"],
        ]
        return "\n".join(part for part in query_parts if part)

    def _merge_correction_guidance(
        self,
        current_guidance: str | None,
        suggestions: list[str] | None,
    ) -> str:
        merged_parts = []
        if current_guidance:
            merged_parts.append(current_guidance)
        if suggestions:
            merged_parts.extend(str(suggestion) for suggestion in suggestions if suggestion)
        return " | ".join(merged_parts) if merged_parts else "Address reflection gaps."
