from shared.worker_base.base_worker import BaseWorkerAgent


class MediaAgent(BaseWorkerAgent):
    """SVC-07 Worker Agent — Media. primary_tools: image_gen, audio_gen, media_analyzer"""

    AGENT_TYPE = "media"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []
        prompt = f"""Media task: {dispatch_payload['sub_task_description']}

Task context:
{dispatch_payload['input_context']}

Context from memory:
{chr(10).join(rag_ctx.context_chunks)}

Correction guidance: {dispatch_payload.get('correction_guidance', 'None')}

Produce a media-oriented response that uses the retrieved context explicitly."""
        response = await self.llm.complete(prompt)
        return response.text, tools_used
