from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app


def test_health_response_schema() -> None:
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["service_id"] == "SVC-07"
    assert body["status"] in {"healthy", "degraded", "unhealthy"}
    assert body["version"] == "1.0.0"
    assert "timestamp" in body


def test_metrics_endpoint_is_plain_text() -> None:
    with TestClient(app) as client:
        response = client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]
