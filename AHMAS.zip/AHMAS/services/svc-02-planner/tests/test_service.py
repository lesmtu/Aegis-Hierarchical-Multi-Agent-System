from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from app.main import app
from app.models.plan import Plan, ReplanContext, TaskContext
from app.services.kafka_consumer import PlannerKafkaConsumer
from app.services.kafka_producer import PlannerKafkaProducer
from app.services.planner import PlannerService
from libs.lib01_reflection.result import ReflectionResult
from libs.lib02_rag.context import RAGContext


class StubAsyncLLM:
    def __init__(self, responses: list[str]):
        self.responses = responses
        self.calls = 0

    async def complete(self, prompt, response_format=None):
        text = self.responses[min(self.calls, len(self.responses) - 1)]
        self.calls += 1
        return SimpleNamespace(text=text)


class StubReflectionLLM:
    def complete(self, *args, **kwargs):
        raise AssertionError("unused")


class StubReflectionEngine:
    def __init__(self, scores: list[float]):
        self.scores = scores
        self.calls = 0

    def evaluate(self, task_description: str, output: str, context: dict) -> ReflectionResult:
        score = self.scores[min(self.calls, len(self.scores) - 1)]
        self.calls += 1
        return ReflectionResult(
            confidence_score=score,
            identified_gaps=[],
            correction_suggestions=[],
            should_retry=score < 0.75,
            should_escalate=score < 0.375,
        )


class StubRAG:
    def retrieve_and_inject(self, **kwargs):
        return RAGContext(
            context_chunks=["prior plan template"],
            source_ids=["memory-1"],
            retrieval_scores=[0.9],
            degraded_mode=False,
        )


class SpyProducerTransport:
    def __init__(self):
        self.sent: list[tuple[str, dict]] = []

    def send(self, topic, payload):
        self.sent.append((topic, payload))


class StubIdempotency:
    def __init__(self):
        self.completed: list[tuple[str, str]] = []
        self.failed: list[tuple[str, str]] = []
        self.seen: set[tuple[str, str]] = set()

    def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        key = (idempotency_key, event_id)
        if key in self.seen:
            return False
        self.seen.add(key)
        return True

    def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        self.completed.append((idempotency_key, event_id))

    def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        self.failed.append((idempotency_key, event_id))


class StubMemoryClient:
    def __init__(self):
        self.stored = []

    async def store(self, payload):
        self.stored.append(payload)


def make_task_context() -> TaskContext:
    return TaskContext(
        task_id=uuid4(),
        user_id="u-1",
        session_id=uuid4(),
        channel="telegram",
        raw_input="build a normal implementation",
        parsed_intent="Implement the requested feature",
        intent_type="task",
        context_chunks=[],
        rag_source_ids=[],
        preliminary_confidence=0.9,
        is_ambiguous=False,
        pii_detected=False,
        created_at=datetime.now(timezone.utc),
        telegram_chat_id="123",
    )


def make_sub_tasks_json() -> str:
    a = uuid4()
    return (
        '{"sub_tasks":[{"sub_task_id":"%s","name":"Analyze goal","description":"Break down the work",'
        '"required_capability":"logic","complexity":"medium","cost_tier":"medium","dependencies":[],"estimated_tokens":600}]}' % a
    )


def make_producer() -> PlannerKafkaProducer:
    return PlannerKafkaProducer(SpyProducerTransport())


def test_plan_all_required_fields():
    planner = PlannerService(
        llm=StubAsyncLLM([make_sub_tasks_json()]),
        rag=StubRAG(),
        reflection=StubReflectionEngine([0.8]),
        producer=make_producer(),
    )
    plan = asyncio.run(planner.create_plan(make_task_context()))
    required = {"plan_id", "task_id", "goal", "priority", "sub_tasks", "reflection_score", "version", "replan_attempt", "created_at"}
    assert required <= set(plan.model_dump(mode="json"))


def test_replan_attempt_max_2():
    with pytest.raises(ValidationError):
        Plan(
            plan_id=uuid4(),
            task_id=uuid4(),
            goal="x",
            priority="normal",
            sub_tasks=[],
            reflection_score=0.1,
            version="1.0.0",
            replan_attempt=3,
            created_at=datetime.now(timezone.utc),
        )


def test_task_failed_does_not_emit_replan():
    idempotency = StubIdempotency()
    memory_client = StubMemoryClient()
    producer = make_producer()
    consumer = PlannerKafkaConsumer(
        idempotency_client=idempotency,
        planner=SimpleNamespace(),
        producer=producer,
        memory_client=memory_client,
    )
    envelope = {
        "event_id": str(uuid4()),
        "event_type": "task.failed",
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": "SVC-04",
        "correlation_id": str(uuid4()),
        "trace_id": str(uuid4()),
        "idempotency_key": str(uuid4()),
        "status": "success",
        "payload": {
            "task_id": str(uuid4()),
            "node_id": str(uuid4()),
            "dag_id": str(uuid4()),
            "failure_reason": "WORKER_TIMEOUT",
            "failure_source": "worker",
            "retry_count": 3,
            "replan_attempt": 1,
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
        "error": None,
    }
    asyncio.run(consumer.process("task.failed", envelope))
    assert producer.produced_events == []
    assert len(memory_client.stored) == 1


def test_reflection_failure_emits_hitl_after_max_retries():
    producer = make_producer()
    planner = PlannerService(
        llm=StubAsyncLLM([make_sub_tasks_json()] * 4),
        rag=StubRAG(),
        reflection=StubReflectionEngine([0.1, 0.2, 0.3, 0.4]),
        producer=producer,
    )
    with pytest.raises(Exception):
        asyncio.run(planner.create_plan(make_task_context()))
    assert producer.produced_events[-1]["event_type"] == "hitl.request"


def test_replan_required_deduplication_guard():
    planner = PlannerService(
        llm=StubAsyncLLM([make_sub_tasks_json()]),
        rag=StubRAG(),
        reflection=StubReflectionEngine([0.8]),
        producer=make_producer(),
    )
    idempotency = StubIdempotency()
    producer = make_producer()
    consumer = PlannerKafkaConsumer(
        idempotency_client=idempotency,
        planner=planner,
        producer=producer,
        memory_client=StubMemoryClient(),
    )
    task_context = make_task_context()
    consumer.task_context_store[str(task_context.task_id)] = task_context
    payload = {
        "task_id": str(task_context.task_id),
        "dag_id": str(uuid4()),
        "failed_node_id": str(uuid4()),
        "failure_context": "node failed",
        "replan_attempt": 1,
        "original_plan_id": str(uuid4()),
        "completed_node_ids": [],
        "replan_source": "execution_orchestrator",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    for event_id in (uuid4(), uuid4()):
        envelope = {
            "event_id": str(event_id),
            "event_type": "replan.required",
            "schema_version": "1.0.0",
            "payload_version": "1.0.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_service": "SVC-04",
            "correlation_id": str(task_context.task_id),
            "trace_id": str(uuid4()),
            "idempotency_key": str(uuid4()),
            "status": "success",
            "payload": payload,
            "error": None,
        }
        asyncio.run(consumer.process("replan.required", envelope))
    assert len([e for e in producer.produced_events if e["event_type"] == "plan.created"]) == 1


def test_health_response_schema():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["service_id"] == "SVC-02"


def test_openclaw_task_context_schema_accepts_route_metadata():
    task_context = TaskContext(
        task_id=uuid4(),
        user_id="u-1",
        session_id=uuid4(),
        channel="openclaw",
        raw_input="build a normal implementation",
        parsed_intent="Implement the requested feature",
        intent_type="task",
        context_chunks=[],
        rag_source_ids=[],
        preliminary_confidence=0.9,
        is_ambiguous=False,
        pii_detected=False,
        created_at=datetime.now(timezone.utc),
        openclaw_conversation_id="conv-1",
        openclaw_message_id="msg-1",
        openclaw_source_channel="telegram",
    )
    dumped = task_context.model_dump(mode="json", exclude_none=True)
    assert dumped["channel"] == "openclaw"
    assert dumped["openclaw_conversation_id"] == "conv-1"


def test_metrics_prometheus_format():
    client = TestClient(app)
    response = client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]
    assert "aegis_planner_task_failed_consumed_total" in response.text
