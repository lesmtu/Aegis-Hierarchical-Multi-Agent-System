from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class Settings:
    service_id: str = "SVC-02"
    service_version: str = "1.0.0"
    reflection_threshold: float = 0.75
    max_replan_internal_retries: int = 3
    replan_max_attempts: int = 2
    hitl_timeout_hours: int = int(os.getenv("SVC02_HITL_TIMEOUT_HOURS", "24"))
    memory_base_url: str = os.getenv("SVC16_BASE_URL", "http://svc-16")


settings = Settings()
