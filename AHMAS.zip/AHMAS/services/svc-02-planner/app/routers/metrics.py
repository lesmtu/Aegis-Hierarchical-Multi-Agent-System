from __future__ import annotations

from fastapi import APIRouter

from ..services.metrics import metrics_response

router = APIRouter()


@router.get("/metrics")
async def metrics():
    return metrics_response()
