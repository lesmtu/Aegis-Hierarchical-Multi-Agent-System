from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter

from ..config import settings
from ..models.plan import DependencyHealthStatus, HealthCheckResponse, HealthStatus

router = APIRouter()


@router.get("/health")
async def health() -> dict:
    return HealthCheckResponse(
        service_id=settings.service_id,
        status=HealthStatus.HEALTHY,
        version=settings.service_version,
        dependencies={"svc16": DependencyHealthStatus.UNKNOWN},
        timestamp=datetime.now(timezone.utc),
    ).model_dump(mode="json")
