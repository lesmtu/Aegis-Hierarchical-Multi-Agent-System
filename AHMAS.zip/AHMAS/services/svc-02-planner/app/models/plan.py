from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class Channel(str, Enum):
    TELEGRAM = "telegram"
    WEBUI = "webui"
    OPENCLAW = "openclaw"


class IntentType(str, Enum):
    QUERY = "query"
    TASK = "task"
    COMMAND = "command"
    CLARIFICATION = "clarification"


class Priority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class RequiredCapability(str, Enum):
    RESEARCH = "research"
    LOGIC = "logic"
    MEDIA = "media"
    CODE = "code"
    TOOL_BUILDER = "tool_builder"
    VALIDATION = "validation"


class Complexity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CostTier(str, Enum):
    CHEAP = "cheap"
    MEDIUM = "medium"
    EXPENSIVE = "expensive"


class HITLTriggerReason(str, Enum):
    LOW_CONFIDENCE = "low_confidence"
    HIGH_RISK = "high_risk"
    AMBIGUOUS_INTENT = "ambiguous_intent"
    PLANNER_FAILURE = "planner_failure"
    AUDIT_ESCALATION = "audit_escalation"
    META_AGENT_FAILURE = "meta_agent_failure"


class RiskClassification(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HITLAction(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    MODIFY = "modify"
    CLARIFY = "clarify"


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class DependencyHealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class HealthCheckResponse(StrictBaseModel):
    service_id: str = Field(pattern=r"^SVC-[0-9]{2}$")
    status: HealthStatus
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    dependencies: dict[str, DependencyHealthStatus] | None = None
    timestamp: datetime


class TaskContext(StrictBaseModel):
    task_id: UUID
    user_id: str = Field(min_length=1)
    session_id: UUID
    channel: Channel
    raw_input: str = Field(min_length=1, max_length=131072)
    parsed_intent: str = Field(min_length=1)
    intent_type: IntentType
    context_chunks: list[str] = Field(default_factory=list, max_length=10)
    rag_source_ids: list[str] = Field(default_factory=list)
    preliminary_confidence: float = Field(ge=0.0, le=1.0)
    is_ambiguous: bool
    pii_detected: bool
    created_at: datetime
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None


class SubTask(StrictBaseModel):
    sub_task_id: UUID
    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    required_capability: RequiredCapability
    complexity: Complexity
    cost_tier: CostTier
    dependencies: list[UUID] = Field(default_factory=list)
    estimated_tokens: int = Field(ge=0, le=16000)


class Plan(StrictBaseModel):
    plan_id: UUID
    task_id: UUID
    goal: str = Field(min_length=1)
    priority: Priority
    sub_tasks: list[SubTask] = Field(min_length=1, max_length=50)
    reflection_score: float = Field(ge=0.0, le=1.0)
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    replan_attempt: int = Field(ge=0, le=2)
    created_at: datetime
    failed_node_id: UUID | None = None
    completed_node_ids: list[UUID] | None = None


class TaskFailedPayload(StrictBaseModel):
    task_id: UUID
    node_id: UUID
    dag_id: UUID
    failure_reason: str = Field(min_length=1)
    failure_source: str
    retry_count: int = Field(ge=0)
    replan_attempt: int = Field(ge=0)
    last_output: str | None = None
    created_at: datetime


class ReplanRequiredPayload(StrictBaseModel):
    task_id: UUID
    dag_id: UUID | None = None
    failed_node_id: UUID | None = None
    failure_context: str = Field(min_length=1)
    replan_attempt: int = Field(ge=1, le=2)
    original_plan_id: UUID
    completed_node_ids: list[UUID]
    replan_source: str
    created_at: datetime


class HITLRequestPayload(StrictBaseModel):
    hitl_id: UUID
    task_id: UUID
    node_id: UUID | None = None
    user_id: str = Field(min_length=1)
    session_id: UUID
    trigger_reason: HITLTriggerReason
    risk_classification: RiskClassification
    context: str = Field(min_length=1)
    current_output: str | None = None
    confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    available_actions: list[HITLAction] = Field(min_length=1)
    timeout_hours: int = Field(ge=1)
    created_at: datetime


class FailureMemoryRecord(StrictBaseModel):
    event_type: str = Field(min_length=1)
    task_id: UUID
    node_id: UUID
    agent_id: str
    failure_reason: str = Field(min_length=1)
    error_details: str | None = None
    retry_count_at_failure: int = Field(ge=0)
    timestamp: datetime


class MemoryStoreRequest(StrictBaseModel):
    content: str = Field(min_length=1)
    memory_type: str = Field(min_length=1)
    task_id: UUID | None = None
    session_id: UUID | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    create_obsidian_note: bool = False
    ttl_seconds: int | None = None


class PlanGenerationResponse(StrictBaseModel):
    sub_tasks: list[SubTask] = Field(min_length=1, max_length=50)


class ReplanContext(StrictBaseModel):
    replan_attempt: int = Field(ge=0, le=2)
    failure_context: str | None = None
    failed_node_id: UUID | None = None
    completed_node_ids: list[UUID] = Field(default_factory=list)
    original_plan_id: UUID | None = None


class ReflectionFailure(Exception):
    """Raised when reflection remains below threshold after max retries."""


class DLQRouteRequired(Exception):
    def __init__(self, error_code: str):
        super().__init__(error_code)
        self.error_code = error_code


class FailureLearningState(StrictBaseModel):
    failure_count: int = Field(ge=0)


class PlannerPromptContext(StrictBaseModel):
    goal: str
    task_context: TaskContext
    rag_context: dict[str, Any]
    replan_context: ReplanContext | None
    attempt: int

    @model_validator(mode="after")
    def validate_goal(self) -> "PlannerPromptContext":
        if not self.goal.strip():
            raise ValueError("goal must not be blank")
        return self
