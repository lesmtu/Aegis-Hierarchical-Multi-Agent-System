"""
SVC-02 Planner Service — production entry point.

Startup sequence:
  1. Connect Redis for idempotency (fallback in-memory)
  2. Start aiokafka producer backend
  3. Start aiokafka consumer loop — subscribes to:
       task.received | replan.required | task.failed
  4. Process messages → produce plan.created | hitl.request

All env vars read from dev_full/env/svc-02.env via docker-compose.
LLM is called via OpenAI-compatible HTTP API (set LLM_API_BASE + LLM_API_KEY + LLM_MODEL).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

# Make shared/ importable
ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from aiokafka.errors import KafkaError

from shared.events.consumer import KafkaEventConsumer as _SharedConsumer
from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.idempotency.client import IdempotencyClient

from .config import settings
from .routers.health import router as health_router
from .routers.metrics import router as metrics_router
from .services.kafka_consumer import PlannerKafkaConsumer
from .services.kafka_producer import PlannerKafkaProducer
from .services.planner import PlannerService
from .services.metrics import KAFKA_MESSAGES

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Env ────────────────────────────────────────────────────────────────────────
_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
_REDIS_HOST    = os.getenv("REDIS_HOST", "localhost")
_REDIS_PORT    = int(os.getenv("REDIS_PORT", "6379"))
_GROUP_ID      = os.getenv("SVC02_KAFKA_CONSUMER_GROUP", "svc-02-planner")
_TOPICS        = ["task.received", "replan.required", "task.failed"]
_RESTART_DELAY = 5  # seconds before restarting crashed consumer

_LLM_API_BASE  = os.getenv("LLM_API_BASE", "https://api.openai.com/v1")
_LLM_API_KEY   = os.getenv("LLM_API_KEY", "")
_LLM_MODEL     = os.getenv("LLM_MODEL", "gpt-4o")
_LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "4096"))
_LLM_TEMP      = float(os.getenv("LLM_TEMPERATURE", "0.3"))


# ── In-memory Redis fallback ────────────────────────────────────────────────────
class _InMemoryLuaScript:
    def __init__(self, store):
        self._store = store
    def __call__(self, *, keys, args):
        key = keys[0]
        if key in self._store:
            return 0
        self._store[key] = args[0]
        return 1

class _InMemoryRedis:
    def __init__(self):
        self.store: dict = {}
    def register_script(self, _):
        return _InMemoryLuaScript(self.store)
    def get(self, key):
        return self.store.get(key)
    def set(self, key, value, xx=False, keepttl=False):
        if xx and key not in self.store:
            return False
        self.store[key] = value
        return True
    def delete(self, key):
        self.store.pop(key, None)


# ── AioKafka producer backend (matches KafkaEventProducer interface) ───────────
class _AioKafkaBackend:
    """Thin wrapper so KafkaEventProducer.backend.send() fires async via loop."""
    def __init__(self, bootstrap_servers: str):
        self._bs = bootstrap_servers
        self._producer: AIOKafkaProducer | None = None

    async def start(self):
        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bs,
            value_serializer=lambda v: json.dumps(v).encode(),
            key_serializer=lambda k: k.encode() if k else None,
            acks="all",
        )
        await self._producer.start()
        logger.info("SVC-02 Kafka producer started — brokers=%s", self._bs)

    async def stop(self):
        if self._producer:
            await self._producer.stop()

    def send(self, topic: str, payload: dict) -> None:
        if not self._producer:
            raise RuntimeError("Producer not started")
        key = payload.get("correlation_id") or payload.get("event_id")
        prod = self._producer

        async def _fire():
            try:
                await prod.send(topic, value=payload, key=key)
                logger.debug("SVC-02 produced topic=%s corr=%s", topic, key)
            except Exception as exc:
                logger.error("SVC-02 produce failed topic=%s: %s", topic, exc, exc_info=True)

        asyncio.ensure_future(_fire())


# ── OpenAI-compatible LLM client ───────────────────────────────────────────────
class _LLMClient:
    """
    Calls any OpenAI-compatible /chat/completions endpoint.
    LLM_API_BASE controls provider (OpenAI, Gemini OpenAI-compat, Groq, etc.)
    LLM_MODEL selects the model.
    """
    def __init__(self):
        import httpx
        self._client = httpx.AsyncClient(timeout=120.0)
        self._base   = _LLM_API_BASE.rstrip("/")
        self._key    = _LLM_API_KEY
        self._model  = _LLM_MODEL

    async def complete(self, prompt: str, response_format: dict | None = None) -> "_LLMResponse":
        body: dict = {
            "model": self._model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": _LLM_MAX_TOKENS,
            "temperature": _LLM_TEMP,
        }
        if response_format:
            body["response_format"] = response_format
        headers = {"Authorization": f"Bearer {self._key}", "Content-Type": "application/json"}
        resp = await self._client.post(f"{self._base}/chat/completions", json=body, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        text = data["choices"][0]["message"]["content"]
        return _LLMResponse(text=text)

    async def aclose(self):
        await self._client.aclose()


class _LLMResponse:
    def __init__(self, text: str):
        self.text = text


# ── RAG stub (SVC-16 call can be added later) ──────────────────────────────────
class _StubRAG:
    def retrieve_and_inject(self, *, query: str, session_id: str, task_id: str):
        class _Ctx:
            context_chunks = [f"rag:{query[:64]}"]
            def to_dict(self): return {"context_chunks": self.context_chunks}
        return _Ctx()


# ── Reflection stub ────────────────────────────────────────────────────────────
class _StubReflection:
    def evaluate(self, *, task_description: str, output: str, context: dict):
        class _R:
            confidence_score = 0.85
            identified_gaps = []
        return _R()


# ── Consumer loop (mirrors SVC-01 ReceptionistConsumerLoop) ───────────────────
class _ConsumerLoop:
    def __init__(self, planner_consumer: PlannerKafkaConsumer):
        self._consumer = planner_consumer
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self):
        self._running = True
        self._task = asyncio.create_task(self._run_with_restart(), name="svc02-kafka-consumer")
        logger.info("SVC-02 consumer loop starting — topics=%s group=%s", _TOPICS, _GROUP_ID)

    async def stop(self):
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        logger.info("SVC-02 consumer loop stopped")

    async def _run_with_restart(self):
        while self._running:
            try:
                await self._run()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("SVC-02 consumer crashed: %s. Restarting in %ds", exc, _RESTART_DELAY, exc_info=True)
                if self._running:
                    await asyncio.sleep(_RESTART_DELAY)

    async def _run(self):
        from aiokafka import TopicPartition
        kafka = AIOKafkaConsumer(
            *_TOPICS,
            bootstrap_servers=_KAFKA_BROKERS,
            group_id=_GROUP_ID,
            auto_offset_reset="earliest",
            enable_auto_commit=False,
            value_deserializer=lambda raw: json.loads(raw.decode("utf-8")),
            session_timeout_ms=30_000,
            heartbeat_interval_ms=10_000,
            max_poll_records=5,
        )
        try:
            await kafka.start()
            logger.info("SVC-02 AIOKafkaConsumer connected — group=%s", _GROUP_ID)
            async for msg in kafka:
                if not self._running:
                    break
                topic = msg.topic
                try:
                    await self._consumer.process(topic, msg.value)
                except Exception as exc:
                    logger.error("SVC-02 message handling error topic=%s: %s", topic, exc, exc_info=True)
                finally:
                    tp = TopicPartition(msg.topic, msg.partition)
                    await kafka.commit({tp: msg.offset + 1})
        finally:
            await kafka.stop()


# ── Lifespan ───────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Redis idempotency
    redis_client = None
    try:
        import redis as redis_lib
        redis_client = redis_lib.Redis(
            host=_REDIS_HOST, port=_REDIS_PORT,
            decode_responses=True, socket_connect_timeout=5,
        )
        redis_client.ping()
        logger.info("SVC-02 Redis connected — %s:%d", _REDIS_HOST, _REDIS_PORT)
    except Exception as exc:
        logger.warning("SVC-02 Redis unavailable (%s) — using in-memory fallback", exc)
        redis_client = _InMemoryRedis()

    idempotency = IdempotencyClient(redis_client, "SVC-02")

    # 2. Kafka producer backend
    backend = _AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    # 3. Wire planner dependencies
    llm = _LLMClient()
    producer = PlannerKafkaProducer(backend)
    planner  = PlannerService(
        llm=llm,
        rag=_StubRAG(),
        reflection=_StubReflection(),
        producer=producer,
    )

    # 4. Kafka consumer
    planner_consumer = PlannerKafkaConsumer(
        idempotency_client=idempotency,
        planner=planner,
        producer=producer,
        memory_client=_StubMemoryClient(),
    )
    loop = _ConsumerLoop(planner_consumer)
    await loop.start()

    logger.info("SVC-02 fully started — LLM_MODEL=%s LLM_API_BASE=%s", _LLM_MODEL, _LLM_API_BASE)
    yield

    logger.info("SVC-02 shutting down")
    await loop.stop()
    await backend.stop()
    await llm.aclose()
    logger.info("SVC-02 shutdown complete")


# ── Memory stub (SVC-16 REST call — extend later) ─────────────────────────────
class _StubMemoryClient:
    async def store(self, request) -> None:
        logger.debug("SVC-02 memory.store stub — content=%s", str(request)[:80])


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Aegis HMAS SVC-02 Planner Service",
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)
app.include_router(health_router)
app.include_router(metrics_router)
