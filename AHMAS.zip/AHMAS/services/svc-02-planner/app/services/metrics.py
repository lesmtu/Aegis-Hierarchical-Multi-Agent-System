from __future__ import annotations

from starlette.responses import Response

try:
    from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
except ModuleNotFoundError:  # pragma: no cover
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4"

    class _MetricChild:
        def __init__(self, metric, labels):
            self.metric = metric
            self.labels = labels

        def inc(self, amount: float = 1.0) -> None:
            self.metric.values[tuple(sorted(self.labels.items()))] = self.metric.values.get(tuple(sorted(self.labels.items())), 0.0) + amount

        def observe(self, amount: float) -> None:
            self.inc(amount)

    class _Metric:
        def __init__(self, name: str, documentation: str, labelnames=()):
            self.name = name
            self.documentation = documentation
            self.labelnames = tuple(labelnames)
            self.values: dict[tuple[tuple[str, str], ...], float] = {}

        def labels(self, **kwargs):
            return _MetricChild(self, kwargs)

    _REGISTRY: list[_Metric] = []

    def Counter(name, documentation, labelnames=()):
        metric = _Metric(name, documentation, labelnames)
        _REGISTRY.append(metric)
        return metric

    def Histogram(name, documentation, labelnames=(), buckets=None):
        metric = _Metric(name, documentation, labelnames)
        _REGISTRY.append(metric)
        return metric

    def generate_latest() -> bytes:
        lines: list[str] = []
        for metric in _REGISTRY:
            lines.append(f"# HELP {metric.name} {metric.documentation}")
            lines.append(f"# TYPE {metric.name} untyped")
            if metric.values:
                for labels, value in metric.values.items():
                    rendered = ",".join(f'{key}="{value_}"' for key, value_ in labels)
                    suffix = f"{{{rendered}}}" if rendered else ""
                    lines.append(f"{metric.name}{suffix} {value}")
            else:
                lines.append(f"{metric.name} 0")
        return ("\n".join(lines) + "\n").encode("utf-8")


KAFKA_MESSAGES = Counter(
    "aegis_planner_kafka_messages_total",
    "Consumed Kafka messages by topic and result",
    ["topic", "result"],
)
PLAN_LATENCY = Histogram(
    "aegis_planner_plan_generation_latency_seconds",
    "SVC-02 plan generation latency",
    ["trigger"],
)
TASK_FAILED_CONSUMED = Counter(
    "aegis_planner_task_failed_consumed_total",
    "Total task.failed events consumed by failure_reason",
    ["failure_reason"],
)
REPLAN_TRIGGERED = Counter(
    "aegis_planner_replan_triggered_total",
    "Total replans triggered by source",
    ["trigger_source"],
)
FAILURE_PATTERN_DETECTED = Counter(
    "aegis_planner_failure_pattern_detected_total",
    "Repeated failure patterns detected by agent_type",
    ["agent_type"],
)


def metrics_response() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
