from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from shared.events.consumer import KafkaEventConsumer

from ..config import settings
from ..models.plan import (
    DLQRouteRequired,
    FailureLearningState,
    FailureMemoryRecord,
    MemoryStoreRequest,
    ReplanContext,
    ReplanRequiredPayload,
    TaskContext,
    TaskFailedPayload,
)
from .metrics import FAILURE_PATTERN_DETECTED, KAFKA_MESSAGES, REPLAN_TRIGGERED, TASK_FAILED_CONSUMED

logger = logging.getLogger(__name__)


class PlannerKafkaConsumer:
    def __init__(
        self,
        *,
        idempotency_client,
        planner,
        producer,
        memory_client,
    ):
        self.idempotency = idempotency_client
        self.planner = planner
        self.producer = producer
        self.memory_client = memory_client
        self.consumer = KafkaEventConsumer()
        self._processed_replans: dict[str, datetime] = {}
        self.failure_tracker: dict[tuple[str, str], FailureLearningState] = {}
        self.task_context_store: dict[str, TaskContext] = {}

    async def process(self, topic: str, message: dict) -> bool:
        should_process, route_topic, _envelope = self.consumer.consume(message)
        if not should_process:
            KAFKA_MESSAGES.labels(topic=topic, result="schema_rejected").inc()
            return False
        if route_topic:
            KAFKA_MESSAGES.labels(topic=topic, result="rejected").inc()
            return False
        if not self.idempotency.check_and_set(message["idempotency_key"], message["event_id"]):
            KAFKA_MESSAGES.labels(topic=topic, result="duplicate").inc()
            return False
        try:
            if topic == "task.received":
                await self.handle_task_received(message)
            elif topic == "replan.required":
                await self.handle_replan_required(message)
            elif topic == "task.failed":
                await self.handle_task_failed(message)
            else:
                raise ValueError(f"Unsupported topic: {topic}")
        except Exception:
            self.idempotency.mark_failed(message["idempotency_key"], message["event_id"])
            KAFKA_MESSAGES.labels(topic=topic, result="failed").inc()
            raise
        self.idempotency.mark_completed(message["idempotency_key"], message["event_id"])
        KAFKA_MESSAGES.labels(topic=topic, result="processed").inc()
        return True

    async def handle_task_received(self, envelope: dict) -> None:
        task_context = TaskContext.model_validate(envelope["payload"])
        self.task_context_store[str(task_context.task_id)] = task_context
        plan = await self.planner.create_plan(task_context)
        self.producer.produce(
            topic="plan.created",
            payload=plan.model_dump(mode="json", exclude_none=True),
            correlation_id=envelope["correlation_id"],
            trace_id=envelope["trace_id"],
        )

    async def handle_replan_required(self, envelope: dict) -> None:
        payload = ReplanRequiredPayload.model_validate(envelope["payload"])
        dedup_key = f"{payload.task_id}:{payload.replan_attempt}"
        now = datetime.now(timezone.utc)
        previous = self._processed_replans.get(dedup_key)
        if previous and (now - previous).total_seconds() <= 60:
            logger.info("SVC-02 duplicate replan suppressed: %s", dedup_key)
            return
        self._processed_replans[dedup_key] = now
        if payload.replan_attempt > settings.replan_max_attempts:
            raise DLQRouteRequired("REPLAN_LIMIT_EXCEEDED")
        task_context = self.task_context_store.get(str(payload.task_id))
        if task_context is None:
            raise KeyError(f"Missing task context for {payload.task_id}")
        replan_context = ReplanContext(
            replan_attempt=payload.replan_attempt,
            failure_context=payload.failure_context,
            failed_node_id=payload.failed_node_id,
            completed_node_ids=payload.completed_node_ids,
            original_plan_id=payload.original_plan_id,
        )
        plan = await self.planner.create_plan(task_context, replan_context)
        REPLAN_TRIGGERED.labels(trigger_source="replan_required").inc()
        self.producer.produce(
            topic="plan.created",
            payload=plan.model_dump(mode="json", exclude_none=True),
            correlation_id=envelope["correlation_id"],
            trace_id=envelope["trace_id"],
        )

    async def handle_task_failed(self, envelope: dict) -> None:
        payload = TaskFailedPayload.model_validate(envelope["payload"])
        TASK_FAILED_CONSUMED.labels(failure_reason=payload.failure_reason).inc()
        agent_id = payload.failure_source
        await self.memory_client.store(
            MemoryStoreRequest(
                content=FailureMemoryRecord(
                    event_type="task_node_terminal_failure",
                    task_id=payload.task_id,
                    node_id=payload.node_id,
                    agent_id=payload.failure_source,
                    failure_reason=payload.failure_reason,
                    error_details=payload.last_output,
                    retry_count_at_failure=payload.retry_count,
                    timestamp=payload.created_at,
                ).model_dump_json(),
                memory_type="episodic",
                task_id=payload.task_id,
                metadata={"source": "SVC-02", "type": "failure_pattern"},
            )
        )
        tracker_key = (payload.failure_source, agent_id)
        state = self.failure_tracker.get(tracker_key, FailureLearningState(failure_count=0))
        state = FailureLearningState(failure_count=state.failure_count + 1)
        self.failure_tracker[tracker_key] = state
        if state.failure_count > 3:
            FAILURE_PATTERN_DETECTED.labels(agent_type=payload.failure_source).inc()
            logger.warning("Repeated failure pattern detected for agent %s", agent_id)
        logger.info("SVC-02 task.failed learned only for task_id=%s", payload.task_id)
