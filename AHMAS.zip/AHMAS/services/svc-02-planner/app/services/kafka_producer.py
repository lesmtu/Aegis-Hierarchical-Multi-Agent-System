from __future__ import annotations

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.events.producer import KafkaEventProducer


class PlannerKafkaProducer:
    def __init__(self, producer):
        self.transport = KafkaEventProducer(producer)
        self.produced_events: list[dict] = []

    def produce(self, *, topic: str, payload: dict, correlation_id: str, trace_id: str) -> dict:
        envelope = AegisCanonicalEventEnvelope.create(
            event_type=topic,
            source_service="SVC-02",
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
        )
        sent = self.transport.send(topic, envelope)
        self.produced_events.append(sent)
        return sent
