from __future__ import annotations

import json
from datetime import datetime, timezone
from time import perf_counter
from uuid import uuid4

from libs.lib01_reflection.engine import ReflectionEngine
from libs.lib02_rag.pipeline import RAGPipeline

from ..config import settings
from ..models.plan import (
    HITLAction,
    HITLRequestPayload,
    HITLTriggerReason,
    Plan,
    PlanGenerationResponse,
    PlannerPromptContext,
    ReflectionFailure,
    ReplanContext,
    RiskClassification,
    TaskContext,
)
from .metrics import PLAN_LATENCY


class PlannerService:
    REFLECTION_THRESHOLD = settings.reflection_threshold
    MAX_INTERNAL_RETRIES = settings.max_replan_internal_retries

    def __init__(self, *, llm, rag: RAGPipeline, reflection: ReflectionEngine, producer):
        self.llm = llm
        self.rag = rag
        self.reflection = reflection
        self.producer = producer

    async def create_plan(self, task_context: TaskContext, replan_context: ReplanContext | None = None) -> Plan:
        started = perf_counter()
        trigger = "replan_required" if replan_context else "task_received"
        goal = task_context.parsed_intent
        rag_ctx = self.rag.retrieve_and_inject(
            query=goal,
            session_id=str(task_context.session_id),
            task_id=str(task_context.task_id),
        )

        plan: Plan | None = None
        for attempt in range(self.MAX_INTERNAL_RETRIES + 1):
            plan = await self._generate_plan(task_context, rag_ctx.to_dict(), replan_context, attempt)
            reflection = self.reflection.evaluate(
                task_description=goal,
                output=json.dumps(plan.model_dump(mode="json")["sub_tasks"]),
                context={"rag_context": rag_ctx.context_chunks, "attempt": attempt},
            )
            plan = plan.model_copy(update={"reflection_score": reflection.confidence_score})
            if reflection.confidence_score >= self.REFLECTION_THRESHOLD:
                PLAN_LATENCY.labels(trigger=trigger).observe(perf_counter() - started)
                return plan
            if attempt == self.MAX_INTERNAL_RETRIES:
                await self._emit_hitl_on_reflection_failure(task_context, plan)
                PLAN_LATENCY.labels(trigger=trigger).observe(perf_counter() - started)
                raise ReflectionFailure("PLAN_REFLECTION_BELOW_THRESHOLD")

        raise ReflectionFailure("PLAN_REFLECTION_BELOW_THRESHOLD")

    async def _generate_plan(
        self,
        task_context: TaskContext,
        rag_context: dict,
        replan_context: ReplanContext | None,
        attempt: int,
    ) -> Plan:
        prompt = self._build_planning_prompt(task_context, rag_context, replan_context, attempt)
        response = await self.llm.complete(prompt, response_format={"type": "json_object"})
        raw = json.loads(response.text)
        generated = PlanGenerationResponse.model_validate(raw)
        return Plan(
            plan_id=uuid4(),
            task_id=task_context.task_id,
            goal=task_context.parsed_intent,
            priority=self._resolve_priority(task_context),
            sub_tasks=generated.sub_tasks,
            reflection_score=0.0,
            version=settings.service_version,
            replan_attempt=replan_context.replan_attempt if replan_context else 0,
            created_at=datetime.now(timezone.utc),
            failed_node_id=replan_context.failed_node_id if replan_context else None,
            completed_node_ids=replan_context.completed_node_ids if replan_context else None,
        )

    def _build_planning_prompt(
        self,
        task_context: TaskContext,
        rag_context: dict,
        replan_context: ReplanContext | None,
        attempt: int,
    ) -> str:
        context = PlannerPromptContext(
            goal=task_context.parsed_intent,
            task_context=task_context,
            rag_context=rag_context,
            replan_context=replan_context,
            attempt=attempt,
        )
        return (
            "You are SVC-02 Planner Service. Decompose the goal into sub-tasks.\n\n"
            "Respond with ONLY a valid JSON object with this exact structure:\n"
            "{\n"
            '  "sub_tasks": [\n'
            "    {\n"
            '      "sub_task_id": "<UUIDv4 string>",\n'
            '      "name": "<short name>",\n'
            '      "description": "<what this sub-task does>",\n'
            '      "required_capability": "<one of: research | logic | media | code | tool_builder | validation>",\n'
            '      "complexity": "<one of: low | medium | high>",\n'
            '      "cost_tier": "<one of: cheap | medium | expensive>",\n'
            '      "dependencies": [],\n'
            '      "estimated_tokens": <integer 0-16000>\n'
            "    }\n"
            "  ]\n"
            "}\n\n"
            "STRICT RULES:\n"
            "- Use ONLY the fields listed above for each sub_task. Do NOT add any extra fields.\n"
            "- sub_task_id MUST be a valid UUID v4 string (e.g. '550e8400-e29b-41d4-a716-446655440000').\n"
            "- required_capability MUST be one of exactly: research, logic, media, code, tool_builder, validation.\n"
            "- complexity MUST be one of exactly: low, medium, high.\n"
            "- cost_tier MUST be one of exactly: cheap, medium, expensive.\n"
            "- estimated_tokens MUST be an integer between 0 and 16000.\n"
            "- dependencies is a list of sub_task_id UUIDs that must complete first (empty list if none).\n"
            "- Do NOT include fields named 'input', 'output', 'type', 'value', or any other fields.\n\n"
            f"Context: {context.model_dump_json()}"
        )

    def _resolve_priority(self, task_context: TaskContext) -> str:
        lowered = task_context.raw_input.lower()
        if "critical" in lowered or "urgent" in lowered:
            return "critical"
        if "high" in lowered:
            return "high"
        if "low" in lowered:
            return "low"
        return "normal"

    async def _emit_hitl_on_reflection_failure(self, task_context: TaskContext, plan: Plan) -> None:
        payload = HITLRequestPayload(
            hitl_id=uuid4(),
            task_id=task_context.task_id,
            node_id=plan.failed_node_id,
            user_id=task_context.user_id,
            session_id=task_context.session_id,
            trigger_reason=HITLTriggerReason.PLANNER_FAILURE,
            risk_classification=RiskClassification.HIGH,
            context=(
                "Planner reflection score remained below threshold after max retries. "
                f"task_id={task_context.task_id} replan_attempt={plan.replan_attempt}"
            ),
            current_output=plan.model_dump_json(),
            confidence_score=plan.reflection_score,
            available_actions=[HITLAction.APPROVE, HITLAction.MODIFY, HITLAction.REJECT],
            timeout_hours=settings.hitl_timeout_hours,
            created_at=datetime.now(timezone.utc),
        )
        self.producer.produce(
            topic="hitl.request",
            payload=payload.model_dump(mode="json", exclude_none=True),
            correlation_id=str(task_context.task_id),
            trace_id=str(task_context.task_id),
        )
