from __future__ import annotations

import os
from datetime import datetime, timezone
from uuid import uuid4

from fastapi.testclient import TestClient

os.environ["SVC19_DATABASE_URL"] = "sqlite+aiosqlite:///./svc19_test.db"
os.environ["SVC19_REDIS_URL"] = "redis://localhost:6399/0"

from app.db import connection  # noqa: E402
from app.main import app  # noqa: E402


def make_client() -> TestClient:
    return TestClient(app)


def capability_payload(**overrides):
    payload = {
        "agent_id": "agent-1",
        "agent_type": "code",
        "capability_type": "code",
        "model_tier": "mid_tier",
        "llm_config": {
            "model_tier": "mid_tier",
            "max_tokens": 4096,
            "temperature": 0.2,
        },
        "tool_ids": [str(uuid4())],
        "health_status": "healthy",
        "trust_score": 0.95,
        "version": "1.0.0",
        "registered_at": datetime.now(timezone.utc).isoformat(),
    }
    payload.update(overrides)
    return payload


def tool_payload(**overrides):
    payload = {
        "tool_id": str(uuid4()),
        "name": "tool-a",
        "description": "A tool",
        "capability_type": "code",
        "interface": {"input_schema": {"type": "object"}, "output_schema": {"type": "object"}},
        "runtime": "python",
        "code_path": "/tmp/tool.py",
        "version": "1.0.0",
        "created_by": "SVC-11",
        "sandbox_test_results": {
            "passed": True,
            "unit_tests_passed": True,
            "integration_tests_passed": True,
            "static_analysis_passed": True,
            "execution_time_ms": 10,
            "failure_details": None,
        },
        "usage_count": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    payload.update(overrides)
    return payload


def setup_module() -> None:
    connection.configure_engine(os.environ["SVC19_DATABASE_URL"])


def teardown_function() -> None:
    import asyncio

    async def reset_db():
        async with connection.engine.begin() as conn:
            await conn.run_sync(connection.Base.metadata.drop_all)
            await conn.run_sync(connection.Base.metadata.create_all)

    asyncio.run(reset_db())


def test_trust_score_clamped_to_0_1():
    with make_client() as client:
        client.post("/capabilities/register", json=capability_payload())
        response = client.patch("/capabilities/agent-1/trust_score", json={"trust_score_delta": 0.1})
    assert response.status_code == 200
    assert response.json()["new_trust_score"] == 1.0


def test_capability_not_found_returns_404():
    with make_client() as client:
        response = client.get("/capabilities/research")
    assert response.status_code == 404


def test_register_returns_409_on_duplicate():
    payload = capability_payload()
    with make_client() as client:
        first = client.post("/capabilities/register", json=payload)
        second = client.post("/capabilities/register", json=payload)
    assert first.status_code == 201
    assert second.status_code == 409


def test_is_dynamic_default_false():
    with make_client() as client:
        response = client.post("/capabilities/register", json=capability_payload(agent_id="agent-2"))
        fetched = client.get("/capabilities/code")
    assert response.status_code == 201
    assert fetched.status_code == 200
    assert fetched.json()["agents"][0]["is_dynamic"] is False
