from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Annotated
from uuid import UUID

from pydantic import Field, field_validator

from .common import StrictBaseModel


class AgentType(str, Enum):
    RESEARCH = "research"
    LOGIC = "logic"
    MEDIA = "media"
    CODE = "code"
    TOOL_BUILDER = "tool_builder"
    VALIDATION = "validation"


class CapabilityRouteType(str, Enum):
    RESEARCH = "research"
    LOGIC = "logic"
    MEDIA = "media"
    CODE = "code"
    TOOL_BUILDER = "tool_builder"
    VALIDATION = "validation"
    DYNAMIC = "dynamic"


class ModelTier(str, Enum):
    LIGHTWEIGHT = "lightweight"
    MID_TIER = "mid_tier"
    HEAVY_REASONING = "heavy_reasoning"


class CapabilityHealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    DISABLED = "disabled"


class AgentLLMConfig(StrictBaseModel):
    model_tier: ModelTier
    max_tokens: int = Field(ge=1, le=128000)
    temperature: float = Field(ge=0.0, le=2.0)


UuidString = Annotated[str, Field(pattern=r"^[0-9a-fA-F-]{36}$")]
SemverString = Annotated[str, Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")]


class CapabilityRegistryEntry(StrictBaseModel):
    agent_id: str = Field(min_length=1)
    agent_type: AgentType
    capability_type: str = Field(min_length=1)
    model_tier: ModelTier
    llm_config: AgentLLMConfig
    tool_ids: list[UUID]
    health_status: CapabilityHealthStatus
    trust_score: float = Field(ge=0.0, le=1.0)
    version: SemverString
    is_dynamic: bool = False
    registered_at: datetime

    @field_validator("trust_score", mode="before")
    @classmethod
    def clamp_trust_score(cls, value: float) -> float:
        return max(0.0, min(1.0, float(value)))


class CapabilityListResponse(StrictBaseModel):
    capabilities: list[CapabilityRegistryEntry]
    total: int = Field(ge=0)


class CapabilityTypeResponse(StrictBaseModel):
    capability_type: str
    agents: list[CapabilityRegistryEntry]


class CapabilityRegisterResponse(StrictBaseModel):
    agent_id: str = Field(min_length=1)
    registered_at: datetime


class TrustScoreUpdateRequest(StrictBaseModel):
    trust_score_delta: float


class TrustScoreUpdateResponse(StrictBaseModel):
    agent_id: str
    new_trust_score: float = Field(ge=0.0, le=1.0)


class CapabilityStatusUpdateRequest(StrictBaseModel):
    health_status: CapabilityHealthStatus


class CapabilityStatusUpdateResponse(StrictBaseModel):
    agent_id: str
    health_status: CapabilityHealthStatus
    updated_at: datetime
