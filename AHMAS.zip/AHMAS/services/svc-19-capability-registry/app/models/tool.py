from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Annotated
from uuid import UUID

from pydantic import Field

from .common import StrictBaseModel
from .capability import SemverString


class ToolRuntime(str, Enum):
    PYTHON = "python"
    BASH = "bash"
    HTTP = "http"


UuidString = Annotated[str, Field(pattern=r"^[0-9a-fA-F-]{36}$")]


class ToolInterfaceSchema(StrictBaseModel):
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]


class SandboxTestResults(StrictBaseModel):
    passed: bool
    unit_tests_passed: bool
    integration_tests_passed: bool
    static_analysis_passed: bool
    execution_time_ms: int = Field(ge=0)
    failure_details: str | None = None


class ToolRegistryEntry(StrictBaseModel):
    tool_id: UUID
    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    capability_type: str = Field(min_length=1)
    interface: ToolInterfaceSchema
    runtime: ToolRuntime
    code_path: str = Field(min_length=1)
    version: SemverString
    created_by: str = Field(min_length=1)
    sandbox_test_results: SandboxTestResults
    usage_count: int = Field(ge=0)
    created_at: datetime


class ToolCreatedPayload(StrictBaseModel):
    tool_id: UUID
    capability_request_id: UUID
    task_id: UUID
    tool_entry: ToolRegistryEntry
    created_at: datetime


class AgentSpec(StrictBaseModel):
    agent_spec_id: UUID
    name: str = Field(min_length=1)
    capability_type: str = Field(min_length=1)
    llm_config: "AgentLLMConfig"
    tool_ids: list[UUID]
    system_prompt_template: str = Field(min_length=1)
    version: SemverString


class AgentCreatedPayload(StrictBaseModel):
    meta_request_id: UUID
    agent_spec: AgentSpec
    sandbox_test_results: SandboxTestResults
    created_at: datetime


class ToolListResponse(StrictBaseModel):
    tools: list[ToolRegistryEntry]
    total: int = Field(ge=0)


class ToolRegisterResponse(StrictBaseModel):
    tool_id: UUID
    registered_at: datetime


class ToolUsageUpdateResponse(StrictBaseModel):
    tool_id: UUID
    usage_count: int = Field(ge=0)


from .capability import AgentLLMConfig  # noqa: E402

AgentSpec.model_rebuild()
