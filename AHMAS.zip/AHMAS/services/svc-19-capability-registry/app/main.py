from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi

from .config import settings
from .models.common import DependencyHealthStatus
from .routers.health import router as health_router
from .services.errors import build_error_response, request_id_from
from .services.metrics import REQUEST_COUNT, REQUEST_LATENCY

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
LOGGER = logging.getLogger(__name__)

try:
    from .db.connection import init_db
    from .routers.capabilities import router as capabilities_router
    from .routers.tools import router as tools_router
    from .services.kafka_consumer import build_idempotency_store
    _OPTIONAL_IMPORT_ERROR = None
except ModuleNotFoundError as exc:  # pragma: no cover - degraded import path for test runtime
    init_db = None  # type: ignore[assignment]
    capabilities_router = None
    tools_router = None
    build_idempotency_store = None  # type: ignore[assignment]
    _OPTIONAL_IMPORT_ERROR = exc


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.database_status = DependencyHealthStatus.UNKNOWN
    app.state.redis_status = DependencyHealthStatus.UNKNOWN
    if _OPTIONAL_IMPORT_ERROR is not None:
        LOGGER.warning("Capability Registry optional dependencies unavailable: %s", _OPTIONAL_IMPORT_ERROR)
        app.state.database_status = DependencyHealthStatus.DEGRADED
        app.state.redis_status = DependencyHealthStatus.DEGRADED
    else:
        try:
            await init_db()
            app.state.database_status = DependencyHealthStatus.HEALTHY
        except Exception:
            LOGGER.exception("Failed to initialize database")
            app.state.database_status = DependencyHealthStatus.UNHEALTHY
        try:
            idempotency_store = await build_idempotency_store()
            app.state.idempotency_store = idempotency_store
            app.state.redis_status = (
                DependencyHealthStatus.DEGRADED
                if idempotency_store.__class__.__name__ == "MemoryIdempotencyStore"
                else DependencyHealthStatus.HEALTHY
            )
        except Exception:
            LOGGER.exception("Failed to initialize idempotency store")
            app.state.redis_status = DependencyHealthStatus.UNHEALTHY
    yield


app = FastAPI(
    title=settings.service_title,
    version=settings.service_version,
    lifespan=lifespan,
    separate_input_output_schemas=False,
)
if capabilities_router is not None:
    app.include_router(capabilities_router)
if tools_router is not None:
    app.include_router(tools_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    components = schema.get("components", {}).get("schemas", {})
    split_names = [name for name in components if name.endswith(("-Input", "-Output"))]
    for name in split_names:
        base_name = name.rsplit("-", 1)[0]
        sibling_names = [f"{base_name}-Input", f"{base_name}-Output"]
        if any(sibling not in components for sibling in sibling_names):
            continue
        normalized = {}
        for sibling in sibling_names:
            payload = json.loads(json.dumps(components[sibling]))
            payload["title"] = base_name
            normalized[sibling] = payload
        input_schema = normalized[f"{base_name}-Input"]
        output_schema = normalized[f"{base_name}-Output"]
        if input_schema != output_schema:
            continue
        components[base_name] = input_schema

        def replace_refs(node):
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == "$ref" and value in {
                        f"#/components/schemas/{base_name}-Input",
                        f"#/components/schemas/{base_name}-Output",
                    }:
                        node[key] = f"#/components/schemas/{base_name}"
                    else:
                        replace_refs(value)
            elif isinstance(node, list):
                for value in node:
                    replace_refs(value)

        replace_refs(schema)
        components.pop(f"{base_name}-Input", None)
        components.pop(f"{base_name}-Output", None)
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = uuid4()
    path = request.url.path
    method = request.method
    started = perf_counter()
    response = None
    try:
        response = await call_next(request)
    finally:
        REQUEST_LATENCY.labels(method=method, path=path).observe(perf_counter() - started)
    if response is not None:
        REQUEST_COUNT.labels(method=method, path=path, status_code=response.status_code).inc()
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return build_error_response(
        status_code=400,
        error_code="INVALID_PAYLOAD",
        message="Request validation failed",
        request_id=request_id_from(request),
        details={"errors": exc.errors()},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    LOGGER.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return build_error_response(
        status_code=500,
        error_code="INTERNAL_ERROR",
        message="Internal server error",
        request_id=request_id_from(request),
        details={"reason": str(exc)},
    )
