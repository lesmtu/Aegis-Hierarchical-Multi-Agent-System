from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from uuid import UUID

from redis.asyncio import Redis
from redis.exceptions import RedisError

from ..config import settings
from ..models.capability import AgentType, CapabilityHealthStatus, CapabilityRegistryEntry
from ..models.common import AegisCanonicalEventEnvelope
from ..models.tool import AgentCreatedPayload, ToolCreatedPayload
from .metrics import KAFKA_MESSAGES
from .registry_service import DuplicateAgentError, DuplicateToolError, RegistryService

LOGGER = logging.getLogger(__name__)


class MemoryIdempotencyStore:
    def __init__(self):
        self._store: dict[str, dict] = {}

    async def claim(self, service_id: str, idempotency_key: UUID, event_id: UUID, ttl_seconds: int) -> bool:
        now = datetime.now(timezone.utc)
        key = f"idempotency:{service_id}:{idempotency_key}"
        existing = self._store.get(key)
        if existing:
            processed_at = datetime.fromisoformat(existing["processed_at"])
            if existing["status"] in {"completed", "processing"} and now - processed_at <= timedelta(minutes=10):
                return False
        self._store[key] = {
            "processed_at": now.isoformat(),
            "service_id": service_id,
            "event_id": str(event_id),
            "status": "processing",
        }
        return True

    async def complete(self, service_id: str, idempotency_key: UUID, event_id: UUID, status: str) -> None:
        key = f"idempotency:{service_id}:{idempotency_key}"
        self._store[key] = {
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": service_id,
            "event_id": str(event_id),
            "status": status,
        }


class RedisIdempotencyStore:
    LUA_SCRIPT = (
        "local existing = redis.call('GET', KEYS[1]); "
        "if existing then return existing; "
        "else redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2]); return false; end"
    )

    def __init__(self, client: Redis):
        self.client = client

    async def claim(self, service_id: str, idempotency_key: UUID, event_id: UUID, ttl_seconds: int) -> bool:
        key = f"idempotency:{service_id}:{idempotency_key}"
        now = datetime.now(timezone.utc)
        payload = json.dumps(
            {
                "processed_at": now.isoformat(),
                "service_id": service_id,
                "event_id": str(event_id),
                "status": "processing",
            }
        )
        raw_existing = await self.client.eval(self.LUA_SCRIPT, 1, key, payload, ttl_seconds)
        if raw_existing in (False, None):
            return True
        if isinstance(raw_existing, bytes):
            raw_existing = raw_existing.decode("utf-8")
        existing = json.loads(raw_existing)
        processed_at = datetime.fromisoformat(existing["processed_at"])
        if existing["status"] == "processing" and now - processed_at > timedelta(minutes=10):
            await self.client.set(key, payload, ex=ttl_seconds)
            LOGGER.warning("Replacing stale idempotency lock for key=%s", key)
            return True
        return existing["status"] not in {"completed", "processing"}

    async def complete(self, service_id: str, idempotency_key: UUID, event_id: UUID, status: str) -> None:
        key = f"idempotency:{service_id}:{idempotency_key}"
        payload = json.dumps(
            {
                "processed_at": datetime.now(timezone.utc).isoformat(),
                "service_id": service_id,
                "event_id": str(event_id),
                "status": status,
            }
        )
        await self.client.set(key, payload, keepttl=True, xx=True)


class CapabilityRegistryKafkaConsumer:
    def __init__(self, registry_service: RegistryService, idempotency_store: RedisIdempotencyStore | MemoryIdempotencyStore):
        self.registry_service = registry_service
        self.idempotency_store = idempotency_store

    async def consume(self, envelope: AegisCanonicalEventEnvelope) -> None:
        if envelope.event_type == "tool.created":
            await self.consume_tool_created(envelope)
            return
        if envelope.event_type == "agent.created":
            await self.consume_agent_created(envelope)
            return
        raise ValueError(f"Unsupported event_type {envelope.event_type}")

    async def consume_tool_created(self, envelope: AegisCanonicalEventEnvelope) -> None:
        if not await self.idempotency_store.claim(
            settings.service_id, envelope.idempotency_key, envelope.event_id, settings.idempotency_ttl_seconds
        ):
            KAFKA_MESSAGES.labels(topic="tool.created", result="duplicate").inc()
            return
        try:
            payload = ToolCreatedPayload.model_validate(envelope.payload)
            await self.registry_service.register_tool(payload.tool_entry)
        except DuplicateToolError:
            LOGGER.info("Duplicate tool registration suppressed for event_id=%s", envelope.event_id)
        except Exception:
            await self.idempotency_store.complete(
                settings.service_id, envelope.idempotency_key, envelope.event_id, "failed"
            )
            KAFKA_MESSAGES.labels(topic="tool.created", result="failed").inc()
            raise
        await self.idempotency_store.complete(settings.service_id, envelope.idempotency_key, envelope.event_id, "completed")
        KAFKA_MESSAGES.labels(topic="tool.created", result="processed").inc()

    async def consume_agent_created(self, envelope: AegisCanonicalEventEnvelope) -> None:
        if not await self.idempotency_store.claim(
            settings.service_id, envelope.idempotency_key, envelope.event_id, settings.idempotency_ttl_seconds
        ):
            KAFKA_MESSAGES.labels(topic="agent.created", result="duplicate").inc()
            return
        try:
            payload = AgentCreatedPayload.model_validate(envelope.payload)
            entry = CapabilityRegistryEntry(
                agent_id=payload.agent_spec.agent_spec_id,
                agent_type=self._derive_agent_type(payload.agent_spec.capability_type),
                capability_type=payload.agent_spec.capability_type,
                model_tier=payload.agent_spec.llm_config.model_tier,
                llm_config=payload.agent_spec.llm_config,
                tool_ids=payload.agent_spec.tool_ids,
                health_status=CapabilityHealthStatus.HEALTHY,
                trust_score=1.0 if payload.sandbox_test_results.passed else 0.0,
                version=payload.agent_spec.version,
                is_dynamic=True,
                registered_at=payload.created_at,
            )
            await self.registry_service.register_capability(entry)
        except DuplicateAgentError:
            LOGGER.info("Duplicate capability registration suppressed for event_id=%s", envelope.event_id)
        except Exception:
            await self.idempotency_store.complete(
                settings.service_id, envelope.idempotency_key, envelope.event_id, "failed"
            )
            KAFKA_MESSAGES.labels(topic="agent.created", result="failed").inc()
            raise
        await self.idempotency_store.complete(settings.service_id, envelope.idempotency_key, envelope.event_id, "completed")
        KAFKA_MESSAGES.labels(topic="agent.created", result="processed").inc()

    @staticmethod
    def _derive_agent_type(capability_type: str) -> AgentType:
        return AgentType(capability_type)


async def build_idempotency_store() -> RedisIdempotencyStore | MemoryIdempotencyStore:
    try:
        client = Redis.from_url(settings.redis_url, decode_responses=False)
        await client.ping()
    except RedisError:
        LOGGER.warning("Redis unavailable, falling back to in-memory idempotency store")
        return MemoryIdempotencyStore()
    return RedisIdempotencyStore(client)
