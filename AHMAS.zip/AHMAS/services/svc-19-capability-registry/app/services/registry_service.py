from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from sqlalchemy import JSON, Boolean, DateTime, Float, Integer, String, UniqueConstraint, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from ..db.connection import Base
from ..models.capability import (
    AgentType,
    CapabilityHealthStatus,
    CapabilityRegistryEntry,
    CapabilityRouteType,
    CapabilityStatusUpdateResponse,
    TrustScoreUpdateResponse,
)
from ..models.tool import ToolRegistryEntry, ToolUsageUpdateResponse
from .metrics import CAPABILITY_REGISTRATIONS, TOOL_REGISTRATIONS


class DuplicateAgentError(Exception):
    pass


class DuplicateToolError(Exception):
    pass


class CapabilityNotFoundError(Exception):
    pass


class ToolNotFoundError(Exception):
    pass


class CapabilityRecord(Base):
    __tablename__ = "capability_registry_entries"

    agent_id: Mapped[str] = mapped_column(String, primary_key=True)
    agent_type: Mapped[str] = mapped_column(String, nullable=False)
    capability_type: Mapped[str] = mapped_column(String, nullable=False, index=True)
    model_tier: Mapped[str] = mapped_column(String, nullable=False)
    llm_config: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    tool_ids: Mapped[list[str]] = mapped_column(JSON, nullable=False)
    health_status: Mapped[str] = mapped_column(String, nullable=False)
    trust_score: Mapped[float] = mapped_column(Float, nullable=False)
    version: Mapped[str] = mapped_column(String, nullable=False)
    is_dynamic: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ToolRecord(Base):
    __tablename__ = "tool_registry_entries"
    __table_args__ = (UniqueConstraint("name", "version", name="uq_tool_name_version"),)

    tool_id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(String, nullable=False)
    capability_type: Mapped[str] = mapped_column(String, nullable=False, index=True)
    interface: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    runtime: Mapped[str] = mapped_column(String, nullable=False)
    code_path: Mapped[str] = mapped_column(String, nullable=False)
    version: Mapped[str] = mapped_column(String, nullable=False)
    created_by: Mapped[str] = mapped_column(String, nullable=False)
    sandbox_test_results: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    usage_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class RegistryService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def list_capabilities(self) -> list[CapabilityRegistryEntry]:
        result = await self.session.execute(select(CapabilityRecord).order_by(CapabilityRecord.registered_at))
        return [self._capability_model_from_record(row) for row in result.scalars().all()]

    async def get_capabilities_by_type(self, capability_type: CapabilityRouteType) -> list[CapabilityRegistryEntry]:
        stmt = select(CapabilityRecord)
        if capability_type == CapabilityRouteType.DYNAMIC:
            stmt = stmt.where(CapabilityRecord.is_dynamic.is_(True))
        else:
            value = capability_type.value
            stmt = stmt.where(
                (CapabilityRecord.agent_type == value) | (CapabilityRecord.capability_type == value)
            )
        result = await self.session.execute(stmt.order_by(CapabilityRecord.registered_at))
        records = result.scalars().all()
        if not records:
            raise CapabilityNotFoundError
        return [self._capability_model_from_record(row) for row in records]

    async def register_capability(self, entry: CapabilityRegistryEntry) -> CapabilityRegistryEntry:
        now = datetime.now(timezone.utc)
        record = CapabilityRecord(
            agent_id=entry.agent_id,
            agent_type=entry.agent_type.value,
            capability_type=entry.capability_type,
            model_tier=entry.model_tier.value,
            llm_config=entry.llm_config.model_dump(mode="json"),
            tool_ids=[str(tool_id) for tool_id in entry.tool_ids],
            health_status=entry.health_status.value,
            trust_score=max(0.0, min(1.0, entry.trust_score)),
            version=entry.version,
            is_dynamic=entry.is_dynamic,
            registered_at=entry.registered_at,
            updated_at=now,
        )
        self.session.add(record)
        try:
            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            CAPABILITY_REGISTRATIONS.labels(result="duplicate").inc()
            raise DuplicateAgentError from exc
        CAPABILITY_REGISTRATIONS.labels(result="created").inc()
        return self._capability_model_from_record(record)

    async def update_trust_score(self, agent_id: str, trust_score_delta: float) -> TrustScoreUpdateResponse:
        record = await self.session.get(CapabilityRecord, agent_id)
        if record is None:
            raise CapabilityNotFoundError
        record.trust_score = max(0.0, min(1.0, float(record.trust_score) + float(trust_score_delta)))
        record.updated_at = datetime.now(timezone.utc)
        await self.session.commit()
        return TrustScoreUpdateResponse(agent_id=agent_id, new_trust_score=record.trust_score)

    async def update_status(
        self, agent_id: str, health_status: CapabilityHealthStatus
    ) -> CapabilityStatusUpdateResponse:
        record = await self.session.get(CapabilityRecord, agent_id)
        if record is None:
            raise CapabilityNotFoundError
        record.health_status = health_status.value
        record.updated_at = datetime.now(timezone.utc)
        await self.session.commit()
        return CapabilityStatusUpdateResponse(
            agent_id=agent_id,
            health_status=health_status,
            updated_at=record.updated_at,
        )

    async def list_tools(self) -> list[ToolRegistryEntry]:
        result = await self.session.execute(select(ToolRecord).order_by(ToolRecord.created_at))
        return [self._tool_model_from_record(row) for row in result.scalars().all()]

    async def get_tool(self, tool_id: str) -> ToolRegistryEntry:
        record = await self.session.get(ToolRecord, str(tool_id))
        if record is None:
            raise ToolNotFoundError
        return self._tool_model_from_record(record)

    async def register_tool(self, entry: ToolRegistryEntry) -> ToolRegistryEntry:
        if not entry.sandbox_test_results.passed:
            raise ValueError("sandbox tests not passed")
        record = ToolRecord(
            tool_id=str(entry.tool_id),
            name=entry.name,
            description=entry.description,
            capability_type=entry.capability_type,
            interface=entry.interface.model_dump(mode="json"),
            runtime=entry.runtime.value,
            code_path=entry.code_path,
            version=entry.version,
            created_by=entry.created_by,
            sandbox_test_results=entry.sandbox_test_results.model_dump(mode="json"),
            usage_count=entry.usage_count,
            created_at=entry.created_at,
        )
        self.session.add(record)
        try:
            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            TOOL_REGISTRATIONS.labels(result="duplicate").inc()
            raise DuplicateToolError from exc
        TOOL_REGISTRATIONS.labels(result="created").inc()
        return self._tool_model_from_record(record)

    async def increment_tool_usage(self, tool_id: str) -> ToolUsageUpdateResponse:
        record = await self.session.get(ToolRecord, str(tool_id))
        if record is None:
            raise ToolNotFoundError
        record.usage_count += 1
        await self.session.commit()
        return ToolUsageUpdateResponse(tool_id=UUID(record.tool_id), usage_count=record.usage_count)

    def _capability_model_from_record(self, record: CapabilityRecord) -> CapabilityRegistryEntry:
        return CapabilityRegistryEntry(
            agent_id=record.agent_id,
            agent_type=AgentType(record.agent_type),
            capability_type=record.capability_type,
            model_tier=record.model_tier,
            llm_config=record.llm_config,
            tool_ids=record.tool_ids,
            health_status=record.health_status,
            trust_score=record.trust_score,
            version=record.version,
            is_dynamic=record.is_dynamic,
            registered_at=record.registered_at,
        )

    def _tool_model_from_record(self, record: ToolRecord) -> ToolRegistryEntry:
        return ToolRegistryEntry(
            tool_id=record.tool_id,
            name=record.name,
            description=record.description,
            capability_type=record.capability_type,
            interface=record.interface,
            runtime=record.runtime,
            code_path=record.code_path,
            version=record.version,
            created_by=record.created_by,
            sandbox_test_results=record.sandbox_test_results,
            usage_count=record.usage_count,
            created_at=record.created_at,
        )
