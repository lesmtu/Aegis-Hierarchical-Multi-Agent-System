CREATE TABLE IF NOT EXISTS capability_registry_entries (
    agent_id TEXT PRIMARY KEY,
    agent_type TEXT NOT NULL,
    capability_type TEXT NOT NULL,
    model_tier TEXT NOT NULL,
    llm_config JSON NOT NULL,
    tool_ids JSON NOT NULL,
    health_status TEXT NOT NULL,
    trust_score DOUBLE PRECISION NOT NULL,
    version TEXT NOT NULL,
    is_dynamic BOOLEAN NOT NULL DEFAULT FALSE,
    registered_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS tool_registry_entries (
    tool_id UUID PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    capability_type TEXT NOT NULL,
    interface JSON NOT NULL,
    runtime TEXT NOT NULL,
    code_path TEXT NOT NULL,
    version TEXT NOT NULL,
    created_by TEXT NOT NULL,
    sandbox_test_results JSON NOT NULL,
    usage_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL,
    UNIQUE (name, version)
);

CREATE TABLE IF NOT EXISTS processed_events (
    service_id TEXT NOT NULL,
    idempotency_key UUID NOT NULL,
    event_id UUID NOT NULL,
    status TEXT NOT NULL,
    processed_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (service_id, idempotency_key)
);
