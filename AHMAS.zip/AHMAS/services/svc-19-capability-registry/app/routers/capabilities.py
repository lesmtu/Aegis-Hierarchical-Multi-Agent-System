from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, Request

from ..db.connection import get_session
from ..models.common import APIErrorResponse
from ..models.capability import (
    CapabilityListResponse,
    CapabilityRegisterResponse,
    CapabilityRegistryEntry,
    CapabilityRouteType,
    CapabilityStatusUpdateRequest,
    CapabilityStatusUpdateResponse,
    CapabilityTypeResponse,
    TrustScoreUpdateRequest,
    TrustScoreUpdateResponse,
)
from ..services.errors import build_error_response, request_id_from
from ..services.registry_service import CapabilityNotFoundError, DuplicateAgentError, RegistryService

router = APIRouter(tags=["capabilities"])


async def get_registry_service(session=Depends(get_session)) -> RegistryService:
    return RegistryService(session)


@router.get("/capabilities", response_model=CapabilityListResponse)
async def list_capabilities(svc: RegistryService = Depends(get_registry_service)) -> CapabilityListResponse:
    capabilities = await svc.list_capabilities()
    return CapabilityListResponse(capabilities=capabilities, total=len(capabilities))


@router.get(
    "/capabilities/{type}",
    response_model=CapabilityTypeResponse,
    responses={404: {"model": APIErrorResponse, "description": "No agents found for capability type"}},
)
async def get_capabilities_by_type(
    type: CapabilityRouteType,
    request: Request,
    svc: RegistryService = Depends(get_registry_service),
):
    try:
        agents = await svc.get_capabilities_by_type(type)
    except CapabilityNotFoundError:
        return build_error_response(
            status_code=404,
            error_code="CAPABILITY_NOT_FOUND",
            message=f"No agents found for capability type: {type.value}",
            request_id=request_id_from(request),
        )
    return CapabilityTypeResponse(capability_type=type.value, agents=agents)


@router.post(
    "/capabilities/register",
    response_model=CapabilityRegisterResponse,
    status_code=201,
    responses={
        400: {"model": APIErrorResponse, "description": "Invalid capability spec"},
        409: {"model": APIErrorResponse, "description": "Agent ID already registered"},
    },
)
async def register_capability(
    entry: CapabilityRegistryEntry,
    request: Request,
    svc: RegistryService = Depends(get_registry_service),
):
    try:
        created = await svc.register_capability(entry)
    except DuplicateAgentError:
        return build_error_response(
            status_code=409,
            error_code="INVALID_PAYLOAD",
            message="Agent ID already registered",
            request_id=request_id_from(request),
        )
    return CapabilityRegisterResponse(agent_id=created.agent_id, registered_at=created.registered_at)


@router.patch(
    "/capabilities/{agent_id}/trust_score",
    response_model=TrustScoreUpdateResponse,
    responses={404: {"model": APIErrorResponse, "description": "Agent not found"}},
)
async def update_trust_score(
    agent_id: str,
    payload: TrustScoreUpdateRequest,
    request: Request,
    svc: RegistryService = Depends(get_registry_service),
):
    try:
        return await svc.update_trust_score(agent_id, payload.trust_score_delta)
    except CapabilityNotFoundError:
        return build_error_response(
            status_code=404,
            error_code="CAPABILITY_NOT_FOUND",
            message=f"Agent not found: {agent_id}",
            request_id=request_id_from(request),
        )


@router.patch(
    "/capabilities/{agent_id}/status",
    response_model=CapabilityStatusUpdateResponse,
    responses={404: {"model": APIErrorResponse, "description": "Agent not found"}},
)
async def update_status(
    agent_id: str,
    payload: CapabilityStatusUpdateRequest,
    request: Request,
    svc: RegistryService = Depends(get_registry_service),
):
    try:
        return await svc.update_status(agent_id, payload.health_status)
    except CapabilityNotFoundError:
        return build_error_response(
            status_code=404,
            error_code="CAPABILITY_NOT_FOUND",
            message=f"Agent not found: {agent_id}",
            request_id=request_id_from(request),
        )
