from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Request, Response

from ..config import settings
from ..models.common import DependencyHealthStatus, HealthCheckResponse, HealthCheckStatus
from ..services.metrics import metrics_response

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthCheckResponse, responses={503: {"model": HealthCheckResponse}})
async def health(request: Request, response: Response) -> HealthCheckResponse:
    dependencies = {
        "database": getattr(request.app.state, "database_status", DependencyHealthStatus.UNKNOWN),
        "redis": getattr(request.app.state, "redis_status", DependencyHealthStatus.UNKNOWN),
    }
    status = HealthCheckStatus.HEALTHY
    if HealthCheckStatus.UNHEALTHY.value in [value.value for value in dependencies.values()]:
        status = HealthCheckStatus.UNHEALTHY
        response.status_code = 503
    elif HealthCheckStatus.DEGRADED.value in [value.value for value in dependencies.values()]:
        status = HealthCheckStatus.DEGRADED
    return HealthCheckResponse(
        service_id=settings.service_id,
        status=status,
        version=settings.service_version,
        dependencies=dependencies,
        timestamp=datetime.now(timezone.utc),
    )


@router.get(
    "/metrics",
    response_class=Response,
    responses={
        200: {
            "description": "Metrics returned",
            "content": {"text/plain; version=0.0.4": {"schema": {"type": "string"}}},
        }
    },
)
async def metrics():
    return metrics_response()
