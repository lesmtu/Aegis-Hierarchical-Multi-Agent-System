from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, Request

from ..db.connection import get_session
from ..models.common import APIErrorResponse
from ..models.tool import ToolListResponse, ToolRegisterResponse, ToolRegistryEntry, ToolUsageUpdateResponse
from ..services.errors import build_error_response, request_id_from
from ..services.registry_service import DuplicateToolError, RegistryService, ToolNotFoundError

router = APIRouter(tags=["tools"])


async def get_registry_service(session=Depends(get_session)) -> RegistryService:
    return RegistryService(session)


@router.get("/tools", response_model=ToolListResponse)
async def list_tools(svc: RegistryService = Depends(get_registry_service)) -> ToolListResponse:
    tools = await svc.list_tools()
    return ToolListResponse(tools=tools, total=len(tools))


@router.get(
    "/tools/{tool_id}",
    response_model=ToolRegistryEntry,
    responses={404: {"model": APIErrorResponse, "description": "Tool not found"}},
)
async def get_tool(tool_id: UUID, request: Request, svc: RegistryService = Depends(get_registry_service)):
    try:
        return await svc.get_tool(tool_id)
    except ToolNotFoundError:
        return build_error_response(
            status_code=404,
            error_code="CAPABILITY_NOT_FOUND",
            message=f"Tool not found: {tool_id}",
            request_id=request_id_from(request),
        )


@router.post(
    "/tools/register",
    response_model=ToolRegisterResponse,
    status_code=201,
    responses={
        400: {"model": APIErrorResponse, "description": "Invalid tool spec or sandbox tests not passed"},
        409: {"model": APIErrorResponse, "description": "Tool with same name and version already registered"},
    },
)
async def register_tool(
    entry: ToolRegistryEntry,
    request: Request,
    svc: RegistryService = Depends(get_registry_service),
):
    try:
        created = await svc.register_tool(entry)
    except DuplicateToolError:
        return build_error_response(
            status_code=409,
            error_code="INVALID_PAYLOAD",
            message="Tool with same name and version already registered",
            request_id=request_id_from(request),
        )
    except ValueError:
        return build_error_response(
            status_code=400,
            error_code="INVALID_PAYLOAD",
            message="Invalid tool spec or sandbox tests not passed",
            request_id=request_id_from(request),
        )
    return ToolRegisterResponse(tool_id=created.tool_id, registered_at=created.created_at)


@router.patch(
    "/tools/{tool_id}/usage",
    response_model=ToolUsageUpdateResponse,
    responses={404: {"model": APIErrorResponse, "description": "Tool not found"}},
)
async def increment_tool_usage(tool_id: UUID, request: Request, svc: RegistryService = Depends(get_registry_service)):
    try:
        return await svc.increment_tool_usage(tool_id)
    except ToolNotFoundError:
        return build_error_response(
            status_code=404,
            error_code="CAPABILITY_NOT_FOUND",
            message=f"Tool not found: {tool_id}",
            request_id=request_id_from(request),
        )
