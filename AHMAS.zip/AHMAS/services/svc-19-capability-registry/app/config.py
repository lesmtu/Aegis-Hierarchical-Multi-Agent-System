from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SVC19_", case_sensitive=False)

    service_id: str = "SVC-19"
    service_version: str = "1.0.0"
    service_title: str = "Aegis HMAS SVC-19 Capability Registry"
    log_level: str = "INFO"
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/aegis_svc19"
    redis_url: str = "redis://localhost:6379/0"
    idempotency_ttl_seconds: int = Field(default=86400, ge=1)
    health_unhealthy_threshold: int = Field(default=2, ge=1)


settings = Settings()
