from __future__ import annotations

import sys
import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import pytest

SERVICE_ROOT = Path("/home/g/AHMAS/services/svc-11-auditor")
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
if "/home/g/AHMAS" not in sys.path:
    sys.path.insert(0, "/home/g/AHMAS")

from app.services.auditor import AuditEnvelope, AuditorService  # noqa: E402
from libs.lib01_reflection.result import ReflectionResult  # noqa: E402


class FakeReflectionEngine:
    def evaluate(self, task_description, output, context):
        return ReflectionResult(
            confidence_score=0.5,
            identified_gaps=["Missing justification"],
            correction_suggestions=["Add supporting detail"],
            should_retry=True,
            should_escalate=False,
        )


class FakeProducer:
    def __init__(self):
        self.produced = []

    async def produce_envelope(self, topic, payload, source_service, correlation_id, trace_id):
        @dataclass
        class ProducedEvent:
            event_type: str
            payload: dict
            source_service: str
            correlation_id: str
            trace_id: str

        self.produced.append(ProducedEvent(topic, payload, source_service, correlation_id, trace_id))


class FakeIdempotency:
    def __init__(self):
        self.completed = []

    def check_and_set(self, idempotency_key, event_id):
        return True

    def mark_completed(self, idempotency_key, event_id):
        self.completed.append((idempotency_key, event_id))


class FakeResponse:
    def __init__(self, status_code):
        self.status_code = status_code


class FakeSvc21Client:
    def __init__(self):
        self.post_calls = []

    async def post(self, url, json):
        self.post_calls.append({"url": url, "json": json})
        return FakeResponse(201)

    def post_called_with_url(self, url):
        return any(call["url"] == url for call in self.post_calls)


def valid_result(**overrides):
    payload = {
        "task_id": str(uuid4()),
        "node_id": str(uuid4()),
        "dag_id": str(uuid4()),
        "agent_id": "agent-1",
        "agent_type": "code",
        "input": "Implement the feature",
        "output": {"status": "ok"},
        "confidence": 0.91,
        "needs_review": False,
        "degraded_mode": False,
        "tools_used": [],
        "rag_sources": [],
        "reflection_log": [],
        "metadata": {"token_count": 10},
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    payload.update(overrides)
    return payload


def build_auditor():
    producer = FakeProducer()
    svc21_client = FakeSvc21Client()
    auditor = AuditorService(FakeReflectionEngine(), svc21_client, producer, FakeIdempotency())
    return auditor, producer, svc21_client


def build_envelope(payload):
    return AuditEnvelope(
        event_id=str(uuid4()),
        idempotency_key=str(uuid4()),
        correlation_id=payload["task_id"],
        trace_id=str(uuid4()),
        payload=payload,
    )


def test_validation_status_only_three_values():
    """contracts.json TaskValidatedPayload: validation_status = passed|failed|escalated ONLY"""
    auditor, _, _ = build_auditor()
    for status in ("passed", "failed", "escalated"):
        assert status in ("passed", "failed", "escalated")
    with pytest.raises(AssertionError):
        import asyncio

        asyncio.run(
            auditor._emit_task_validated(
                payload=valid_result(),
                envelope=build_envelope(valid_result()),
                validation_status="invalid",
                checks=auditor._checks(
                    logical_consistency=False,
                    data_validity=False,
                    confidence_threshold=False,
                ),
            )
        )


def test_retry_required_not_task_failed_when_retries_remain():
    """contracts.json: emit retry.required (not task.failed) when retry_count < max"""
    auditor, producer, _ = build_auditor()
    payload = {**valid_result(), "confidence": 0.5, "retry_count": 0, "needs_review": True}
    envelope = build_envelope(payload)
    asyncio.run(auditor.audit_task_result(envelope))
    produced = [e.event_type for e in producer.produced]
    assert "retry.required" in produced
    assert "task.failed" not in produced
    assert "task.validated" not in produced


def test_escalated_after_max_retries():
    """After max_retries_before_escalation=3, emit task.validated: escalated"""
    auditor, producer, _ = build_auditor()
    payload = {**valid_result(), "confidence": 0.5, "retry_count": 3, "needs_review": True}
    envelope = build_envelope(payload)
    asyncio.run(auditor.audit_task_result(envelope))
    validated = [e for e in producer.produced if e.event_type == "task.validated"][0]
    assert validated.payload["validation_status"] == "escalated"


def test_svc21_save_called_on_escalation():
    """contracts.json: POST /prompt/save on SVC-21 after escalated validation"""
    auditor, _, svc21_client = build_auditor()
    payload = {**valid_result(), "confidence": 0.5, "retry_count": 3, "needs_review": True}
    envelope = build_envelope(payload)
    asyncio.run(auditor.audit_task_result(envelope))
    assert svc21_client.post_called_with_url("/prompt/save")
    save_body = svc21_client.post_calls[0]["json"]
    assert save_body["saved_by"] == "SVC-11"
    assert save_body["source"] == "generated"


def test_correction_guidance_in_retry_required():
    """contracts.json: correction_guidance_from_reflection=true"""
    auditor, producer, _ = build_auditor()
    payload = {**valid_result(), "confidence": 0.5, "retry_count": 0, "needs_review": True}
    envelope = build_envelope(payload)
    asyncio.run(auditor.audit_task_result(envelope))
    retry_event = [e for e in producer.produced if e.event_type == "retry.required"][0]
    assert retry_event.payload["correction_guidance"] is not None
    assert len(retry_event.payload["correction_guidance"]) > 0
