from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class RetryRequiredPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    task_id: str
    node_id: str
    dag_id: str
    failure_reason: str = Field(min_length=1)
    correction_guidance: str = Field(min_length=1)
    retry_count: int = Field(ge=0)
    max_retries: int = Field(ge=0)
    created_at: datetime

