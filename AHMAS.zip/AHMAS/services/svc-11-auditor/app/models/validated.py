from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ValidationChecksModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    logical_consistency: bool
    data_validity: bool
    confidence_threshold: bool


class TaskValidatedPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")

    task_id: str
    node_id: str
    dag_id: str
    validation_status: Literal["passed", "failed", "escalated"]
    checks: ValidationChecksModel
    failure_reason: str | None = None
    correction_guidance: str | None = None
    auditor_confidence: float = Field(ge=0.0, le=1.0)
    retry_count: int = Field(ge=0)
    created_at: datetime

