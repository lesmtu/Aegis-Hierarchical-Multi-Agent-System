from __future__ import annotations


class AuditorKafkaConsumer:
    def __init__(self, auditor_service):
        self.auditor_service = auditor_service

    async def consume(self, envelope) -> None:
        await self.auditor_service.audit_task_result(envelope)

