from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from libs.lib01_reflection.result import ReflectionResult

from ..config import settings
from ..models.retry import RetryRequiredPayload
from ..models.validated import TaskValidatedPayload, ValidationChecksModel
from .schema_validator import SchemaValidator

logger = logging.getLogger(__name__)


@dataclass
class AuditEnvelope:
    event_id: str
    idempotency_key: str
    correlation_id: str
    trace_id: str
    payload: dict[str, Any]


class AuditorService:
    CONFIDENCE_THRESHOLD = settings.confidence_threshold
    MAX_RETRIES_BEFORE_ESCALATION = settings.max_retries_before_escalation

    def __init__(self, reflection_engine, svc21_client, producer, idempotency, schema_validator: SchemaValidator | None = None):
        self.reflection = reflection_engine
        self.svc21 = svc21_client
        self.producer = producer
        self.idempotency = idempotency
        self.schema_validator = schema_validator or SchemaValidator()

    async def audit_task_result(self, envelope: AuditEnvelope) -> None:
        if not self.idempotency.check_and_set(envelope.idempotency_key, envelope.event_id):
            return

        payload = envelope.payload
        retry_count = payload.get("retry_count", 0)
        schema_errors = self._validate_schema(payload)
        if schema_errors:
            await self._emit_task_validated(
                payload=payload,
                envelope=envelope,
                validation_status="failed",
                checks=self._checks(logical_consistency=False, data_validity=False, confidence_threshold=False),
                failure_reason=f"Schema validation failed: {schema_errors}",
                correction_guidance="Fix output schema compliance",
                retry_count=retry_count,
            )
            self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)
            return

        confidence = float(payload["confidence"])
        needs_review = payload["needs_review"]
        if confidence >= self.CONFIDENCE_THRESHOLD and not needs_review:
            await self._emit_task_validated(
                payload=payload,
                envelope=envelope,
                validation_status="passed",
                checks=self._checks(logical_consistency=True, data_validity=True, confidence_threshold=True),
                retry_count=retry_count,
            )
            self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)
            return

        reflection: ReflectionResult = self.reflection.evaluate(
            task_description=payload["input"],
            output=str(payload["output"]),
            context={"confidence": confidence, "retry_count": retry_count},
        )
        correction_guidance = self._build_correction_guidance(reflection)
        checks = self._checks(
            logical_consistency=reflection.confidence_score >= self.CONFIDENCE_THRESHOLD,
            data_validity=not bool(reflection.identified_gaps),
            confidence_threshold=confidence >= self.CONFIDENCE_THRESHOLD,
        )
        if retry_count < self.MAX_RETRIES_BEFORE_ESCALATION:
            await self._emit_retry_required(payload, envelope, retry_count, correction_guidance)
            self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)
            return

        await self._emit_task_validated(
            payload=payload,
            envelope=envelope,
            validation_status="escalated",
            checks=checks,
            failure_reason=f"Confidence {confidence:.3f} below threshold after {retry_count} retries",
            correction_guidance=correction_guidance,
            retry_count=retry_count,
        )
        await self._save_failed_pattern_to_svc21(payload, reflection)
        self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)

    async def _emit_task_validated(
        self,
        payload: dict[str, Any],
        envelope: AuditEnvelope,
        validation_status: str,
        checks: ValidationChecksModel,
        failure_reason: str | None = None,
        correction_guidance: str | None = None,
        retry_count: int = 0,
    ) -> None:
        assert validation_status in ("passed", "failed", "escalated"), f"Invalid validation_status: {validation_status}"
        validated_payload = TaskValidatedPayload(
            task_id=payload["task_id"],
            node_id=payload["node_id"],
            dag_id=payload["dag_id"],
            validation_status=validation_status,
            checks=checks,
            failure_reason=failure_reason,
            correction_guidance=correction_guidance,
            auditor_confidence=float(payload.get("confidence", 0.0)),
            retry_count=retry_count,
            created_at=datetime.now(timezone.utc),
        )
        await self.producer.produce_envelope(
            topic="task.validated",
            payload=validated_payload.model_dump(mode="json"),
            source_service="SVC-11",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
        )

    async def _emit_retry_required(
        self,
        payload: dict[str, Any],
        envelope: AuditEnvelope,
        current_retry_count: int,
        correction_guidance: str,
    ) -> None:
        retry_payload = RetryRequiredPayload(
            task_id=payload["task_id"],
            node_id=payload["node_id"],
            dag_id=payload["dag_id"],
            failure_reason=f"Confidence {float(payload['confidence']):.3f} below threshold {self.CONFIDENCE_THRESHOLD}",
            correction_guidance=correction_guidance,
            retry_count=current_retry_count + 1,
            max_retries=self.MAX_RETRIES_BEFORE_ESCALATION,
            created_at=datetime.now(timezone.utc),
        )
        await self.producer.produce_envelope(
            topic="retry.required",
            payload=retry_payload.model_dump(mode="json"),
            source_service="SVC-11",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
        )

    def _build_correction_guidance(self, reflection: ReflectionResult) -> str:
        parts: list[str] = []
        if reflection.identified_gaps:
            parts.append(f"Gaps: {'; '.join(reflection.identified_gaps[:3])}")
        if reflection.correction_suggestions:
            parts.append(f"Suggestions: {'; '.join(reflection.correction_suggestions[:3])}")
        return " | ".join(parts) if parts else "Improve output quality and completeness"

    async def _save_failed_pattern_to_svc21(self, payload: dict[str, Any], reflection: ReflectionResult) -> None:
        try:
            save_request = {
                "description": f"Failed pattern for {payload['agent_type']}: {payload['input'][:100]}",
                "template": (
                    "# FAILED PATTERN — DO NOT USE AS POSITIVE EXAMPLE\n"
                    f"Agent: {payload['agent_type']}\n"
                    f"Task: {payload['input']}\n"
                    f"Failed Output: {str(payload['output'])[:500]}\n"
                    f"Identified Gaps: {'; '.join(reflection.identified_gaps)}\n"
                    f"Correction Suggestions: {'; '.join(reflection.correction_suggestions)}"
                ),
                "capability_type": payload["agent_type"],
                "tags": ["failed_pattern", "audit_escalated", payload["agent_type"]],
                "source": "generated",
                "is_agent_template": False,
                "saved_by": "SVC-11",
                "task_id": payload["task_id"],
                "is_verified": False,
            }
            response = await self.svc21.post("/prompt/save", json=save_request)
            if getattr(response, "status_code", 500) not in (201, 202):
                logger.warning("SVC-11: Failed to save pattern to SVC-21: %s", getattr(response, "status_code", "unknown"))
        except Exception as exc:  # pragma: no cover
            logger.error("SVC-11: SVC-21 save failed (non-critical): %s", exc)

    def _validate_schema(self, payload: dict[str, Any]) -> list[str]:
        return self.schema_validator.validate_task_result(payload)

    @staticmethod
    def _checks(*, logical_consistency: bool, data_validity: bool, confidence_threshold: bool) -> ValidationChecksModel:
        return ValidationChecksModel(
            logical_consistency=logical_consistency,
            data_validity=data_validity,
            confidence_threshold=confidence_threshold,
        )

