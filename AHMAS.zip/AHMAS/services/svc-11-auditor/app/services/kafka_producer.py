from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4


class AuditorKafkaProducer:
    def __init__(self):
        self.produced: list[dict] = []

    async def produce_envelope(
        self,
        topic: str,
        payload: dict,
        source_service: str,
        correlation_id: str,
        trace_id: str,
    ) -> None:
        self.produced.append(
            {
                "event_id": str(uuid4()),
                "event_type": topic,
                "schema_version": "1.0.0",
                "payload_version": "1.0.0",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source_service": source_service,
                "correlation_id": correlation_id,
                "trace_id": trace_id,
                "idempotency_key": str(uuid4()),
                "status": "success",
                "payload": payload,
                "error": None,
            }
        )

