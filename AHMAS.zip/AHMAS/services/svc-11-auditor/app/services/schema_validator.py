from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class SchemaValidator:
    OPTIONAL_RUNTIME_FIELDS = {"retry_count"}

    def __init__(self, contracts_path: Path | None = None):
        self.contracts_path = contracts_path or Path(__file__).resolve().parents[4] / "contracts.json"
        self._contracts = json.loads(self.contracts_path.read_text(encoding="utf-8"))
        self.task_result_schema = self._contracts["global"]["shared_schemas"]["TaskResultPayload"]

    def validate_task_result(self, payload: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        required_fields = self.task_result_schema["required"]
        for field_name in required_fields:
            if field_name not in payload:
                errors.append(f"Missing required field: {field_name}")

        allowed_fields = set(required_fields) | self.OPTIONAL_RUNTIME_FIELDS
        if not errors and set(payload.keys()) - allowed_fields:
            extra_fields = sorted(set(payload.keys()) - allowed_fields)
            for field_name in extra_fields:
                errors.append(f"Unexpected field: {field_name}")

        confidence = payload.get("confidence")
        if confidence is not None and not isinstance(confidence, (int, float)):
            errors.append("confidence must be a number")
        elif confidence is not None and not (0.0 <= float(confidence) <= 1.0):
            errors.append(f"confidence out of range: {confidence}")

        if "needs_review" in payload and not isinstance(payload["needs_review"], bool):
            errors.append("needs_review must be a boolean")
        if "degraded_mode" in payload and not isinstance(payload["degraded_mode"], bool):
            errors.append("degraded_mode must be a boolean")
        if "tools_used" in payload and not isinstance(payload["tools_used"], list):
            errors.append("tools_used must be an array")
        if "rag_sources" in payload and not isinstance(payload["rag_sources"], list):
            errors.append("rag_sources must be an array")
        if "reflection_log" in payload and not isinstance(payload["reflection_log"], list):
            errors.append("reflection_log must be an array")
        if "metadata" in payload and not isinstance(payload["metadata"], dict):
            errors.append("metadata must be an object")
        if "input" in payload and (not isinstance(payload["input"], str) or not payload["input"]):
            errors.append("input must be a non-empty string")
        if "output" in payload and not isinstance(payload["output"], (str, dict)):
            errors.append("output must be a string or object")
        if "agent_id" in payload and (not isinstance(payload["agent_id"], str) or not payload["agent_id"]):
            errors.append("agent_id must be a non-empty string")
        return errors
