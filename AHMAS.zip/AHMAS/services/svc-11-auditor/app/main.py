"""
SVC-11 Auditor Service — production entry point with Kafka lifespan.
Subscribes to: task.result
Produces to: task.validated, retry.required, task.failed, hitl.request, task.dlq
"""
from __future__ import annotations

import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.idempotency.client import IdempotencyClient
from shared.kafka_loop import AioKafkaBackend, SimpleConsumerLoop

from .config import settings
from .services.auditor import AuditorService, AuditEnvelope
from .services.kafka_producer import AuditorKafkaProducer
from .services.schema_validator import SchemaValidator

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
_REDIS_HOST    = os.getenv("REDIS_HOST", "localhost")
_REDIS_PORT    = int(os.getenv("REDIS_PORT", "6379"))
_GROUP_ID      = "svc-11-auditor"
_TOPICS        = ["task.result"]


# ── In-memory Redis fallback ──────────────────────────────────────────────────
class _InMemoryLuaScript:
    def __init__(self, store):
        self._store = store
    def __call__(self, *, keys, args):
        k = keys[0]
        if k in self._store:
            return 0
        self._store[k] = args[0]
        return 1

class _InMemoryRedis:
    def __init__(self):
        self.store: dict = {}
    def register_script(self, _):
        return _InMemoryLuaScript(self.store)
    def get(self, key):
        return self.store.get(key)
    def set(self, key, value, xx=False, keepttl=False):
        if xx and key not in self.store:
            return False
        self.store[key] = value
        return True
    def delete(self, key):
        self.store.pop(key, None)


# ── Reflection stub (SVC-21 call can be wired later) ─────────────────────────
class _StubReflection:
    def evaluate(self, *, task_description, output, context):
        class _R:
            confidence_score = 0.85
            identified_gaps = []
        return _R()


# ── Process function wrapping AuditorService ──────────────────────────────────
def _make_process_fn(auditor: AuditorService):
    async def process(topic: str, message: dict) -> None:
        envelope = AuditEnvelope(
            event_id=message.get("event_id", ""),
            idempotency_key=message.get("idempotency_key", ""),
            correlation_id=message.get("correlation_id", ""),
            trace_id=message.get("trace_id", ""),
            payload=message.get("payload", {}),
        )
        await auditor.audit_task_result(envelope)
    return process


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    redis_client = None
    try:
        import redis as redis_lib
        redis_client = redis_lib.Redis(host=_REDIS_HOST, port=_REDIS_PORT,
                                       decode_responses=True, socket_connect_timeout=5)
        redis_client.ping()
        logger.info("SVC-11 Redis connected")
    except Exception as exc:
        logger.warning("SVC-11 Redis unavailable (%s) — in-memory fallback", exc)
        redis_client = _InMemoryRedis()

    idempotency = IdempotencyClient(redis_client, "SVC-11")
    backend = AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    producer = AuditorKafkaProducer.__new__(AuditorKafkaProducer)
    producer.__dict__.update({"produced": []})
    # Patch producer to actually send via Kafka backend
    import types
    async def _real_produce(self, topic, payload, source_service, correlation_id, trace_id):
        from shared.events.envelope import AegisCanonicalEventEnvelope
        envelope = AegisCanonicalEventEnvelope.create(
            event_type=topic, source_service=source_service,
            payload=payload, correlation_id=correlation_id, trace_id=trace_id,
        )
        backend.send(topic, envelope.to_dict())
    producer.produce_envelope = types.MethodType(_real_produce, producer)

    svc21_stub = type("_SVC21", (), {"base_url": settings.svc21_base_url})()
    auditor = AuditorService(
        reflection_engine=_StubReflection(),
        svc21_client=svc21_stub,
        producer=producer,
        idempotency=idempotency,
        schema_validator=SchemaValidator(),
    )

    loop = SimpleConsumerLoop(
        bootstrap_servers=_KAFKA_BROKERS,
        group_id=_GROUP_ID,
        topics=_TOPICS,
        process_fn=_make_process_fn(auditor),
    )
    await loop.start()
    logger.info("SVC-11 fully started — consuming %s", _TOPICS)
    yield
    await loop.stop()
    await backend.stop()
    logger.info("SVC-11 shutdown complete")


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Aegis HMAS SVC-11 Auditor Service",
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict:
    return {"service_id": settings.service_id, "status": "healthy",
            "version": settings.service_version, "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return ""
