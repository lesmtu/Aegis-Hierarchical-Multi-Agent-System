from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    service_id: str = "SVC-11"
    service_version: str = "1.0.0"
    confidence_threshold: float = float(os.getenv("SVC11_CONFIDENCE_THRESHOLD", "0.75"))
    max_retries_before_escalation: int = int(os.getenv("SVC11_MAX_RETRIES_BEFORE_ESCALATION", "3"))
    svc21_base_url: str = os.getenv("SVC11_SVC21_BASE_URL", "http://svc-21-prompt-intelligence")


settings = Settings()

