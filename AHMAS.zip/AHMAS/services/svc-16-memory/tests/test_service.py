from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from uuid import uuid4

import httpx
from fastapi.testclient import TestClient

from app.dependencies import get_memory_service
from app.main import app
from app.models.common import MemoryType
from app.models.record import MemoryRecord
from app.models.retrieve import MemoryRetrieveResponse
from app.services.qdrant_backend import SearchResult


client = TestClient(app)


def test_store_returns_201():
    response = client.post(
        "/memory/store",
        json={
            "content": "semantic memory",
            "memory_type": "semantic",
            "task_id": None,
            "session_id": None,
            "metadata": {"agent_type": "planner"},
            "create_obsidian_note": False,
            "ttl_seconds": None,
        },
    )
    assert response.status_code == 201
    body = response.json()
    assert "memory_id" in body
    assert "stored_at" in body


def test_memory_retrieve_request_schema():
    response = client.post(
        "/memory/retrieve",
        json={
            "query": "q",
            "session_id": str(uuid4()),
            "task_id": str(uuid4()),
            "top_k": 11,
            "memory_types": ["episodic"],
        },
    )
    assert response.status_code == 400


def test_retrieve_returns_degraded_on_qdrant_failure():
    service = get_memory_service()
    original = service.qdrant_backend.search

    async def failing_search(**_: object):
        raise RuntimeError("qdrant failed")

    service.qdrant_backend.search = failing_search
    try:
        response = client.post(
            "/memory/retrieve",
            json={
                "query": "q",
                "session_id": str(uuid4()),
                "task_id": str(uuid4()),
                "top_k": 5,
                "memory_types": ["episodic"],
            },
        )
    finally:
        service.qdrant_backend.search = original

    assert response.status_code == 200
    assert response.json() == MemoryRetrieveResponse(
        context_chunks=[],
        source_ids=[],
        retrieval_scores=[],
        degraded_mode=True,
    ).model_dump(mode="json")


def test_retrieve_returns_qdrant_only_results_on_obsidian_failure():
    service = get_memory_service()
    original_qdrant_search = service.qdrant_backend.search
    original_obsidian_traverse = service.obsidian_backend.traverse_links
    original_redis_search = service.redis_backend.search_by_session

    session_id = uuid4()
    task_id = uuid4()
    first_qdrant = MemoryRecord(
        memory_id=uuid4(),
        content="semantic result one",
        memory_type=MemoryType.SEMANTIC,
        task_id=task_id,
        session_id=None,
        metadata={"source": "qdrant"},
        retrieval_count=0,
        outcome_score=2.0,
        obsidian_note_path=None,
        created_at=datetime.now(timezone.utc),
    )
    second_qdrant = MemoryRecord(
        memory_id=uuid4(),
        content="semantic result two",
        memory_type=MemoryType.EPISODIC,
        task_id=task_id,
        session_id=None,
        metadata={"source": "qdrant"},
        retrieval_count=0,
        outcome_score=1.0,
        obsidian_note_path=None,
        created_at=datetime.now(timezone.utc),
    )
    working_record = MemoryRecord(
        memory_id=uuid4(),
        content="working context that must be excluded during obsidian fallback",
        memory_type=MemoryType.WORKING,
        task_id=task_id,
        session_id=session_id,
        metadata={"source": "redis"},
        retrieval_count=0,
        outcome_score=10.0,
        obsidian_note_path=None,
        created_at=datetime.now(timezone.utc),
    )

    async def successful_qdrant_search(**_: object) -> list[SearchResult]:
        return [
            SearchResult(record=first_qdrant, similarity_score=0.8),
            SearchResult(record=second_qdrant, similarity_score=0.6),
        ]

    async def failing_obsidian_traverse(_: list[SearchResult]) -> list[SearchResult]:
        raise RuntimeError("obsidian unavailable")

    async def working_memory_results(_: object) -> list[MemoryRecord]:
        return [working_record]

    service.qdrant_backend.search = successful_qdrant_search
    service.obsidian_backend.traverse_links = failing_obsidian_traverse
    service.redis_backend.search_by_session = working_memory_results
    try:
        response = client.post(
            "/memory/retrieve",
            json={
                "query": "q",
                "session_id": str(session_id),
                "task_id": str(task_id),
                "top_k": 5,
                "memory_types": ["semantic", "working"],
            },
        )
    finally:
        service.qdrant_backend.search = original_qdrant_search
        service.obsidian_backend.traverse_links = original_obsidian_traverse
        service.redis_backend.search_by_session = original_redis_search

    assert response.status_code == 200
    assert response.json() == MemoryRetrieveResponse(
        context_chunks=["semantic result one", "semantic result two"],
        source_ids=[first_qdrant.memory_id, second_qdrant.memory_id],
        retrieval_scores=[0.8, 0.6],
        degraded_mode=True,
    ).model_dump(mode="json")


def test_health_response_schema():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["service_id"] == "SVC-16"
    assert body["status"] in ["healthy", "degraded", "unhealthy"]


def test_pipeline_returns_at_most_five_results():
    for idx in range(7):
        client.post(
            "/memory/store",
            json={
                "content": f"memory {idx}",
                "memory_type": "semantic",
                "task_id": None,
                "session_id": None,
                "metadata": {"rank": idx},
                "create_obsidian_note": False,
                "ttl_seconds": None,
            },
        )
    response = client.post(
        "/memory/retrieve",
        json={
            "query": "memory",
            "session_id": str(uuid4()),
            "task_id": str(uuid4()),
            "top_k": 10,
            "memory_types": ["semantic"],
        },
    )
    assert response.status_code == 200
    assert len(response.json()["context_chunks"]) <= 5


def test_http_embedding_backend_uses_openai_compatible_endpoint(monkeypatch):
    service = get_memory_service()
    original_backend = service.embedding_service.backend
    original_base = service.embedding_service.base_url
    original_path = service.embedding_service.api_path
    original_key = service.embedding_service.api_key
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["authorization"] = request.headers.get("Authorization")
        return httpx.Response(200, json={"data": [{"embedding": [0.1, 0.2, 0.3]}]})

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            self.client = httpx.Client(transport=httpx.MockTransport(handler))

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            self.client.close()

        async def post(self, *args, **kwargs):
            return self.client.post(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    service.embedding_service.backend = "http"
    service.embedding_service.base_url = "http://openclaw.local"
    service.embedding_service.api_path = "/v1/embeddings"
    service.embedding_service.api_key = "secret"
    try:
        embedding = asyncio.run(service.embedding_service.embed("hello"))
    finally:
        service.embedding_service.backend = original_backend
        service.embedding_service.base_url = original_base
        service.embedding_service.api_path = original_path
        service.embedding_service.api_key = original_key

    assert embedding == [0.1, 0.2, 0.3]
    assert captured["url"] == "http://openclaw.local/v1/embeddings"
    assert captured["authorization"] == "Bearer secret"


def test_http_embedding_backend_calls_ollama_embeddings_endpoint(monkeypatch):
    service = get_memory_service()
    original_backend = service.embedding_service.backend
    original_base = service.embedding_service.base_url
    original_path = service.embedding_service.api_path
    original_key = service.embedding_service.api_key
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["authorization"] = request.headers.get("Authorization")
        captured["json"] = request.read().decode("utf-8")
        return httpx.Response(200, json={"embedding": [0.9, 0.8, 0.7]})

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            self.client = httpx.Client(transport=httpx.MockTransport(handler))

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            self.client.close()

        async def post(self, *args, **kwargs):
            return self.client.post(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    service.embedding_service.backend = "http"
    service.embedding_service.base_url = "http://ollama.local:11434"
    service.embedding_service.api_path = "/api/embeddings"
    service.embedding_service.api_key = ""
    try:
        embedding = asyncio.run(service.embedding_service.embed("hello"))
    finally:
        service.embedding_service.backend = original_backend
        service.embedding_service.base_url = original_base
        service.embedding_service.api_path = original_path
        service.embedding_service.api_key = original_key

    assert embedding == [0.9, 0.8, 0.7]
    assert captured["url"] == "http://ollama.local:11434/api/embeddings"
    assert captured["authorization"] is None
    assert '"prompt":"hello"' in captured["json"].replace(" ", "")
