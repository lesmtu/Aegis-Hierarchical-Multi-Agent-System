from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, Request, status

from ..dependencies import get_memory_service
from ..models.common import APIErrorResponse
from ..models.record import DeleteMemoryResponse, MemoryRecord, ScoreUpdateRequest, ScoreUpdateResponse
from ..models.retrieve import MemoryRetrieveRequest, MemoryRetrieveResponse
from ..models.store import MemoryStoreRequest, MemoryStoreResponse
from ..services.errors import build_error_response, request_id_from
from ..services.memory_service import MemoryService

router = APIRouter(prefix="/memory", tags=["memory"])

STORE_RESPONSES = {
    400: {"model": APIErrorResponse, "description": "Invalid request payload"},
    500: {"model": APIErrorResponse, "description": "Storage backend error"},
}
RETRIEVE_RESPONSES = {
    400: {"model": APIErrorResponse, "description": "Invalid request payload"},
    500: {"model": APIErrorResponse, "description": "Storage backend error"},
}
NOT_FOUND_RESPONSE = {404: {"model": APIErrorResponse, "description": "Memory record not found"}}


@router.post(
    "/store",
    response_model=MemoryStoreResponse,
    status_code=status.HTTP_201_CREATED,
    responses=STORE_RESPONSES,
)
async def store_memory(request: Request, payload: MemoryStoreRequest, svc: MemoryService = Depends(get_memory_service)) -> MemoryStoreResponse:
    try:
        return await svc.store(payload)
    except Exception as exc:
        return build_error_response(
            status_code=500,
            error_code="MEMORY_STORE_FAILED",
            message="Memory store backend error",
            request_id=request_id_from(request),
            details={"reason": str(exc)},
        )


@router.post(
    "/retrieve",
    response_model=MemoryRetrieveResponse,
    status_code=status.HTTP_200_OK,
    responses=RETRIEVE_RESPONSES,
)
async def retrieve_memory(payload: MemoryRetrieveRequest, svc: MemoryService = Depends(get_memory_service)) -> MemoryRetrieveResponse:
    return await svc.retrieve(payload)


@router.get("/{memory_id}", response_model=MemoryRecord, responses=NOT_FOUND_RESPONSE)
async def get_memory(memory_id: UUID, request: Request, svc: MemoryService = Depends(get_memory_service)) -> MemoryRecord:
    record = await svc.get(memory_id)
    if record is None:
        return build_error_response(
            status_code=404,
            error_code="INVALID_PAYLOAD",
            message="Memory record not found",
            request_id=request_id_from(request),
        )
    return record


@router.delete("/{memory_id}", response_model=DeleteMemoryResponse, responses=NOT_FOUND_RESPONSE)
async def delete_memory(memory_id: UUID, request: Request, svc: MemoryService = Depends(get_memory_service)) -> DeleteMemoryResponse:
    deleted = await svc.delete(memory_id)
    if not deleted:
        return build_error_response(
            status_code=404,
            error_code="INVALID_PAYLOAD",
            message="Memory record not found",
            request_id=request_id_from(request),
        )
    return DeleteMemoryResponse(deleted=True, memory_id=memory_id)


@router.patch(
    "/{memory_id}/score",
    response_model=ScoreUpdateResponse,
    responses=NOT_FOUND_RESPONSE,
)
async def patch_memory_score(
    memory_id: UUID,
    payload: ScoreUpdateRequest,
    request: Request,
    svc: MemoryService = Depends(get_memory_service),
) -> ScoreUpdateResponse:
    new_score = await svc.update_score(memory_id, payload.outcome_delta)
    if new_score is None:
        return build_error_response(
            status_code=404,
            error_code="INVALID_PAYLOAD",
            message="Memory record not found",
            request_id=request_id_from(request),
        )
    return ScoreUpdateResponse(memory_id=memory_id, new_outcome_score=new_score)
