from __future__ import annotations

from fastapi import APIRouter, Depends, Response

from ..dependencies import get_memory_service
from ..models.common import HealthCheckResponse, HealthStatus
from ..services.memory_service import MemoryService
from ..services.metrics import metrics_response

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthCheckResponse, responses={503: {"model": HealthCheckResponse}})
async def health(response: Response, svc: MemoryService = Depends(get_memory_service)) -> HealthCheckResponse:
    payload = await svc.health()
    if payload.status == HealthStatus.UNHEALTHY:
        response.status_code = 503
    return payload


@router.get(
    "/metrics",
    response_class=Response,
    responses={
        200: {
            "description": "Metrics returned",
            "content": {"text/plain; version=0.0.4": {"schema": {"type": "string"}}},
        }
    },
)
async def metrics():
    return metrics_response()
