from __future__ import annotations

import logging
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse

from .config import settings
from .routers.health import router as health_router
from .routers.memory import router as memory_router
from .services.errors import build_error_response, request_id_from
from .services.metrics import REQUEST_COUNT, REQUEST_LATENCY

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))

app = FastAPI(
    title="Aegis HMAS SVC-16 Memory Service",
    version=settings.service_version,
    separate_input_output_schemas=False,
)
app.include_router(memory_router)
app.include_router(health_router)


def custom_openapi():
    if app.openapi_schema is not None:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.middleware("http")
async def request_context(request: Request, call_next):
    request.state.request_id = uuid4()
    path = request.url.path
    method = request.method
    started = perf_counter()
    response = None
    try:
        response = await call_next(request)
    finally:
        REQUEST_LATENCY.labels(method=method, path=path).observe(perf_counter() - started)
    if response is not None:
        REQUEST_COUNT.labels(method=method, path=path, status_code=response.status_code).inc()
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return build_error_response(
        status_code=400,
        error_code="INVALID_PAYLOAD",
        message="Request validation failed",
        request_id=request_id_from(request),
        details={"errors": exc.errors()},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    if request.url.path == "/memory/retrieve":
        return JSONResponse(
            status_code=200,
            content={
                "context_chunks": [],
                "source_ids": [],
                "retrieval_scores": [],
                "degraded_mode": True,
            },
        )
    return build_error_response(
        status_code=500,
        error_code="INTERNAL_ERROR",
        message="Internal server error",
        request_id=request_id_from(request),
        details={"reason": str(exc)},
    )
