from __future__ import annotations

from functools import lru_cache

from .config import settings
from .services.circuit_breaker import CircuitBreakerConfig
from .services.embedding import EmbeddingService
from .services.memory_service import MemoryService
from .services.obsidian_backend import ObsidianBackend
from .services.qdrant_backend import QdrantBackend
from .services.redis_backend import RedisBackend


@lru_cache
def get_memory_service() -> MemoryService:
    embedding_service = EmbeddingService(settings)
    return MemoryService(
        service_id=settings.service_id,
        version=settings.service_version,
        embedding_service=embedding_service,
        qdrant_backend=QdrantBackend(
            embedding_service,
            CircuitBreakerConfig(
                failure_threshold=settings.qdrant_failure_threshold,
                recovery_timeout_seconds=settings.qdrant_recovery_timeout_seconds,
                half_open_max_calls=settings.qdrant_half_open_max_calls,
            ),
        ),
        obsidian_backend=ObsidianBackend(
            settings.obsidian_mount_path,
            CircuitBreakerConfig(
                failure_threshold=settings.obsidian_failure_threshold,
                recovery_timeout_seconds=settings.obsidian_recovery_timeout_seconds,
                half_open_max_calls=settings.obsidian_half_open_max_calls,
            ),
        ),
        redis_backend=RedisBackend(
            CircuitBreakerConfig(
                failure_threshold=settings.redis_failure_threshold,
                recovery_timeout_seconds=settings.redis_recovery_timeout_seconds,
                half_open_max_calls=settings.redis_half_open_max_calls,
            ),
        ),
    )
