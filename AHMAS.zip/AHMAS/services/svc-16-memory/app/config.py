from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SVC16_", case_sensitive=False)

    service_id: str = "SVC-16"
    service_version: str = "1.0.0"
    qdrant_collection: str = "aegis_memory"
    qdrant_url: str = "http://localhost:6333"
    obsidian_mount_path: str = "/data/obsidian-vault"
    redis_url: str = "redis://localhost:6379/0"
    embedding_model_name: str = "bge-m3:latest"
    embedding_backend: str = Field(
        default="stub",
        validation_alias=AliasChoices("SVC16_EMBEDDING_BACKEND"),
    )
    embedding_api_base_url: str = Field(
        default="http://host.docker.internal:11434",
        validation_alias=AliasChoices("SVC16_EMBEDDING_API_BASE_URL", "OPENCLAW_URL"),
    )
    embedding_api_path: str = Field(
        default="/api/embeddings",
        validation_alias=AliasChoices("SVC16_EMBEDDING_API_PATH"),
    )
    embedding_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("SVC16_EMBEDDING_API_KEY"),
    )
    log_level: str = "INFO"
    qdrant_failure_threshold: int = 5
    qdrant_recovery_timeout_seconds: int = 30
    qdrant_half_open_max_calls: int = 2
    redis_failure_threshold: int = 3
    redis_recovery_timeout_seconds: int = 15
    redis_half_open_max_calls: int = 1
    obsidian_failure_threshold: int = 3
    obsidian_recovery_timeout_seconds: int = 60
    obsidian_half_open_max_calls: int = 1
    health_unhealthy_threshold: int = Field(default=2, ge=1)


settings = Settings()
