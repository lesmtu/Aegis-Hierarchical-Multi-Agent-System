from __future__ import annotations

import logging
from datetime import datetime, timezone
from uuid import UUID, uuid4

from ..models.common import DependencyHealthStatus, HealthCheckResponse, HealthStatus, MemoryType
from ..models.record import MemoryRecord
from ..models.retrieve import MemoryRetrieveRequest, MemoryRetrieveResponse
from ..models.store import MemoryStoreRequest, MemoryStoreResponse
from .embedding import EmbeddingService
from .metrics import DEGRADED_MODE_COUNT
from .obsidian_backend import ObsidianBackend
from .qdrant_backend import QdrantBackend, SearchResult
from .redis_backend import RedisBackend

logger = logging.getLogger(__name__)


class MemoryService:
    def __init__(
        self,
        *,
        service_id: str,
        version: str,
        embedding_service: EmbeddingService,
        qdrant_backend: QdrantBackend,
        obsidian_backend: ObsidianBackend,
        redis_backend: RedisBackend,
    ) -> None:
        self.service_id = service_id
        self.version = version
        self.embedding_service = embedding_service
        self.qdrant_backend = qdrant_backend
        self.obsidian_backend = obsidian_backend
        self.redis_backend = redis_backend

    async def store(self, request: MemoryStoreRequest) -> MemoryStoreResponse:
        now = datetime.now(timezone.utc)
        record = MemoryRecord(
            memory_id=uuid4(),
            content=request.content,
            memory_type=request.memory_type,
            task_id=request.task_id,
            session_id=request.session_id,
            metadata=request.metadata,
            retrieval_count=0,
            outcome_score=0.0,
            obsidian_note_path=None,
            created_at=now,
        )
        if request.memory_type == MemoryType.WORKING:
            await self.redis_backend.store(record, request.ttl_seconds)
        else:
            await self.qdrant_backend.store(record)
        if request.create_obsidian_note:
            try:
                record.obsidian_note_path = await self.obsidian_backend.create_note(record)
                if request.memory_type != MemoryType.WORKING:
                    await self.qdrant_backend.store(record)
            except Exception as exc:
                logger.warning("SVC-16 obsidian write skipped: %s", exc)
        return MemoryStoreResponse(memory_id=record.memory_id, stored_at=now)

    async def retrieve(self, request: MemoryRetrieveRequest) -> MemoryRetrieveResponse:
        degraded_mode = False
        qdrant_results: list[SearchResult] = []
        working_results: list[SearchResult] = []
        query_embedding = await self.embedding_service.embed(request.query)

        if MemoryType.WORKING in request.memory_types:
            try:
                working_records = await self.redis_backend.search_by_session(request.session_id)
                working_results = [
                    SearchResult(
                        record=record,
                        similarity_score=self.embedding_service.cosine_similarity(
                            query_embedding, await self.embedding_service.embed(record.content)
                        ),
                    )
                    for record in working_records
                ]
            except Exception as exc:
                logger.warning("SVC-16 working-memory retrieval degraded on Redis failure: %s", exc)
                DEGRADED_MODE_COUNT.labels(backend="redis").inc()
                degraded_mode = True
                working_results = []

        non_working = [memory_type for memory_type in request.memory_types if memory_type != MemoryType.WORKING]
        if non_working:
            try:
                qdrant_results = await self.qdrant_backend.search(
                    query_embedding=query_embedding,
                    top_k=10,
                    memory_types=non_working,
                    session_id=request.session_id,
                    task_id=request.task_id,
                )
            except Exception as exc:
                logger.critical("SVC-16 retrieve degraded on Qdrant failure: %s", exc)
                DEGRADED_MODE_COUNT.labels(backend="qdrant").inc()
                return MemoryRetrieveResponse(
                    context_chunks=[],
                    source_ids=[],
                    retrieval_scores=[],
                    degraded_mode=True,
                )

        combined_results = qdrant_results + working_results
        if qdrant_results:
            try:
                combined_results = await self.obsidian_backend.traverse_links(qdrant_results[:3]) + qdrant_results[3:] + working_results
            except Exception as exc:
                logger.warning("SVC-16 obsidian traversal degraded: %s", exc)
                DEGRADED_MODE_COUNT.labels(backend="obsidian").inc()
                degraded_mode = True
                combined_results = qdrant_results

        ranked = sorted(
            combined_results,
            key=lambda item: item.similarity_score * item.record.outcome_score,
            reverse=True,
        )
        top_results = ranked[: min(request.top_k, 5)]
        await self.qdrant_backend.increment_retrieval_count([item.record.memory_id for item in top_results if item.record.memory_type != MemoryType.WORKING])
        response = MemoryRetrieveResponse(
            context_chunks=[item.record.content for item in top_results],
            source_ids=[item.record.memory_id for item in top_results],
            retrieval_scores=[max(0.0, min(1.0, item.similarity_score)) for item in top_results],
            degraded_mode=degraded_mode,
        )
        return response

    async def get(self, memory_id: UUID) -> MemoryRecord | None:
        record = await self.redis_backend.get(memory_id)
        if record is not None:
            return record
        return await self.qdrant_backend.get(memory_id)

    async def delete(self, memory_id: UUID) -> bool:
        record = await self.get(memory_id)
        if record is None:
            return False
        if record.memory_type == MemoryType.WORKING:
            await self.redis_backend.delete(memory_id)
        else:
            await self.qdrant_backend.delete(memory_id)
        try:
            await self.obsidian_backend.delete_note(record.obsidian_note_path)
        except Exception as exc:
            logger.warning("SVC-16 obsidian delete failed: %s", exc)
        return True

    async def update_score(self, memory_id: UUID, outcome_delta: float) -> float | None:
        record = await self.get(memory_id)
        if record is None:
            return None
        if record.memory_type == MemoryType.WORKING:
            record.outcome_score += outcome_delta
            await self.redis_backend.store(record, None)
            return record.outcome_score
        return await self.qdrant_backend.update_score(memory_id, outcome_delta)

    async def health(self) -> HealthCheckResponse:
        dependencies = {
            "qdrant": DependencyHealthStatus(await self.qdrant_backend.dependency_status()),
            "obsidian": DependencyHealthStatus(await self.obsidian_backend.dependency_status()),
            "redis": DependencyHealthStatus(await self.redis_backend.dependency_status()),
        }
        values = set(dependencies.values())
        if DependencyHealthStatus.UNHEALTHY in values:
            status = HealthStatus.UNHEALTHY
        elif DependencyHealthStatus.DEGRADED in values:
            status = HealthStatus.DEGRADED
        else:
            status = HealthStatus.HEALTHY
        return HealthCheckResponse(
            service_id=self.service_id,
            status=status,
            version=self.version,
            dependencies=dependencies,
            timestamp=datetime.now(timezone.utc),
        )
