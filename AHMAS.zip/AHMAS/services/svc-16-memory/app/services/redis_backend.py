from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import UUID

from ..models.record import MemoryRecord
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig


class RedisBackend:
    def __init__(self, config: CircuitBreakerConfig) -> None:
        self._breaker = CircuitBreaker("redis", config)
        self._records: dict[UUID, tuple[MemoryRecord, datetime | None]] = {}

    async def store(self, record: MemoryRecord, ttl_seconds: int | None) -> None:
        await self._breaker.before_call()
        try:
            expiry = None
            if ttl_seconds is not None:
                expiry = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
            self._records[record.memory_id] = (record, expiry)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()

    async def get(self, memory_id: UUID) -> MemoryRecord | None:
        await self._breaker.before_call()
        try:
            payload = self._records.get(memory_id)
            if payload is None:
                record = None
            else:
                record, expiry = payload
                if expiry is not None and expiry < datetime.now(timezone.utc):
                    self._records.pop(memory_id, None)
                    record = None
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return record

    async def delete(self, memory_id: UUID) -> bool:
        await self._breaker.before_call()
        try:
            existed = self._records.pop(memory_id, None) is not None
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return existed

    async def search_by_session(self, session_id: UUID) -> list[MemoryRecord]:
        await self._breaker.before_call()
        try:
            now = datetime.now(timezone.utc)
            matches: list[MemoryRecord] = []
            expired: list[UUID] = []
            for memory_id, (record, expiry) in self._records.items():
                if expiry is not None and expiry < now:
                    expired.append(memory_id)
                    continue
                if record.session_id in {None, session_id}:
                    matches.append(record)
            for memory_id in expired:
                self._records.pop(memory_id, None)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return matches

    async def dependency_status(self) -> str:
        if self._breaker.state == "open":
            return "unhealthy"
        if self._breaker.failure_count > 0:
            return "degraded"
        return "healthy"
