from __future__ import annotations

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from starlette.responses import Response


REQUEST_COUNT = Counter(
    "aegis_memory_service_requests_total",
    "Total SVC-16 requests",
    ["method", "path", "status_code"],
)
REQUEST_LATENCY = Histogram(
    "aegis_memory_service_request_latency_seconds",
    "SVC-16 request latency",
    ["method", "path"],
)
DEGRADED_MODE_COUNT = Counter(
    "aegis_memory_service_degraded_mode_total",
    "Total degraded responses by backend",
    ["backend"],
)


def metrics_response() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
