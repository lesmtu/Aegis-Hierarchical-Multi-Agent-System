from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerOpenError(RuntimeError):
    pass


@dataclass
class CircuitBreakerConfig:
    failure_threshold: int
    recovery_timeout_seconds: int
    half_open_max_calls: int


class CircuitBreaker:
    def __init__(self, name: str, config: CircuitBreakerConfig) -> None:
        self.name = name
        self.config = config
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_at: datetime | None = None
        self.half_open_calls = 0
        self._lock = asyncio.Lock()

    async def before_call(self) -> None:
        async with self._lock:
            now = datetime.now(timezone.utc)
            if self.state == CircuitState.OPEN:
                if self.last_failure_at is None:
                    raise CircuitBreakerOpenError(self.name)
                if now - self.last_failure_at >= timedelta(seconds=self.config.recovery_timeout_seconds):
                    self.state = CircuitState.HALF_OPEN
                    self.half_open_calls = 0
                else:
                    raise CircuitBreakerOpenError(self.name)
            if self.state == CircuitState.HALF_OPEN:
                if self.half_open_calls >= self.config.half_open_max_calls:
                    raise CircuitBreakerOpenError(self.name)
                self.half_open_calls += 1

    async def on_success(self) -> None:
        async with self._lock:
            self.failure_count = 0
            self.half_open_calls = 0
            self.state = CircuitState.CLOSED
            self.last_failure_at = None

    async def on_failure(self) -> None:
        async with self._lock:
            self.failure_count += 1
            self.last_failure_at = datetime.now(timezone.utc)
            if self.failure_count >= self.config.failure_threshold:
                self.state = CircuitState.OPEN
            elif self.state == CircuitState.HALF_OPEN:
                self.state = CircuitState.OPEN

