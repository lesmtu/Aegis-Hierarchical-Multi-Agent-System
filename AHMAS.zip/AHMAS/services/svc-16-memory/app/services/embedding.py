from __future__ import annotations

import hashlib
from typing import Sequence

import httpx

from ..config import Settings


class EmbeddingService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.model_name = settings.embedding_model_name
        self.backend = settings.embedding_backend.lower()
        self.base_url = settings.embedding_api_base_url.rstrip("/")
        self.api_path = settings.embedding_api_path if settings.embedding_api_path.startswith("/") else f"/{settings.embedding_api_path}"
        self.api_key = settings.embedding_api_key

    async def embed(self, text: str) -> list[float]:
        if self.backend == "http":
            return await self._embed_via_http(text)
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        return [digest[i] / 255.0 for i in range(32)]

    async def _embed_via_http(self, text: str) -> list[float]:
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = self._build_request_payload(text)
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}{self.api_path}",
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
        embedding = self._extract_embedding(response.json())
        if not isinstance(embedding, list) or not embedding:
            raise ValueError("Embedding response must contain a non-empty embedding list")
        return [float(value) for value in embedding]

    def _build_request_payload(self, text: str) -> dict[str, str]:
        if self.api_path == "/api/embeddings":
            return {"model": self.model_name, "prompt": text}
        return {"model": self.model_name, "input": text}

    @staticmethod
    def _extract_embedding(body: object) -> list[float]:
        if not isinstance(body, dict):
            raise ValueError("Invalid embedding response payload")
        embedding = body.get("embedding")
        if embedding is None:
            try:
                embedding = body["data"][0]["embedding"]
            except (KeyError, IndexError, TypeError) as exc:
                raise ValueError("Invalid embedding response payload") from exc
        return embedding

    @staticmethod
    def cosine_similarity(left: Sequence[float], right: Sequence[float]) -> float:
        numerator = sum(a * b for a, b in zip(left, right))
        left_mag = sum(a * a for a in left) ** 0.5
        right_mag = sum(b * b for b in right) ** 0.5
        if left_mag == 0 or right_mag == 0:
            return 0.0
        score = numerator / (left_mag * right_mag)
        return max(0.0, min(1.0, (score + 1.0) / 2.0))
