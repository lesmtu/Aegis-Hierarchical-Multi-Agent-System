from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Iterable
from uuid import UUID

from ..models.common import MemoryType
from ..models.record import MemoryRecord
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig
from .embedding import EmbeddingService

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    record: MemoryRecord
    similarity_score: float


class QdrantBackend:
    def __init__(self, embedding_service: EmbeddingService, config: CircuitBreakerConfig) -> None:
        self._embedding_service = embedding_service
        self._breaker = CircuitBreaker("qdrant", config)
        self._records: dict[UUID, MemoryRecord] = {}
        self._embeddings: dict[UUID, list[float]] = {}

    async def store(self, record: MemoryRecord) -> None:
        await self._breaker.before_call()
        try:
            self._records[record.memory_id] = record
            self._embeddings[record.memory_id] = await self._embedding_service.embed(record.content)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()

    async def get(self, memory_id: UUID) -> MemoryRecord | None:
        await self._breaker.before_call()
        try:
            record = self._records.get(memory_id)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return record

    async def delete(self, memory_id: UUID) -> bool:
        await self._breaker.before_call()
        try:
            existed = memory_id in self._records
            self._records.pop(memory_id, None)
            self._embeddings.pop(memory_id, None)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return existed

    async def update_score(self, memory_id: UUID, outcome_delta: float) -> float | None:
        await self._breaker.before_call()
        try:
            record = self._records.get(memory_id)
            if record is None:
                new_score = None
            else:
                record.outcome_score += outcome_delta
                new_score = record.outcome_score
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return new_score

    async def increment_retrieval_count(self, memory_ids: Iterable[UUID]) -> None:
        for memory_id in memory_ids:
            record = self._records.get(memory_id)
            if record is not None:
                record.retrieval_count += 1

    async def search(
        self,
        query_embedding: list[float],
        top_k: int,
        memory_types: list[MemoryType],
        session_id: UUID,
        task_id: UUID,
    ) -> list[SearchResult]:
        await self._breaker.before_call()
        try:
            candidates: list[SearchResult] = []
            for memory_id, record in self._records.items():
                if record.memory_type not in memory_types:
                    continue
                if record.memory_type == MemoryType.WORKING and record.session_id not in {None, session_id}:
                    continue
                score = self._embedding_service.cosine_similarity(query_embedding, self._embeddings[memory_id])
                candidates.append(SearchResult(record=record, similarity_score=score))
            candidates.sort(key=lambda item: item.similarity_score, reverse=True)
            results = candidates[:top_k]
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return results

    async def dependency_status(self) -> str:
        if self._breaker.state == "open":
            return "unhealthy"
        if self._breaker.failure_count > 0:
            return "degraded"
        return "healthy"
