from __future__ import annotations

import logging
from pathlib import Path
from uuid import UUID

from ..models.record import MemoryRecord
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig
from .qdrant_backend import SearchResult

logger = logging.getLogger(__name__)


class ObsidianBackend:
    def __init__(self, mount_path: str, config: CircuitBreakerConfig) -> None:
        self.mount_path = Path(mount_path)
        self._breaker = CircuitBreaker("obsidian", config)
        self._links: dict[UUID, list[MemoryRecord]] = {}

    async def create_note(self, record: MemoryRecord) -> str | None:
        await self._breaker.before_call()
        try:
            self.mount_path.mkdir(parents=True, exist_ok=True)
            note_path = self.mount_path / f"{record.memory_id}.md"
            note_path.write_text(record.content, encoding="utf-8")
            result = str(note_path)
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return result

    async def delete_note(self, note_path: str | None) -> None:
        if note_path is None:
            return
        await self._breaker.before_call()
        try:
            path = Path(note_path)
            if path.exists():
                path.unlink()
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()

    async def traverse_links(self, top_results: list[SearchResult]) -> list[SearchResult]:
        await self._breaker.before_call()
        try:
            enriched = list(top_results)
            for result in top_results:
                for linked_record in self._links.get(result.record.memory_id, []):
                    enriched.append(SearchResult(record=linked_record, similarity_score=result.similarity_score))
        except Exception:
            await self._breaker.on_failure()
            raise
        await self._breaker.on_success()
        return enriched

    async def dependency_status(self) -> str:
        if self._breaker.state == "open":
            return "unhealthy"
        if self._breaker.failure_count > 0:
            return "degraded"
        return "healthy"
