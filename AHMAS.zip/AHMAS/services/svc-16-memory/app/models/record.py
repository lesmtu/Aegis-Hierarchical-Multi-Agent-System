from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import Field

from .common import MemoryType, StrictBaseModel


class MemoryRecord(StrictBaseModel):
    memory_id: UUID
    content: str = Field(min_length=1)
    memory_type: MemoryType
    task_id: UUID | None = None
    session_id: UUID | None = None
    metadata: dict[str, Any]
    retrieval_count: int = Field(ge=0)
    outcome_score: float
    obsidian_note_path: str | None = None
    created_at: datetime


class DeleteMemoryResponse(StrictBaseModel):
    deleted: bool
    memory_id: UUID


class ScoreUpdateRequest(StrictBaseModel):
    outcome_delta: float


class ScoreUpdateResponse(StrictBaseModel):
    memory_id: UUID
    new_outcome_score: float
