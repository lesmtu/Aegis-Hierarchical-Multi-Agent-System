from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import Field

from .common import MemoryType, StrictBaseModel


class MemoryStoreRequest(StrictBaseModel):
    content: str = Field(min_length=1)
    memory_type: MemoryType
    task_id: UUID | None = None
    session_id: UUID | None = None
    metadata: dict[str, Any]
    create_obsidian_note: bool = False
    ttl_seconds: int | None = Field(default=None, ge=1)


class MemoryStoreResponse(StrictBaseModel):
    memory_id: UUID
    stored_at: datetime
