from __future__ import annotations

from typing import Annotated
from uuid import UUID

from pydantic import Field

from .common import MemoryType, StrictBaseModel


class MemoryRetrieveRequest(StrictBaseModel):
    query: str = Field(min_length=1)
    session_id: UUID
    task_id: UUID
    top_k: int = Field(..., ge=1, le=10, json_schema_extra={"default": 5})
    memory_types: list[MemoryType] = Field(min_length=1)


class MemoryRetrieveResponse(StrictBaseModel):
    context_chunks: list[str] = Field(..., max_length=10)
    source_ids: list[UUID]
    retrieval_scores: list[Annotated[float, Field(ge=0.0, le=1.0)]]
    degraded_mode: bool
