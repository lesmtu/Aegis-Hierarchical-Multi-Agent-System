import os
import subprocess
import sys
import tempfile

from shared.worker_base.base_worker import BaseWorkerAgent


class ToolBuilderAgent(BaseWorkerAgent):
    """
    SVC-09 Worker Agent — Tool Builder.
    contracts.json SVC-09.behavior.sandbox_required_for_code_execution=true
    contracts.json SVC-09.behavior.static_analysis_required=true
    contracts.json SVC-09.behavior.static_analysis_tool="bandit"
    primary_tools: code_executor, tool_registry_client, sandbox
    """

    AGENT_TYPE = "tool_builder"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []

        prompt = f"""Tool building task: {dispatch_payload['sub_task_description']}

Task context:
{dispatch_payload['input_context']}

Context from memory:
{chr(10).join(rag_ctx.context_chunks)}

Correction guidance: {dispatch_payload.get('correction_guidance', 'None')}

Generate a Python tool function with input/output schema."""

        response = await self.llm.complete(prompt)
        code = response.text

        bandit_result = await self._run_bandit(code)
        sandbox_result = await self._execute_in_sandbox(code)

        output = {
            "code": code,
            "bandit_passed": bandit_result["passed"],
            "sandbox_passed": sandbox_result["passed"],
            "bandit_result": bandit_result,
            "sandbox_result": sandbox_result,
        }
        tools_used.extend(["code_executor", "sandbox", "bandit"])
        return output, tools_used

    async def _run_bandit(self, code: str) -> dict:
        """Static analysis with bandit (contracts.json SVC-09.behavior.static_analysis_tool='bandit')"""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as handle:
            handle.write(code.encode())
            tmpfile = handle.name
        try:
            result = subprocess.run(
                ["bandit", "-r", tmpfile, "-f", "json"],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            return {"passed": result.returncode == 0, "output": result.stdout}
        except Exception as exc:
            return {"passed": False, "output": str(exc)}
        finally:
            os.unlink(tmpfile)

    async def _execute_in_sandbox(self, code: str) -> dict:
        try:
            with tempfile.TemporaryDirectory(prefix="svc09-sandbox-") as sandbox_dir:
                result = subprocess.run(
                    [sys.executable, "-I", "-c", code],
                    timeout=30,
                    capture_output=True,
                    text=True,
                    check=False,
                    cwd=sandbox_dir,
                    env={},
                )
                return {
                    "passed": result.returncode == 0,
                    "output": result.stdout,
                    "failure_details": result.stderr if result.returncode != 0 else None,
                }
        except subprocess.TimeoutExpired:
            return {"passed": False, "failure_details": "Execution timeout"}
