from shared.worker_base.base_worker import BaseWorkerAgent


class LogicAgent(BaseWorkerAgent):
    """SVC-06 Worker Agent — Logic. primary_tools: calculator, logic_evaluator, constraint_solver"""

    AGENT_TYPE = "logic"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []
        prompt = f"""Logic/reasoning task: {dispatch_payload['sub_task_description']}

Context: {chr(10).join(rag_ctx.context_chunks)}
Correction guidance: {dispatch_payload.get('correction_guidance', 'None')}

Apply logical reasoning. Show your work step by step."""

        response = await self.llm.complete(prompt)
        return response.text, tools_used
