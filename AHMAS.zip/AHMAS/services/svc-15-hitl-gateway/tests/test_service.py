from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from fastapi.testclient import TestClient

from app.dependencies import get_hitl_service, get_kafka_producer, get_repository, get_scheduler, reset_runtime_state
from app.main import app
from app.models import HITLRespondRequest


def make_client() -> TestClient:
    return TestClient(app)


def setup_function() -> None:
    reset_runtime_state()


def hitl_envelope(*, risk: str = "medium", timeout_hours: int = 24) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    hitl_id = str(uuid4())
    task_id = str(uuid4())
    return {
        "event_id": str(uuid4()),
        "event_type": "hitl.request",
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": now,
        "source_service": "SVC-04",
        "correlation_id": task_id,
        "trace_id": str(uuid4()),
        "idempotency_key": str(uuid4()),
        "status": "success",
        "payload": {
            "hitl_id": hitl_id,
            "task_id": task_id,
            "node_id": str(uuid4()),
            "user_id": "user-1",
            "session_id": str(uuid4()),
            "trigger_reason": "high_risk",
            "risk_classification": risk,
            "context": "Need operator approval",
            "available_actions": ["approve", "reject", "modify", "clarify"],
            "timeout_hours": timeout_hours,
            "created_at": now,
        },
        "error": None,
    }


def run(coro):
    import asyncio

    return asyncio.run(coro)


def test_hitl_already_responded_on_duplicate():
    envelope = hitl_envelope()
    svc = get_hitl_service()
    run(svc.handle_hitl_request(envelope))
    run(svc.record_response(envelope["payload"]["hitl_id"], HITLRespondRequest(decision="approve", responded_by="user-1")))
    try:
        run(svc.record_response(envelope["payload"]["hitl_id"], HITLRespondRequest(decision="reject", responded_by="user-1")))
        assert False, "Expected duplicate response error"
    except Exception as exc:
        assert exc.__class__.__name__ == "HITLAlreadyRespondedError"


def test_auto_timeout_decision_exact_string():
    envelope = hitl_envelope(risk="medium", timeout_hours=1)
    svc = get_hitl_service()
    run(svc.handle_hitl_request(envelope))
    run(svc.auto_reject_timeout(envelope["payload"]["hitl_id"]))
    produced = [event for event in get_kafka_producer().produced if event.event_type == "hitl.response"]
    assert produced[0].payload["decision"] == "timeout_auto_reject"


def test_hitl_response_emitted_on_all_decisions():
    decisions = ["approve", "reject", "modify", "clarify"]
    svc = get_hitl_service()
    producer = get_kafka_producer()
    for decision in decisions:
        envelope = hitl_envelope()
        run(svc.handle_hitl_request(envelope))
        kwargs = {"decision": decision, "responded_by": "operator"}
        if decision == "modify":
            kwargs["modified_output"] = "patched output"
        if decision == "clarify":
            kwargs["clarification_text"] = "need more detail"
        run(svc.record_response(envelope["payload"]["hitl_id"], HITLRespondRequest(**kwargs)))
    envelope = hitl_envelope()
    run(svc.handle_hitl_request(envelope))
    run(svc.auto_reject_timeout(envelope["payload"]["hitl_id"]))
    emitted = [event.payload["decision"] for event in producer.produced if event.event_type == "hitl.response"]
    assert emitted == ["approve", "reject", "modify", "clarify", "timeout_auto_reject"]


def test_postgresql_audit_record_exists():
    envelope = hitl_envelope()
    svc = get_hitl_service()
    run(svc.handle_hitl_request(envelope))
    record = run(get_repository().get_session(envelope["payload"]["hitl_id"]))
    assert record is not None
    assert record.request_payload["hitl_id"] == envelope["payload"]["hitl_id"]


def test_409_on_already_responded():
    envelope = hitl_envelope()
    svc = get_hitl_service()
    run(svc.handle_hitl_request(envelope))
    hitl_id = envelope["payload"]["hitl_id"]
    with make_client() as client:
        response1 = client.post(f"/hitl/{hitl_id}/respond", json={"decision": "approve", "responded_by": "user-1"})
        response2 = client.post(f"/hitl/{hitl_id}/respond", json={"decision": "reject", "responded_by": "user-1"})
    assert response1.status_code == 200
    assert response2.status_code == 409
    assert response2.json()["error_code"] == "HITL_ALREADY_RESPONDED"


def test_scheduler_job_cancelled_after_human_response():
    envelope = hitl_envelope()
    svc = get_hitl_service()
    scheduler = get_scheduler()
    run(svc.handle_hitl_request(envelope))
    hitl_id = envelope["payload"]["hitl_id"]
    assert scheduler.get_job(f"hitl_timeout_{hitl_id}") is not None
    run(svc.record_response(hitl_id, HITLRespondRequest(decision="approve", responded_by="operator")))
    assert f"hitl_timeout_{hitl_id}" in scheduler.removed_jobs


def test_idempotency_enforced_before_processing():
    envelope = hitl_envelope()
    svc = get_hitl_service()
    run(svc.handle_hitl_request(envelope))
    before = len(get_repository().sessions)
    run(svc.handle_hitl_request(envelope))
    after = len(get_repository().sessions)
    assert before == 1
    assert after == 1
