from __future__ import annotations

import json
from dataclasses import dataclass


class InMemoryRedis:
    def __init__(self):
        self.values: dict[str, str] = {}
        self.hashes: dict[str, dict[str, str]] = {}
        self.sorted_sets: dict[str, dict[str, float]] = {}

    def register_script(self, _script: str):
        def runner(*, keys, args):
            key = keys[0]
            if key in self.values:
                return 0
            self.values[key] = args[0]
            return 1

        return runner

    def get(self, key: str):
        return self.values.get(key)

    def set(self, key: str, value: str, xx: bool = False, keepttl: bool = False):
        if xx and key not in self.values:
            return False
        self.values[key] = value
        return True

    def delete(self, key: str):
        self.values.pop(key, None)
        self.hashes.pop(key, None)

    def hset(self, key: str, mapping: dict[str, str]):
        self.hashes.setdefault(key, {}).update(mapping)

    def hgetall(self, key: str) -> dict[str, str]:
        return dict(self.hashes.get(key, {}))

    def zadd(self, key: str, mapping: dict[str, float]):
        self.sorted_sets.setdefault(key, {}).update(mapping)

    def zrem(self, key: str, member: str):
        self.sorted_sets.setdefault(key, {}).pop(member, None)

    def zrangebyscore(self, key: str, minimum: float, maximum: float) -> list[str]:
        items = self.sorted_sets.get(key, {})
        return [member for member, score in items.items() if minimum <= score <= maximum]


@dataclass
class InMemoryProducerBackend:
    messages: list[tuple[str, dict]]

    def __init__(self):
        self.messages = []

    def send(self, topic: str, envelope: dict) -> None:
        self.messages.append((topic, envelope))


class RecordedScheduler:
    def __init__(self):
        self.jobs: dict[str, tuple] = {}
        self.removed_jobs: list[str] = []

    def add_job(self, func, trigger: str, *, id: str, replace_existing: bool = False, args=None, run_date=None, **kwargs):
        if not replace_existing and id in self.jobs:
            raise ValueError(f"Job {id} already exists")
        self.jobs[id] = (func, trigger, args or [], run_date, kwargs)

    def remove_job(self, job_id: str):
        self.removed_jobs.append(job_id)
        self.jobs.pop(job_id, None)

    def get_job(self, job_id: str):
        return self.jobs.get(job_id)

