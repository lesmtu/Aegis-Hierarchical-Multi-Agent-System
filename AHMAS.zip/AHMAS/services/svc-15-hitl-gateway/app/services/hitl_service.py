from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from app.models import (
    HITLDecision,
    HITLRequestPayload,
    HITLRespondRequest,
    HITLResponsePayload,
    HITLStatus,
    HITLStatusResponse,
)
from app.services.errors import HITLAlreadyRespondedError, HITLNotFoundError
from app.services.metrics import HITL_RESPONSES_TOTAL, HITL_STATUS_GAUGE, HITL_TIMEOUT_TOTAL


class HITLService:
    def __init__(self, repository, producer, idempotency, timer_store, scheduler):
        self.repository = repository
        self.producer = producer
        self.idempotency = idempotency
        self.timer_store = timer_store
        self.scheduler = scheduler

    async def handle_hitl_request(self, envelope: dict) -> None:
        idem_key = envelope["idempotency_key"]
        event_id = envelope["event_id"]
        if not self.idempotency.check_and_set(idem_key, event_id):
            return
        try:
            payload = HITLRequestPayload.model_validate(envelope["payload"])
            effective_timeout = self.scheduler.effective_timeout_seconds(payload.risk_classification.value)
            await self.repository.create_session(
                request=payload,
                correlation_id=envelope["correlation_id"],
                trace_id=envelope["trace_id"],
                effective_timeout_seconds=effective_timeout,
            )
            expires_at = datetime.now(timezone.utc) + timedelta(seconds=effective_timeout)
            await self.timer_store.store_session(
                hitl_id=payload.hitl_id,
                request_payload=payload.model_dump(mode="json", exclude_none=True),
                status="pending",
                expires_at=expires_at,
            )
            await self.scheduler.schedule_session(
                hitl_id=payload.hitl_id,
                risk_classification=payload.risk_classification.value,
            )
            HITL_STATUS_GAUGE.labels(hitl_id=payload.hitl_id, status="pending").set(1)
            self.idempotency.mark_completed(idem_key, event_id)
        except Exception:
            self.idempotency.mark_failed(idem_key, event_id)
            raise

    async def record_response(self, hitl_id: str, request: HITLRespondRequest) -> dict:
        session = await self.repository.get_session(hitl_id)
        if session is None:
            raise HITLNotFoundError(hitl_id)
        if session.status not in {"pending", "escalated"}:
            raise HITLAlreadyRespondedError(hitl_id)

        response = HITLResponsePayload(
            hitl_id=hitl_id,
            task_id=session.task_id,
            node_id=session.node_id,
            decision=request.decision,
            modified_output=request.modified_output,
            clarification_text=request.clarification_text,
            responded_by=request.responded_by,
            responded_at=datetime.now(timezone.utc),
        )
        updated = await self.repository.record_response(hitl_id, response, HITLStatus.RESPONDED.value)
        if not updated:
            raise HITLAlreadyRespondedError(hitl_id)
        await self.timer_store.update_status(
            hitl_id=hitl_id,
            status=HITLStatus.RESPONDED.value,
            response_payload=response.model_dump(mode="json", exclude_none=True),
        )
        self.scheduler.cancel_session_jobs(hitl_id)
        await self._emit_hitl_response(response, session.correlation_id, session.trace_id)
        return {
            "hitl_id": hitl_id,
            "accepted": True,
            "timestamp": response.responded_at,
        }

    async def get_status(self, hitl_id: str) -> HITLStatusResponse | None:
        session = await self.repository.get_session(hitl_id)
        if session is None:
            return None
        return HITLStatusResponse(
            hitl_id=hitl_id,
            status=HITLStatus(session.status),
            request=HITLRequestPayload.model_validate(session.request_payload),
            response=HITLResponsePayload.model_validate(session.response_payload) if session.response_payload else None,
            created_at=session.created_at,
        )

    async def escalate_session(self, hitl_id: str) -> None:
        session = await self.repository.get_session(hitl_id)
        if session is None or session.status != HITLStatus.PENDING.value:
            return
        await self.timer_store.update_status(hitl_id=hitl_id, status=HITLStatus.ESCALATED.value, response_payload=None)
        session.status = HITLStatus.ESCALATED.value
        request_payload = dict(session.request_payload)
        request_payload["urgency"] = "critical"
        request_payload["remaining_time_seconds"] = 300
        await self.producer.produce_envelope(
            topic="hitl.request",
            payload=request_payload,
            correlation_id=session.correlation_id,
            trace_id=session.trace_id,
        )

    async def auto_reject_timeout(self, hitl_id: str) -> None:
        session = await self.repository.get_session(hitl_id)
        if session is None or session.status not in {"pending", "escalated"}:
            return
        response = HITLResponsePayload(
            hitl_id=hitl_id,
            task_id=session.task_id,
            node_id=session.node_id,
            decision=HITLDecision.TIMEOUT_AUTO_REJECT,
            responded_by="system_timeout",
            responded_at=datetime.now(timezone.utc),
        )
        await self.repository.record_response(hitl_id, response, HITLStatus.TIMED_OUT.value)
        await self.timer_store.update_status(
            hitl_id=hitl_id,
            status=HITLStatus.TIMED_OUT.value,
            response_payload=response.model_dump(mode="json", exclude_none=True),
        )
        self.scheduler.cancel_session_jobs(hitl_id)
        await self._emit_hitl_response(response, session.correlation_id, session.trace_id)
        await self.producer.emit_timeout_dlq(session_record=session, original_payload=session.request_payload)
        HITL_TIMEOUT_TOTAL.inc()

    async def recover_expired_sessions(self) -> None:
        for hitl_id in await self.timer_store.expired_sessions(datetime.now(timezone.utc)):
            await self.auto_reject_timeout(hitl_id)

    async def _emit_hitl_response(self, response: HITLResponsePayload, correlation_id: str, trace_id: str) -> None:
        await self.producer.produce_envelope(
            topic="hitl.response",
            payload=response.model_dump(mode="json", exclude_none=True),
            correlation_id=correlation_id,
            trace_id=trace_id,
        )
        HITL_RESPONSES_TOTAL.labels(decision=response.decision.value).inc()

