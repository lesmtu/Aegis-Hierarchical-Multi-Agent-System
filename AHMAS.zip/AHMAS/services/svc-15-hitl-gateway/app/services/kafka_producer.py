from __future__ import annotations

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.events.error_codes import AegisErrorCode, build_error_payload


class HITLKafkaProducer:
    def __init__(self, backend):
        self.backend = backend
        self.produced: list[AegisCanonicalEventEnvelope] = []

    async def produce_envelope(
        self,
        *,
        topic: str,
        payload: dict,
        correlation_id: str,
        trace_id: str,
        status: str = "success",
        error: dict | None = None,
        idempotency_key: str | None = None,
    ) -> AegisCanonicalEventEnvelope:
        envelope = AegisCanonicalEventEnvelope.create(
            event_type=topic,
            source_service="SVC-15",
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status=status,
            error=error,
            idempotency_key=idempotency_key,
        )
        self.backend.send(topic, envelope.to_dict())
        self.produced.append(envelope)
        return envelope

    async def emit_timeout_dlq(self, *, session_record, original_payload: dict) -> None:
        error = build_error_payload(
            AegisErrorCode.HITL_TIMEOUT_EXCEEDED,
            f"HITL session {session_record.hitl_id} timed out",
            details={"hitl_id": session_record.hitl_id},
        )
        await self.produce_envelope(
            topic="task.dlq",
            payload={
                "dlq_id": session_record.hitl_id,
                "original_topic": "hitl.request",
                "original_event_id": session_record.hitl_id,
                "original_payload": original_payload,
                "failure_reason": AegisErrorCode.HITL_TIMEOUT_EXCEEDED.value,
                "retry_count": 0,
                "source_service": "SVC-15",
                "created_at": original_payload["created_at"],
            },
            correlation_id=session_record.task_id,
            trace_id=session_record.trace_id,
            status="error",
            error=error,
        )
