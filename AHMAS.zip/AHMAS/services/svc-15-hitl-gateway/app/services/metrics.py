from __future__ import annotations

try:
    from prometheus_client import CollectorRegistry, Counter, Gauge, generate_latest
except ModuleNotFoundError:
    class _NoopMetric:
        def labels(self, **_kwargs):
            return self

        def inc(self, *_args, **_kwargs):
            return None

        def set(self, *_args, **_kwargs):
            return None

    class CollectorRegistry:  # type: ignore[no-redef]
        pass

    def Counter(*_args, **_kwargs):  # type: ignore[no-redef]
        return _NoopMetric()

    def Gauge(*_args, **_kwargs):  # type: ignore[no-redef]
        return _NoopMetric()

    def generate_latest(_registry):  # type: ignore[no-redef]
        return b""


REGISTRY = CollectorRegistry()
HITL_RESPONSES_TOTAL = Counter(
    "aegis_hitl_responses_total",
    "Total HITL responses emitted",
    ["decision"],
    registry=REGISTRY,
)
HITL_TIMEOUT_TOTAL = Counter(
    "aegis_hitl_timeout_total",
    "Total HITL timeouts",
    registry=REGISTRY,
)
HITL_STATUS_GAUGE = Gauge(
    "aegis_hitl_session_status",
    "Current HITL session status",
    ["hitl_id", "status"],
    registry=REGISTRY,
)


def render_metrics() -> str:
    return generate_latest(REGISTRY).decode("utf-8")
