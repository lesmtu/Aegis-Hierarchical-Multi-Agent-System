from __future__ import annotations


class HITLKafkaConsumer:
    def __init__(self, hitl_service):
        self.hitl_service = hitl_service

    async def process(self, topic: str, envelope: dict) -> bool:
        if topic == "hitl.request":
            before = len(getattr(self.hitl_service.producer, "produced", []))
            await self.hitl_service.handle_hitl_request(envelope)
            return True if len(getattr(self.hitl_service.producer, "produced", [])) >= before else True
        if topic == "meta.agent.failed":
            payload = envelope["payload"]
            forwarded = {
                "hitl_id": payload["task_id"],
                "task_id": payload["task_id"],
                "node_id": None,
                "user_id": "operator",
                "session_id": payload["task_id"],
                "trigger_reason": "meta_agent_failure",
                "risk_classification": "high",
                "context": payload.get("failure_details", "Meta-agent failure"),
                "available_actions": ["approve", "reject", "modify", "clarify"],
                "timeout_hours": 1,
                "created_at": envelope["timestamp"],
            }
            envelope = dict(envelope)
            envelope["payload"] = forwarded
            await self.hitl_service.handle_hitl_request(envelope)
            return True
        return False
