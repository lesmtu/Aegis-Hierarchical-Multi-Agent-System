from __future__ import annotations

from datetime import datetime, timedelta, timezone


class RedisTimerStore:
    ACTIVE_KEY = "hitl:active_sessions"

    def __init__(self, redis_client):
        self.redis = redis_client

    def session_key(self, hitl_id: str) -> str:
        return f"hitl:{hitl_id}"

    async def store_session(self, *, hitl_id: str, request_payload: dict, status: str, expires_at: datetime) -> None:
        self.redis.hset(
            self.session_key(hitl_id),
            {
                "status": status,
                "request_payload": __import__("json").dumps(request_payload),
                "response_payload": "null",
                "expires_at": expires_at.isoformat(),
            },
        )
        self.redis.zadd(self.ACTIVE_KEY, {hitl_id: expires_at.timestamp()})

    async def update_status(self, *, hitl_id: str, status: str, response_payload: dict | None) -> None:
        mapping = {"status": status}
        if response_payload is not None:
            mapping["response_payload"] = __import__("json").dumps(response_payload)
        self.redis.hset(self.session_key(hitl_id), mapping)
        if status != "pending":
            self.redis.zrem(self.ACTIVE_KEY, hitl_id)

    async def get_session(self, hitl_id: str) -> dict[str, str]:
        return self.redis.hgetall(self.session_key(hitl_id))

    async def expired_sessions(self, now: datetime) -> list[str]:
        return self.redis.zrangebyscore(self.ACTIVE_KEY, float("-inf"), now.timestamp())


class TimeoutScheduler:
    RISK_TIMEOUT_SECONDS = {
        "low": 1800,
        "medium": 3600,
        "high": 7200,
        "critical": 14400,
    }

    def __init__(self, scheduler, timer_store: RedisTimerStore, hitl_service):
        self.scheduler = scheduler
        self.timer_store = timer_store
        self.hitl_service = hitl_service

    def effective_timeout_seconds(self, risk_classification: str) -> int:
        return self.RISK_TIMEOUT_SECONDS[risk_classification]

    async def schedule_session(self, *, hitl_id: str, risk_classification: str) -> None:
        timeout_seconds = self.effective_timeout_seconds(risk_classification)
        now = datetime.now(timezone.utc)
        warning_at = now + timedelta(seconds=(timeout_seconds * 3) / 4)
        timeout_at = now + timedelta(seconds=timeout_seconds)
        self.scheduler.add_job(
            self.hitl_service.escalate_session,
            "date",
            id=f"hitl_warning_{hitl_id}",
            replace_existing=True,
            args=[hitl_id],
            run_date=warning_at,
        )
        self.scheduler.add_job(
            self.hitl_service.auto_reject_timeout,
            "date",
            id=f"hitl_timeout_{hitl_id}",
            replace_existing=True,
            args=[hitl_id],
            run_date=timeout_at,
        )
        return timeout_seconds

    def cancel_session_jobs(self, hitl_id: str) -> None:
        self.scheduler.remove_job(f"hitl_warning_{hitl_id}")
        self.scheduler.remove_job(f"hitl_timeout_{hitl_id}")

