from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class HITLDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    MODIFY = "modify"
    CLARIFY = "clarify"
    TIMEOUT_AUTO_REJECT = "timeout_auto_reject"


class RiskClassification(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HITLStatus(str, Enum):
    PENDING = "pending"
    RESPONDED = "responded"
    TIMED_OUT = "timed_out"
    ESCALATED = "escalated"


class HITLRequestPayload(StrictModel):
    hitl_id: str
    task_id: str
    user_id: str = Field(min_length=1)
    session_id: str
    trigger_reason: str
    risk_classification: RiskClassification
    context: str = Field(min_length=1)
    available_actions: list[str] = Field(min_length=1)
    timeout_hours: int = Field(ge=1)
    created_at: datetime
    node_id: str | None = None
    current_output: str | None = None
    confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)


class HITLResponsePayload(StrictModel):
    hitl_id: str
    task_id: str
    decision: HITLDecision
    responded_by: str = Field(min_length=1)
    responded_at: datetime
    node_id: str | None = None
    modified_output: str | None = None
    clarification_text: str | None = None


class HITLRespondRequest(StrictModel):
    decision: HITLDecision
    responded_by: str = Field(min_length=1)
    modified_output: str | None = None
    clarification_text: str | None = None

    @model_validator(mode="after")
    def validate_fields(self) -> "HITLRespondRequest":
        if self.decision == HITLDecision.MODIFY and not self.modified_output:
            raise ValueError("modified_output is required when decision is 'modify'")
        if self.decision == HITLDecision.CLARIFY and not self.clarification_text:
            raise ValueError("clarification_text is required when decision is 'clarify'")
        if self.decision == HITLDecision.TIMEOUT_AUTO_REJECT:
            raise ValueError("timeout_auto_reject is reserved for system timeout handling")
        return self


class HITLRespondResponse(StrictModel):
    hitl_id: str
    accepted: bool
    timestamp: datetime


class APIErrorResponse(StrictModel):
    error_code: str
    error_type: str
    retryable: bool
    message: str
    details: dict[str, Any] | None = None


class HITLStatusResponse(StrictModel):
    hitl_id: str
    status: HITLStatus
    request: HITLRequestPayload
    response: HITLResponsePayload | None = None
    created_at: datetime

