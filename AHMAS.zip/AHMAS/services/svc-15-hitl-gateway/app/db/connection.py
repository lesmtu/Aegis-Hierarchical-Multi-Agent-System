from __future__ import annotations

try:
    import asyncpg
except ModuleNotFoundError:  # pragma: no cover
    asyncpg = None


class PostgresConnection:
    def __init__(self, dsn: str):
        self.dsn = dsn
        self.pool = None

    async def connect(self) -> None:
        if asyncpg is None:
            raise RuntimeError("asyncpg is required for PostgreSQL connections")
        if self.pool is None:
            self.pool = await asyncpg.create_pool(self.dsn)

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()
            self.pool = None
