from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime

from app.models import HITLRequestPayload, HITLResponsePayload


@dataclass
class HITLSessionRecord:
    hitl_id: str
    task_id: str
    node_id: str | None
    user_id: str
    session_id: str
    status: str
    request_payload: dict
    response_payload: dict | None
    created_at: datetime
    correlation_id: str
    trace_id: str
    risk_classification: str
    effective_timeout_seconds: int


class PostgresHITLRepository:
    def __init__(self, pool):
        self.pool = pool

    async def create_session(self, *, request: HITLRequestPayload, correlation_id: str, trace_id: str, effective_timeout_seconds: int) -> None:
        async with self.pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO hitl_audit.hitl_requests (
                    hitl_id, task_id, node_id, user_id, session_id, trigger_reason,
                    risk_classification, context, current_output, confidence_score,
                    available_actions, timeout_hours, effective_timeout_seconds,
                    status, request_payload, created_at, correlation_id, trace_id
                ) VALUES (
                    $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'pending',$14,$15,$16,$17
                )
                ON CONFLICT (hitl_id) DO NOTHING
                """,
                request.hitl_id,
                request.task_id,
                request.node_id,
                request.user_id,
                request.session_id,
                request.trigger_reason,
                request.risk_classification.value,
                request.context,
                request.current_output,
                request.confidence_score,
                json.dumps(request.available_actions),
                request.timeout_hours,
                effective_timeout_seconds,
                json.dumps(request.model_dump(mode="json", exclude_none=True)),
                request.created_at,
                correlation_id,
                trace_id,
            )

    async def get_session(self, hitl_id: str) -> HITLSessionRecord | None:
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM hitl_audit.hitl_requests WHERE hitl_id = $1", hitl_id)
        if row is None:
            return None
        return HITLSessionRecord(
            hitl_id=row["hitl_id"],
            task_id=row["task_id"],
            node_id=row["node_id"],
            user_id=row["user_id"],
            session_id=row["session_id"],
            status=row["status"],
            request_payload=json.loads(row["request_payload"]),
            response_payload=json.loads(row["response_payload"]) if row["response_payload"] else None,
            created_at=row["created_at"],
            correlation_id=row["correlation_id"],
            trace_id=row["trace_id"],
            risk_classification=row["risk_classification"],
            effective_timeout_seconds=row["effective_timeout_seconds"],
        )

    async def record_response(self, hitl_id: str, response: HITLResponsePayload, status: str) -> bool:
        async with self.pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE hitl_audit.hitl_requests
                SET status = $1, response_payload = $2, responded_at = $3, responded_by = $4, decision = $5
                WHERE hitl_id = $6 AND status IN ('pending', 'escalated')
                """,
                status,
                json.dumps(response.model_dump(mode="json", exclude_none=True)),
                response.responded_at,
                response.responded_by,
                response.decision.value,
                hitl_id,
            )
        return result.endswith("1")


class InMemoryHITLRepository:
    def __init__(self):
        self.sessions: dict[str, HITLSessionRecord] = {}

    async def create_session(self, *, request: HITLRequestPayload, correlation_id: str, trace_id: str, effective_timeout_seconds: int) -> None:
        if request.hitl_id in self.sessions:
            return
        self.sessions[request.hitl_id] = HITLSessionRecord(
            hitl_id=request.hitl_id,
            task_id=request.task_id,
            node_id=request.node_id,
            user_id=request.user_id,
            session_id=request.session_id,
            status="pending",
            request_payload=request.model_dump(mode="json", exclude_none=True),
            response_payload=None,
            created_at=request.created_at,
            correlation_id=correlation_id,
            trace_id=trace_id,
            risk_classification=request.risk_classification.value,
            effective_timeout_seconds=effective_timeout_seconds,
        )

    async def get_session(self, hitl_id: str) -> HITLSessionRecord | None:
        return self.sessions.get(hitl_id)

    async def record_response(self, hitl_id: str, response: HITLResponsePayload, status: str) -> bool:
        record = self.sessions.get(hitl_id)
        if record is None or record.status not in {"pending", "escalated"}:
            return False
        record.status = status
        record.response_payload = response.model_dump(mode="json", exclude_none=True)
        return True
