CREATE SCHEMA IF NOT EXISTS hitl_audit;

CREATE TABLE IF NOT EXISTS hitl_audit.hitl_requests (
    hitl_id UUID PRIMARY KEY,
    task_id UUID NOT NULL,
    node_id UUID NULL,
    user_id TEXT NOT NULL,
    session_id UUID NOT NULL,
    trigger_reason TEXT NOT NULL,
    risk_classification TEXT NOT NULL,
    context TEXT NOT NULL,
    current_output TEXT NULL,
    confidence_score DOUBLE PRECISION NULL,
    available_actions JSONB NOT NULL,
    timeout_hours INTEGER NOT NULL,
    effective_timeout_seconds INTEGER NOT NULL,
    status TEXT NOT NULL,
    request_payload JSONB NOT NULL,
    response_payload JSONB NULL,
    responded_at TIMESTAMPTZ NULL,
    responded_by TEXT NULL,
    decision TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    correlation_id UUID NOT NULL,
    trace_id UUID NOT NULL
);
