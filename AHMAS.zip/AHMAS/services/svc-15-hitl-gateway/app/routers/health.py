from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse

from app.config import settings
from app.services.metrics import render_metrics

router = APIRouter()


@router.get("/health")
async def health() -> dict:
    return {
        "service_id": settings.service_id,
        "status": "healthy",
        "version": settings.service_version,
        "dependencies": {
            "kafka": "unknown",
            "redis": "unknown",
            "postgresql": "unknown",
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return render_metrics()
