from __future__ import annotations

from fastapi import APIRouter, Depends

from shared.events.error_codes import AegisErrorCode

from app.dependencies import get_hitl_service
from app.models import HITLRespondRequest, HITLRespondResponse, HITLStatusResponse
from app.services.errors import (
    HITLAlreadyRespondedError,
    HITLNotFoundError,
    build_error_response,
)

router = APIRouter()


@router.post("/hitl/{hitl_id}/respond", response_model=HITLRespondResponse)
async def respond_to_hitl(hitl_id: str, request: HITLRespondRequest, svc=Depends(get_hitl_service)):
    try:
        result = await svc.record_response(hitl_id, request)
        return HITLRespondResponse.model_validate(result)
    except HITLNotFoundError:
        return build_error_response(404, AegisErrorCode.INVALID_PAYLOAD, f"HITL request {hitl_id} not found")
    except HITLAlreadyRespondedError:
        return build_error_response(
            409,
            AegisErrorCode.HITL_ALREADY_RESPONDED,
            f"HITL {hitl_id} already has a recorded response",
        )


@router.get("/hitl/{hitl_id}", response_model=HITLStatusResponse)
async def get_hitl_status(hitl_id: str, svc=Depends(get_hitl_service)):
    result = await svc.get_status(hitl_id)
    if result is None:
        return build_error_response(404, AegisErrorCode.INVALID_PAYLOAD, f"HITL request {hitl_id} not found")
    return result
