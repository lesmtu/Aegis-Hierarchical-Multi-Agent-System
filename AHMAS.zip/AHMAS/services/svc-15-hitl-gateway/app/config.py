from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    service_id: str = "SVC-15"
    service_version: str = "1.0.0"
    service_title: str = "Aegis HMAS SVC-15 HITL Gateway"
    kafka_bootstrap_servers: str = os.getenv("SVC15_KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    redis_url: str = os.getenv("SVC15_REDIS_URL", "redis://localhost:6379/0")
    postgres_dsn: str = os.getenv("SVC15_POSTGRES_DSN", "postgresql://postgres:postgres@localhost:5432/aegis")
    log_level: str = os.getenv("SVC15_LOG_LEVEL", "INFO")


settings = Settings()
