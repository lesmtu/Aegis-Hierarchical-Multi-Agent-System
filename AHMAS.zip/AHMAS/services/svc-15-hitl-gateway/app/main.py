from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError

from app.config import settings
from app.dependencies import get_hitl_service
from app.routers.health import router as health_router
from app.routers.hitl import router as hitl_router
from app.services.errors import build_error_response
from shared.events.error_codes import AegisErrorCode

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))

app = FastAPI(
    title=settings.service_title,
    version=settings.service_version,
    separate_input_output_schemas=False,
)
app.include_router(hitl_router)
app.include_router(health_router)


@app.on_event("startup")
async def startup_recovery() -> None:
    await get_hitl_service().recover_expired_sessions()


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_request, exc: RequestValidationError):
    return build_error_response(
        400,
        AegisErrorCode.INVALID_PAYLOAD,
        "Request validation failed",
        details={"errors": exc.errors()},
    )
