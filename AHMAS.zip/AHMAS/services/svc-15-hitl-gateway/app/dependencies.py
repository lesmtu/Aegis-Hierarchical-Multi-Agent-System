from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.idempotency.client import IdempotencyClient

from app.db.repository import InMemoryHITLRepository
from app.services.hitl_service import HITLService
from app.services.kafka_consumer import HITLKafkaConsumer
from app.services.kafka_producer import HITLKafkaProducer
from app.services.runtime import InMemoryProducerBackend, InMemoryRedis, RecordedScheduler
from app.services.timeout_scheduler import RedisTimerStore, TimeoutScheduler


_redis = InMemoryRedis()
_repository = InMemoryHITLRepository()
_producer_backend = InMemoryProducerBackend()
_producer = HITLKafkaProducer(_producer_backend)
_idempotency = IdempotencyClient(_redis, "SVC-15")
_timer_store = RedisTimerStore(_redis)
_recorded_scheduler = RecordedScheduler()
_timeout_scheduler = TimeoutScheduler(_recorded_scheduler, _timer_store, None)
_hitl_service = HITLService(_repository, _producer, _idempotency, _timer_store, _timeout_scheduler)
_timeout_scheduler.hitl_service = _hitl_service
_consumer = HITLKafkaConsumer(_hitl_service)


def get_hitl_service() -> HITLService:
    return _hitl_service


def get_kafka_consumer() -> HITLKafkaConsumer:
    return _consumer


def get_kafka_producer() -> HITLKafkaProducer:
    return _producer


def get_repository() -> InMemoryHITLRepository:
    return _repository


def get_scheduler() -> RecordedScheduler:
    return _recorded_scheduler


def get_redis() -> InMemoryRedis:
    return _redis


def reset_runtime_state() -> None:
    _redis.values.clear()
    _redis.hashes.clear()
    _redis.sorted_sets.clear()
    _repository.sessions.clear()
    _producer_backend.messages.clear()
    _producer.produced.clear()
    _recorded_scheduler.jobs.clear()
    _recorded_scheduler.removed_jobs.clear()
