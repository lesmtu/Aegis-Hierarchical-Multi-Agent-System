"""
SVC-13 Tool Generator — production entry point with Kafka lifespan.
Subscribes to: capability.missing   (contracts.json)
Produces to: tool.created, tool.generation.failed
"""
from __future__ import annotations

import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.idempotency.client import IdempotencyClient
from shared.kafka_loop import AioKafkaBackend, SimpleConsumerLoop

from .config import settings
from .services.generator import LLMClient, ToolGenerator
from .services.kafka_consumer import CapabilityMissingConsumer
from .services.kafka_producer import ToolGeneratorKafkaProducer
from .services.sandbox import SandboxExecutor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
_GROUP_ID      = "svc-13-tool-generator"
_TOPICS        = ["capability.missing"]


def _make_process_fn(consumer: CapabilityMissingConsumer):
    async def process(topic: str, message: dict) -> None:
        # Build a lightweight envelope object the generator service expects
        envelope = type("E", (), {
            "event_id":        message.get("event_id", ""),
            "idempotency_key": message.get("idempotency_key", ""),
            "correlation_id":  message.get("correlation_id", ""),
            "trace_id":        message.get("trace_id", ""),
            "payload":         message.get("payload", {}),
        })()
        await consumer.consume(envelope)
    return process


@asynccontextmanager
async def lifespan(app: FastAPI):
    import httpx
    backend = AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    producer = ToolGeneratorKafkaProducer(backend)
    sandbox  = SandboxExecutor(
        timeout_seconds=settings.sandbox_timeout_seconds,
        memory_limit_mb=settings.sandbox_memory_limit_mb,
    )

    # Proper OpenAI-compatible LLM client (fixes AttributeError: 'AsyncClient' has no 'complete')
    llm_api_base = os.getenv("LLM_API_BASE", "https://api.openai.com/v1")
    llm_api_key  = os.getenv("LLM_API_KEY", "")
    llm_model    = os.getenv("LLM_MODEL", "gpt-4o")
    _llm_http = httpx.AsyncClient(timeout=120.0)
    llm = LLMClient(
        http=_llm_http,
        base_url=llm_api_base,
        api_key=llm_api_key,
        model=llm_model,
    )

    svc19 = httpx.AsyncClient(base_url=os.getenv("SVC19_BASE_URL", "http://svc-19:8000"), timeout=30.0)
    svc21 = httpx.AsyncClient(base_url=os.getenv("SVC21_BASE_URL", "http://svc-21:8080"), timeout=30.0)

    # Idempotency
    try:
        import redis as redis_lib
        _rc = redis_lib.Redis(host=os.getenv("REDIS_HOST", "redis"),
                              port=int(os.getenv("REDIS_PORT", "6379")),
                              decode_responses=True, socket_connect_timeout=5)
        _rc.ping()
    except Exception:
        class _IML:
            def __init__(self, s): self._s = s
            def __call__(self, *, keys, args):
                k = keys[0]
                if k in self._s: return 0
                self._s[k] = args[0]; return 1
        class _IMR:
            def __init__(self): self.store = {}
            def register_script(self, _): return _IML(self.store)
            def get(self, k): return self.store.get(k)
            def set(self, k, v, xx=False, keepttl=False):
                if xx and k not in self.store: return False
                self.store[k] = v; return True
            def delete(self, k): self.store.pop(k, None)
        _rc = _IMR()
    idempotency = IdempotencyClient(_rc, "SVC-13")

    generator = ToolGenerator(
        llm=llm,
        svc19_client=svc19,
        svc21_client=svc21,
        producer=producer,
        idempotency=idempotency,
        sandbox=sandbox,
    )
    consumer = CapabilityMissingConsumer(generator=generator)

    loop = SimpleConsumerLoop(
        bootstrap_servers=_KAFKA_BROKERS,
        group_id=_GROUP_ID,
        topics=_TOPICS,
        process_fn=_make_process_fn(consumer),
    )
    await loop.start()
    logger.info("SVC-13 fully started — consuming %s", _TOPICS)
    yield
    await loop.stop()
    await backend.stop()
    await llm.aclose()   # also closes internal _llm_http
    await svc19.aclose()
    await svc21.aclose()
    logger.info("SVC-13 shutdown complete")


app = FastAPI(
    title=settings.service_title,
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict:
    return {"service_id": settings.service_id, "status": "healthy",
            "version": settings.service_version, "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return ""
