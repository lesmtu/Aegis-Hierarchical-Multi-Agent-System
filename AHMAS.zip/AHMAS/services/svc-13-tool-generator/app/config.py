from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    service_id: str = "SVC-13"
    service_version: str = "1.0.0"
    service_title: str = "Aegis HMAS SVC-13 Tool Generator"
    sandbox_timeout_seconds: int = int(os.getenv("SVC13_SANDBOX_TIMEOUT_SECONDS", "30"))
    sandbox_memory_limit_mb: int = int(os.getenv("SVC13_SANDBOX_MEMORY_LIMIT_MB", "512"))
    max_generation_retries: int = int(os.getenv("SVC13_MAX_GENERATION_RETRIES", "3"))
    tools_root: Path = Path(os.getenv("SVC13_TOOLS_ROOT", "/tmp/aegis-tools"))


settings = Settings()

