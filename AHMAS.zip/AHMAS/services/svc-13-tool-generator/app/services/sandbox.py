from __future__ import annotations

import resource
import subprocess
import tempfile
import time
from pathlib import Path


class SandboxExecutor:
    def __init__(self, python_executable: str = "python3", timeout_seconds: int = 30, memory_limit_mb: int = 512):
        self.python_executable = python_executable
        self.timeout_seconds = timeout_seconds
        self.memory_limit_mb = memory_limit_mb

    def _limit_resources(self) -> None:
        memory_bytes = self.memory_limit_mb * 1024 * 1024
        try:
            resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))
        except (ValueError, OSError):
            # Some environments do not allow RLIMIT_AS changes; timeout still applies.
            pass

    async def run(self, code: str, test_code: str | None = None) -> dict:
        started = time.perf_counter()
        with tempfile.TemporaryDirectory(prefix="svc13-sandbox-") as tmpdir:
            root = Path(tmpdir)
            tool_path = root / "generated_tool.py"
            tool_path.write_text(code, encoding="utf-8")
            test_path: Path | None = None
            if test_code:
                test_path = root / "test_generated_tool.py"
                test_path.write_text(test_code, encoding="utf-8")

            try:
                tool_result = subprocess.run(
                    [self.python_executable, str(tool_path)],
                    cwd=root,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_seconds,
                    preexec_fn=self._limit_resources,
                )
                if tool_result.returncode != 0:
                    return {
                        "passed": False,
                        "unit_tests_passed": False,
                        "integration_tests_passed": False,
                        "static_analysis_passed": True,
                        "execution_time_ms": int((time.perf_counter() - started) * 1000),
                        "failure_details": tool_result.stderr or tool_result.stdout or "Generated tool exited non-zero",
                    }

                unit_tests_passed = True
                if test_path is not None:
                    test_result = subprocess.run(
                        [self.python_executable, "-m", "pytest", str(test_path)],
                        cwd=root,
                        capture_output=True,
                        text=True,
                        timeout=self.timeout_seconds,
                        preexec_fn=self._limit_resources,
                    )
                    unit_tests_passed = test_result.returncode == 0
                    if not unit_tests_passed:
                        return {
                            "passed": False,
                            "unit_tests_passed": False,
                            "integration_tests_passed": False,
                            "static_analysis_passed": True,
                            "execution_time_ms": int((time.perf_counter() - started) * 1000),
                            "failure_details": test_result.stderr or test_result.stdout or "Unit tests failed",
                        }

                return {
                    "passed": True,
                    "unit_tests_passed": unit_tests_passed,
                    "integration_tests_passed": True,
                    "static_analysis_passed": True,
                    "execution_time_ms": int((time.perf_counter() - started) * 1000),
                    "failure_details": None,
                }
            except subprocess.TimeoutExpired:
                return {
                    "passed": False,
                    "unit_tests_passed": False,
                    "integration_tests_passed": False,
                    "static_analysis_passed": True,
                    "execution_time_ms": int((time.perf_counter() - started) * 1000),
                    "failure_details": f"Sandbox timeout ({self.timeout_seconds}s)",
                }

