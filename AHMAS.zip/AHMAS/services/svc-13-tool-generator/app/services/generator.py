from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from shared.events.error_codes import AegisErrorCode, build_error_payload

from ..config import settings
from .sandbox import SandboxExecutor

logger = logging.getLogger(__name__)


# ── OpenAI-compatible LLM client ────────────────────────────────────────────────

class _LLMResponse:
    """Thin wrapper so caller can use response.text (matches existing usage)."""
    def __init__(self, text: str):
        self.text = text


class LLMClient:
    """
    OpenAI-compatible LLM client for SVC-13 Tool Generator.

    Wraps httpx.AsyncClient to provide the .complete() interface expected
    by ToolGenerator._generate_tool_code().
    """

    def __init__(
        self,
        http: httpx.AsyncClient,
        base_url: str,
        api_key: str,
        model: str,
    ) -> None:
        self._http     = http
        self._base_url = base_url.rstrip("/")
        self._api_key  = api_key
        self._model    = model

    async def complete(
        self,
        prompt: str,
        *,
        response_format: dict | None = None,
        max_tokens: int = 4096,
        **_kwargs: Any,      # absorb extra kwargs like `reasoning=` cleanly
    ) -> _LLMResponse:
        """
        POST /v1/chat/completions (OpenAI-compatible).
        Returns _LLMResponse with `.text` containing the assistant message content.
        """
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type":  "application/json",
        }
        body: dict[str, Any] = {
            "model":    self._model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }
        if response_format:
            body["response_format"] = response_format

        resp = await self._http.post(
            f"{self._base_url}/chat/completions",
            json=body,
            headers=headers,
        )
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"]
        return _LLMResponse(content)

    async def aclose(self) -> None:
        await self._http.aclose()


class CapabilityMissingPayloadModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    capability_request_id: str
    task_id: str
    dag_id: str
    required_capability: str = Field(min_length=1)
    description: str = Field(min_length=1)
    sub_task_id: str
    suggested_tool_type: str
    created_at: str


class ToolInterfaceSchemaModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    input_schema: dict[str, Any]
    output_schema: dict[str, Any]


class SandboxTestResultsModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    passed: bool
    unit_tests_passed: bool
    integration_tests_passed: bool
    static_analysis_passed: bool
    execution_time_ms: int = Field(ge=0)
    failure_details: str | None = None


class ToolRegistryEntryModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_id: str
    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    capability_type: str = Field(min_length=1)
    interface: ToolInterfaceSchemaModel
    runtime: str
    code_path: str = Field(min_length=1)
    version: str
    created_by: str = Field(min_length=1)
    sandbox_test_results: SandboxTestResultsModel
    usage_count: int = Field(ge=0)
    created_at: str


class ToolCreatedPayloadModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_id: str
    capability_request_id: str
    task_id: str
    tool_entry: ToolRegistryEntryModel
    created_at: str


class ToolGenerationFailedPayloadModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    capability_request_id: str
    task_id: str
    required_capability: str = Field(min_length=1)
    failure_reason: str = Field(min_length=1)
    retry_count: int = Field(ge=0)
    created_at: str


class GeneratedToolModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    code: str = Field(min_length=1)
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    runtime: str = "python"
    test_code: str | None = None


class ToolGenerationError(Exception):
    pass


@dataclass
class PipelineRecord:
    steps: list[str]


class ToolGenerator:
    def __init__(self, llm: LLMClient, svc19_client, svc21_client, producer, idempotency, sandbox: SandboxExecutor | None = None):
        self.llm = llm
        self.svc19 = svc19_client
        self.svc21 = svc21_client
        self.producer = producer
        self.idempotency = idempotency
        self.sandbox = sandbox or SandboxExecutor(
            timeout_seconds=settings.sandbox_timeout_seconds,
            memory_limit_mb=settings.sandbox_memory_limit_mb,
        )
        self.pipeline_history: list[PipelineRecord] = []

    async def handle_capability_missing(self, envelope) -> None:
        if not self.idempotency.check_and_set(envelope.idempotency_key, envelope.event_id):
            return

        payload = CapabilityMissingPayloadModel.model_validate(envelope.payload)
        steps: list[str] = []
        self.pipeline_history.append(PipelineRecord(steps=steps))

        try:
            steps.append("generate")
            generation_prompt = self._build_generation_prompt(payload)
            generated = await self._generate_tool_code(generation_prompt)

            steps.append("bandit")
            bandit_result = await self._run_bandit(generated.code)
            if not bandit_result["passed"]:
                raise ToolGenerationError(f"Bandit static analysis failed: {bandit_result['issues']}")

            steps.append("sandbox")
            sandbox_result = await self.sandbox.run(generated.code, generated.test_code)
            if not sandbox_result["passed"]:
                await self._emit_tool_generation_failed(
                    payload=payload,
                    envelope=envelope,
                    failure_reason=sandbox_result["failure_details"] or "Sandbox execution failed",
                    error_code=AegisErrorCode.TOOL_SANDBOX_FAILED,
                )
                self.idempotency.mark_failed(envelope.idempotency_key, envelope.event_id)
                return

            tool_entry = self._build_tool_registry_entry(generated, payload, sandbox_result)

            steps.append("svc19_register")
            tool_id = await self._register_in_svc19(tool_entry)
            tool_entry["tool_id"] = tool_id

            steps.append("tool_created")
            await self._emit_tool_created(tool_entry, payload, envelope)

            steps.append("svc21_save")
            asyncio.create_task(self._save_template_to_svc21(tool_entry, payload, generation_prompt))

            self.idempotency.mark_completed(envelope.idempotency_key, envelope.event_id)
        except ToolGenerationError as exc:
            await self._emit_tool_generation_failed(
                payload=payload,
                envelope=envelope,
                failure_reason=str(exc),
                error_code=AegisErrorCode.TOOL_GENERATION_FAILED,
            )
            self.idempotency.mark_failed(envelope.idempotency_key, envelope.event_id)
        except ValidationError as exc:
            await self._emit_tool_generation_failed(
                payload=payload,
                envelope=envelope,
                failure_reason=str(exc),
                error_code=AegisErrorCode.TOOL_GENERATION_FAILED,
            )
            self.idempotency.mark_failed(envelope.idempotency_key, envelope.event_id)
        except Exception as exc:  # pragma: no cover
            logger.exception("SVC-13 unexpected error")
            await self._emit_tool_generation_failed(
                payload=payload,
                envelope=envelope,
                failure_reason=str(exc),
                error_code=AegisErrorCode.TOOL_GENERATION_FAILED,
            )
            self.idempotency.mark_failed(envelope.idempotency_key, envelope.event_id)

    def _build_generation_prompt(self, payload: CapabilityMissingPayloadModel) -> str:
        return (
            "Generate a Python tool for the following capability.\n\n"
            f"Capability Type: {payload.required_capability}\n"
            f"Description: {payload.description}\n"
            f"Sub-task Id: {payload.sub_task_id}\n"
            f"Suggested Tool Type: {payload.suggested_tool_type}\n\n"
            "Return JSON with tool_name, description, code, input_schema, output_schema, runtime, and optional test_code."
        )

    async def _generate_tool_code(self, prompt: str) -> GeneratedToolModel:
        response = await self.llm.complete(
            prompt,
            response_format={"type": "json_object"},
            max_tokens=8192,
            reasoning="heavy_reasoning",
        )
        return GeneratedToolModel.model_validate(json.loads(response.text))

    async def _run_bandit(self, code: str) -> dict[str, Any]:
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w", encoding="utf-8") as handle:
            handle.write(code)
            tmpfile = Path(handle.name)

        command_candidates = []
        if shutil.which("bandit"):
            command_candidates.append(["bandit", "-r", str(tmpfile), "-f", "json", "-ll"])
        command_candidates.append(["python3", "-m", "bandit", "-r", str(tmpfile), "-f", "json", "-ll"])
        audit_venv_bandit = Path(__file__).resolve().parents[4] / ".audit-venv" / "bin" / "bandit"
        if audit_venv_bandit.exists():
            command_candidates.insert(0, [str(audit_venv_bandit), "-r", str(tmpfile), "-f", "json", "-ll"])

        try:
            for command in command_candidates:
                result = subprocess.run(command, capture_output=True, text=True, timeout=30)
                if result.returncode == 0:
                    return {"passed": True, "issues": []}
                if "No module named bandit" in (result.stderr or "") or "command not found" in (result.stderr or ""):
                    continue
                issues = self._parse_bandit_issues(result.stdout, result.stderr)
                return {"passed": False, "issues": issues}
            return self._heuristic_bandit(code)
        finally:
            tmpfile.unlink(missing_ok=True)

    def _parse_bandit_issues(self, stdout: str, stderr: str) -> list[str]:
        try:
            report = json.loads(stdout or "{}")
        except json.JSONDecodeError:
            report = {}
        issues = [item.get("issue_text", "bandit issue") for item in report.get("results", [])]
        if issues:
            return issues
        return [stderr or stdout or "Bandit failed"]

    def _heuristic_bandit(self, code: str) -> dict[str, Any]:
        blocked_patterns = {
            "os.system(": "Use of os.system is blocked",
            "subprocess.Popen(": "Use of subprocess.Popen is blocked",
            "subprocess.call(": "Use of subprocess.call is blocked",
            "eval(": "Use of eval is blocked",
            "exec(": "Use of exec is blocked",
            "rm -rf": "Destructive shell command detected",
        }
        issues = [message for pattern, message in blocked_patterns.items() if pattern in code]
        return {"passed": not issues, "issues": issues}

    def _build_tool_registry_entry(
        self,
        generated: GeneratedToolModel,
        payload: CapabilityMissingPayloadModel,
        sandbox_result: dict[str, Any],
    ) -> dict[str, Any]:
        tool_dir = settings.tools_root / payload.required_capability
        code_path = tool_dir / f"{generated.tool_name}.py"
        code_path.parent.mkdir(parents=True, exist_ok=True)
        code_path.write_text(generated.code, encoding="utf-8")

        entry = {
            "tool_id": str(uuid.uuid4()),
            "name": generated.tool_name,
            "description": generated.description,
            "capability_type": payload.required_capability,
            "interface": {
                "input_schema": generated.input_schema,
                "output_schema": generated.output_schema,
            },
            "runtime": generated.runtime,
            "code_path": str(code_path),
            "version": "1.0.0",
            "created_by": "SVC-13",
            "sandbox_test_results": sandbox_result,
            "usage_count": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        ToolRegistryEntryModel.model_validate(entry)
        return entry

    async def _register_in_svc19(self, tool_entry: dict[str, Any]) -> str:
        response = await self.svc19.post("/tools/register", json=tool_entry)
        response.raise_for_status()
        body = response.json()
        return body["tool_id"]

    async def _save_template_to_svc21(
        self,
        tool_entry: dict[str, Any],
        payload: CapabilityMissingPayloadModel,
        generation_prompt: str,
    ) -> None:
        delays = [1, 2, 4]
        save_request = {
            "description": f"{payload.description} [Tool: {tool_entry['name']}]",
            "template": generation_prompt,
            "capability_type": tool_entry["capability_type"],
            "tags": ["generated", tool_entry["runtime"], tool_entry["capability_type"]],
            "source": "generated",
            "is_agent_template": False,
            "saved_by": "SVC-11",
            "task_id": payload.task_id,
            "is_verified": True,
        }
        for attempt, delay in enumerate(delays, start=1):
            try:
                response = await self.svc21.post("/prompt/save", json=save_request)
                status_code = getattr(response, "status_code", 500)
                if status_code in (201, 202):
                    return
                if status_code == 403:
                    logger.critical("SVC-11 rejected by SVC-21 access control")
                    return
                if status_code == 400:
                    logger.error("Malformed SVC-21 payload: %s", save_request)
                    return
                if status_code in (503, 504) and attempt < len(delays):
                    await asyncio.sleep(delay)
                    continue
                logger.error("SVC-21 unavailable during feedback loop save for tool %s", tool_entry["tool_id"])
                return
            except Exception:  # pragma: no cover
                if attempt < len(delays):
                    await asyncio.sleep(delay)
                    continue
                logger.error("SVC-21 unavailable during feedback loop save for tool %s", tool_entry["tool_id"])
                return

    async def _emit_tool_created(self, tool_entry: dict[str, Any], payload: CapabilityMissingPayloadModel, envelope) -> None:
        created_payload = {
            "tool_id": tool_entry["tool_id"],
            "capability_request_id": payload.capability_request_id,
            "task_id": payload.task_id,
            "tool_entry": tool_entry,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        ToolCreatedPayloadModel.model_validate(created_payload)
        await self.producer.produce_envelope(
            topic="tool.created",
            payload=created_payload,
            source_service="SVC-13",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
        )

    async def _emit_tool_generation_failed(
        self,
        *,
        payload: CapabilityMissingPayloadModel,
        envelope,
        failure_reason: str,
        error_code: AegisErrorCode,
    ) -> None:
        failed_payload = {
            "capability_request_id": payload.capability_request_id,
            "task_id": payload.task_id,
            "required_capability": payload.required_capability,
            "failure_reason": failure_reason,
            "retry_count": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        ToolGenerationFailedPayloadModel.model_validate(failed_payload)
        await self.producer.produce_envelope(
            topic="tool.generation.failed",
            payload=failed_payload,
            source_service="SVC-13",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
            status="error",
            error=build_error_payload(error_code, failure_reason),
        )
