from __future__ import annotations


class CapabilityMissingConsumer:
    def __init__(self, generator):
        self.generator = generator

    async def consume(self, envelope) -> None:
        await self.generator.handle_capability_missing(envelope)

