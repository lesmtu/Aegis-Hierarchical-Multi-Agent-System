from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

SERVICE_ROOT = Path("/home/g/AHMAS/services/svc-13-tool-generator")
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
if "/home/g/AHMAS" not in sys.path:
    sys.path.insert(0, "/home/g/AHMAS")

from app.services.generator import ToolGenerator  # noqa: E402
from app.services.kafka_consumer import CapabilityMissingConsumer  # noqa: E402
from app.services.kafka_producer import ToolGeneratorKafkaProducer  # noqa: E402
from app.services.sandbox import SandboxExecutor  # noqa: E402


class FakeLLMResponse:
    def __init__(self, text: str):
        self.text = text


class FakeLLM:
    def __init__(self, text: str):
        self.text = text
        self.calls = []

    async def complete(self, prompt, **kwargs):
        self.calls.append({"prompt": prompt, "kwargs": kwargs})
        return FakeLLMResponse(self.text)


class FakeHTTPResponse:
    def __init__(self, status_code: int, body: dict):
        self.status_code = status_code
        self._body = body

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")

    def json(self):
        return self._body


class FakeHTTPClient:
    def __init__(self, response: FakeHTTPResponse):
        self.response = response
        self.calls = []

    async def post(self, url, json):
        self.calls.append({"url": url, "json": json})
        return self.response

    def post_calls_with(self, url: str) -> bool:
        return any(call["url"] == url for call in self.calls)


class FakeProducerBackend:
    def __init__(self):
        self.sent = []

    def send(self, topic, payload):
        self.sent.append({"topic": topic, "payload": payload})


class FakeIdempotency:
    def __init__(self):
        self.completed = []
        self.failed = []
        self.claims = []
        self.allow = True

    def check_and_set(self, idempotency_key, event_id):
        self.claims.append((idempotency_key, event_id))
        return self.allow

    def mark_completed(self, idempotency_key, event_id):
        self.completed.append((idempotency_key, event_id))

    def mark_failed(self, idempotency_key, event_id):
        self.failed.append((idempotency_key, event_id))


class FakeSandbox:
    def __init__(self, result):
        self.result = result
        self.calls = []

    async def run(self, code: str, test_code: str | None = None):
        self.calls.append({"code": code, "test_code": test_code})
        return self.result


@dataclass
class Envelope:
    event_id: str
    idempotency_key: str
    correlation_id: str
    trace_id: str
    payload: dict


def valid_capability_payload(**overrides):
    payload = {
        "capability_request_id": str(uuid4()),
        "task_id": str(uuid4()),
        "dag_id": str(uuid4()),
        "required_capability": "code",
        "description": "Create a summarizer tool",
        "sub_task_id": str(uuid4()),
        "suggested_tool_type": "python_function",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    payload.update(overrides)
    return payload


def valid_generated_tool_json():
    return """
{
  "tool_name": "generated_tool",
  "description": "Generated tool",
  "code": "def main():\\n    return 0\\n\\nif __name__ == '__main__':\\n    main()\\n",
  "input_schema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
  "output_schema": {"type": "object", "properties": {"summary": {"type": "string"}}, "required": ["summary"]},
  "runtime": "python",
  "test_code": "from generated_tool import main\\n\\ndef test_main():\\n    assert main() == 0\\n"
}
""".strip()


def build_generator(*, sandbox_result=None):
    producer_backend = FakeProducerBackend()
    producer = ToolGeneratorKafkaProducer(producer_backend)
    llm = FakeLLM(valid_generated_tool_json())
    svc19 = FakeHTTPClient(FakeHTTPResponse(201, {"tool_id": str(uuid4()), "registered_at": datetime.now(timezone.utc).isoformat()}))
    svc21 = FakeHTTPClient(FakeHTTPResponse(201, {"prompt_id": str(uuid4()), "saved_to": "vault", "indexed": True, "created_at": datetime.now(timezone.utc).isoformat()}))
    idempotency = FakeIdempotency()
    sandbox = FakeSandbox(
        sandbox_result
        or {
            "passed": True,
            "unit_tests_passed": True,
            "integration_tests_passed": True,
            "static_analysis_passed": True,
            "execution_time_ms": 12,
            "failure_details": None,
        }
    )
    generator = ToolGenerator(llm, svc19, svc21, producer, idempotency, sandbox=sandbox)
    return generator, producer, producer_backend, svc19, svc21, idempotency, sandbox


def build_envelope(payload=None):
    return Envelope(
        event_id=str(uuid4()),
        idempotency_key=str(uuid4()),
        correlation_id=str(uuid4()),
        trace_id=str(uuid4()),
        payload=payload or valid_capability_payload(),
    )


def test_tool_created_emitted_on_success():
    generator, producer, _, _, svc21, _, _ = build_generator()
    asyncio.run(generator.handle_capability_missing(build_envelope()))
    asyncio.run(asyncio.sleep(0))
    events = [e.event_type for e in producer.produced]
    assert "tool.created" in events
    assert svc21.post_calls_with("/prompt/save")


def test_tool_generation_failed_on_sandbox_failure():
    generator, producer, _, _, _, _, _ = build_generator(
        sandbox_result={
            "passed": False,
            "unit_tests_passed": False,
            "integration_tests_passed": False,
            "static_analysis_passed": True,
            "execution_time_ms": 11,
            "failure_details": "sandbox exploded",
        }
    )
    asyncio.run(generator.handle_capability_missing(build_envelope()))
    events = [e.event_type for e in producer.produced]
    assert "tool.generation.failed" in events
    failed = [e for e in producer.produced if e.event_type == "tool.generation.failed"][0]
    assert failed.error["error_code"] in ("TOOL_GENERATION_FAILED", "TOOL_SANDBOX_FAILED")


def test_svc19_register_called():
    generator, _, _, svc19, _, _, _ = build_generator()
    asyncio.run(generator.handle_capability_missing(build_envelope()))
    assert svc19.post_calls_with("/tools/register")


def test_svc21_save_called_after_success():
    generator, _, _, _, svc21, _, _ = build_generator()
    asyncio.run(generator.handle_capability_missing(build_envelope()))
    asyncio.run(asyncio.sleep(0))
    assert svc21.post_calls_with("/prompt/save")


def test_bandit_analysis_blocks_dangerous_code():
    generator, _, _, _, _, _, _ = build_generator()
    dangerous_code = "import os\\nos.system('rm -rf /')\\n"
    result = asyncio.run(generator._run_bandit(dangerous_code))
    assert result["passed"] is False


def test_pipeline_order_strictly_enforced():
    generator, producer, _, svc19, svc21, _, _ = build_generator()
    asyncio.run(generator.handle_capability_missing(build_envelope()))
    asyncio.run(asyncio.sleep(0))
    assert generator.pipeline_history[-1].steps == [
        "generate",
        "bandit",
        "sandbox",
        "svc19_register",
        "tool_created",
        "svc21_save",
    ]
    assert svc19.calls[0]["url"] == "/tools/register"
    assert producer.produced[0].event_type == "tool.created"
    assert svc21.calls[0]["url"] == "/prompt/save"


def test_idempotency_on_capability_missing_consumer():
    generator, producer, _, _, _, idempotency, _ = build_generator()
    idempotency.allow = False
    consumer = CapabilityMissingConsumer(generator)
    asyncio.run(consumer.consume(build_envelope()))
    assert producer.produced == []


def test_sandbox_timeout_is_30_seconds():
    sandbox = SandboxExecutor(timeout_seconds=30, memory_limit_mb=512)
    assert sandbox.timeout_seconds == 30
