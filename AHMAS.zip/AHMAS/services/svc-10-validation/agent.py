import json

from shared.worker_base.base_worker import BaseWorkerAgent


class ValidationAgent(BaseWorkerAgent):
    """
    SVC-10 Worker Agent — Validation.
    primary_tools: fact_checker, schema_validator, logic_evaluator
    """

    AGENT_TYPE = "validation"

    async def execute_task(self, dispatch_payload: dict, rag_ctx) -> tuple:
        tools_used = []

        prompt = f"""Validation task: {dispatch_payload['sub_task_description']}

Task context:
{dispatch_payload['input_context']}

Context from memory:
{chr(10).join(rag_ctx.context_chunks)}

Correction guidance: {dispatch_payload.get('correction_guidance', 'None')}

Perform comprehensive validation:
1. Fact-check all claims
2. Validate logical consistency
3. Check schema compliance if applicable
4. Flag any discrepancies

Return JSON:
{{
  "validation_passed": <boolean>,
  "issues_found": [<string>, ...],
  "confidence": <float 0.0-1.0>,
  "recommendation": "<approve|reject|review>"
}}"""

        response = await self.llm.complete(prompt, response_format={"type": "json_object"})
        validation_result = json.loads(response.text)
        tools_used.append("fact_checker")

        return validation_result, tools_used
