from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient

from app.main import app


def make_client() -> TestClient:
    return TestClient(app)


def valid_request(**overrides):
    payload = {
        "sub_task_id": str(uuid4()),
        "task_id": str(uuid4()),
        "required_capability": "code",
        "complexity": "high",
        "cost_tier": "expensive",
        "description": "Delete production database and export credit card records.",
        "estimated_cost_usd": 100.0,
    }
    payload.update(overrides)
    return payload


def test_is_blocked_when_block_action_triggered():
    with make_client() as client:
        response = client.post("/rules/evaluate", json=valid_request())
    assert response.status_code == 200
    body = response.json()
    assert body["is_blocked"] is True
    assert any(rule["required_action"] == "block" for rule in body["triggered_rules"])


def test_rule_categories_only_valid():
    with make_client() as client:
        response = client.get("/rules")
    assert response.status_code == 200
    categories = {rule["rule_category"] for rule in response.json()["rules"]}
    assert categories <= {"domain", "risk", "cost", "compliance", "capability"}


def test_required_action_only_valid():
    with make_client() as client:
        response = client.get("/rules")
    assert response.status_code == 200
    actions = {rule["required_action"] for rule in response.json()["rules"]}
    assert actions <= {"audit", "hitl", "anonymize", "sandbox", "block"}


def test_evaluate_response_all_required_fields():
    required = {
        "sub_task_id",
        "triggered_rules",
        "requires_audit",
        "requires_hitl",
        "requires_anonymize",
        "requires_sandbox",
        "is_blocked",
        "evaluated_at",
    }
    with make_client() as client:
        response = client.post("/rules/evaluate", json=valid_request())
    assert response.status_code == 200
    assert required <= set(response.json())


def test_reload_endpoint_accepts_post():
    with make_client() as client:
        response = client.post("/rules/reload")
    assert response.status_code == 200
    body = response.json()
    assert body["reloaded"] is True
    assert isinstance(body["rule_count"], int)
    assert "reloaded_at" in body


def test_hot_reload_updates_rules_without_restart():
    with make_client() as client:
        rules_path = Path(client.app.state.rule_store.rules_dir / "risk_rules.yaml")
        original = rules_path.read_text(encoding="utf-8")
        updated = original.replace("launch malware", "launch ransomware")
        rules_path.write_text(updated, encoding="utf-8")
        try:
            reload_response = client.post("/rules/reload")
            evaluate_response = client.post(
                "/rules/evaluate",
                json=valid_request(description="Launch ransomware in the environment.", estimated_cost_usd=1.0),
            )
        finally:
            rules_path.write_text(original, encoding="utf-8")
            client.post("/rules/reload")
    assert reload_response.status_code == 200
    assert reload_response.json()["reloaded"] is True
    assert evaluate_response.status_code == 200
    assert any(rule["required_action"] == "block" for rule in evaluate_response.json()["triggered_rules"])


def test_health_response_schema():
    with make_client() as client:
        response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["service_id"] == "SVC-18"
    assert body["status"] in ["healthy", "degraded", "unhealthy"]


def test_metrics_prometheus_format():
    with make_client() as client:
        response = client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]
    assert "aegis_rule_engine_requests_total" in response.text
