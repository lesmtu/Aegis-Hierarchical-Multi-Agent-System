from __future__ import annotations

from pathlib import Path

from pydantic import Field, field_validator

from .common import StrictBaseModel
from .evaluate import Complexity, CostTier, RequiredAction, RequiredCapability, RuleCategory


class RuleCondition(StrictBaseModel):
    required_capabilities: list[RequiredCapability] | None = None
    complexity_in: list[Complexity] | None = None
    min_complexity: Complexity | None = None
    cost_tiers: list[CostTier] | None = None
    min_estimated_cost_usd: float | None = Field(default=None, ge=0.0)
    description_contains_any: list[str] | None = None
    description_regex: str | None = None
    task_ids: list[str] | None = None
    sub_task_ids: list[str] | None = None

    @field_validator("description_contains_any")
    @classmethod
    def non_empty_terms(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return value
        cleaned = [term.strip() for term in value if term.strip()]
        if not cleaned:
            raise ValueError("description_contains_any must include at least one non-empty term")
        return cleaned


class RuleDefinition(StrictBaseModel):
    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    rule_category: RuleCategory
    required_action: RequiredAction
    description: str = Field(min_length=1)
    enabled: bool = True
    condition: RuleCondition


class RuleFile(StrictBaseModel):
    rules: list[RuleDefinition]


class RuleFileSnapshot(StrictBaseModel):
    path: Path
    modified_time: float
