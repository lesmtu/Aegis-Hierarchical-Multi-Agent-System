from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ErrorType(str, Enum):
    SYSTEM = "system"
    AGENT = "agent"
    VALIDATION = "validation"
    TIMEOUT = "timeout"


class ErrorCode(str, Enum):
    WORKER_TIMEOUT = "WORKER_TIMEOUT"
    VALIDATION_FAILED = "VALIDATION_FAILED"
    MEMORY_UNAVAILABLE = "MEMORY_UNAVAILABLE"
    TOOL_SANDBOX_FAILED = "TOOL_SANDBOX_FAILED"
    PLAN_REFLECTION_BELOW_THRESHOLD = "PLAN_REFLECTION_BELOW_THRESHOLD"
    DAG_NODE_RETRY_EXHAUSTED = "DAG_NODE_RETRY_EXHAUSTED"
    HITL_TIMEOUT_EXCEEDED = "HITL_TIMEOUT_EXCEEDED"
    SCHEMA_VERSION_MISMATCH = "SCHEMA_VERSION_MISMATCH"
    IDEMPOTENCY_KEY_DUPLICATE = "IDEMPOTENCY_KEY_DUPLICATE"
    CAPABILITY_NOT_FOUND = "CAPABILITY_NOT_FOUND"
    RULE_BLOCKED = "RULE_BLOCKED"
    REPLAN_LIMIT_EXCEEDED = "REPLAN_LIMIT_EXCEEDED"
    META_AGENT_KILL_SWITCH_ACTIVE = "META_AGENT_KILL_SWITCH_ACTIVE"
    META_AGENT_RATE_LIMIT_EXCEEDED = "META_AGENT_RATE_LIMIT_EXCEEDED"
    TOOL_GENERATION_FAILED = "TOOL_GENERATION_FAILED"
    META_AGENT_CREATION_FAILED = "META_AGENT_CREATION_FAILED"
    NOTIFICATION_DELIVERY_FAILED = "NOTIFICATION_DELIVERY_FAILED"
    MEMORY_STORE_FAILED = "MEMORY_STORE_FAILED"
    MEMORY_RETRIEVE_FAILED = "MEMORY_RETRIEVE_FAILED"
    INVALID_PAYLOAD = "INVALID_PAYLOAD"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    HITL_ALREADY_RESPONDED = "HITL_ALREADY_RESPONDED"
    AGENT_TRUST_SCORE_TOO_LOW = "AGENT_TRUST_SCORE_TOO_LOW"
    OPENCLAW_TRANSLATION_FAILED = "OPENCLAW_TRANSLATION_FAILED"
    CYCLIC_DEPENDENCY_IN_PLAN = "CYCLIC_DEPENDENCY_IN_PLAN"


class ErrorSchema(StrictBaseModel):
    error_code: ErrorCode
    error_type: ErrorType
    retryable: bool
    message: str = Field(min_length=1)
    details: dict[str, Any] | None = None


class APIErrorResponse(StrictBaseModel):
    error: ErrorSchema
    request_id: UUID
    timestamp: datetime


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class DependencyHealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class HealthCheckResponse(StrictBaseModel):
    service_id: str = Field(pattern=r"^SVC-[0-9]{2}$")
    status: HealthStatus
    version: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    dependencies: dict[str, DependencyHealthStatus] | None = None
    timestamp: datetime
