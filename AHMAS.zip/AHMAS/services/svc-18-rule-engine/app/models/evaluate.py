from __future__ import annotations

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import Field, field_validator

from .common import StrictBaseModel


class RequiredCapability(str, Enum):
    RESEARCH = "research"
    LOGIC = "logic"
    MEDIA = "media"
    CODE = "code"
    TOOL_BUILDER = "tool_builder"
    VALIDATION = "validation"


class Complexity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CostTier(str, Enum):
    CHEAP = "cheap"
    MEDIUM = "medium"
    EXPENSIVE = "expensive"


class RuleCategory(str, Enum):
    DOMAIN = "domain"
    RISK = "risk"
    COST = "cost"
    COMPLIANCE = "compliance"
    CAPABILITY = "capability"


class RequiredAction(str, Enum):
    AUDIT = "audit"
    HITL = "hitl"
    ANONYMIZE = "anonymize"
    SANDBOX = "sandbox"
    BLOCK = "block"


class TriggeredRule(StrictBaseModel):
    rule_id: str = Field(min_length=1)
    rule_category: RuleCategory
    rule_name: str = Field(min_length=1)
    required_action: RequiredAction
    description: str | None = Field(default=None, min_length=1)


class RuleEvaluateRequest(StrictBaseModel):
    sub_task_id: UUID
    task_id: UUID | None = None
    required_capability: RequiredCapability
    complexity: Complexity
    cost_tier: CostTier
    description: str = Field(min_length=1)
    estimated_cost_usd: float | None = Field(default=None, ge=0.0)


class RuleEvaluateResponse(StrictBaseModel):
    sub_task_id: UUID
    triggered_rules: list[TriggeredRule]
    requires_audit: bool
    requires_hitl: bool
    requires_anonymize: bool
    requires_sandbox: bool
    is_blocked: bool
    evaluated_at: datetime

    @field_validator("evaluated_at")
    @classmethod
    def ensure_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("evaluated_at must include timezone")
        return value


class RulesListResponse(StrictBaseModel):
    rules: list[TriggeredRule]
    loaded_at: datetime


class RulesReloadResponse(StrictBaseModel):
    reloaded: bool
    rule_count: int = Field(ge=0)
    reloaded_at: datetime
