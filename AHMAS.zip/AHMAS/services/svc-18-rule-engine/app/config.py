from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SVC18_", case_sensitive=False)

    service_id: str = "SVC-18"
    service_version: str = "1.0.0"
    log_level: str = "INFO"
    rules_dir: Path = Path(__file__).resolve().parents[1] / "rules"
    service_title: str = "Aegis HMAS SVC-18 Rule Engine + Guardrails"
    request_timeout_seconds: int = Field(default=10, ge=1)


settings = Settings()
