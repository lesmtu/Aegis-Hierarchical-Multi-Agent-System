from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID, uuid4

from fastapi import Request
from fastapi.responses import JSONResponse

from ..models.common import APIErrorResponse, ErrorSchema


ERROR_DEFINITIONS = {
    "INVALID_PAYLOAD": {"error_type": "validation", "retryable": False},
    "INTERNAL_ERROR": {"error_type": "system", "retryable": True},
}


def build_error_response(
    *,
    status_code: int,
    error_code: str,
    message: str,
    request_id: UUID | None = None,
    details: dict | None = None,
) -> JSONResponse:
    definition = ERROR_DEFINITIONS[error_code]
    payload = APIErrorResponse(
        error=ErrorSchema(
            error_code=error_code,
            error_type=definition["error_type"],
            retryable=definition["retryable"],
            message=message,
            details=details,
        ),
        request_id=request_id or uuid4(),
        timestamp=datetime.now(timezone.utc),
    )
    return JSONResponse(status_code=status_code, content=payload.model_dump(mode="json"))


def request_id_from(request: Request) -> UUID:
    request_id = getattr(request.state, "request_id", None)
    if request_id is None:
        request_id = uuid4()
        request.state.request_id = request_id
    return request_id
