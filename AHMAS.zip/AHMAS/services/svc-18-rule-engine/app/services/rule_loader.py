from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

import yaml

from ..models.evaluate import TriggeredRule
from ..models.rule import RuleDefinition, RuleFile
from .metrics import RULE_RELOAD_COUNT, RULES_LOADED

LOGGER = logging.getLogger(__name__)


class RuleStore:
    def __init__(self, rules_dir: Path):
        self._rules_dir = rules_dir
        self._rules: list[RuleDefinition] = []
        self._loaded_at: datetime = datetime.now(timezone.utc)

    @property
    def loaded_at(self) -> datetime:
        return self._loaded_at

    @property
    def rules_dir(self) -> Path:
        return self._rules_dir

    def load(self) -> int:
        self._rules_dir.mkdir(parents=True, exist_ok=True)
        loaded: list[RuleDefinition] = []
        for path in sorted(self._rules_dir.glob("*.yaml")):
            LOGGER.info("Loading rule file %s", path)
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            rule_file = RuleFile.model_validate(data)
            for rule in rule_file.rules:
                if rule.enabled:
                    loaded.append(rule)
                    RULES_LOADED.labels(category=rule.rule_category.value).inc()
        self._rules = loaded
        self._loaded_at = datetime.now(timezone.utc)
        LOGGER.info("Loaded %s enabled rules from %s", len(self._rules), self._rules_dir)
        return len(self._rules)

    def reload(self) -> int:
        try:
            count = self.load()
        except Exception:
            RULE_RELOAD_COUNT.labels(result="failure").inc()
            raise
        RULE_RELOAD_COUNT.labels(result="success").inc()
        return count

    def get_rules(self) -> list[RuleDefinition]:
        return list(self._rules)

    def list_triggered_rules(self) -> list[TriggeredRule]:
        return [
            TriggeredRule(
                rule_id=rule.id,
                rule_category=rule.rule_category,
                rule_name=rule.name,
                required_action=rule.required_action,
                description=rule.description,
            )
            for rule in self._rules
        ]
