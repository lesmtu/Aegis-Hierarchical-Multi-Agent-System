from __future__ import annotations

from starlette.responses import Response

try:
    from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
except ImportError:  # pragma: no cover
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4; charset=utf-8"

    _COUNTERS: dict[tuple[str, tuple[str, ...]], float] = {}
    _HISTOGRAMS: dict[tuple[str, tuple[str, ...]], list[float]] = {}

    class _MetricHandle:
        def __init__(self, storage: dict, name: str, label_values: tuple[str, ...]):
            self._storage = storage
            self._key = (name, label_values)

        def inc(self, amount: float = 1.0) -> None:
            self._storage[self._key] = self._storage.get(self._key, 0.0) + amount

        def observe(self, value: float) -> None:
            self._storage.setdefault(self._key, []).append(value)

    class Counter:  # type: ignore[override]
        def __init__(self, name: str, _: str, labelnames: list[str]):
            self.name = name
            self.labelnames = tuple(labelnames)

        def labels(self, **labels: str) -> _MetricHandle:
            values = tuple(labels[label] for label in self.labelnames)
            return _MetricHandle(_COUNTERS, self.name, values)

    class Histogram:  # type: ignore[override]
        def __init__(self, name: str, _: str, labelnames: list[str]):
            self.name = name
            self.labelnames = tuple(labelnames)

        def labels(self, **labels: str) -> _MetricHandle:
            values = tuple(labels[label] for label in self.labelnames)
            return _MetricHandle(_HISTOGRAMS, self.name, values)

    def generate_latest() -> bytes:
        lines: list[str] = []
        for (name, labels), value in sorted(_COUNTERS.items()):
            rendered_labels = ",".join(f'label_{idx}="{label}"' for idx, label in enumerate(labels))
            suffix = f"{{{rendered_labels}}}" if rendered_labels else ""
            lines.append(f"{name}{suffix} {value}")
        for (name, labels), values in sorted(_HISTOGRAMS.items()):
            rendered_labels = ",".join(f'label_{idx}="{label}"' for idx, label in enumerate(labels))
            suffix = f"{{{rendered_labels}}}" if rendered_labels else ""
            lines.append(f"{name}_count{suffix} {len(values)}")
            lines.append(f"{name}_sum{suffix} {sum(values)}")
        return ("\n".join(lines) + "\n").encode("utf-8")


REQUEST_COUNT = Counter(
    "aegis_rule_engine_requests_total",
    "Total SVC-18 requests",
    ["method", "path", "status_code"],
)
REQUEST_LATENCY = Histogram(
    "aegis_rule_engine_request_latency_seconds",
    "SVC-18 request latency",
    ["method", "path"],
)
RULES_LOADED = Counter(
    "aegis_rule_engine_rules_loaded_total",
    "Total rules loaded by category",
    ["category"],
)
RULE_RELOAD_COUNT = Counter(
    "aegis_rule_engine_rule_reload_total",
    "Total rule reload attempts",
    ["result"],
)
RULE_TRIGGER_COUNT = Counter(
    "aegis_rule_engine_rule_triggered_total",
    "Total triggered rules by category and action",
    ["rule_category", "required_action"],
)
EVALUATION_COUNT = Counter(
    "aegis_rule_engine_evaluations_total",
    "Total rule evaluations",
    ["blocked"],
)


def metrics_response() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
