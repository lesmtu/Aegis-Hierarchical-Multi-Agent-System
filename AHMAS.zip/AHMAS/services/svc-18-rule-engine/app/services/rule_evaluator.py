from __future__ import annotations

import re
from datetime import datetime, timezone

from ..models.evaluate import Complexity, RequiredAction, RuleEvaluateRequest, RuleEvaluateResponse, TriggeredRule
from ..models.rule import RuleCondition, RuleDefinition
from .metrics import EVALUATION_COUNT, RULE_TRIGGER_COUNT
from .rule_loader import RuleStore


COMPLEXITY_ORDER = {
    Complexity.LOW: 1,
    Complexity.MEDIUM: 2,
    Complexity.HIGH: 3,
}


class RuleEvaluator:
    def __init__(self, rule_store: RuleStore):
        self._rule_store = rule_store

    def evaluate(self, request: RuleEvaluateRequest) -> RuleEvaluateResponse:
        triggered: list[TriggeredRule] = []
        for rule in self._rule_store.get_rules():
            if self._matches(rule.condition, request):
                triggered_rule = TriggeredRule(
                    rule_id=rule.id,
                    rule_category=rule.rule_category,
                    rule_name=rule.name,
                    required_action=rule.required_action,
                    description=rule.description,
                )
                triggered.append(triggered_rule)
                RULE_TRIGGER_COUNT.labels(
                    rule_category=triggered_rule.rule_category.value,
                    required_action=triggered_rule.required_action.value,
                ).inc()

        response = RuleEvaluateResponse(
            sub_task_id=request.sub_task_id,
            triggered_rules=triggered,
            requires_audit=any(rule.required_action == RequiredAction.AUDIT for rule in triggered),
            requires_hitl=any(rule.required_action == RequiredAction.HITL for rule in triggered),
            requires_anonymize=any(rule.required_action == RequiredAction.ANONYMIZE for rule in triggered),
            requires_sandbox=any(rule.required_action == RequiredAction.SANDBOX for rule in triggered),
            is_blocked=any(rule.required_action == RequiredAction.BLOCK for rule in triggered),
            evaluated_at=datetime.now(timezone.utc),
        )
        EVALUATION_COUNT.labels(blocked=str(response.is_blocked).lower()).inc()
        return response

    def _matches(self, condition: RuleCondition, request: RuleEvaluateRequest) -> bool:
        if condition.required_capabilities and request.required_capability not in condition.required_capabilities:
            return False
        if condition.complexity_in and request.complexity not in condition.complexity_in:
            return False
        if condition.min_complexity and (
            COMPLEXITY_ORDER[request.complexity] < COMPLEXITY_ORDER[condition.min_complexity]
        ):
            return False
        if condition.cost_tiers and request.cost_tier not in condition.cost_tiers:
            return False
        if condition.min_estimated_cost_usd is not None:
            if request.estimated_cost_usd is None or request.estimated_cost_usd < condition.min_estimated_cost_usd:
                return False
        if condition.description_contains_any:
            haystack = request.description.casefold()
            if not any(term.casefold() in haystack for term in condition.description_contains_any):
                return False
        if condition.description_regex and re.search(condition.description_regex, request.description, re.IGNORECASE) is None:
            return False
        if condition.task_ids:
            task_id = str(request.task_id) if request.task_id is not None else None
            if task_id not in condition.task_ids:
                return False
        if condition.sub_task_ids and str(request.sub_task_id) not in condition.sub_task_ids:
            return False
        return True
