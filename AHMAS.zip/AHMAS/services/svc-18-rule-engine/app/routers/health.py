from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Request, Response

from ..config import settings
from ..models.common import DependencyHealthStatus, HealthCheckResponse, HealthStatus
from ..services.metrics import metrics_response

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthCheckResponse, responses={503: {"model": HealthCheckResponse}})
async def health(_: Request, response: Response) -> HealthCheckResponse:
    payload = HealthCheckResponse(
        service_id=settings.service_id,
        status=HealthStatus.HEALTHY,
        version=settings.service_version,
        dependencies={"rule_store": DependencyHealthStatus.HEALTHY},
        timestamp=datetime.now(timezone.utc),
    )
    if payload.status == HealthStatus.UNHEALTHY:
        response.status_code = 503
    return payload


@router.get(
    "/metrics",
    response_class=Response,
    responses={
        200: {
            "description": "Metrics returned",
            "content": {"text/plain; version=0.0.4": {"schema": {"type": "string"}}},
        }
    },
)
async def metrics():
    return metrics_response()
