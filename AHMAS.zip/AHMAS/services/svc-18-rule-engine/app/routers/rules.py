from __future__ import annotations

from datetime import datetime, timezone
import logging

from fastapi import APIRouter, Request

from ..models.common import APIErrorResponse
from ..models.evaluate import RuleEvaluateRequest, RuleEvaluateResponse, RulesListResponse, RulesReloadResponse
from ..services.rule_evaluator import RuleEvaluator
from ..services.rule_loader import RuleStore

LOGGER = logging.getLogger(__name__)

router = APIRouter(tags=["rules"])


@router.post(
    "/rules/evaluate",
    response_model=RuleEvaluateResponse,
    responses={
        400: {"model": APIErrorResponse, "description": "Invalid request payload"},
        500: {"model": APIErrorResponse, "description": "Rule engine internal error"},
    },
)
async def evaluate_rules(request: Request, payload: RuleEvaluateRequest) -> RuleEvaluateResponse:
    evaluator: RuleEvaluator = request.app.state.rule_evaluator
    result = evaluator.evaluate(payload)
    LOGGER.info("Evaluated sub_task_id=%s blocked=%s triggered=%s", payload.sub_task_id, result.is_blocked, len(result.triggered_rules))
    return result


@router.get("/rules", response_model=RulesListResponse)
async def list_rules(request: Request) -> RulesListResponse:
    rule_store: RuleStore = request.app.state.rule_store
    return RulesListResponse(rules=rule_store.list_triggered_rules(), loaded_at=rule_store.loaded_at)


@router.post(
    "/rules/reload",
    response_model=RulesReloadResponse,
    responses={500: {"model": APIErrorResponse, "description": "Reload failed"}},
)
async def reload_rules(request: Request) -> RulesReloadResponse:
    rule_store: RuleStore = request.app.state.rule_store
    count = rule_store.reload()
    reloaded_at = datetime.now(timezone.utc)
    LOGGER.info("Reloaded rules count=%s at=%s", count, reloaded_at.isoformat())
    return RulesReloadResponse(reloaded=True, rule_count=count, reloaded_at=reloaded_at)
