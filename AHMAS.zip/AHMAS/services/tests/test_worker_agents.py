import asyncio
import importlib.util
import uuid
from pathlib import Path

from libs.lib02_rag import RAGContext


ROOT = Path("/home/g/AHMAS")


def load_agent_class(relative_path: str, class_name: str):
    path = ROOT / relative_path
    spec = importlib.util.spec_from_file_location(class_name.lower(), path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return getattr(module, class_name)


ResearchAgent = load_agent_class("services/svc-05-research/agent.py", "ResearchAgent")
CodeAgent = load_agent_class("services/svc-08-code/agent.py", "CodeAgent")
ToolBuilderAgent = load_agent_class("services/svc-09-tool-builder/agent.py", "ToolBuilderAgent")


class DummyEnvelope:
    def __init__(self, event_type: str, payload: dict):
        self.event_id = str(uuid.uuid4())
        self.event_type = event_type
        self.payload = payload
        self.correlation_id = payload["task_id"]
        self.trace_id = str(uuid.uuid4())


class DummyProducer:
    def __init__(self):
        self.produced = []

    async def produce_envelope(self, topic, payload, source_service, correlation_id, trace_id):
        self.produced.append(
            type(
                "ProducedEvent",
                (),
                {
                    "event_type": topic,
                    "payload": payload,
                    "source_service": source_service,
                    "correlation_id": correlation_id,
                    "trace_id": trace_id,
                },
            )()
        )

    async def produce_coemitted(
        self,
        events,
        source_service,
        correlation_id,
        trace_id,
        idempotency_key=None,
    ):
        for event in events:
            await self.produce_envelope(
                event["topic"],
                event["payload"],
                source_service,
                correlation_id,
                trace_id,
            )


class DummyIdempotency:
    def __init__(self):
        self.check_and_set_called_with = None
        self.completed = []
        self.failed = []

    def check_and_set(self, idempotency_key, event_id):
        self.check_and_set_called_with = idempotency_key
        return True

    def mark_completed(self, idempotency_key, event_id):
        self.completed.append((idempotency_key, event_id))

    def mark_failed(self, idempotency_key, event_id):
        self.failed.append((idempotency_key, event_id))


class DummyMemory:
    def __init__(self):
        self.store_called = False
        self.store_calls = []

    async def store(self, payload):
        self.store_called = True
        self.store_calls.append(payload)


class DummyReflectionResult:
    def __init__(self, confidence_score):
        self.confidence_score = confidence_score
        self.identified_gaps = ["gap"]
        self.correction_suggestions = ["tighten output"]


class DummyReflection:
    def __init__(self, confidence_scores):
        self.confidence_scores = list(confidence_scores)
        self.calls = 0

    def evaluate(self, task_description, output, context):
        score = self.confidence_scores[min(self.calls, len(self.confidence_scores) - 1)]
        self.calls += 1
        return DummyReflectionResult(score)


class DummyRAG:
    def __init__(self, ctx=None):
        self.ctx = ctx or RAGContext(
            context_chunks=["ctx"],
            source_ids=["source-1"],
            retrieval_scores=[0.9],
            degraded_mode=False,
        )

    def retrieve_and_inject(self, *args, **kwargs):
        return self.ctx


class DummyTool:
    def __init__(self, tool_id, name):
        self.tool_id = tool_id
        self.name = name


class DummyToolResult:
    def __init__(self, success, output):
        self.success = success
        self.output = output


class DummyTools:
    def list_available_tools(self, capability_type):
        if capability_type == "research":
            return [DummyTool("web_search", "web_search")]
        return []

    def invoke_tool(self, tool_id, payload):
        return DummyToolResult(True, {"results": [payload["query"]]})


class DummyLLMResponse:
    def __init__(self, text):
        self.text = text


class DummyLLM:
    def __init__(self, text='{"code":"print(1)"}', model_name="test-model"):
        self.text = text
        self.model_name = model_name

    async def complete(self, *args, **kwargs):
        return DummyLLMResponse(self.text)


def valid_payload(agent_type="research"):
    return {
        "task_id": str(uuid.uuid4()),
        "node_id": str(uuid.uuid4()),
        "dag_id": str(uuid.uuid4()),
        "agent_type": agent_type,
        "agent_id": "agent-1",
        "sub_task_name": "name",
        "sub_task_description": "desc",
        "input_context": "context",
        "model_tier": "mid_tier",
        "retry_count": 0,
        "idempotency_key": str(uuid.uuid4()),
        "requires_audit": True,
        "requires_hitl": False,
        "priority": "normal",
        "dispatched_at": "2026-03-31T00:00:00+00:00",
    }


def make_agent(agent_cls, agent_type="research", reflection_scores=(0.9,), llm_text="ok"):
    return agent_cls(
        llm_client=DummyLLM(llm_text),
        rag_pipeline=DummyRAG(),
        reflection_engine=DummyReflection(reflection_scores),
        tool_interface=DummyTools(),
        memory_client=DummyMemory(),
        producer=DummyProducer(),
        idempotency=DummyIdempotency(),
        service_id={
            "research": "SVC-05",
            "logic": "SVC-06",
            "media": "SVC-07",
            "code": "SVC-08",
            "tool_builder": "SVC-09",
            "validation": "SVC-10",
        }[agent_type],
    )


def test_agent_type_filter():
    """Worker MUST ignore task.dispatched where payload.agent_type != own type"""
    envelope = DummyEnvelope("task.dispatched", valid_payload(agent_type="code"))
    research_agent = make_agent(ResearchAgent, agent_type="research")
    asyncio.run(research_agent.process_dispatched_task(envelope))
    assert len(research_agent.producer.produced) == 0


def test_idempotency_key_from_dispatch_payload():
    """contracts.json: idempotency_key is in TaskDispatchedPayload, not envelope header"""
    envelope = DummyEnvelope("task.dispatched", valid_payload())
    agent = make_agent(ResearchAgent, agent_type="research")
    asyncio.run(agent.process_dispatched_task(envelope))
    assert agent.idempotency.check_and_set_called_with == envelope.payload["idempotency_key"]


def test_task_result_all_required_fields():
    """TaskResultPayload: all required fields from contracts.json"""
    required = [
        "task_id",
        "node_id",
        "dag_id",
        "agent_id",
        "agent_type",
        "input",
        "output",
        "confidence",
        "needs_review",
        "degraded_mode",
        "tools_used",
        "rag_sources",
        "reflection_log",
        "metadata",
        "created_at",
    ]
    agent = make_agent(ResearchAgent, agent_type="research")
    asyncio.run(agent.process_dispatched_task(DummyEnvelope("task.dispatched", valid_payload())))
    result_event = [e for e in agent.producer.produced if e.event_type == "task.result"][0]
    for field in required:
        assert field in result_event.payload, f"Missing TaskResultPayload field: {field}"


def test_task_confidence_coemitted():
    """task.confidence MUST be emitted together with task.result"""
    agent = make_agent(ResearchAgent, agent_type="research")
    asyncio.run(agent.process_dispatched_task(DummyEnvelope("task.dispatched", valid_payload())))
    result_events = [e.event_type for e in agent.producer.produced]
    assert "task.result" in result_events
    assert "task.confidence" in result_events


def test_needs_review_true_after_max_retries():
    """contracts.json: needs_review=True when confidence < 0.75 after max 2 internal retries"""
    agent = make_agent(ResearchAgent, agent_type="research", reflection_scores=(0.5, 0.5, 0.5))
    asyncio.run(agent.process_dispatched_task(DummyEnvelope("task.dispatched", valid_payload())))
    result_event = [e for e in agent.producer.produced if e.event_type == "task.result"][0]
    assert result_event.payload["needs_review"] is True


def test_degraded_mode_propagated_from_rag():
    """contracts.json: degraded_mode=True in TaskResultPayload when SVC-16 unavailable"""
    agent = make_agent(ResearchAgent, agent_type="research")
    agent.rag.retrieve_and_inject = lambda *a, **kw: RAGContext.empty_degraded()
    asyncio.run(agent.process_dispatched_task(DummyEnvelope("task.dispatched", valid_payload())))
    result = [e for e in agent.producer.produced if e.event_type == "task.result"][0]
    assert result.payload["degraded_mode"] is True


def test_svc08_sandbox_required():
    """contracts.json SVC-08.behavior.sandbox_required_for_code_execution=true"""
    code_agent = make_agent(
        CodeAgent,
        agent_type="code",
        llm_text='{"code":"print(1)","tests":"assert True","usage":"python x.py"}',
    )
    output, tools = asyncio.run(
        code_agent.execute_task(valid_payload(agent_type="code"), DummyRAG().ctx)
    )
    assert "code_executor" in tools
    assert "sandbox_result" in output


def test_svc09_bandit_static_analysis():
    """contracts.json SVC-09.behavior.static_analysis_tool='bandit'"""
    tool_builder = make_agent(
        ToolBuilderAgent,
        agent_type="tool_builder",
        llm_text="def run(x):\n    return x\n",
    )
    output, tools = asyncio.run(
        tool_builder.execute_task(
            valid_payload(agent_type="tool_builder"), DummyRAG().ctx
        )
    )
    assert "bandit_passed" in output


def test_episodic_memory_stored_after_completion():
    """contracts.json SVC-05..10 behavior.store_result_in_episodic_memory=True"""
    agent = make_agent(ResearchAgent, agent_type="research")
    asyncio.run(agent.process_dispatched_task(DummyEnvelope("task.dispatched", valid_payload())))
    assert agent.memory.store_called is True
    call_args = agent.memory.store_calls[0]
    assert call_args["memory_type"] == "episodic"
