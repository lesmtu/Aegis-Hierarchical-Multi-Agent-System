from __future__ import annotations

import asyncio
import importlib
import importlib.util
import json
import sys
import types
from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from jsonschema import Draft7Validator, RefResolver

try:
    from prometheus_client import REGISTRY
except ModuleNotFoundError:  # pragma: no cover - optional in root test env
    REGISTRY = None


ROOT = Path("/home/g/AHMAS")
CONTRACTS = json.loads((ROOT / "contracts.json").read_text(encoding="utf-8"))
SHARED_SCHEMAS = CONTRACTS["global"]["shared_schemas"]
TOPICS = list(CONTRACTS["global"]["topics"].keys())
TOPIC_TO_SCHEMA = {
    "user.input": "UserInputPayload",
    "task.received": "TaskContext",
    "plan.created": "Plan",
    "dag.created": "DAG",
    "task.dispatched": "TaskDispatchedPayload",
    "task.result": "TaskResultPayload",
    "task.confidence": "TaskConfidencePayload",
    "task.validated": "TaskValidatedPayload",
    "retry.required": "RetryRequiredPayload",
    "task.failed": "TaskFailedPayload",
    "task.completed": "TaskCompletedPayload",
    "replan.required": "ReplanRequiredPayload",
    "result.ready": "ResultReadyPayload",
    "notification.out": "NotificationOutPayload",
    "hitl.request": "HITLRequestPayload",
    "hitl.response": "HITLResponsePayload",
    "capability.missing": "CapabilityMissingPayload",
    "tool.created": "ToolCreatedPayload",
    "tool.generation.failed": "ToolGenerationFailedPayload",
    "meta.agent.request": "MetaAgentRequestPayload",
    "agent.created": "AgentCreatedPayload",
    "meta.agent.failed": "MetaAgentFailedPayload",
    "task.progress": "TaskProgressPayload",
    "task.dlq": "DLQPayload",
    "event.dlq": "DLQPayload",
}
EVENT_VALIDATOR = Draft7Validator(
    CONTRACTS["global"]["event_schema"],
    resolver=RefResolver.from_schema(CONTRACTS),
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def uuid_str() -> str:
    return str(uuid4())


def schema_validator(schema_name: str) -> Draft7Validator:
    return Draft7Validator(
        SHARED_SCHEMAS[schema_name],
        resolver=RefResolver.from_schema(CONTRACTS),
    )


def validate_payload(topic: str, payload: dict[str, Any]) -> None:
    schema_name = TOPIC_TO_SCHEMA[topic]
    schema_validator(schema_name).validate(payload)


def build_envelope(
    topic: str,
    payload: dict[str, Any],
    *,
    source_service: str,
    correlation_id: str,
    trace_id: str,
    idempotency_key: str | None = None,
    status: str = "success",
    error: dict[str, Any] | None = None,
) -> dict[str, Any]:
    envelope = {
        "event_id": uuid_str(),
        "event_type": topic,
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": now_iso(),
        "source_service": source_service,
        "correlation_id": correlation_id,
        "trace_id": trace_id,
        "idempotency_key": idempotency_key or uuid_str(),
        "status": status,
        "payload": payload,
        "error": error if status == "error" else None,
    }
    validate_payload(topic, payload)
    EVENT_VALIDATOR.validate(envelope)
    return envelope


def sample_payloads(task_id: str | None = None) -> dict[str, dict[str, Any]]:
    task_id = task_id or uuid_str()
    session_id = uuid_str()
    dag_id = uuid_str()
    plan_id = uuid_str()
    node_id = "node-1"
    sub_task_id = uuid_str()
    capability_request_id = uuid_str()
    meta_request_id = uuid_str()
    hitl_id = uuid_str()
    tool_id = uuid_str()
    user_id = "user-1"
    created_at = now_iso()
    agent_spec = {
        "agent_spec_id": uuid_str(),
        "name": "dynamic-logic-agent",
        "capability_type": "logic",
        "tool_ids": [tool_id],
        "system_prompt_template": "Solve logic tasks safely.",
        "llm_config": {
            "model_tier": "mid_tier",
            "max_tokens": 4096,
            "temperature": 0.2,
        },
        "version": "1.0.0",
    }
    sandbox_results = {
        "passed": True,
        "unit_tests_passed": True,
        "integration_tests_passed": True,
        "static_analysis_passed": True,
        "execution_time_ms": 450,
        "failure_details": None,
    }
    tool_entry = {
        "tool_id": tool_id,
        "name": "graph_search",
        "description": "Graph lookup helper",
        "capability_type": "tool_builder",
        "interface": {
            "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
            "output_schema": {"type": "object", "properties": {"result": {"type": "string"}}, "required": ["result"]},
        },
        "runtime": "python",
        "code_path": "/tools/graph_search.py",
        "version": "1.0.0",
        "created_by": "SVC-11",
        "sandbox_test_results": sandbox_results,
        "usage_count": 0,
        "created_at": created_at,
    }
    return {
        "user.input": {
            "user_id": user_id,
            "session_id": session_id,
            "channel": "telegram",
            "raw_input": "Research the history of artificial intelligence",
            "timestamp": created_at,
            "telegram_chat_id": "456",
            "telegram_message_id": 10,
        },
        "task.received": {
            "task_id": task_id,
            "user_id": user_id,
            "session_id": session_id,
            "channel": "telegram",
            "raw_input": "Research the history of artificial intelligence",
            "parsed_intent": "research the history of artificial intelligence",
            "intent_type": "task",
            "context_chunks": ["context chunk"],
            "rag_source_ids": ["note-1"],
            "preliminary_confidence": 0.86,
            "is_ambiguous": False,
            "pii_detected": False,
            "telegram_chat_id": "456",
            "created_at": created_at,
        },
        "plan.created": {
            "plan_id": plan_id,
            "task_id": task_id,
            "goal": "Research the history of artificial intelligence",
            "priority": "normal",
            "sub_tasks": [
                {
                    "sub_task_id": sub_task_id,
                    "name": "Research AI history",
                    "description": "Collect a concise historical summary.",
                    "required_capability": "research",
                    "complexity": "medium",
                    "cost_tier": "cheap",
                    "dependencies": [],
                    "estimated_tokens": 512,
                }
            ],
            "reflection_score": 0.91,
            "version": "1.0.0",
            "replan_attempt": 0,
            "created_at": created_at,
        },
        "dag.created": {
            "dag_id": dag_id,
            "plan_id": plan_id,
            "task_id": task_id,
            "nodes": [
                {
                    "node_id": node_id,
                    "sub_task_id": sub_task_id,
                    "agent_type": "research",
                    "agent_id": "agent-research-1",
                    "dependencies": [],
                    "model_tier": "lightweight",
                    "retry_policy": {"max_retries": 2, "backoff_strategy": "linear"},
                    "requires_audit": True,
                    "requires_hitl": False,
                    "priority": "normal",
                }
            ],
            "edges": [],
            "version": "1.0.0",
            "created_at": created_at,
        },
        "task.dispatched": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "agent_type": "research",
            "agent_id": "agent-research-1",
            "sub_task_name": "Research AI history",
            "sub_task_description": "Collect a concise historical summary.",
            "input_context": "Context: prior retrieved notes about the history of AI.",
            "model_tier": "lightweight",
            "retry_count": 0,
            "idempotency_key": uuid_str(),
            "requires_audit": True,
            "requires_hitl": False,
            "priority": "normal",
            "dispatched_at": created_at,
        },
        "task.result": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "agent_id": "agent-research-1",
            "agent_type": "research",
            "input": "Research the history of artificial intelligence",
            "output": {"summary": "AI history summary"},
            "confidence": 0.92,
            "needs_review": False,
            "degraded_mode": False,
            "tools_used": ["wikipedia"],
            "rag_sources": ["note-1"],
            "reflection_log": ["Reflection passed", "Output is complete"],
            "metadata": {
                "cost_usd": 0.02,
                "latency_ms": 1200,
                "tokens_used": 300,
                "model_used": "gpt-5-mini",
            },
            "created_at": created_at,
        },
        "task.confidence": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "agent_type": "research",
            "confidence": 0.92,
            "needs_review": False,
            "model_used": "gpt-5-mini",
            "created_at": created_at,
        },
        "task.validated": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "validation_status": "passed",
            "checks": {
                "logical_consistency": True,
                "data_validity": True,
                "confidence_threshold": True,
            },
            "auditor_confidence": 0.95,
            "retry_count": 0,
            "created_at": created_at,
        },
        "retry.required": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "failure_reason": "Validation failed",
            "correction_guidance": "Add missing source citations.",
            "retry_count": 1,
            "max_retries": 2,
            "created_at": created_at,
        },
        "task.failed": {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "failure_reason": "Worker timeout after retries exhausted",
            "failure_source": "orchestrator",
            "retry_count": 2,
            "replan_attempt": 1,
            "last_output": "partial output",
            "created_at": created_at,
        },
        "task.completed": {
            "task_id": task_id,
            "dag_id": dag_id,
            "user_id": user_id,
            "session_id": session_id,
            "channel": "telegram",
            "completed_nodes": 1,
            "total_nodes": 1,
            "total_cost_usd": 0.02,
            "total_latency_ms": 1800,
            "created_at": created_at,
        },
        "replan.required": {
            "task_id": task_id,
            "dag_id": dag_id,
            "failed_node_id": node_id,
            "failure_context": "CYCLIC_DEPENDENCY_IN_PLAN: A -> B -> A",
            "replan_attempt": 1,
            "original_plan_id": plan_id,
            "completed_node_ids": [],
            "replan_source": "delegation_engine",
            "created_at": created_at,
        },
        "result.ready": {
            "task_id": task_id,
            "dag_id": dag_id,
            "user_id": user_id,
            "session_id": session_id,
            "channel": "telegram",
            "telegram_chat_id": "456",
            "synthesized_output": "Final answer for the user",
            "reflection_score": 0.93,
            "aggregation_metadata": {
                "total_nodes": 1,
                "conflict_resolutions": 0,
                "sources_used": ["note-1"],
            },
            "created_at": created_at,
        },
        "notification.out": {
            "notification_id": uuid_str(),
            "task_id": task_id,
            "user_id": user_id,
            "session_id": session_id,
            "channel": "telegram",
            "message_type": "result",
            "message_content": "Final answer for the user",
            "telegram_chat_id": "456",
            "delivery_status": "pending",
            "retry_count": 0,
            "created_at": created_at,
        },
        "hitl.request": {
            "hitl_id": hitl_id,
            "task_id": task_id,
            "node_id": node_id,
            "user_id": user_id,
            "session_id": session_id,
            "trigger_reason": "planner_failure",
            "risk_classification": "high",
            "context": "Cycle detected in execution plan",
            "current_output": "A -> B -> A",
            "confidence_score": 0.2,
            "available_actions": ["approve", "reject", "modify", "clarify"],
            "timeout_hours": 24,
            "created_at": created_at,
        },
        "hitl.response": {
            "hitl_id": hitl_id,
            "task_id": task_id,
            "node_id": node_id,
            "decision": "timeout_auto_reject",
            "responded_by": "system",
            "responded_at": created_at,
        },
        "capability.missing": {
            "capability_request_id": capability_request_id,
            "task_id": task_id,
            "dag_id": dag_id,
            "required_capability": "tool_builder",
            "description": "Need a custom graph traversal tool",
            "sub_task_id": sub_task_id,
            "suggested_tool_type": "python_function",
            "created_at": created_at,
        },
        "tool.created": {
            "tool_id": tool_id,
            "capability_request_id": capability_request_id,
            "task_id": task_id,
            "tool_entry": tool_entry,
            "created_at": created_at,
        },
        "tool.generation.failed": {
            "capability_request_id": capability_request_id,
            "task_id": task_id,
            "required_capability": "tool_builder",
            "failure_reason": "Sandbox execution failed",
            "retry_count": 3,
            "created_at": created_at,
        },
        "meta.agent.request": {
            "meta_request_id": meta_request_id,
            "task_id": task_id,
            "trigger_reason": "tool_generation_failed",
            "required_capability": "logic",
            "failure_pattern_description": "Repeated tool generation failures",
            "historical_failure_count": 3,
            "historical_failure_logs": ["attempt-1", "attempt-2", "attempt-3"],
            "created_at": created_at,
        },
        "agent.created": {
            "meta_request_id": meta_request_id,
            "agent_spec": agent_spec,
            "sandbox_test_results": sandbox_results,
            "created_at": created_at,
        },
        "meta.agent.failed": {
            "meta_request_id": meta_request_id,
            "task_id": task_id,
            "required_capability": "logic",
            "failure_reason": "Kill switch is active: all meta-agent creation is halted",
            "created_at": created_at,
        },
        "task.progress": {
            "task_id": task_id,
            "dag_id": dag_id,
            "user_id": user_id,
            "session_id": session_id,
            "progress_percentage": 100.0,
            "current_step": "task_completed",
            "completed_nodes": 1,
            "total_nodes": 1,
            "status": "completing",
            "created_at": created_at,
        },
        "task.dlq": {
            "dlq_id": uuid_str(),
            "original_topic": "task.received",
            "original_event_id": uuid_str(),
            "original_payload": {"task_id": task_id},
            "failure_reason": "Worker timeout after retries exhausted",
            "retry_count": 2,
            "source_service": "SVC-04",
            "created_at": created_at,
        },
        "event.dlq": {
            "dlq_id": uuid_str(),
            "original_topic": "task.received",
            "original_event_id": uuid_str(),
            "original_payload": {"task_id": task_id},
            "failure_reason": "Schema version mismatch",
            "retry_count": 0,
            "source_service": "SVC-01",
            "created_at": created_at,
        },
    }


@dataclass
class CapturedEvent:
    topic: str
    envelope: dict[str, Any]


class IntegrationHarness:
    def __init__(self) -> None:
        self.events: list[CapturedEvent] = []
        self._processed: set[tuple[str, str]] = set()
        self._idempotency_lock = asyncio.Lock()

    def emit(
        self,
        topic: str,
        payload: dict[str, Any],
        *,
        source_service: str,
        correlation_id: str,
        trace_id: str,
        idempotency_key: str | None = None,
        status: str = "success",
        error: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        envelope = build_envelope(
            topic,
            payload,
            source_service=source_service,
            correlation_id=correlation_id,
            trace_id=trace_id,
            idempotency_key=idempotency_key,
            status=status,
            error=error,
        )
        self.events.append(CapturedEvent(topic=topic, envelope=envelope))
        return envelope

    def count(self, topic: str, correlation_id: str | None = None) -> int:
        return sum(
            1
            for event in self.events
            if event.topic == topic
            and (correlation_id is None or event.envelope["correlation_id"] == correlation_id)
        )

    def topics(self) -> list[str]:
        return [event.topic for event in self.events]

    def by_topic(self, topic: str) -> list[dict[str, Any]]:
        return [event.envelope for event in self.events if event.topic == topic]

    async def process_task_received(self, envelope: dict[str, Any]) -> bool:
        service_key = ("SVC-02", envelope["idempotency_key"])
        async with self._idempotency_lock:
            if service_key in self._processed:
                return False
            self._processed.add(service_key)

        task_id = envelope["correlation_id"]
        trace_id = envelope["trace_id"]
        fixtures = sample_payloads(task_id)
        self.emit(
            "plan.created",
            fixtures["plan.created"],
            source_service="SVC-02",
            correlation_id=task_id,
            trace_id=trace_id,
        )
        return True

    def run_happy_path(self) -> tuple[str, str]:
        task_id = uuid_str()
        trace_id = uuid_str()
        fixtures = sample_payloads(task_id)

        self.emit("user.input", fixtures["user.input"], source_service="SVC-01", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.received", fixtures["task.received"], source_service="SVC-01", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 10.0, "current_step": "task_received", "status": "running"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("plan.created", fixtures["plan.created"], source_service="SVC-02", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 25.0, "current_step": "plan_created", "status": "running"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("dag.created", fixtures["dag.created"], source_service="SVC-03", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 40.0, "current_step": "dag_created", "status": "running"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.dispatched", fixtures["task.dispatched"], source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 55.0, "current_step": "task_dispatched", "status": "running"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.result", fixtures["task.result"], source_service="SVC-05", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.confidence", fixtures["task.confidence"], source_service="SVC-05", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 70.0, "current_step": "task_result", "status": "running"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.validated", fixtures["task.validated"], source_service="SVC-12", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 82.0, "current_step": "task_validated", "status": "completing"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("result.ready", fixtures["result.ready"], source_service="SVC-13", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "progress_percentage": 91.0, "current_step": "result_ready", "status": "completing"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("notification.out", fixtures["notification.out"], source_service="SVC-14", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.completed", fixtures["task.completed"], source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        self.emit("task.progress", {**fixtures["task.progress"], "status": "completing"}, source_service="SVC-04", correlation_id=task_id, trace_id=trace_id)
        return task_id, trace_id


def purge_app_modules() -> None:
    for name in list(sys.modules):
        if name == "app" or name.startswith("app.") or name == "tests" or name.startswith("tests."):
            sys.modules.pop(name)


def reset_prometheus_registry() -> None:
    if REGISTRY is None:
        return
    for collector in list(REGISTRY._collector_to_names.keys()):
        REGISTRY.unregister(collector)


def _normalize_service_path(service_root: Path) -> None:
    service_root_str = str(service_root)
    sys.path[:] = [
        entry for entry in sys.path
        if "/home/g/AHMAS/services/svc-" not in entry or entry == service_root_str
    ]
    if service_root_str in sys.path:
        sys.path.remove(service_root_str)
    sys.path.insert(0, service_root_str)
    if "prometheus_client" not in sys.modules:
        fake = types.ModuleType("prometheus_client")

        class _NoopMetric:
            def labels(self, **_kwargs):
                return self

            def inc(self, *_args, **_kwargs):
                return None

            def set(self, *_args, **_kwargs):
                return None

            def observe(self, *_args, **_kwargs):
                return None

        fake.Counter = lambda *args, **kwargs: _NoopMetric()
        fake.Gauge = lambda *args, **kwargs: _NoopMetric()
        fake.Histogram = lambda *args, **kwargs: _NoopMetric()
        fake.Summary = lambda *args, **kwargs: _NoopMetric()
        fake.CollectorRegistry = object
        fake.generate_latest = lambda *_args, **_kwargs: b""
        fake.CONTENT_TYPE_LATEST = "text/plain; version=0.0.4"
        fake.REGISTRY = None
        sys.modules["prometheus_client"] = fake
    if "aiokafka" not in sys.modules:
        fake_aiokafka = types.ModuleType("aiokafka")

        class _FakeProducer:
            async def start(self):
                return None

            async def stop(self):
                return None

            async def send_and_wait(self, *args, **kwargs):
                return None

        fake_aiokafka.AIOKafkaProducer = _FakeProducer
        sys.modules["aiokafka"] = fake_aiokafka


def import_service_app(service_root: Path):
    purge_app_modules()
    reset_prometheus_registry()
    _normalize_service_path(service_root)
    return importlib.import_module("app.main")


def import_service_module(service_root: Path, module_name: str):
    purge_app_modules()
    _normalize_service_path(service_root)
    return importlib.import_module(module_name)


def import_module_from_file(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def test_happy_path_traces_full_message_and_validates_contracts():
    harness = IntegrationHarness()
    task_id, trace_id = harness.run_happy_path()

    expected_order = [
        "user.input",
        "task.received",
        "task.progress",
        "plan.created",
        "task.progress",
        "dag.created",
        "task.progress",
        "task.dispatched",
        "task.progress",
        "task.result",
        "task.confidence",
        "task.progress",
        "task.validated",
        "task.progress",
        "result.ready",
        "task.progress",
        "notification.out",
        "task.completed",
        "task.progress",
    ]
    assert harness.topics() == expected_order

    for event in harness.events:
        assert event.envelope["correlation_id"] == task_id
        assert event.envelope["trace_id"] == trace_id
        validate_payload(event.topic, event.envelope["payload"])
        EVENT_VALIDATOR.validate(event.envelope)

    result_index = harness.topics().index("task.result")
    confidence_index = harness.topics().index("task.confidence")
    assert confidence_index == result_index + 1
    assert harness.by_topic("task.result")[0]["payload"]["confidence"] == harness.by_topic("task.confidence")[0]["payload"]["confidence"]

    state_topics = {
        "task.received": "task_received",
        "plan.created": "plan_created",
        "dag.created": "dag_created",
        "task.dispatched": "task_dispatched",
        "task.result": "task_result",
        "task.validated": "task_validated",
        "result.ready": "result_ready",
        "task.completed": "task_completed",
    }
    progress_steps = {event["payload"]["current_step"] for event in harness.by_topic("task.progress")}
    assert progress_steps >= set(state_topics.values())
    assert harness.by_topic("task.validated")[0]["payload"]["validation_status"] == "passed"


def test_idempotency_with_five_concurrent_identical_envelopes_processes_once():
    harness = IntegrationHarness()
    task_id = uuid_str()
    trace_id = uuid_str()
    fixtures = sample_payloads(task_id)
    shared_key = uuid_str()
    envelopes = [
        build_envelope(
            "task.received",
            fixtures["task.received"],
            source_service="SVC-01",
            correlation_id=task_id,
            trace_id=trace_id,
            idempotency_key=shared_key,
        )
        for _ in range(5)
    ]
    async def run_concurrently():
        return await asyncio.gather(*(harness.process_task_received(deepcopy(envelope)) for envelope in envelopes))

    results = asyncio.run(run_concurrently())
    assert Counter(results) == Counter({False: 4, True: 1})
    assert harness.count("plan.created", task_id) == 1


def test_all_25_kafka_topics_have_contract_valid_sample_events():
    task_id = uuid_str()
    trace_id = uuid_str()
    payloads = sample_payloads(task_id)
    produced_topics: set[str] = set()
    consumed_topics: set[str] = set()
    topic_to_sources = defaultdict(set)
    topic_to_consumers = defaultdict(set)

    for service in CONTRACTS["services"]:
        for topic in service["produces_topics"]:
            topic_to_sources[topic].add(service["service_id"])
        for topic in service["consumes_topics"]:
            topic_to_consumers[topic].add(service["service_id"])

    for topic in TOPICS:
        source = sorted(topic_to_sources[topic])[0] if topic_to_sources[topic] else "SVC-01"
        envelope = build_envelope(
            topic,
            payloads[topic],
            source_service=source,
            correlation_id=task_id,
            trace_id=trace_id,
            status="error" if topic in {"task.dlq", "event.dlq"} else "success",
            error={
                "error_code": "WORKER_TIMEOUT",
                "error_type": "timeout",
                "retryable": True,
                "message": "worker timed out",
            } if topic == "task.dlq" else ({
                "error_code": "SCHEMA_VERSION_MISMATCH",
                "error_type": "validation",
                "retryable": False,
                "message": "major schema mismatch",
            } if topic == "event.dlq" else None),
        )
        EVENT_VALIDATOR.validate(envelope)
        produced_topics.add(topic)
        if topic_to_consumers[topic]:
            consumed_topics.add(topic)

    assert produced_topics == set(TOPICS)
    assert consumed_topics == set(TOPICS)


def test_svc22_non_retryable_dlq_retry_returns_not_retried():
    service_root = ROOT / "services" / "svc-22-dlq-manager"
    module = import_service_app(service_root)
    test_module = importlib.import_module("tests.test_service")
    test_module.setup_function()
    envelope = test_module.dlq_envelope(error_code="HITL_TIMEOUT_EXCEEDED", source_service="SVC-15")
    asyncio.run(test_module.get_kafka_consumer().consume(envelope))
    with TestClient(module.app) as client:
        response = client.post(
            f"/dlq/events/{envelope['payload']['dlq_id']}/retry",
            json={
                "operator_id": "op-1",
                "retry_justification": "This error is non-retryable and should stay out of the main flow.",
            },
        )
    assert response.status_code == 422
    assert test_module.get_kafka_producer().backend.messages == []


def test_hitl_timeout_auto_reject_emits_exact_decision():
    service_root = ROOT / "services" / "svc-15-hitl-gateway"
    module = import_service_module(service_root, "app.dependencies")
    models = import_service_module(service_root, "app.models")
    module.reset_runtime_state()
    service = module.get_hitl_service()

    envelope = build_envelope(
        "hitl.request",
        sample_payloads()["hitl.request"],
        source_service="SVC-04",
        correlation_id=sample_payloads()["hitl.request"]["task_id"],
        trace_id=uuid_str(),
    )
    asyncio.run(service.handle_hitl_request(envelope))
    asyncio.run(service.auto_reject_timeout(envelope["payload"]["hitl_id"]))
    produced = [event for event in module.get_kafka_producer().produced if event.event_type == "hitl.response"]
    assert produced[-1].payload["decision"] == models.HITLDecision.TIMEOUT_AUTO_REJECT.value


def test_cycle_detection_emits_hitl_request_and_replan_required():
    service_root = ROOT / "services" / "svc-03-delegation"
    module = import_service_module(service_root, "app.services.dag_builder")

    class Producer:
        def __init__(self) -> None:
            self.events: list[dict[str, Any]] = []

        async def produce(self, topic, payload, correlation_id, trace_id, message_key=None, status="success", error=None):
            self.events.append(
                {
                    "topic": topic,
                    "payload": payload,
                    "correlation_id": correlation_id,
                    "trace_id": trace_id,
                    "status": status,
                    "error": error,
                }
            )

    task_id = uuid_str()
    producer = Producer()
    builder = module.DAGBuilder(
        rule_checker=object(),
        capability_resolver=object(),
        cost_optimizer=object(),
        producer=producer,
    )
    plan = sample_payloads(task_id)["plan.created"]
    plan["sub_tasks"] = [
        {
            "sub_task_id": "A",
            "name": "A",
            "description": "depends on B",
            "required_capability": "logic",
            "complexity": "low",
            "cost_tier": "cheap",
            "dependencies": ["B"],
            "estimated_tokens": 10,
        },
        {
            "sub_task_id": "B",
            "name": "B",
            "description": "depends on A",
            "required_capability": "logic",
            "complexity": "low",
            "cost_tier": "cheap",
            "dependencies": ["A"],
            "estimated_tokens": 10,
        },
    ]

    dag, status = asyncio.run(
        builder.build_dag(
            plan=plan,
            correlation_id=task_id,
            trace_id=uuid_str(),
            replan_attempt=0,
        )
    )
    assert dag is None
    assert status == module.BuildStatus.TERMINAL_FAILURE
    topics = [event["topic"] for event in producer.events]
    assert "hitl.request" in topics
    assert "replan.required" in topics
    replan = next(event for event in producer.events if event["topic"] == "replan.required")
    assert "CYCLIC_DEPENDENCY_IN_PLAN" in replan["payload"]["failure_context"]


def test_meta_agent_kill_switch_blocks_creation_end_to_end():
    service_root = ROOT / "services" / "svc-17-meta-agent-builder"
    purge_app_modules()
    _normalize_service_path(service_root)
    module = import_module_from_file("svc17_test_module", service_root / "tests" / "test_svc17.py")

    redis = module.MockRedis()
    producer = module.MockKafkaProducer()
    builder, *_ = module._make_builder(redis_mock=redis, producer=producer)
    module.KillSwitch(redis).activate()

    envelope = module._make_envelope()
    asyncio.run(builder.handle_meta_agent_request(envelope))

    created = producer.of_type("agent.created")
    failed = producer.of_type("meta.agent.failed")
    assert created == []
    assert len(failed) == 1
    assert failed[0]["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"


@pytest.mark.parametrize(
    ("service_rel", "ready_path", "expected_service_id", "metrics_needles"),
        [
            ("services/svc-01-receptionist", None, "SVC-01", ["aegis_receptionist_requests_total"]),
            ("services/svc-21-prompt-intelligence", "/ready", None, ["aegis_prompt_search_total", "aegis_prompt_vault_size"]),
            ("services/svc-22-dlq-manager", "/ready", "SVC-22", ["aegis_dlq_event_received_total"]),
        ],
    )
def test_health_metrics_and_ready_endpoints(service_rel, ready_path, expected_service_id, metrics_needles, tmp_path, monkeypatch):
    service_root = ROOT / service_rel
    if service_rel.endswith("svc-21-prompt-intelligence"):
        monkeypatch.setenv("PROMPT_VAULT_PATH", str(tmp_path / "prompt-vault"))
        monkeypatch.setenv("PROMPT_SYNC_SOURCES_CONFIG", "[]")
        monkeypatch.setenv("PROMPT_SYNC_INTERVAL_HOURS", "6")
    module = import_service_app(service_root)
    with TestClient(module.app) as client:
        health = client.get("/health")
        assert health.status_code in {200, 503}
        if expected_service_id is not None:
            assert health.json()["service_id"] == expected_service_id
            schema_validator("HealthCheckResponse").validate(health.json())

        metrics = client.get("/metrics")
        assert metrics.status_code == 200
        if metrics.text:
            for needle in metrics_needles:
                assert needle in metrics.text

        if ready_path:
            if service_rel.endswith("svc-21-prompt-intelligence"):
                state = client.app.state.container.startup_state
                state.bge_m3_loaded = False
                state.reindex_worker_complete = False
            ready_first = client.get(ready_path)
            assert ready_first.status_code in {200, 503}
            if service_rel.endswith("svc-21-prompt-intelligence"):
                assert ready_first.status_code == 503
                state.bge_m3_loaded = True
                state.reindex_worker_complete = True
                ready_second = client.get(ready_path)
                assert ready_second.status_code == 200
