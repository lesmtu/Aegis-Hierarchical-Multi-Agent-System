from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import sys
from pathlib import Path

import httpx
import pytest

ROOT = Path("/home/g/AHMAS")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.events.error_codes import AegisErrorCode, ERROR_RETRYABLE
from shared.events.versioning import CURRENT_ENVELOPE_VERSION, negotiate_schema_version

from services.tests.test_step_11_1_e2e import (
    import_module_from_file,
    import_service_app,
    purge_app_modules,
    reset_prometheus_registry,
    schema_validator,
)


CONTRACTS = json.loads((ROOT / "contracts.json").read_text(encoding="utf-8"))
TOPICS = CONTRACTS["global"]["topics"]
ERROR_CODES = CONTRACTS["global"]["global_error_codes"]["codes"]
SERVICES = {service["service_id"]: service for service in CONTRACTS["services"]}
HEALTH_RESPONSE_VALIDATOR = schema_validator("HealthCheckResponse")
SERVICE_ROOTS = {service_id: ROOT / "services" / f"svc-{int(service_id.split('-')[1]):02d}-{suffix}" for service_id, suffix in {
    "SVC-01": "receptionist",
    "SVC-02": "planner",
    "SVC-03": "delegation",
    "SVC-04": "orchestrator",
    "SVC-05": "research",
    "SVC-06": "logic",
    "SVC-07": "media",
    "SVC-08": "code",
    "SVC-09": "tool-builder",
    "SVC-10": "validation",
    "SVC-11": "auditor",
    "SVC-12": "quality-controller",
    "SVC-13": "tool-generator",
    "SVC-14": "notification",
    "SVC-15": "hitl-gateway",
    "SVC-16": "memory",
    "SVC-17": "meta-agent-builder",
    "SVC-18": "rule-engine",
    "SVC-19": "capability-registry",
    "SVC-20": "cost-optimizer",
    "SVC-21": "prompt-intelligence",
    "SVC-22": "dlq-manager",
}.items()}


def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _svc21_client(tmp_path, monkeypatch):
    monkeypatch.setenv("PROMPT_VAULT_PATH", str(tmp_path / "prompt-vault"))
    monkeypatch.setenv("PROMPT_SYNC_SOURCES_CONFIG", "[]")
    monkeypatch.setenv("PROMPT_SYNC_INTERVAL_HOURS", "6")
    module = import_service_app(SERVICE_ROOTS["SVC-21"])
    module.app.state.container = module.ServiceContainer()
    return module.app


def _service_app(service_id: str, tmp_path, monkeypatch):
    if service_id == "SVC-21":
        return _svc21_client(tmp_path, monkeypatch)
    return import_service_app(SERVICE_ROOTS[service_id]).app


async def _request(app, method: str, path: str) -> httpx.Response:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        return await client.request(method, path)


class _KafkaAdminFromRepoConfig:
    def __init__(self) -> None:
        self._topics = {topic["topic_name"]: topic for topic in _load_json(ROOT / "infra/kafka/topics-config.json")}

    def list_topics(self):
        return self._topics

    def describe_topic(self, topic_name: str):
        return self._topics[topic_name]


class TestKafkaTopicCompliance:
    """Verify all 25 Kafka topics match contracts.json exactly."""

    def test_all_25_topics_exist(self):
        kafka_admin = _KafkaAdminFromRepoConfig()
        topics = kafka_admin.list_topics()
        expected = set(TOPICS.keys())
        actual = set(topics.keys())
        missing = expected - actual
        assert not missing, f"Missing topics: {sorted(missing)}"

    def test_topic_configs_match_contracts(self):
        kafka_admin = _KafkaAdminFromRepoConfig()
        for topic_name, topic_spec in TOPICS.items():
            config = kafka_admin.describe_topic(topic_name)
            assert config["partitions"] == topic_spec["partitions"], f"{topic_name}: partitions mismatch"
            assert config["retention_ms"] == topic_spec["retention_ms"], f"{topic_name}: retention_ms mismatch"
            assert config["cleanup_policy"] == topic_spec["cleanup_policy"], f"{topic_name}: cleanup_policy mismatch"


class TestErrorCodeCompliance:
    """Verify all 25 error codes from contracts.json are implemented."""

    def test_all_error_codes_in_enum(self):
        expected_codes = {spec["code"] for spec in ERROR_CODES.values()}
        actual_codes = {code.value for code in AegisErrorCode}
        assert actual_codes == expected_codes, f"Error code mismatch: {sorted(actual_codes.symmetric_difference(expected_codes))}"

    def test_retryable_flags_match_contracts(self):
        for code_name, code_spec in ERROR_CODES.items():
            code = AegisErrorCode[code_name]
            assert ERROR_RETRYABLE[code] == code_spec["retryable"], (
                f"Retryable mismatch for {code_spec['code']}: "
                f"expected {code_spec['retryable']}, got {ERROR_RETRYABLE[code]}"
            )


class TestHealthEndpointCompliance:
    """Verify all 22 services expose GET /health with correct HealthCheckResponse."""

    @pytest.mark.parametrize("service_id", list(SERVICES))
    def test_all_services_health(self, service_id: str, tmp_path, monkeypatch):
        app = _service_app(service_id, tmp_path, monkeypatch)
        response = asyncio.run(_request(app, "GET", "/health"))
        assert response.status_code in {200, 503}, f"{service_id}: /health returned {response.status_code}"
        data = response.json()
        HEALTH_RESPONSE_VALIDATOR.validate(data)
        assert data["service_id"] == service_id, f"service_id mismatch: expected {service_id}, got {data['service_id']}"


class TestPrometheusMetricsCompliance:
    """Verify SVC-21 metrics match contracts.json."""

    def test_svc21_all_15_metrics_present(self, tmp_path, monkeypatch):
        expected_metrics = [metric["name"] for metric in SERVICES["SVC-21"]["observability"]["prometheus_metrics"]]
        app = _svc21_client(tmp_path, monkeypatch)
        response = asyncio.run(_request(app, "GET", "/metrics"))
        assert response.status_code == 200
        for metric in expected_metrics:
            assert metric in response.text, f"Missing SVC-21 metric: {metric}"


class TestSchemaVersionNegotiation:
    """Verify version negotiation from contracts.json versioning_policy."""

    def test_major_mismatch_routes_to_event_dlq(self):
        current_major, current_minor, current_patch = CURRENT_ENVELOPE_VERSION.split(".")
        should_process, route_topic, error_payload = negotiate_schema_version(f"{int(current_major) + 1}.{current_minor}.{current_patch}")
        assert should_process is False
        assert route_topic == "event.dlq"
        assert error_payload["error_code"] == "SCHEMA_VERSION_MISMATCH"

    def test_minor_mismatch_processes_with_warning(self, caplog):
        current_major, current_minor, current_patch = CURRENT_ENVELOPE_VERSION.split(".")
        with caplog.at_level(logging.WARNING):
            should_process, route_topic, error_payload = negotiate_schema_version(
                f"{current_major}.{int(current_minor) + 1}.{current_patch}"
            )
        assert should_process is True
        assert route_topic is None
        assert error_payload is None
        assert any(record.levelno == logging.WARNING and "version" in record.getMessage().lower() for record in caplog.records)


class TestSVC21StartupSequence:
    """Verify SVC-21 startup sequence compliance."""

    def test_ready_503_before_startup_complete(self, tmp_path, monkeypatch):
        app = _svc21_client(tmp_path, monkeypatch)
        state = app.state.container.startup_state
        state.bge_m3_loaded = False
        state.reindex_worker_complete = False
        response = asyncio.run(_request(app, "GET", "/ready"))
        assert response.status_code == 503
        assert response.headers.get("Retry-After") == "10"
        assert response.json()["ready"] is False

    def test_ready_200_after_startup_complete(self, tmp_path, monkeypatch):
        app = _svc21_client(tmp_path, monkeypatch)
        state = app.state.container.startup_state
        state.bge_m3_loaded = True
        state.reindex_worker_complete = True
        response = asyncio.run(_request(app, "GET", "/ready"))
        assert response.status_code == 200
        assert response.json()["ready"] is True


class TestSVC17KillSwitch:
    """Verify SVC-17 kill switch blocks all agent creation."""

    def test_kill_switch_blocks_creation(self):
        service_root = SERVICE_ROOTS["SVC-17"]
        purge_app_modules()
        module = import_module_from_file("svc17_step_11_2_module", service_root / "tests/test_svc17.py")

        redis = module.MockRedis()
        producer = module.MockKafkaProducer()
        builder, *_ = module._make_builder(redis_mock=redis, producer=producer)
        module.KillSwitch(redis).activate()

        envelope = module._make_envelope()
        asyncio.run(builder.handle_meta_agent_request(envelope))

        failed = producer.of_type("meta.agent.failed")
        assert len(failed) == 1
        assert failed[0]["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"
        assert producer.of_type("agent.created") == []


class TestSVC03CycleDetection:
    """Verify cyclic dependency detection end-to-end."""

    @pytest.mark.asyncio
    async def test_cycle_emits_hitl_and_replan(self):
        service_root = SERVICE_ROOTS["SVC-03"]
        purge_app_modules()
        reset_prometheus_registry()
        if str(service_root) not in sys.path:
            sys.path.insert(0, str(service_root))

        spec = importlib.util.spec_from_file_location("svc03_step_11_2_module", service_root / "tests/test_dag_builder.py")
        assert spec is not None and spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        sys.modules["svc03_step_11_2_module"] = module
        spec.loader.exec_module(module)

        plan = module._plan(
            [
                module._sub_task("A", deps=["B"]),
                module._sub_task("B", deps=["A"]),
            ],
            replan_attempt=0,
        )
        producer = module.MockProducer()
        builder = module._builder(producer, module.AsyncMock(), module.AsyncMock(), module.AsyncMock())

        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=module._uuid(),
            replan_attempt=0,
        )

        assert dag is None
        assert status == module.BuildStatus.TERMINAL_FAILURE
        hitl_events = producer.by_topic("hitl.request")
        replan_events = producer.by_topic("replan.required")
        assert len(hitl_events) == 1
        assert hitl_events[0]["payload"]["trigger_reason"] == "planner_failure"
        assert len(replan_events) == 1
        assert replan_events[0]["payload"]["replan_source"] == "delegation_engine"
        assert replan_events[0]["payload"]["dag_id"] is None
        assert replan_events[0]["payload"]["failed_node_id"] is None
