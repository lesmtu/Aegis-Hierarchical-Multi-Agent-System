# FILE: services/svc-04-orchestrator/tests/test_orchestrator.py

"""
SVC-04 Execution Orchestrator — Validation Test Suite

Covers all 7 tests from Step 4 Validation Results:
  1. test_atomic_lua_prevents_duplicate_dispatch  (C-15)
  2. test_progress_emitted_on_every_transition    (progress_event_on_every_state_transition)
  3. test_task_completed_when_all_terminal        (TaskCompletedPayload, 10 required fields)
  4. test_replan_at_attempt_1_not_dlq             (PC-08 replan path, attempt 0→1)
  5. test_dlq_at_replan_attempt_2                 (PC-08 DLQ path, DLQPayload 8 required fields)
  6. test_dispatch_payload_all_required_fields    (TaskDispatchedPayload 15 required fields)
  7. test_hitl_node_set_awaiting_human            (HITL pause, hitl.request emission)

Run:
    pytest tests/test_orchestrator.py -v

Requirements:
    pytest>=7.0.0
    pytest-asyncio>=0.21.0
"""
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.dag_state import DAGStateManager
from app.services.dispatcher import NodeDispatcher
from app.services.orchestrator import ExecutionOrchestrator


# ══════════════════════════════════════════════════════════════════════════════
# DATA BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def make_node(
    node_id: str = "node-0",
    agent_type: str = "researcher",
    dependencies: list = None,
    requires_hitl: bool = False,
    requires_audit: bool = False,
    max_retries: int = 2,
    priority: str = "medium",
) -> dict:
    return {
        "node_id": node_id,
        "agent_type": agent_type,
        "agent_id": f"agent-{node_id}",
        "sub_task_id": f"st-{node_id}",
        "dependencies": dependencies if dependencies is not None else [],
        "model_tier": "standard",
        "retry_policy": {"max_retries": max_retries},
        "requires_audit": requires_audit,
        "requires_hitl": requires_hitl,
        "priority": priority,
    }


def make_dag(
    dag_id: str = None,
    task_id: str = None,
    nodes: list = None,
) -> dict:
    return {
        "dag_id": dag_id or str(uuid.uuid4()),
        "task_id": task_id or str(uuid.uuid4()),
        "plan_id": str(uuid.uuid4()),
        "nodes": nodes if nodes is not None else [
            make_node("node-0"),
            make_node("node-1", dependencies=["node-0"]),
        ],
    }


def make_envelope(
    event_type: str,
    payload: dict,
    idempotency_key: str = None,
    event_id: str = None,
    trace_id: str = None,
) -> dict:
    return {
        "event_id": event_id or str(uuid.uuid4()),
        "event_type": event_type,
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": "SVC-03",
        "correlation_id": payload.get("task_id", str(uuid.uuid4())),
        "trace_id": trace_id or str(uuid.uuid4()),
        "idempotency_key": idempotency_key or str(uuid.uuid4()),
        "status": "success",
        "payload": payload,
        "error": None,
    }


def make_meta(
    task_id: str,
    dag_id: str,
    replan_attempt: int = 0,
    total_nodes: int = 2,
) -> dict:
    return {
        "task_id": task_id,
        "dag_id": dag_id,
        "plan_id": str(uuid.uuid4()),
        "user_id": "user-test-001",
        "session_id": "session-test-001",
        "channel": "webui",
        "replan_attempt": replan_attempt,
        "total_nodes": total_nodes,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "total_cost_usd": 0.0,
    }


# ══════════════════════════════════════════════════════════════════════════════
# CALL-LIST HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def extract_topics(call_args_list: list) -> list:
    """Return every Kafka topic name from producer.produce call_args_list."""
    topics = []
    for c in call_args_list:
        topic = c.kwargs.get("topic") or (c.args[0] if c.args else None)
        if topic:
            topics.append(topic)
    return topics


def find_call(call_args_list: list, topic: str):
    """Return the first producer.produce call whose topic matches, or None."""
    for c in call_args_list:
        t = c.kwargs.get("topic") or (c.args[0] if c.args else None)
        if t == topic:
            return c
    return None


def extract_payload(call_obj) -> dict:
    """Extract the payload kwarg from a producer.produce call."""
    if call_obj is None:
        return {}
    return call_obj.kwargs.get("payload") or (
        call_obj.args[1] if len(call_obj.args) > 1 else {}
    )


# ══════════════════════════════════════════════════════════════════════════════
# FIXTURES
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def mock_producer() -> MagicMock:
    """Mocked KafkaProducer — captures every produce() call."""
    p = MagicMock()
    p.produce = AsyncMock(return_value=str(uuid.uuid4()))
    return p


@pytest.fixture
def mock_dag_state() -> MagicMock:
    """
    Fully mocked DAGStateManager.
    Async methods → AsyncMock; sync helpers → MagicMock.
    """
    s = MagicMock()
    s.atomic_transition      = AsyncMock(return_value=True)
    s.get_node_states        = AsyncMock(return_value={})
    s.get_ready_nodes        = AsyncMock(return_value=[])
    s.all_nodes_completed    = AsyncMock(return_value=False)
    s.all_nodes_terminal     = AsyncMock(return_value=False)
    s.count_completed        = MagicMock(return_value=0)
    s.increment_retry        = AsyncMock(return_value=1)
    s.get_retry_count        = AsyncMock(return_value=0)
    s.get_meta               = AsyncMock(return_value={})
    s.update_meta            = AsyncMock()
    s.get_dag_structure      = AsyncMock(return_value=None)
    s.get_dag_id_by_task     = AsyncMock(return_value=None)
    s.get_replan_attempt     = AsyncMock(return_value=0)
    s.set_replan_attempt     = AsyncMock()
    s.initialize_dag         = AsyncMock()
    s.get_task_context       = AsyncMock(return_value={
        "user_id": "user-001",
        "session_id": "session-001",
        "channel": "webui",
    })
    s.find_node              = MagicMock(return_value=None)
    return s


@pytest.fixture
def mock_idempotency() -> MagicMock:
    """Mocked IdempotencyService — always permits processing."""
    i = MagicMock()
    i.check_and_set  = AsyncMock(return_value=True)
    i.mark_completed = AsyncMock()
    i.mark_failed    = AsyncMock()
    return i


@pytest.fixture
def mock_redis() -> MagicMock:
    """Mocked Redis client (used for pub/sub inside _emit_progress)."""
    r = MagicMock()
    r.publish  = AsyncMock()
    r.hgetall  = AsyncMock(return_value={})
    r.get      = AsyncMock(return_value=None)
    r.set      = AsyncMock(return_value=True)
    r.hset     = AsyncMock()
    r.hincrby  = AsyncMock(return_value=1)
    return r


@pytest.fixture
def orchestrator(
    mock_dag_state, mock_producer, mock_idempotency, mock_redis
) -> ExecutionOrchestrator:
    """
    ExecutionOrchestrator with all external dependencies mocked.
    NodeDispatcher uses the real class so dispatch_node logic is exercised.
    """
    dispatcher = NodeDispatcher(producer=mock_producer, state=mock_dag_state)
    return ExecutionOrchestrator(
        dag_state=mock_dag_state,
        dispatcher=dispatcher,
        producer=mock_producer,
        idempotency=mock_idempotency,
        redis_client=mock_redis,
    )


# ══════════════════════════════════════════════════════════════════════════════
# TEST 1 — C-15: Atomic Lua Prevents Duplicate Dispatch
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_atomic_lua_prevents_duplicate_dispatch():
    """
    C-15: Two concurrent atomic_transition calls with the same expected_state
    must succeed exactly once.

    Lua semantics reproduced by side_effect:
      Call 1 → HGET == "pending"  → HSET + return 1  (transition succeeds)
      Call 2 → HGET == "running" ≠ "pending" → return 0  (stale, rejected)
    """
    # Arrange: script returns 1 on first call, 0 on second (simulates Redis atomicity)
    transition_script = AsyncMock(side_effect=[1, 0])

    redis = MagicMock()
    redis.register_script = MagicMock(return_value=transition_script)

    state_manager = DAGStateManager(redis)

    dag_id  = "dag-atomic-001"
    node_id = "node-001"

    # Act: two calls racing with the same expected state
    result_1 = await state_manager.atomic_transition(dag_id, node_id, "pending", "running")
    result_2 = await state_manager.atomic_transition(dag_id, node_id, "pending", "running")

    # Assert: first caller wins, second is rejected
    assert result_1 is True,  "First atomic transition must succeed (Lua returns 1)"
    assert result_2 is False, "Second atomic transition must be rejected (Lua returns 0 — stale)"

    # Assert: Lua invoked exactly twice with correct KEYS and ARGV
    assert transition_script.call_count == 2
    for c in transition_script.call_args_list:
        assert c.kwargs["keys"] == [f"dag:{dag_id}:nodes"], \
            "Lua KEYS[1] must be the dag nodes hash"
        assert c.kwargs["args"] == [node_id, "pending", "running"], \
            "Lua ARGV must carry node_id, expected_state, new_state"


# ══════════════════════════════════════════════════════════════════════════════
# TEST 2 — task.progress Emitted on Every State Transition
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_progress_emitted_on_every_transition(
    orchestrator, mock_dag_state, mock_producer
):
    """
    contracts.json: progress_event_on_every_state_transition = true

    Validates that task.progress is produced for every node state transition
    and that each payload carries all 10 required fields.

    Flow exercised:
      node-0 validation_status=passed → running→completed → progress(1)
      node-1 unblocked → dispatch pending→running        → progress(2)
    """
    dag     = make_dag()
    dag_id  = dag["dag_id"]
    task_id = dag["task_id"]
    node_0  = dag["nodes"][0]
    node_1  = dag["nodes"][1]
    meta    = make_meta(task_id, dag_id, total_nodes=2)

    mock_dag_state.get_dag_structure.return_value  = dag
    mock_dag_state.find_node.return_value          = node_0
    mock_dag_state.atomic_transition.return_value  = True
    mock_dag_state.all_nodes_completed.return_value = False
    mock_dag_state.all_nodes_terminal.return_value  = False
    mock_dag_state.get_meta.return_value            = meta
    mock_dag_state.get_node_states.return_value     = {
        "node-0": "completed",
        "node-1": "pending",
    }
    mock_dag_state.count_completed.return_value     = 1
    mock_dag_state.get_ready_nodes.return_value     = [node_1]   # node-1 unblocked

    envelope = make_envelope(
        event_type="task.validated",
        payload={
            "task_id": task_id,
            "dag_id": dag_id,
            "node_id": node_0["node_id"],
            "validation_status": "passed",
            "failure_reason": None,
        },
    )

    # Act
    await orchestrator.handle_task_validated(envelope)

    # Assert: task.progress produced at least once per transition
    progress_calls = [
        c for c in mock_producer.produce.call_args_list
        if (c.kwargs.get("topic") or (c.args[0] if c.args else None)) == "task.progress"
    ]
    assert len(progress_calls) >= 1, (
        f"task.progress must be emitted on every state transition — "
        f"got {len(progress_calls)}. All topics: "
        f"{extract_topics(mock_producer.produce.call_args_list)}"
    )

    # Assert: every progress payload carries all 10 required fields
    required_fields = {
        "task_id", "dag_id", "user_id", "session_id",
        "progress_percentage", "current_step",
        "completed_nodes", "total_nodes", "status", "created_at",
    }
    for c in progress_calls:
        payload = extract_payload(c)
        missing = required_fields - set(payload.keys())
        assert not missing, f"task.progress payload missing fields: {missing}"
        assert payload["task_id"] == task_id
        assert payload["dag_id"]  == dag_id
        assert isinstance(payload["progress_percentage"], float)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 3 — task.completed Emitted When All Nodes Terminal
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_task_completed_when_all_terminal(
    orchestrator, mock_dag_state, mock_producer
):
    """
    When the last node transitions running→completed and all_nodes_completed()
    returns True, SVC-04 MUST emit exactly one task.completed event containing
    all 10 required fields (contracts.json TaskCompletedPayload).
    """
    dag     = make_dag()
    dag_id  = dag["dag_id"]
    task_id = dag["task_id"]
    node_1  = dag["nodes"][1]   # last node
    meta    = make_meta(task_id, dag_id, total_nodes=2)

    mock_dag_state.get_dag_structure.return_value   = dag
    mock_dag_state.find_node.return_value           = node_1
    mock_dag_state.atomic_transition.return_value   = True
    mock_dag_state.all_nodes_completed.return_value = True   # ← all nodes done
    mock_dag_state.get_meta.return_value            = meta
    mock_dag_state.get_node_states.return_value     = {
        "node-0": "completed",
        "node-1": "completed",
    }
    mock_dag_state.count_completed.return_value     = 2

    envelope = make_envelope(
        event_type="task.validated",
        payload={
            "task_id": task_id,
            "dag_id": dag_id,
            "node_id": node_1["node_id"],
            "validation_status": "passed",
            "failure_reason": None,
        },
    )

    # Act
    await orchestrator.handle_task_validated(envelope)

    # Assert: task.completed emitted exactly once
    completed_calls = [
        c for c in mock_producer.produce.call_args_list
        if (c.kwargs.get("topic") or (c.args[0] if c.args else None)) == "task.completed"
    ]
    assert len(completed_calls) == 1, (
        f"task.completed must be emitted exactly once when all nodes complete — "
        f"got {len(completed_calls)}. "
        f"All topics: {extract_topics(mock_producer.produce.call_args_list)}"
    )

    # Assert: all 10 required fields (contracts.json TaskCompletedPayload)
    payload = extract_payload(completed_calls[0])
    required_fields = {
        "task_id", "dag_id", "user_id", "session_id", "channel",
        "completed_nodes", "total_nodes",
        "total_cost_usd", "total_latency_ms", "created_at",
    }
    missing = required_fields - set(payload.keys())
    assert not missing, f"TaskCompletedPayload missing required fields: {missing}"

    assert payload["task_id"]         == task_id
    assert payload["dag_id"]          == dag_id
    assert payload["completed_nodes"] == 2
    assert payload["total_nodes"]     == 2
    assert isinstance(payload["total_latency_ms"], int), \
        "total_latency_ms must be an integer (milliseconds)"
    assert isinstance(payload["total_cost_usd"], float), \
        "total_cost_usd must be a float"


# ══════════════════════════════════════════════════════════════════════════════
# TEST 4 — replan.required Emitted at Attempt 1 (NOT task.dlq)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_replan_at_attempt_1_not_dlq(
    orchestrator, mock_dag_state, mock_producer
):
    """
    PC-08: When replan_attempt == 0 (first failure), SVC-04 MUST emit
    replan.required with replan_attempt=1 and
    replan_source='execution_orchestrator'.
    It MUST NOT emit task.dlq.

    IMMUTABLE RULE #9: SVC-02 replan triggered ONLY from replan.required.
    """
    dag     = make_dag()
    dag_id  = dag["dag_id"]
    task_id = dag["task_id"]
    node_0  = dag["nodes"][0]
    meta    = make_meta(task_id, dag_id, replan_attempt=0, total_nodes=2)  # attempt 0

    mock_dag_state.get_dag_structure.return_value  = dag
    mock_dag_state.find_node.return_value          = node_0
    mock_dag_state.atomic_transition.return_value  = True
    mock_dag_state.get_meta.return_value           = meta
    mock_dag_state.get_node_states.return_value    = {
        "node-0": "failed",
        "node-1": "pending",
    }
    mock_dag_state.count_completed.return_value    = 0
    mock_dag_state.get_retry_count.return_value    = 2

    envelope = make_envelope(
        event_type="task.validated",
        payload={
            "task_id": task_id,
            "dag_id": dag_id,
            "node_id": node_0["node_id"],
            "validation_status": "escalated",
            "failure_reason": "Agent produced invalid output after max retries",
        },
    )

    # Act
    await orchestrator.handle_task_validated(envelope)

    produced = extract_topics(mock_producer.produce.call_args_list)

    # Assert: replan.required produced
    assert "replan.required" in produced, (
        f"replan.required must be emitted at attempt 0→1. Topics: {produced}"
    )

    # Assert: task.dlq NOT produced
    assert "task.dlq" not in produced, (
        f"task.dlq must NOT be emitted at attempt 1. Topics: {produced}"
    )

    # Assert: ReplanRequiredPayload field values
    replan_payload = extract_payload(
        find_call(mock_producer.produce.call_args_list, "replan.required")
    )
    assert replan_payload["replan_attempt"] == 1, \
        "replan_attempt must be incremented to 1"
    assert replan_payload["replan_source"] == "execution_orchestrator", \
        "replan_source must be 'execution_orchestrator' (IMMUTABLE RULE #9)"
    assert "completed_node_ids" in replan_payload, \
        "completed_node_ids must be present in ReplanRequiredPayload"
    assert replan_payload["task_id"]        == task_id
    assert replan_payload["dag_id"]         == dag_id
    assert replan_payload["failed_node_id"] == node_0["node_id"]

    # Assert: replan counter persisted
    mock_dag_state.set_replan_attempt.assert_called_once_with(task_id, 1)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 5 — task.dlq Emitted at Replan Attempt 2 (NOT replan.required)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_dlq_at_replan_attempt_2(
    orchestrator, mock_dag_state, mock_producer
):
    """
    PC-08: When replan_attempt == 2 (maximum exhausted), SVC-04 MUST emit
    task.dlq with all 8 required DLQPayload fields.
    It MUST NOT emit replan.required.
    failure_reason MUST contain 'REPLAN_LIMIT_EXCEEDED'.
    source_service MUST be 'SVC-04'.
    """
    dag     = make_dag()
    dag_id  = dag["dag_id"]
    task_id = dag["task_id"]
    node_0  = dag["nodes"][0]
    meta    = make_meta(task_id, dag_id, replan_attempt=2, total_nodes=2)  # MAX reached

    mock_dag_state.get_dag_structure.return_value  = dag
    mock_dag_state.find_node.return_value          = node_0
    mock_dag_state.atomic_transition.return_value  = True
    mock_dag_state.get_meta.return_value           = meta
    mock_dag_state.get_node_states.return_value    = {
        "node-0": "failed",
        "node-1": "pending",
    }
    mock_dag_state.count_completed.return_value    = 0
    mock_dag_state.get_retry_count.return_value    = 2

    envelope = make_envelope(
        event_type="task.validated",
        payload={
            "task_id": task_id,
            "dag_id": dag_id,
            "node_id": node_0["node_id"],
            "validation_status": "escalated",
            "failure_reason": "Repeated agent failure after 2 replan attempts",
        },
    )

    # Act
    await orchestrator.handle_task_validated(envelope)

    produced = extract_topics(mock_producer.produce.call_args_list)

    # Assert: task.dlq produced
    assert "task.dlq" in produced, (
        f"task.dlq must be emitted when replan_attempt >= 2. Topics: {produced}"
    )

    # Assert: replan.required NOT produced
    assert "replan.required" not in produced, (
        f"replan.required must NOT be emitted when replan_attempt >= 2. Topics: {produced}"
    )

    # Assert: DLQPayload has all 8 required fields (contracts.json)
    dlq_payload = extract_payload(
        find_call(mock_producer.produce.call_args_list, "task.dlq")
    )
    required_fields = {
        "dlq_id", "original_topic", "original_event_id", "original_payload",
        "failure_reason", "retry_count", "source_service", "created_at",
    }
    missing = required_fields - set(dlq_payload.keys())
    assert not missing, f"DLQPayload missing required fields: {missing}"

    assert dlq_payload["source_service"] == "SVC-04", \
        "DLQPayload.source_service must be 'SVC-04'"
    assert "REPLAN_LIMIT_EXCEEDED" in dlq_payload["failure_reason"], \
        "DLQPayload.failure_reason must contain 'REPLAN_LIMIT_EXCEEDED'"
    assert isinstance(dlq_payload["dlq_id"], str) and dlq_payload["dlq_id"], \
        "dlq_id must be a non-empty string (UUID)"
    assert dlq_payload["original_topic"] == "task.validated", \
        "original_topic must reflect the triggering Kafka topic"


# ══════════════════════════════════════════════════════════════════════════════
# TEST 6 — TaskDispatchedPayload Contains All 15 Required Fields
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_dispatch_payload_all_required_fields(mock_producer, mock_dag_state):
    """
    contracts.json TaskDispatchedPayload: ALL 15 required fields must be
    present and correctly typed in every task.dispatched Kafka event.

    Tests NodeDispatcher in isolation to verify field completeness
    independently of the orchestrator flow.
    """
    dag     = make_dag()
    dag_id  = dag["dag_id"]
    task_id = dag["task_id"]
    node    = dag["nodes"][0]

    # Arrange: C-15 transition succeeds (pending → running)
    mock_dag_state.atomic_transition.return_value = True

    dispatcher = NodeDispatcher(producer=mock_producer, state=mock_dag_state)

    # Act
    dispatched = await dispatcher.dispatch_node(
        dag=dag,
        node=node,
        task_id=task_id,
        retry_count=0,
        trace_id=str(uuid.uuid4()),
    )

    # Assert: dispatch returned True (transition succeeded)
    assert dispatched is True, \
        "dispatch_node must return True when atomic_transition succeeds"

    # Assert: task.dispatched was produced
    dispatch_call = find_call(mock_producer.produce.call_args_list, "task.dispatched")
    assert dispatch_call is not None, "task.dispatched must be produced"

    payload = extract_payload(dispatch_call)
    assert payload, "task.dispatched payload must not be empty"

    # Assert: ALL 15 required fields (contracts.json TaskDispatchedPayload)
    required_15 = {
        "task_id",
        "node_id",
        "dag_id",
        "agent_type",
        "agent_id",
        "sub_task_name",
        "sub_task_description",
        "input_context",
        "model_tier",
        "retry_count",
        "idempotency_key",
        "requires_audit",
        "requires_hitl",
        "priority",
        "dispatched_at",
    }
    missing = required_15 - set(payload.keys())
    assert not missing, (
        f"TaskDispatchedPayload missing {len(missing)} required field(s): {missing}"
    )

    # Assert: field value correctness
    assert payload["task_id"]       == task_id,             "task_id mismatch"
    assert payload["node_id"]       == node["node_id"],     "node_id mismatch"
    assert payload["dag_id"]        == dag_id,              "dag_id mismatch"
    assert payload["agent_type"]    == node["agent_type"],  "agent_type mismatch"
    assert payload["agent_id"]      == node["agent_id"],    "agent_id mismatch"
    assert payload["model_tier"]    == node["model_tier"],  "model_tier mismatch"
    assert payload["retry_count"]   == 0,                   "retry_count must be 0 on first dispatch"
    assert payload["requires_audit"] == node["requires_audit"]
    assert payload["requires_hitl"]  == node["requires_hitl"]
    assert payload["priority"]       == node["priority"]
    assert isinstance(payload["dispatched_at"], str),       "dispatched_at must be ISO string"
    assert isinstance(payload["idempotency_key"], str) and payload["idempotency_key"], \
        "idempotency_key must be a non-empty string"
    assert isinstance(payload["sub_task_name"], str) and payload["sub_task_name"], \
        "sub_task_name must be a non-empty string"
    assert isinstance(payload["sub_task_description"], str) and payload["sub_task_description"], \
        "sub_task_description must be a non-empty string"
    assert isinstance(payload["input_context"], str) and payload["input_context"], \
        "input_context must be a non-empty string"

    # Assert: C-15 — atomic transition was called with correct args before produce
    mock_dag_state.atomic_transition.assert_called_once_with(
        dag_id, node["node_id"], "pending", "running"
    )


# ══════════════════════════════════════════════════════════════════════════════
# TEST 7 — HITL Node Set to awaiting_human State
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_hitl_node_set_awaiting_human(
    orchestrator, mock_dag_state, mock_producer
):
    """
    When a node has requires_hitl=True, SVC-04 MUST:
      1. Atomically transition the node pending→awaiting_human  (C-15)
      2. Emit hitl.request with all required fields
      3. Emit task.progress on the state transition
      4. NOT dispatch the node to task.dispatched (worker must not receive it)
    """
    dag_id    = str(uuid.uuid4())
    task_id   = str(uuid.uuid4())
    hitl_node = make_node("node-hitl", requires_hitl=True)
    dag       = make_dag(dag_id=dag_id, task_id=task_id, nodes=[hitl_node])
    meta      = make_meta(task_id, dag_id, total_nodes=1)

    mock_dag_state.get_replan_attempt.return_value  = 0
    mock_dag_state.get_task_context.return_value    = {
        "user_id": "user-001",
        "session_id": "session-001",
        "channel": "webui",
    }
    mock_dag_state.atomic_transition.return_value   = True   # pending → awaiting_human
    mock_dag_state.get_meta.return_value            = meta
    mock_dag_state.get_node_states.return_value     = {"node-hitl": "awaiting_human"}
    mock_dag_state.count_completed.return_value     = 0
    mock_dag_state.get_ready_nodes.return_value     = [hitl_node]

    envelope = make_envelope(
        event_type="dag.created",
        payload=dag,
    )

    # Act
    await orchestrator.handle_dag_created(envelope)

    produced = extract_topics(mock_producer.produce.call_args_list)

    # Assert 1: C-15 — atomic transition called exactly once with correct args
    mock_dag_state.atomic_transition.assert_called_once_with(
        dag_id, "node-hitl", "pending", "awaiting_human"
    )

    # Assert 2: hitl.request produced
    assert "hitl.request" in produced, (
        f"hitl.request must be produced for requires_hitl=True node. Topics: {produced}"
    )

    # Assert 3: task.dispatched NOT produced (node is paused, not sent to worker)
    assert "task.dispatched" not in produced, (
        f"task.dispatched must NOT be produced for requires_hitl=True node. Topics: {produced}"
    )

    # Assert 4: task.progress produced (pending → awaiting_human is a state transition)
    assert "task.progress" in produced, (
        f"task.progress must be emitted on pending→awaiting_human transition. Topics: {produced}"
    )

    # Assert 5: hitl.request payload required fields (contracts.json HITLRequestPayload)
    hitl_payload = extract_payload(
        find_call(mock_producer.produce.call_args_list, "hitl.request")
    )
    required_hitl_fields = {
        "hitl_id", "task_id", "node_id", "user_id", "session_id",
        "trigger_reason", "risk_classification", "context",
        "available_actions", "created_at",
    }
    missing = required_hitl_fields - set(hitl_payload.keys())
    assert not missing, f"HITLRequestPayload missing required fields: {missing}"

    assert hitl_payload["task_id"] == task_id,     "hitl_payload.task_id mismatch"
    assert hitl_payload["node_id"] == "node-hitl", "hitl_payload.node_id mismatch"
    assert hitl_payload["trigger_reason"] == "high_risk", \
        "trigger_reason must be 'high_risk' for requires_hitl nodes"
    assert isinstance(hitl_payload["hitl_id"], str) and hitl_payload["hitl_id"], \
        "hitl_id must be a non-empty string (UUID)"
    assert isinstance(hitl_payload["available_actions"], list) and hitl_payload["available_actions"], \
        "available_actions must be a non-empty list"
