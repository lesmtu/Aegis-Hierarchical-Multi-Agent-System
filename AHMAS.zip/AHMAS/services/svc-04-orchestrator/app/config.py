# FILE: services/svc-04-orchestrator/app/config.py

"""
SVC-04 Execution Orchestrator — Configuration
contracts.json SVC-04
"""
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Service Identity ──────────────────────────────────────────────────
    service_id: str = "SVC-04"
    service_version: str = "1.0.0"
    schema_version: str = "1.0.0"
    payload_version: str = "1.0.0"

    # ── Kafka ─────────────────────────────────────────────────────────────
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_consumer_group: str = "svc-04-orchestrator"
    kafka_auto_offset_reset: str = "earliest"

    # ── Redis ─────────────────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"

    # ── Orchestration Behavior ────────────────────────────────────────────
    max_replan_attempts: int = 2        # PC-08: maximum 2 replan attempts
    idempotency_ttl: int = 86400        # 24h (contracts.json idempotency_policy.ttl_seconds)
    stale_lock_timeout: int = 600       # 10 min stale lock (contracts.json step_6_on_status_processing_stale)

    class Config:
        env_file = ".env"
        env_prefix = "SVC04_"


settings = Settings()