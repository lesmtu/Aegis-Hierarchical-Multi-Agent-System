# FILE: services/svc-04-orchestrator/app/routers/websocket.py

"""
WebSocket endpoint for real-time DAG state monitoring.
contracts.json SVC-04 GET /ws/dag/{dag_id}

Outbound message format (additionalProperties: false):
{
    "dag_id"      : "uuid",
    "node_states" : {"<node_id>": "pending|running|completed|failed|retrying|awaiting_human"},
    "timestamp"   : "ISO8601"
}
"""
import asyncio
import json
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.services.redis_client import get_redis

router = APIRouter()
logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 0.5


@router.websocket("/ws/dag/{dag_id}")
async def dag_websocket(websocket: WebSocket, dag_id: str):
    """
    Real-time DAG execution state.
    Sends current node_states on connect; sends updates whenever state changes.
    Uses Redis pub/sub (published by orchestrator._emit_progress) for live updates.
    Falls back to polling if pub/sub is unavailable.
    """
    await websocket.accept()
    redis = get_redis()
    logger.info("WebSocket connected", extra={"dag_id": dag_id})

    pubsub = redis.pubsub()

    async def forward_pubsub():
        """Forward Redis pub/sub messages to WebSocket."""
        await pubsub.subscribe(f"dag_updates:{dag_id}")
        async for message in pubsub.listen():
            if message.get("type") == "message":
                try:
                    data = json.loads(message["data"])
                    await websocket.send_json(data)
                except Exception:
                    break

    async def detect_disconnect():
        """Block until client disconnects."""
        try:
            while True:
                await asyncio.wait_for(websocket.receive_bytes(), timeout=5.0)
        except (WebSocketDisconnect, asyncio.TimeoutError):
            pass

    try:
        # Send initial node states immediately on connect
        initial_states = await redis.hgetall(f"dag:{dag_id}:nodes")
        await websocket.send_json({
            "dag_id": dag_id,
            "node_states": initial_states,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # Run pub/sub forwarding and disconnect detection concurrently
        forward_task = asyncio.create_task(forward_pubsub())
        disconnect_task = asyncio.create_task(detect_disconnect())

        done, pending = await asyncio.wait(
            {forward_task, disconnect_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    except WebSocketDisconnect:
        pass
    except Exception:
        logger.exception("WebSocket error", extra={"dag_id": dag_id})
    finally:
        try:
            await pubsub.unsubscribe(f"dag_updates:{dag_id}")
            await pubsub.aclose()
        except Exception:
            pass
        logger.info("WebSocket disconnected", extra={"dag_id": dag_id})