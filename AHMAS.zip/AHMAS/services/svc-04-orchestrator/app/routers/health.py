# FILE: services/svc-04-orchestrator/app/routers/health.py

"""
Health check and Prometheus metrics endpoints.
contracts.json HealthCheckResponse schema.
"""
import logging
from datetime import datetime, timezone

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse

from app.config import settings
from app.services.redis_client import get_redis

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/health")
async def health_check():
    """
    Health check endpoint.
    contracts.json HealthCheckResponse:
      service_id, status, version, dependencies, timestamp
    """
    redis_status = "healthy"
    try:
        redis = get_redis()
        if redis:
            await redis.ping()
        else:
            redis_status = "unhealthy"
    except Exception:
        redis_status = "unhealthy"

    overall = "healthy" if redis_status == "healthy" else "degraded"

    return {
        "service_id": settings.service_id,
        "status": overall,
        "version": settings.service_version,
        "dependencies": {
            "redis": redis_status,
            "kafka": "healthy",
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.get("/metrics", response_class=PlainTextResponse)
async def metrics():
    """Prometheus metrics — text/plain; version=0.0.4."""
    try:
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        return PlainTextResponse(
            content=generate_latest().decode("utf-8"),
            media_type=CONTENT_TYPE_LATEST,
        )
    except ImportError:
        return PlainTextResponse(
            content="# prometheus_client not installed\n",
            media_type="text/plain",
        )