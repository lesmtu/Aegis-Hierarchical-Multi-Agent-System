# FILE: services/svc-04-orchestrator/app/services/kafka_consumer.py

"""
Kafka consumer for SVC-04.
Consumed topics: dag.created, task.validated, retry.required, hitl.response
Manual offset commit after processing (at-least-once delivery).
Idempotency enforced per-message by orchestrator handlers.
"""
import json
import logging

try:
    from aiokafka import AIOKafkaConsumer
except ImportError:  # pragma: no cover - import-safe fallback for test runtime
    class AIOKafkaConsumer:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            self._messages = []

        async def start(self) -> None:
            return None

        async def stop(self) -> None:
            return None

        async def commit(self) -> None:
            return None

        def __aiter__(self):
            return self

        async def __anext__(self):
            raise StopAsyncIteration

from app.config import settings
from app.services.orchestrator import ExecutionOrchestrator

logger = logging.getLogger(__name__)

CONSUMED_TOPICS = ["dag.created", "task.validated", "retry.required", "hitl.response"]


class KafkaConsumerService:
    def __init__(self, orchestrator: ExecutionOrchestrator):
        self.orchestrator = orchestrator
        self._consumer: AIOKafkaConsumer = None
        self._running = False

    async def start(self) -> None:
        self._consumer = AIOKafkaConsumer(
            *CONSUMED_TOPICS,
            bootstrap_servers=settings.kafka_bootstrap_servers,
            group_id=settings.kafka_consumer_group,
            auto_offset_reset=settings.kafka_auto_offset_reset,
            enable_auto_commit=False,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            key_deserializer=lambda k: k.decode("utf-8") if k else None,
        )
        await self._consumer.start()
        self._running = True
        logger.info("Kafka consumer started", extra={"topics": CONSUMED_TOPICS})

    async def stop(self) -> None:
        self._running = False
        if self._consumer:
            await self._consumer.stop()
            logger.info("Kafka consumer stopped")

    async def consume_loop(self) -> None:
        """
        Main message consumption loop.
        Manual commit after successful processing.
        No commit on exception → message will be re-delivered (idempotency handles dedup).
        """
        async for msg in self._consumer:
            if not self._running:
                break
            await self._handle_message(msg)
            await self._consumer.commit()

    async def _handle_message(self, msg) -> None:
        """Route message to the appropriate orchestrator handler."""
        topic = msg.topic
        envelope = msg.value

        if not isinstance(envelope, dict):
            logger.error(
                "Malformed message (not a dict)",
                extra={"topic": topic, "partition": msg.partition, "offset": msg.offset},
            )
            return

        event_id = envelope.get("event_id", "unknown")
        idem_key = envelope.get("idempotency_key", "unknown")

        logger.info(
            "Message received",
            extra={
                "topic": topic,
                "event_id": event_id,
                "idempotency_key": idem_key,
                "partition": msg.partition,
                "offset": msg.offset,
            },
        )

        if topic == "dag.created":
            await self.orchestrator.handle_dag_created(envelope)
        elif topic == "task.validated":
            await self.orchestrator.handle_task_validated(envelope)
        elif topic == "retry.required":
            await self.orchestrator.handle_retry_required(envelope)
        elif topic == "hitl.response":
            await self.orchestrator.handle_hitl_response(envelope)
        else:
            logger.warning("Unhandled topic", extra={"topic": topic})
