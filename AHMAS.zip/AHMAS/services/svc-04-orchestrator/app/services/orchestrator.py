# FILE: services/svc-04-orchestrator/app/services/orchestrator.py

"""
SVC-04 Execution Orchestrator — core business logic.

contracts.json SVC-04.behavior:
  idempotency_key_check                   : true
  max_replan_attempts                     : 2  (PC-08)
  dlq_on_terminal_failure                 : true
  progress_event_on_every_state_transition: true

IMMUTABLE RULES enforced here:
  #8: SVC-02 consumes task.failed for LEARNING ONLY — task.failed does NOT trigger replan.
  #9: SVC-02 replan triggered ONLY from replan.required.
  C-15: ALL DAG node state transitions use atomic Lua scripts.
  PC-08: max_replan_attempts = 2.
"""
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

from app.config import settings
from app.services.dag_state import DAGStateManager
from app.services.dispatcher import NodeDispatcher
from app.services.idempotency import IdempotencyService
from app.services.kafka_producer import KafkaProducer

logger = logging.getLogger(__name__)


class ExecutionOrchestrator:
    # PC-08: Maximum replan attempts per task
    MAX_REPLAN_ATTEMPTS: int = settings.max_replan_attempts  # = 2

    def __init__(
        self,
        dag_state: DAGStateManager,
        dispatcher: NodeDispatcher,
        producer: KafkaProducer,
        idempotency: IdempotencyService,
        redis_client,
    ) -> None:
        self.state = dag_state
        self.dispatcher = dispatcher
        self.producer = producer
        self.idempotency = idempotency
        self.redis = redis_client

    # ══════════════════════════════════════════════════════════════════════
    # PUBLIC EVENT HANDLERS  (consumed topics)
    # ══════════════════════════════════════════════════════════════════════

    async def handle_dag_created(self, envelope: dict) -> None:
        """
        dag.created → Initialize DAG Redis state → Dispatch initial ready nodes.
        Idempotency: skip if this dag_id was already initialized.
        """
        idem_key = envelope["idempotency_key"]
        event_id = envelope["event_id"]
        if not await self.idempotency.check_and_set(idem_key, event_id):
            return

        try:
            dag = envelope["payload"]           # contracts.json DAG schema
            dag_id = dag["dag_id"]
            task_id = dag["task_id"]
            trace_id = envelope.get("trace_id")

            # Replan attempt persists across DAG instances for the same task
            replan_attempt = await self.state.get_replan_attempt(task_id)

            # User context (populated by SVC-01 in production)
            ctx = await self.state.get_task_context(task_id)

            # contracts.json SVC-04.redis_state_schema.additional_keys dag:{dag_id}:meta
            meta = {
                "task_id": task_id,
                "dag_id": dag_id,
                "plan_id": dag.get("plan_id", ""),
                "user_id": ctx["user_id"],
                "session_id": ctx["session_id"],
                "channel": ctx["channel"],
                "replan_attempt": replan_attempt,
                "total_nodes": len(dag["nodes"]),
                "started_at": datetime.now(timezone.utc).isoformat(),
                "total_cost_usd": 0.0,
            }

            await self.state.initialize_dag(dag, meta)
            await self._dispatch_ready_nodes(dag, dag_id, task_id, trace_id)
            await self.idempotency.mark_completed(idem_key, event_id)

        except Exception:
            await self.idempotency.mark_failed(idem_key, event_id)
            logger.exception("handle_dag_created failed", extra={"event_id": event_id})
            raise

    async def handle_task_validated(self, envelope: dict) -> None:
        """
        task.validated → Update node state per validation result.
          passed    → running → completed; dispatch dependents
          failed    → no action (retry.required will arrive separately)
          escalated → running → failed; emit task.failed + replan or DLQ
        """
        idem_key = envelope["idempotency_key"]
        event_id = envelope["event_id"]
        if not await self.idempotency.check_and_set(idem_key, event_id):
            return

        try:
            payload = envelope["payload"]       # TaskValidatedPayload
            dag_id = payload["dag_id"]
            node_id = payload["node_id"]
            task_id = payload["task_id"]
            trace_id = envelope.get("trace_id")

            dag = await self.state.get_dag_structure(dag_id)
            if dag is None:
                logger.error("DAG structure not found", extra={"dag_id": dag_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            node = self.state.find_node(dag, node_id)
            if node is None:
                logger.error("Node not found", extra={"dag_id": dag_id, "node_id": node_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            status = payload["validation_status"]

            if status == "passed":
                await self._on_node_passed(dag, node, task_id, trace_id)

            elif status == "escalated":
                # Retry budget exhausted — trigger replan or DLQ
                await self._on_node_escalated(
                    dag=dag,
                    node=node,
                    task_id=task_id,
                    failure_reason=payload.get(
                        "failure_reason", "Validation escalated: retry budget exhausted"
                    ),
                    original_event_id=event_id,
                    original_topic="task.validated",
                    original_payload=envelope,
                    trace_id=trace_id,
                )

            elif status == "failed":
                # Retry available — retry.required event will handle re-dispatch
                logger.debug(
                    "Validation failed (retry available) — awaiting retry.required",
                    extra={"node_id": node_id, "dag_id": dag_id},
                )

            await self.idempotency.mark_completed(idem_key, event_id)

        except Exception:
            await self.idempotency.mark_failed(idem_key, event_id)
            logger.exception("handle_task_validated failed", extra={"event_id": event_id})
            raise

    async def handle_retry_required(self, envelope: dict) -> None:
        """
        retry.required → Increment retry count → Re-dispatch node with correction guidance.
        C-15: running → retrying → running (two atomic transitions).
        Emit task.progress on each transition.
        """
        idem_key = envelope["idempotency_key"]
        event_id = envelope["event_id"]
        if not await self.idempotency.check_and_set(idem_key, event_id):
            return

        try:
            payload = envelope["payload"]       # RetryRequiredPayload
            dag_id = payload["dag_id"]
            node_id = payload["node_id"]
            task_id = payload["task_id"]
            trace_id = envelope.get("trace_id")

            dag = await self.state.get_dag_structure(dag_id)
            if dag is None:
                logger.error("DAG structure not found", extra={"dag_id": dag_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            node = self.state.find_node(dag, node_id)
            if node is None:
                logger.error("Node not found", extra={"node_id": node_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            retry_count = await self.state.increment_retry(dag_id, node_id)
            max_retries = node["retry_policy"]["max_retries"]

            if retry_count > max_retries:
                # Safety net: Auditor should have escalated, but handle defensively
                logger.warning(
                    "retry_count=%d > max_retries=%d in retry.required — treating as escalated",
                    retry_count, max_retries,
                    extra={"node_id": node_id},
                )
                await self._on_node_escalated(
                    dag=dag, node=node, task_id=task_id,
                    failure_reason=f"Retry count {retry_count} exceeded max {max_retries}",
                    original_event_id=event_id,
                    original_topic="retry.required",
                    original_payload=envelope,
                    trace_id=trace_id,
                )
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            meta = await self.state.get_meta(dag_id)

            # C-15: running → retrying
            await self.state.atomic_transition(dag_id, node_id, "running", "retrying")
            # Emit progress on transition (contracts.json: every state transition)
            await self._emit_progress(dag_id, task_id, meta, "running", trace_id)

            # Re-dispatch: internally transitions retrying → running (C-15)
            dispatched = await self.dispatcher.dispatch_node(
                dag=dag,
                node=node,
                task_id=task_id,
                retry_count=retry_count,
                correction_guidance=payload.get("correction_guidance"),
                trace_id=trace_id,
            )

            if dispatched:
                # Emit progress on retrying → running transition
                meta = await self.state.get_meta(dag_id)
                await self._emit_progress(dag_id, task_id, meta, "running", trace_id)

            await self.idempotency.mark_completed(idem_key, event_id)

        except Exception:
            await self.idempotency.mark_failed(idem_key, event_id)
            logger.exception("handle_retry_required failed", extra={"event_id": event_id})
            raise

    async def handle_hitl_response(self, envelope: dict) -> None:
        """
        hitl.response → Resume or abort DAG based on human decision.
        Handles: approve | reject | modify | clarify | timeout_auto_reject
        """
        idem_key = envelope["idempotency_key"]
        event_id = envelope["event_id"]
        if not await self.idempotency.check_and_set(idem_key, event_id):
            return

        try:
            payload = envelope["payload"]       # HITLResponsePayload
            task_id = payload["task_id"]
            node_id = payload.get("node_id")
            decision = payload["decision"]
            trace_id = envelope.get("trace_id")

            dag_id = await self.state.get_dag_id_by_task(task_id)
            if not dag_id:
                logger.warning("No DAG found for HITL response", extra={"task_id": task_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            dag = await self.state.get_dag_structure(dag_id)
            if dag is None:
                logger.error("DAG structure not found", extra={"dag_id": dag_id})
                await self.idempotency.mark_completed(idem_key, event_id)
                return

            meta = await self.state.get_meta(dag_id)

            if decision == "approve":
                if node_id:
                    # C-15: awaiting_human → pending → (then dispatch will do pending → running)
                    ok = await self.state.atomic_transition(
                        dag_id, node_id, "awaiting_human", "pending"
                    )
                    if ok:
                        await self._emit_progress(dag_id, task_id, meta, "running", trace_id)
                        await self._dispatch_ready_nodes(dag, dag_id, task_id, trace_id)

            elif decision in ("reject", "timeout_auto_reject", "clarify"):
                if node_id:
                    node = self.state.find_node(dag, node_id)
                    # C-15: awaiting_human → failed
                    ok = await self.state.atomic_transition(
                        dag_id, node_id, "awaiting_human", "failed"
                    )
                    if ok and node:
                        await self._emit_progress(dag_id, task_id, meta, "running", trace_id)

                        retry_count = await self.state.get_retry_count(dag_id, node_id)
                        await self._emit_task_failed(
                            task_id=task_id,
                            node_id=node_id,
                            dag_id=dag_id,
                            failure_reason=f"HITL decision: {decision}",
                            failure_source="orchestrator",
                            retry_count=retry_count,
                            replan_attempt=meta.get("replan_attempt", 0),
                            correlation_id=task_id,
                            trace_id=trace_id,
                        )

                        await self._handle_terminal_failure(
                            dag=dag,
                            node=node,
                            task_id=task_id,
                            dag_id=dag_id,
                            failure_reason=f"HITL decision: {decision}",
                            meta=meta,
                            original_event_id=event_id,
                            original_topic="hitl.response",
                            original_payload=envelope,
                            trace_id=trace_id,
                        )

            elif decision == "modify":
                if node_id:
                    # Human provided corrected output — treat as completed
                    # C-15: awaiting_human → completed
                    ok = await self.state.atomic_transition(
                        dag_id, node_id, "awaiting_human", "completed"
                    )
                    if ok:
                        if await self.state.all_nodes_completed(dag_id):
                            await self._emit_progress(dag_id, task_id, meta, "completing", trace_id)
                            await self._emit_task_completed(dag, dag_id, task_id, meta, trace_id)
                        else:
                            await self._emit_progress(dag_id, task_id, meta, "running", trace_id)
                            await self._dispatch_ready_nodes(dag, dag_id, task_id, trace_id)

            await self.idempotency.mark_completed(idem_key, event_id)

        except Exception:
            await self.idempotency.mark_failed(idem_key, event_id)
            logger.exception("handle_hitl_response failed", extra={"event_id": event_id})
            raise

    # ══════════════════════════════════════════════════════════════════════
    # PRIVATE — Node State Handlers
    # ══════════════════════════════════════════════════════════════════════

    async def _on_node_passed(
        self,
        dag: dict,
        node: dict,
        task_id: str,
        trace_id: Optional[str],
    ) -> None:
        """Node passed validation → running → completed."""
        dag_id = dag["dag_id"]
        node_id = node["node_id"]

        # C-15: atomic transition
        success = await self.state.atomic_transition(dag_id, node_id, "running", "completed")
        if not success:
            return  # Stale — another instance processed this

        meta = await self.state.get_meta(dag_id)

        if await self.state.all_nodes_completed(dag_id):
            # Happy path: every node completed successfully
            await self._emit_progress(dag_id, task_id, meta, "completing", trace_id)
            await self._emit_task_completed(dag, dag_id, task_id, meta, trace_id)
        elif await self.state.all_nodes_terminal(dag_id):
            # Mixed terminal state (some failed, already handled via failure path)
            logger.info(
                "All nodes terminal but not all completed — failure path already handled",
                extra={"dag_id": dag_id},
            )
        else:
            # More work to do — dispatch next ready nodes
            await self._emit_progress(dag_id, task_id, meta, "running", trace_id)
            await self._dispatch_ready_nodes(dag, dag_id, task_id, trace_id)

    async def _on_node_escalated(
        self,
        dag: dict,
        node: dict,
        task_id: str,
        failure_reason: str,
        original_event_id: str,
        original_topic: str,
        original_payload: dict,
        trace_id: Optional[str],
    ) -> None:
        """Node validation escalated (retry budget exhausted) → running → failed."""
        dag_id = dag["dag_id"]
        node_id = node["node_id"]

        # C-15: running → failed
        await self.state.atomic_transition(dag_id, node_id, "running", "failed")

        meta = await self.state.get_meta(dag_id)
        retry_count = await self.state.get_retry_count(dag_id, node_id)

        # Emit task.failed — consumed by SVC-02 for LEARNING ONLY (IMMUTABLE RULE #8)
        # SVC-02 replan triggered ONLY from replan.required (IMMUTABLE RULE #9)
        await self._emit_task_failed(
            task_id=task_id,
            node_id=node_id,
            dag_id=dag_id,
            failure_reason=failure_reason,
            failure_source="auditor",
            retry_count=retry_count,
            replan_attempt=meta.get("replan_attempt", 0),
            correlation_id=task_id,
            trace_id=trace_id,
        )

        # Emit progress on state transition
        await self._emit_progress(dag_id, task_id, meta, "running", trace_id)

        # Decide: replan or DLQ (PC-08)
        await self._handle_terminal_failure(
            dag=dag,
            node=node,
            task_id=task_id,
            dag_id=dag_id,
            failure_reason=failure_reason,
            meta=meta,
            original_event_id=original_event_id,
            original_topic=original_topic,
            original_payload=original_payload,
            trace_id=trace_id,
        )

    async def _handle_terminal_failure(
        self,
        dag: dict,
        node: dict,
        task_id: str,
        dag_id: str,
        failure_reason: str,
        meta: dict,
        original_event_id: str,
        original_topic: str,
        original_payload: dict,
        trace_id: Optional[str],
    ) -> None:
        """
        Terminal node failure decision point.
        PC-08: max_replan_attempts = 2.

        replan_attempt  0 → emit replan.required(attempt=1), continue
        replan_attempt  1 → emit replan.required(attempt=2), continue
        replan_attempt ≥2 → emit task.dlq (REPLAN_LIMIT_EXCEEDED), terminal
        """
        replan_attempt = meta.get("replan_attempt", 0)

        if replan_attempt >= self.MAX_REPLAN_ATTEMPTS:
            # ── TERMINAL: max replans exhausted → DLQ ─────────────────────
            logger.error(
                "Max replan attempts (%d) exhausted — routing to task.dlq",
                self.MAX_REPLAN_ATTEMPTS,
                extra={"task_id": task_id, "dag_id": dag_id},
            )

            # Emit meta.agent.request for repeated failure (SVC-04 produces this)
            await self._emit_meta_agent_request(
                task_id=task_id,
                node=node,
                failure_reason=failure_reason,
                trace_id=trace_id,
            )

            # DLQ producer_protocol: (1) log ERROR, (2) Prometheus counter, (3) DLQPayload
            logger.error(
                "DLQ: routing failed task",
                extra={
                    "original_event_id": original_event_id,
                    "idempotency_key": original_payload.get("idempotency_key"),
                    "failure_reason": failure_reason,
                },
            )
            # Prometheus: aegis_dlq_messages_total{topic='task.dlq', source_service='SVC-04'}
            try:
                from prometheus_client import Counter
                _dlq_counter = Counter(
                    "aegis_dlq_messages_total",
                    "DLQ messages",
                    ["topic", "source_service"],
                )
                _dlq_counter.labels(topic="task.dlq", source_service="SVC-04").inc()
            except Exception:
                pass

            await self._emit_dlq(
                original_topic=original_topic,
                original_event_id=original_event_id,
                original_payload=original_payload,
                failure_reason=f"REPLAN_LIMIT_EXCEEDED: {failure_reason}",
                retry_count=replan_attempt,
                correlation_id=task_id,
                trace_id=trace_id,
            )

            await self._emit_progress(dag_id, task_id, meta, "completing", trace_id)

        else:
            # ── REPLAN: emit replan.required ───────────────────────────────
            states = await self.state.get_node_states(dag_id)
            completed_node_ids = [nid for nid, s in states.items() if s == "completed"]
            new_attempt = replan_attempt + 1       # min=1, max=2 (contracts.json)

            # ReplanRequiredPayload — all 7 required fields
            replan_payload = {
                "task_id": task_id,
                "dag_id": dag_id,
                "failed_node_id": node["node_id"],
                "failure_context": (
                    f"Node {node['node_id']} ({node['agent_type']}) failed: {failure_reason}"
                ),
                "replan_attempt": new_attempt,              # minimum=1, maximum=2
                "original_plan_id": meta.get("plan_id", str(uuid.uuid4())),
                "completed_node_ids": completed_node_ids,
                "replan_source": "execution_orchestrator",  # IMMUTABLE RULE #9
                "created_at": datetime.now(timezone.utc).isoformat(),
            }

            # message_key = task_id (contracts.json replan.required.message_key_field)
            await self.producer.produce(
                topic="replan.required",
                payload=replan_payload,
                correlation_id=task_id,
                message_key=task_id,
                trace_id=trace_id,
            )

            # Persist updated replan_attempt
            meta["replan_attempt"] = new_attempt
            await self.state.update_meta(dag_id, meta)
            await self.state.set_replan_attempt(task_id, new_attempt)

            await self._emit_progress(dag_id, task_id, meta, "replanning", trace_id)

            logger.info(
                "Replan triggered",
                extra={"task_id": task_id, "replan_attempt": new_attempt, "node": node["node_id"]},
            )

    # ══════════════════════════════════════════════════════════════════════
    # PRIVATE — Dispatch Helpers
    # ══════════════════════════════════════════════════════════════════════

    async def _dispatch_ready_nodes(
        self,
        dag: dict,
        dag_id: str,
        task_id: str,
        trace_id: Optional[str],
    ) -> None:
        """Dispatch all pending nodes whose dependencies are fully completed."""
        ready_nodes = await self.state.get_ready_nodes(dag, dag_id)
        meta = await self.state.get_meta(dag_id)

        for node in ready_nodes:
            if node.get("requires_hitl", False):
                await self._dispatch_with_hitl(dag, node, dag_id, task_id, meta, trace_id)
            else:
                dispatched = await self.dispatcher.dispatch_node(
                    dag=dag, node=node, task_id=task_id, retry_count=0, trace_id=trace_id,
                )
                if dispatched:
                    # Emit progress on pending → running transition
                    meta = await self.state.get_meta(dag_id)  # refresh after state change
                    await self._emit_progress(dag_id, task_id, meta, "running", trace_id)

    async def _dispatch_with_hitl(
        self,
        dag: dict,
        node: dict,
        dag_id: str,
        task_id: str,
        meta: dict,
        trace_id: Optional[str],
    ) -> None:
        """
        Handle requires_hitl=True node.
        C-15: pending → awaiting_human.
        Emit hitl.request (all 10 required fields).
        Emit progress on state transition.
        """
        node_id = node["node_id"]

        # C-15: pending → awaiting_human
        success = await self.state.atomic_transition(dag_id, node_id, "pending", "awaiting_human")
        if not success:
            return

        hitl_id = str(uuid.uuid4())

        # HITLRequestPayload — all 10 required fields (contracts.json)
        hitl_payload = {
            "hitl_id": hitl_id,
            "task_id": task_id,
            "node_id": node_id,
            "user_id": meta.get("user_id", "unknown"),
            "session_id": meta.get("session_id", "00000000-0000-0000-0000-000000000000"),
            "trigger_reason": "high_risk",
            "risk_classification": "high",
            "context": (
                f"Node {node_id} (type: {node['agent_type']}, priority: {node['priority']}) "
                "requires human approval before execution."
            ),
            "current_output": None,
            "confidence_score": None,
            "available_actions": ["approve", "reject"],
            "timeout_hours": 1,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # message_key = hitl_id (contracts.json hitl.request.message_key_field)
        await self.producer.produce(
            topic="hitl.request",
            payload=hitl_payload,
            correlation_id=task_id,
            message_key=hitl_id,
            trace_id=trace_id,
        )

        # Emit progress on pending → awaiting_human transition
        await self._emit_progress(dag_id, task_id, meta, "awaiting_human", trace_id)

        logger.info(
            "HITL approval required for node",
            extra={"node_id": node_id, "hitl_id": hitl_id, "dag_id": dag_id},
        )

    # ══════════════════════════════════════════════════════════════════════
    # PRIVATE — Event Emission
    # ══════════════════════════════════════════════════════════════════════

    async def _emit_progress(
        self,
        dag_id: str,
        task_id: str,
        meta: dict,
        status: str,        # "running" | "replanning" | "awaiting_human" | "completing"
        trace_id: Optional[str],
    ) -> None:
        """
        Emit TaskProgressPayload to task.progress.
        MUST be called on EVERY node state transition.
        contracts.json: progress_event_on_every_state_transition = true
        TaskProgressPayload: all 10 required fields.
        """
        states = await self.state.get_node_states(dag_id)
        completed = self.state.count_completed(states)
        total = meta.get("total_nodes", max(len(states), 1))
        pct = round((completed / total) * 100.0, 2) if total > 0 else 0.0

        # TaskProgressPayload — 10 required fields
        progress_payload = {
            "task_id": task_id,
            "dag_id": dag_id,
            "user_id": meta.get("user_id", "unknown"),
            "session_id": meta.get("session_id", "00000000-0000-0000-0000-000000000000"),
            "progress_percentage": pct,
            "current_step": f"DAG execution: {completed}/{total} nodes completed",
            "completed_nodes": completed,
            "total_nodes": total,
            "status": status,   # enum: running|replanning|awaiting_human|completing
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # message_key = task_id (contracts.json task.progress.message_key_field)
        await self.producer.produce(
            topic="task.progress",
            payload=progress_payload,
            correlation_id=task_id,
            message_key=task_id,
            trace_id=trace_id,
        )

        # Publish to Redis pub/sub for WebSocket subscribers (best-effort)
        try:
            await self.redis.publish(
                f"dag_updates:{dag_id}",
                json.dumps({
                    "dag_id": dag_id,
                    "node_states": states,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }),
            )
        except Exception as exc:
            logger.warning("Redis pub/sub publish failed (non-critical): %s", exc)

    async def _emit_task_completed(
        self,
        dag: dict,
        dag_id: str,
        task_id: str,
        meta: dict,
        trace_id: Optional[str],
    ) -> None:
        """
        Emit TaskCompletedPayload to task.completed.
        All 10 required fields (contracts.json).
        Triggered when ALL DAG nodes reach terminal state.
        """
        states = await self.state.get_node_states(dag_id)
        completed_count = self.state.count_completed(states)

        started_at_str = meta.get("started_at", datetime.now(timezone.utc).isoformat())
        try:
            started_at = datetime.fromisoformat(started_at_str)
            latency_ms = int((datetime.now(timezone.utc) - started_at).total_seconds() * 1000)
        except (ValueError, TypeError):
            latency_ms = 0

        # TaskCompletedPayload — 10 required fields
        completed_payload = {
            "task_id": task_id,
            "dag_id": dag_id,
            "user_id": meta.get("user_id", "unknown"),
            "session_id": meta.get("session_id", "00000000-0000-0000-0000-000000000000"),
            "channel": meta.get("channel", "webui"),
            "completed_nodes": completed_count,
            "total_nodes": meta.get("total_nodes", len(states)),
            "total_cost_usd": meta.get("total_cost_usd", 0.0),
            "total_latency_ms": latency_ms,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # message_key = task_id (contracts.json task.completed.message_key_field)
        await self.producer.produce(
            topic="task.completed",
            payload=completed_payload,
            correlation_id=task_id,
            message_key=task_id,
            trace_id=trace_id,
        )

        logger.info(
            "Task completed",
            extra={
                "task_id": task_id,
                "completed_nodes": completed_count,
                "total_nodes": meta.get("total_nodes"),
                "latency_ms": latency_ms,
            },
        )

    async def _emit_task_failed(
        self,
        task_id: str,
        node_id: str,
        dag_id: str,
        failure_reason: str,
        failure_source: str,    # "worker"|"auditor"|"timeout"|"orchestrator"
        retry_count: int,
        replan_attempt: int,
        correlation_id: str,
        trace_id: Optional[str],
    ) -> None:
        """
        Emit TaskFailedPayload to task.failed.
        All 8 required fields (contracts.json).
        SVC-02 consumes for LEARNING ONLY — NOT replan trigger (IMMUTABLE RULE #8).
        """
        # TaskFailedPayload — 8 required fields
        failed_payload = {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "failure_reason": failure_reason,
            "failure_source": failure_source,
            "retry_count": retry_count,
            "replan_attempt": replan_attempt,
            "last_output": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # message_key = node_id (contracts.json task.failed.message_key_field)
        await self.producer.produce(
            topic="task.failed",
            payload=failed_payload,
            correlation_id=correlation_id,
            message_key=node_id,
            trace_id=trace_id,
        )

    async def _emit_dlq(
        self,
        original_topic: str,
        original_event_id: str,
        original_payload: dict,
        failure_reason: str,
        retry_count: int,
        correlation_id: str,
        trace_id: Optional[str],
    ) -> None:
        """
        Emit DLQPayload to task.dlq.
        All 8 required fields (contracts.json DLQPayload).
        message_key = original_event_id (contracts.json task.dlq.message_key_field)
        """
        # DLQPayload — 8 required fields
        dlq_payload = {
            "dlq_id": str(uuid.uuid4()),
            "original_topic": original_topic,
            "original_event_id": original_event_id,
            "original_payload": original_payload,
            "failure_reason": failure_reason,
            "retry_count": retry_count,
            "source_service": settings.service_id,     # "SVC-04"
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        await self.producer.produce(
            topic="task.dlq",
            payload=dlq_payload,
            correlation_id=correlation_id,
            message_key=original_event_id,
            trace_id=trace_id,
            status="error",
            error={
                # error_code from contracts.json global_error_codes enum
                "error_code": "REPLAN_LIMIT_EXCEEDED",
                "error_type": "agent",
                "retryable": False,
                "message": failure_reason,
            },
        )

    async def _emit_meta_agent_request(
        self,
        task_id: str,
        node: dict,
        failure_reason: str,
        trace_id: Optional[str],
    ) -> None:
        """
        Emit MetaAgentRequestPayload to meta.agent.request.
        All 8 required fields (contracts.json).
        Triggered when DLQ threshold reached (repeated agent failure).
        """
        meta_request_id = str(uuid.uuid4())

        # MetaAgentRequestPayload — 8 required fields
        meta_payload = {
            "meta_request_id": meta_request_id,
            "task_id": task_id,
            "trigger_reason": "repeated_agent_failure",
            "required_capability": node["agent_type"],
            "failure_pattern_description": (
                f"Agent type '{node['agent_type']}' failed after "
                f"{self.MAX_REPLAN_ATTEMPTS + 1} execution attempts. "
                f"Last failure: {failure_reason}"
            ),
            "historical_failure_count": self.MAX_REPLAN_ATTEMPTS + 1,
            "historical_failure_logs": [failure_reason],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # message_key = meta_request_id (contracts.json meta.agent.request.message_key_field)
        await self.producer.produce(
            topic="meta.agent.request",
            payload=meta_payload,
            correlation_id=task_id,
            message_key=meta_request_id,
            trace_id=trace_id,
        )