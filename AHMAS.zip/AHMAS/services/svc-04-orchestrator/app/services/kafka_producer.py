# FILE: services/svc-04-orchestrator/app/services/kafka_producer.py

"""
Kafka producer for SVC-04.
All messages wrapped in AegisCanonicalEventEnvelope (contracts.json global.event_schema).
Required envelope fields: event_id, event_type, schema_version, payload_version,
  timestamp, source_service, correlation_id, trace_id, idempotency_key, status, payload
"""
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

from aiokafka import AIOKafkaProducer

from app.config import settings

logger = logging.getLogger(__name__)


def build_envelope(
    event_type: str,
    payload: dict,
    correlation_id: str,
    trace_id: Optional[str] = None,
    status: str = "success",
    error: Optional[dict] = None,
) -> dict:
    """
    Build AegisCanonicalEventEnvelope — all 11 required fields.
    contracts.json global.event_schema (additionalProperties: false)
    """
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "schema_version": settings.schema_version,
        "payload_version": settings.payload_version,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": settings.service_id,       # "SVC-04" (pattern ^SVC-[0-9]{2}$)
        "correlation_id": correlation_id,             # MUST equal originating task_id (C-05)
        "trace_id": trace_id or str(uuid.uuid4()),
        "idempotency_key": str(uuid.uuid4()),
        "status": status,
        "payload": payload,
        "error": error,                               # null when status="success"
    }


class KafkaProducer:
    def __init__(self):
        self._producer: Optional[AIOKafkaProducer] = None

    async def start(self) -> None:
        self._producer = AIOKafkaProducer(
            bootstrap_servers=settings.kafka_bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks="all",
            enable_idempotence=True,
        )
        await self._producer.start()
        logger.info("Kafka producer started")

    async def stop(self) -> None:
        if self._producer:
            await self._producer.stop()
            logger.info("Kafka producer stopped")

    async def produce(
        self,
        topic: str,
        payload: dict,
        correlation_id: str,
        message_key: Optional[str] = None,
        trace_id: Optional[str] = None,
        status: str = "success",
        error: Optional[dict] = None,
    ) -> str:
        """Produce Kafka message in canonical envelope. Returns event_id."""
        envelope = build_envelope(
            event_type=topic,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status=status,
            error=error,
        )
        await self._producer.send_and_wait(
            topic=topic,
            value=envelope,
            key=message_key,
        )
        logger.info(
            "Event produced",
            extra={
                "topic": topic,
                "event_id": envelope["event_id"],
                "correlation_id": correlation_id,
            },
        )
        return envelope["event_id"]