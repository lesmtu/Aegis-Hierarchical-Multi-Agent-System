# FILE: services/svc-04-orchestrator/app/services/redis_client.py

"""Redis async client for SVC-04."""
import logging
import redis.asyncio as aioredis
from app.config import settings

logger = logging.getLogger(__name__)
_redis: aioredis.Redis = None


async def init_redis() -> None:
    global _redis
    _redis = aioredis.from_url(settings.redis_url, decode_responses=True)
    await _redis.ping()
    logger.info("Redis connection established")


async def close_redis() -> None:
    global _redis
    if _redis:
        await _redis.aclose()
        logger.info("Redis connection closed")


def get_redis() -> aioredis.Redis:
    return _redis