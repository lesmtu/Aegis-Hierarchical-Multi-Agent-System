# FILE: services/svc-04-orchestrator/app/services/dag_state.py

"""
Redis DAG state management with atomic Lua scripts.

contracts.json SVC-04.redis_state_schema:
  dag:{dag_id}:nodes        → Hash (node_id → status)
  dag:{dag_id}:meta         → JSON string (task_id, user_id, session_id,
                               channel, replan_attempt, total_nodes)
  dag:{dag_id}:retry_counts → Hash (node_id → integer count)

C-15: ALL state transitions MUST use atomic Lua scripts.
      Non-atomic HSET is FORBIDDEN.
"""
import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Valid node statuses (contracts.json SVC-04.redis_state_schema.field_enum)
NODE_STATES = frozenset({
    "pending", "running", "completed", "failed", "retrying", "awaiting_human",
})

# ── C-15: Atomic state-transition Lua script ─────────────────────────────
# KEYS[1] = "dag:{dag_id}:nodes"   (Redis Hash)
# ARGV[1] = node_id
# ARGV[2] = expected_current_state
# ARGV[3] = new_state
# Returns 1 if transition succeeded, 0 if current ≠ expected (stale → skip).
ATOMIC_TRANSITION_LUA = """
local current = redis.call('HGET', KEYS[1], ARGV[1])
if current ~= ARGV[2] then
    return 0
end
redis.call('HSET', KEYS[1], ARGV[1], ARGV[3])
return 1
"""


class DAGStateManager:
    """
    All DAG node state changes go through atomic_transition().
    Direct HSET on dag:{dag_id}:nodes is PROHIBITED (C-15).
    """

    def __init__(self, redis_client):
        self.redis = redis_client
        self._transition_script = redis_client.register_script(ATOMIC_TRANSITION_LUA)

    # ── DAG Lifecycle ─────────────────────────────────────────────────────

    async def initialize_dag(self, dag: dict, meta: dict) -> None:
        """
        Initialize Redis state for a new or replanned DAG.
        All nodes start as 'pending'.
        """
        dag_id = dag["dag_id"]
        task_id = dag["task_id"]

        # dag:{dag_id}:nodes — Hash(node_id → "pending")
        node_states = {node["node_id"]: "pending" for node in dag["nodes"]}
        await self.redis.hset(f"dag:{dag_id}:nodes", mapping=node_states)

        # dag:{dag_id}:retry_counts — Hash(node_id → "0")
        retry_init = {node["node_id"]: "0" for node in dag["nodes"]}
        await self.redis.hset(f"dag:{dag_id}:retry_counts", mapping=retry_init)

        # dag:{dag_id}:meta — JSON
        await self.redis.set(f"dag:{dag_id}:meta", json.dumps(meta))

        # Full DAG structure for later retrieval during execution
        await self.redis.set(f"dag:{dag_id}:structure", json.dumps(dag))

        # Reverse mapping: task_id → latest dag_id
        await self.redis.set(f"task:{task_id}:dag_id", dag_id)

        logger.info(
            "DAG state initialized",
            extra={"dag_id": dag_id, "task_id": task_id, "nodes": len(dag["nodes"])},
        )

    # ── C-15: Atomic Transition ───────────────────────────────────────────

    async def atomic_transition(
        self,
        dag_id: str,
        node_id: str,
        expected_state: str,
        new_state: str,
    ) -> bool:
        """
        C-15: Atomic node state transition via Lua script.
        Returns True  → transition succeeded.
        Returns False → current state ≠ expected_state (stale — caller MUST skip).
        Raises ValueError for invalid state names.
        """
        if expected_state not in NODE_STATES:
            raise ValueError(f"Invalid expected_state: {expected_state!r}")
        if new_state not in NODE_STATES:
            raise ValueError(f"Invalid new_state: {new_state!r}")

        result = await self._transition_script(
            keys=[f"dag:{dag_id}:nodes"],
            args=[node_id, expected_state, new_state],
        )
        success = bool(result)
        if success:
            logger.debug(
                "Node state: %s → %s",
                expected_state, new_state,
                extra={"dag_id": dag_id, "node_id": node_id},
            )
        else:
            logger.info(
                "Atomic transition skipped (stale): expected=%s",
                expected_state,
                extra={"dag_id": dag_id, "node_id": node_id},
            )
        return success

    # ── State Queries ─────────────────────────────────────────────────────

    async def get_node_states(self, dag_id: str) -> dict:
        """Return {node_id: status} for all nodes."""
        return await self.redis.hgetall(f"dag:{dag_id}:nodes")

    async def get_ready_nodes(self, dag: dict, dag_id: str) -> list:
        """
        Return nodes in 'pending' state whose ALL dependencies are 'completed'.
        """
        states = await self.get_node_states(dag_id)
        return [
            node for node in dag["nodes"]
            if states.get(node["node_id"]) == "pending"
            and all(states.get(dep) == "completed" for dep in node["dependencies"])
        ]

    async def all_nodes_completed(self, dag_id: str) -> bool:
        """True only when every node is in 'completed' state (no failures)."""
        states = await self.get_node_states(dag_id)
        return bool(states) and all(s == "completed" for s in states.values())

    async def all_nodes_terminal(self, dag_id: str) -> bool:
        """True when every node is in {completed, failed}."""
        states = await self.get_node_states(dag_id)
        return bool(states) and all(s in ("completed", "failed") for s in states.values())

    def count_completed(self, states: dict) -> int:
        return sum(1 for s in states.values() if s == "completed")

    # ── Retry Tracking ────────────────────────────────────────────────────

    async def increment_retry(self, dag_id: str, node_id: str) -> int:
        return int(await self.redis.hincrby(f"dag:{dag_id}:retry_counts", node_id, 1))

    async def get_retry_count(self, dag_id: str, node_id: str) -> int:
        val = await self.redis.hget(f"dag:{dag_id}:retry_counts", node_id)
        return int(val) if val else 0

    # ── Metadata ─────────────────────────────────────────────────────────

    async def get_meta(self, dag_id: str) -> Optional[dict]:
        raw = await self.redis.get(f"dag:{dag_id}:meta")
        return json.loads(raw) if raw else None

    async def update_meta(self, dag_id: str, meta: dict) -> None:
        await self.redis.set(f"dag:{dag_id}:meta", json.dumps(meta))

    # ── DAG Structure ─────────────────────────────────────────────────────

    async def get_dag_structure(self, dag_id: str) -> Optional[dict]:
        raw = await self.redis.get(f"dag:{dag_id}:structure")
        return json.loads(raw) if raw else None

    async def get_dag_id_by_task(self, task_id: str) -> Optional[str]:
        return await self.redis.get(f"task:{task_id}:dag_id")

    # ── Task-Level Replan Counter (persists across DAG instances) ─────────

    async def get_replan_attempt(self, task_id: str) -> int:
        val = await self.redis.get(f"task:{task_id}:replan_attempt")
        return int(val) if val else 0

    async def set_replan_attempt(self, task_id: str, attempt: int) -> None:
        await self.redis.set(f"task:{task_id}:replan_attempt", str(attempt))

    # ── User Context (populated by upstream services) ─────────────────────

    async def get_task_context(self, task_id: str) -> dict:
        """
        Retrieve stored user context (user_id, session_id, channel).
        Defaults used when upstream service has not populated the key.
        Production: SVC-01 stores this on task receipt.
        """
        raw = await self.redis.get(f"task:{task_id}:context")
        if raw:
            return json.loads(raw)
        return {
            "user_id": "unknown",
            "session_id": "00000000-0000-0000-0000-000000000000",
            "channel": "webui",
        }

    async def store_task_context(self, task_id: str, context: dict) -> None:
        await self.redis.set(f"task:{task_id}:context", json.dumps(context))

    # ── Node Lookup ───────────────────────────────────────────────────────

    def find_node(self, dag: dict, node_id: str) -> Optional[dict]:
        for node in dag.get("nodes", []):
            if node["node_id"] == node_id:
                return node
        return None