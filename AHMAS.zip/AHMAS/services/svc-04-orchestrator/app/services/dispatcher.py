# FILE: services/svc-04-orchestrator/app/services/dispatcher.py

"""
Node dispatch logic — produces TaskDispatchedPayload to task.dispatched.
contracts.json TaskDispatchedPayload: 15 required fields.
C-15: dispatch atomically transitions node state pending/retrying → running.
"""
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

from app.services.dag_state import DAGStateManager
from app.services.kafka_producer import KafkaProducer

logger = logging.getLogger(__name__)


class NodeDispatcher:
    def __init__(self, producer: KafkaProducer, state: DAGStateManager):
        self.producer = producer
        self.state = state

    async def dispatch_node(
        self,
        dag: dict,
        node: dict,
        task_id: str,
        retry_count: int = 0,
        correction_guidance: Optional[str] = None,
        trace_id: Optional[str] = None,
    ) -> bool:
        """
        Dispatch a DAG node to task.dispatched.

        C-15: Atomically transitions state:
          retry_count == 0 → pending  → running
          retry_count  > 0 → retrying → running

        TaskDispatchedPayload (15 required fields, contracts.json):
          task_id, node_id, dag_id, agent_type, agent_id, sub_task_name,
          sub_task_description, input_context, model_tier, retry_count,
          idempotency_key, requires_audit, requires_hitl, priority, dispatched_at

        Returns True if dispatched, False if stale state (caller skips progress emit).
        """
        dag_id = dag["dag_id"]
        node_id = node["node_id"]

        # C-15: atomic transition BEFORE producing to Kafka
        expected = "retrying" if retry_count > 0 else "pending"
        success = await self.state.atomic_transition(dag_id, node_id, expected, "running")
        if not success:
            logger.info("Dispatch skipped — stale state", extra={"node_id": node_id})
            return False

        sub_task_name, sub_task_description = self._resolve_subtask_meta(dag, node)

        # ── TaskDispatchedPayload: ALL 15 required fields ─────────────────
        dispatch_payload: dict = {
            "task_id": task_id,
            "node_id": node_id,
            "dag_id": dag_id,
            "agent_type": node["agent_type"],
            "agent_id": node["agent_id"],
            "sub_task_name": sub_task_name,
            "sub_task_description": sub_task_description,
            "input_context": self._build_context(dag, node),
            "model_tier": node["model_tier"],
            "retry_count": retry_count,
            "idempotency_key": str(uuid.uuid4()),   # Per-dispatch key for worker idempotency
            "requires_audit": node["requires_audit"],
            "requires_hitl": node["requires_hitl"],
            "priority": node["priority"],
            "dispatched_at": datetime.now(timezone.utc).isoformat(),
        }

        # Optional field: correction_guidance on retry (contracts.json TaskDispatchedPayload)
        if retry_count > 0 and correction_guidance:
            dispatch_payload["correction_guidance"] = correction_guidance

        # message_key = node_id (contracts.json task.dispatched.message_key_field)
        await self.producer.produce(
            topic="task.dispatched",
            payload=dispatch_payload,
            correlation_id=task_id,
            message_key=node_id,
            trace_id=trace_id,
        )

        logger.info(
            "Node dispatched",
            extra={
                "node_id": node_id,
                "agent_type": node["agent_type"],
                "retry_count": retry_count,
                "dag_id": dag_id,
            },
        )
        return True

    def _resolve_subtask_meta(self, dag: dict, node: dict) -> tuple:
        """
        Resolve sub_task_name and sub_task_description.
        Checks dag._sub_tasks lookup (SVC-03 may populate this).
        Falls back to agent_type + node_id identifier when not available.
        Note: DAGNode schema does not include sub-task name/description directly.
        """
        sub_tasks: dict = dag.get("_sub_tasks", {})
        sub_task_id = node["sub_task_id"]

        if sub_task_id in sub_tasks:
            st = sub_tasks[sub_task_id]
            return (
                st.get("name", f"{node['agent_type'].capitalize()} Task"),
                st.get("description", f"Sub-task {sub_task_id}"),
            )

        # Fallback: derived identifier
        return (
            f"{node['agent_type'].capitalize()} Task [{node['node_id'][:8]}]",
            f"Execute {node['agent_type']} sub-task (sub_task_id={sub_task_id})",
        )

    def _build_context(self, dag: dict, node: dict) -> str:
        """Build input_context from dependency chain."""
        if not node["dependencies"]:
            return "No prior context. This is the first step in the execution plan."
        deps = node["dependencies"]
        preview = ", ".join(deps[:3]) + ("..." if len(deps) > 3 else "")
        return (
            f"This task depends on {len(deps)} completed predecessor(s): {preview}. "
            "Outputs from completed nodes are available in task execution history."
        )