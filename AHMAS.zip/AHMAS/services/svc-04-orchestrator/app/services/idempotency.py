# FILE: services/svc-04-orchestrator/app/services/idempotency.py

"""
Redis-based idempotency enforcement for SVC-04.
contracts.json global.idempotency_policy

key_schema : idempotency:{service_id}:{idempotency_key}
TTL        : 86400 s (24 h)
Lua script : contracts.json idempotency_policy.lua_script
"""
import json
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# contracts.json idempotency_policy.lua_script
# Returns 1 → key was new (proceed).  Returns 0 → key existed (skip).
IDEMPOTENCY_LUA = """
local existing = redis.call('GET', KEYS[1])
if existing then
    return 0
else
    redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2])
    return 1
end
"""


class IdempotencyService:
    SERVICE_ID = "SVC-04"

    def __init__(self, redis_client, ttl: int = 86400, stale_lock_timeout: int = 600):
        self.redis = redis_client
        self.ttl = ttl
        self.stale_lock_timeout = stale_lock_timeout
        self._lua = redis_client.register_script(IDEMPOTENCY_LUA)

    def _key(self, idempotency_key: str) -> str:
        # contracts.json: key_schema = "idempotency:{service_id}:{idempotency_key}"
        return f"idempotency:{self.SERVICE_ID}:{idempotency_key}"

    async def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        """
        Atomically check-and-set idempotency key.
        Returns True  → new key, proceed with processing.
        Returns False → duplicate or in-flight, skip.

        Implements stale lock detection per contracts.json
        idempotency_policy.processing_protocol.step_6_on_status_processing_stale
        """
        key = self._key(idempotency_key)
        now = datetime.now(timezone.utc)
        value = json.dumps({
            "processed_at": now.isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": "processing",
        })

        # Atomic SET NX (contracts.json lua_script)
        result = await self._lua(keys=[key], args=[value, str(self.ttl)])
        if result:
            return True  # New key — proceed

        # Key exists — inspect status
        existing_raw = await self.redis.get(key)
        if not existing_raw:
            # Expired between Lua check and GET — retry
            result = await self._lua(keys=[key], args=[value, str(self.ttl)])
            return bool(result)

        existing = json.loads(existing_raw)
        status = existing.get("status", "completed")

        if status in ("completed", "failed"):
            logger.info(
                "Idempotency: duplicate message skipped (status=%s)", status,
                extra={"idempotency_key": idempotency_key, "event_id": event_id},
            )
            return False

        if status == "processing":
            # contracts.json step_6: stale lock after 10 min → reprocess
            processed_at_str = existing.get("processed_at", now.isoformat())
            try:
                processed_at = datetime.fromisoformat(processed_at_str)
                age = (now - processed_at).total_seconds()
            except (ValueError, TypeError):
                age = 0

            if age > self.stale_lock_timeout:
                logger.warning(
                    "Stale idempotency lock (age=%.0fs) — overwriting and reprocessing",
                    age,
                    extra={"idempotency_key": idempotency_key},
                )
                await self.redis.set(key, value, ex=self.ttl)
                return True
            else:
                logger.info(
                    "Idempotency: message in-flight by another instance (age=%.0fs)", age,
                    extra={"idempotency_key": idempotency_key},
                )
                return False

        return False

    async def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        """step_4: update status → 'completed'."""
        key = self._key(idempotency_key)
        value = json.dumps({
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": "completed",
        })
        await self.redis.set(key, value, xx=True, keepttl=True)

    async def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        """step_5: update status → 'failed'."""
        key = self._key(idempotency_key)
        value = json.dumps({
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": "failed",
        })
        await self.redis.set(key, value, xx=True, keepttl=True)