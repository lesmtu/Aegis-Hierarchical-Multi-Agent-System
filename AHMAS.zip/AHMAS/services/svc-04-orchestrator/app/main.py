# FILE: services/svc-04-orchestrator/app/main.py

"""
SVC-04 Execution Orchestrator — FastAPI application entry point.
Aegis HMAS | contracts.json SVC-04
"""
import asyncio
import logging

from fastapi import FastAPI

from app.config import settings
from app.routers.health import router as health_router
from app.routers.websocket import router as ws_router
from app.services.redis_client import init_redis, close_redis, get_redis
from app.services.dag_state import DAGStateManager
from app.services.idempotency import IdempotencyService
from app.services.kafka_producer import KafkaProducer
from app.services.kafka_consumer import KafkaConsumerService
from app.services.dispatcher import NodeDispatcher
from app.services.orchestrator import ExecutionOrchestrator

logging.basicConfig(
    level=logging.INFO,
    format='{"ts":"%(asctime)s","lvl":"%(levelname)s","svc":"SVC-04","msg":"%(message)s"}',
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="SVC-04 Execution Orchestrator",
    description="Aegis HMAS — DAG execution, atomic state management, replanning",
    version=settings.service_version,
)

app.include_router(health_router)
app.include_router(ws_router)

# Service singletons
_producer: KafkaProducer = None
_consumer_service: KafkaConsumerService = None
_consumer_task: asyncio.Task = None


@app.on_event("startup")
async def startup_event() -> None:
    global _producer, _consumer_service, _consumer_task

    logger.info("SVC-04 starting up")

    # 1. Redis
    await init_redis()
    redis = get_redis()

    # 2. Service graph (dependency injection)
    dag_state = DAGStateManager(redis)
    idempotency = IdempotencyService(
        redis_client=redis,
        ttl=settings.idempotency_ttl,
        stale_lock_timeout=settings.stale_lock_timeout,
    )

    _producer = KafkaProducer()
    await _producer.start()

    dispatcher = NodeDispatcher(producer=_producer, state=dag_state)

    orchestrator = ExecutionOrchestrator(
        dag_state=dag_state,
        dispatcher=dispatcher,
        producer=_producer,
        idempotency=idempotency,
        redis_client=redis,
    )

    # 3. Kafka consumer
    _consumer_service = KafkaConsumerService(orchestrator=orchestrator)
    await _consumer_service.start()
    _consumer_task = asyncio.create_task(_consumer_service.consume_loop())

    logger.info("SVC-04 Execution Orchestrator ready")


@app.on_event("shutdown")
async def shutdown_event() -> None:
    global _consumer_task

    logger.info("SVC-04 shutting down")

    if _consumer_task and not _consumer_task.done():
        _consumer_task.cancel()
        try:
            await _consumer_task
        except asyncio.CancelledError:
            pass

    if _consumer_service:
        await _consumer_service.stop()

    if _producer:
        await _producer.stop()

    await close_redis()

    logger.info("SVC-04 shutdown complete")