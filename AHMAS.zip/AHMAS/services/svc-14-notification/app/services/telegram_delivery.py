from __future__ import annotations

import httpx


class TelegramDeliveryClient:
    def __init__(self, bot_token: str, *, api_base: str = "https://api.telegram.org"):
        self.bot_token = bot_token
        self.base_url = f"{api_base}/bot{bot_token}"
        self.http = httpx.AsyncClient(timeout=10.0)

    async def send_message(self, chat_id: str, text: str) -> dict:
        response = await self.http.post(
            f"{self.base_url}/sendMessage",
            json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "MarkdownV2",
            },
        )
        response.raise_for_status()
        return response.json()
