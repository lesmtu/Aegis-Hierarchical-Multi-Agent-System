from __future__ import annotations

try:
    from prometheus_client import CollectorRegistry, Counter, generate_latest
except ModuleNotFoundError:  # pragma: no cover
    class _CounterChild:
        def inc(self, amount: float = 1.0) -> None:
            return None

    class Counter:  # type: ignore[override]
        def __init__(self, *args, **kwargs):
            return None

        def labels(self, **kwargs):
            return _CounterChild()

    class CollectorRegistry:  # type: ignore[override]
        pass

    def generate_latest(registry) -> bytes:
        return b""


REGISTRY = CollectorRegistry()

DELIVERY_TOTAL = Counter(
    "aegis_notification_delivery_total",
    "Notification delivery attempts by channel and outcome",
    labelnames=("channel", "status"),
    registry=REGISTRY,
)

KAFKA_MESSAGES = Counter(
    "aegis_notification_kafka_messages_total",
    "Kafka messages processed by SVC-14",
    labelnames=("topic", "result"),
    registry=REGISTRY,
)

DLQ_MESSAGES = Counter(
    "aegis_dlq_messages_total",
    "DLQ messages emitted by source service",
    labelnames=("topic", "source_service"),
    registry=REGISTRY,
)


def render_metrics() -> str:
    return generate_latest(REGISTRY).decode("utf-8")
