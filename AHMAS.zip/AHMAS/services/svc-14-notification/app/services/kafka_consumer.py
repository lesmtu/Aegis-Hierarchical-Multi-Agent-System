from __future__ import annotations

import logging

from shared.events.envelope import AegisCanonicalEventEnvelope
from shared.events.consumer import KafkaEventConsumer
from shared.idempotency.client import IdempotencyClient

from .metrics import KAFKA_MESSAGES
from .notification_service import validate_incoming_payload

logger = logging.getLogger(__name__)


class NotificationKafkaConsumer:
    SUPPORTED_TOPICS = {"result.ready", "hitl.request", "task.progress"}

    def __init__(self, *, idempotency_client: IdempotencyClient, notification_service):
        self.idempotency = idempotency_client
        self.notification_service = notification_service
        self.consumer = KafkaEventConsumer()

    async def process(self, topic: str, message: dict) -> bool:
        if topic not in self.SUPPORTED_TOPICS:
            raise ValueError(f"Unsupported topic: {topic}")

        should_process, route_topic, envelope_payload = self.consumer.consume(message)
        if not should_process:
            KAFKA_MESSAGES.labels(topic=topic, result="schema_rejected").inc()
            return False
        if route_topic:
            KAFKA_MESSAGES.labels(topic=topic, result="rejected").inc()
            return False

        if not self.idempotency.check_and_set(message["idempotency_key"], message["event_id"]):
            logger.info(
                "Duplicate message skipped. topic=%s idempotency_key=%s event_id=%s",
                topic,
                message["idempotency_key"],
                message["event_id"],
            )
            KAFKA_MESSAGES.labels(topic=topic, result="duplicate").inc()
            return False

        try:
            validate_incoming_payload(topic, message["payload"])
            await self.notification_service.handle_event(topic, AegisCanonicalEventEnvelope(**envelope_payload))
        except Exception:
            self.idempotency.mark_failed(message["idempotency_key"], message["event_id"])
            KAFKA_MESSAGES.labels(topic=topic, result="failed").inc()
            raise

        self.idempotency.mark_completed(message["idempotency_key"], message["event_id"])
        KAFKA_MESSAGES.labels(topic=topic, result="processed").inc()
        return True
