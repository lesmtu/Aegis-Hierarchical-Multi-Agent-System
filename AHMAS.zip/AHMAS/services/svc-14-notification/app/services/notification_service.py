from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from shared.events.error_codes import AegisErrorCode, build_error_payload

from .metrics import DELIVERY_TOTAL, DLQ_MESSAGES

logger = logging.getLogger(__name__)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ResultReadyPayload(StrictModel):
    task_id: str
    dag_id: str
    user_id: str = Field(min_length=1)
    session_id: str
    channel: str
    synthesized_output: str = Field(min_length=1)
    reflection_score: float = Field(ge=0.0, le=1.0)
    aggregation_metadata: dict[str, Any]
    created_at: str
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None

    @model_validator(mode="after")
    def validate_route(self) -> "ResultReadyPayload":
        if self.channel == "telegram" and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == "webui" and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == "openclaw":
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class HITLRequestPayload(StrictModel):
    hitl_id: str
    task_id: str
    node_id: str | None = None
    user_id: str = Field(min_length=1)
    session_id: str
    trigger_reason: str
    risk_classification: str
    context: str = Field(min_length=1)
    current_output: str | None = None
    confidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    available_actions: list[str] = Field(min_length=1)
    timeout_hours: int = Field(ge=1)
    created_at: str
    channel: str = "telegram"
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None

    @model_validator(mode="after")
    def validate_route(self) -> "HITLRequestPayload":
        if self.channel == "telegram" and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == "webui" and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == "openclaw":
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class TaskProgressPayload(StrictModel):
    task_id: str
    dag_id: str
    user_id: str = Field(min_length=1)
    session_id: str
    progress_percentage: float = Field(ge=0.0, le=100.0)
    current_step: str = Field(min_length=1)
    completed_nodes: int = Field(ge=0)
    total_nodes: int = Field(ge=0)
    status: str
    created_at: str
    channel: str = "telegram"
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None

    @model_validator(mode="after")
    def validate_route(self) -> "TaskProgressPayload":
        if self.channel == "telegram" and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == "webui" and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == "openclaw":
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class NotificationOutPayload(StrictModel):
    notification_id: str
    task_id: str
    user_id: str = Field(min_length=1)
    session_id: str
    channel: str
    message_type: str
    message_content: str = Field(min_length=1)
    delivery_status: str
    retry_count: int = Field(ge=0, le=5)
    created_at: str
    telegram_chat_id: str | None = None
    webui_connection_id: str | None = None
    openclaw_conversation_id: str | None = None
    openclaw_message_id: str | None = None
    openclaw_source_channel: str | None = None

    @model_validator(mode="after")
    def validate_route(self) -> "NotificationOutPayload":
        if self.channel == "telegram" and not self.telegram_chat_id:
            raise ValueError("telegram_chat_id is required when channel is 'telegram'")
        if self.channel == "webui" and not self.webui_connection_id:
            raise ValueError("webui_connection_id is required when channel is 'webui'")
        if self.channel == "openclaw":
            if not self.openclaw_conversation_id:
                raise ValueError("openclaw_conversation_id is required when channel is 'openclaw'")
            if not self.openclaw_source_channel:
                raise ValueError("openclaw_source_channel is required when channel is 'openclaw'")
        return self


class NotificationDeliveryError(RuntimeError):
    pass


class NotificationService:
    TELEGRAM_MAX_RETRIES = 3
    BACKOFF_SCHEDULE_SECONDS = (1.0, 2.0, 4.0)

    def __init__(self, telegram_client, webui_client, producer, *, sleep=asyncio.sleep):
        self.telegram = telegram_client
        self.webui = webui_client
        self.producer = producer
        self.sleep = sleep

    async def handle_event(self, topic: str, envelope) -> None:
        payload = self._build_notification(topic, envelope.payload)
        try:
            retry_count = 0
            if payload["channel"] == "telegram":
                retry_count = await self._deliver_telegram_with_retry(payload)
            elif payload["channel"] == "webui":
                await self._deliver_webui(payload)
            payload["delivery_status"] = "delivered"
            payload["retry_count"] = retry_count
            DELIVERY_TOTAL.labels(channel=payload["channel"], status="success").inc()
            await self.producer.produce_envelope(
                topic="notification.out",
                payload=NotificationOutPayload.model_validate(payload).model_dump(mode="json", exclude_none=True),
                source_service="SVC-14",
                correlation_id=envelope.correlation_id,
                trace_id=envelope.trace_id,
            )
        except Exception as exc:
            DELIVERY_TOTAL.labels(channel=payload["channel"], status="failed").inc()
            await self._emit_delivery_failed(payload, envelope, str(exc))
            raise NotificationDeliveryError(str(exc)) from exc

    def _build_notification(self, topic: str, payload: dict) -> dict:
        if topic == "result.ready":
            event = ResultReadyPayload.model_validate(payload)
            notification = {
                "notification_id": str(uuid4()),
                "task_id": event.task_id,
                "user_id": event.user_id,
                "session_id": event.session_id,
                "channel": event.channel,
                "message_type": "result",
                "message_content": event.synthesized_output,
                "delivery_status": "pending",
                "retry_count": 0,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            if event.telegram_chat_id:
                notification["telegram_chat_id"] = event.telegram_chat_id
            if event.webui_connection_id:
                notification["webui_connection_id"] = event.webui_connection_id
            if event.openclaw_conversation_id:
                notification["openclaw_conversation_id"] = event.openclaw_conversation_id
            if event.openclaw_message_id:
                notification["openclaw_message_id"] = event.openclaw_message_id
            if event.openclaw_source_channel:
                notification["openclaw_source_channel"] = event.openclaw_source_channel
            return notification
        if topic == "hitl.request":
            event = HITLRequestPayload.model_validate(payload)
            notification = {
                "notification_id": str(uuid4()),
                "task_id": event.task_id,
                "user_id": event.user_id,
                "session_id": event.session_id,
                "channel": event.channel,
                "message_type": "hitl_request",
                "message_content": event.context,
                "delivery_status": "pending",
                "retry_count": 0,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            if event.telegram_chat_id:
                notification["telegram_chat_id"] = event.telegram_chat_id
            if event.webui_connection_id:
                notification["webui_connection_id"] = event.webui_connection_id
            if event.openclaw_conversation_id:
                notification["openclaw_conversation_id"] = event.openclaw_conversation_id
            if event.openclaw_message_id:
                notification["openclaw_message_id"] = event.openclaw_message_id
            if event.openclaw_source_channel:
                notification["openclaw_source_channel"] = event.openclaw_source_channel
            return notification
        if topic == "task.progress":
            event = TaskProgressPayload.model_validate(payload)
            notification = {
                "notification_id": str(uuid4()),
                "task_id": event.task_id,
                "user_id": event.user_id,
                "session_id": event.session_id,
                "channel": event.channel,
                "message_type": "progress_update",
                "message_content": f"{event.current_step} ({event.progress_percentage:.0f}% complete)",
                "delivery_status": "pending",
                "retry_count": 0,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            if event.telegram_chat_id:
                notification["telegram_chat_id"] = event.telegram_chat_id
            if event.webui_connection_id:
                notification["webui_connection_id"] = event.webui_connection_id
            if event.openclaw_conversation_id:
                notification["openclaw_conversation_id"] = event.openclaw_conversation_id
            if event.openclaw_message_id:
                notification["openclaw_message_id"] = event.openclaw_message_id
            if event.openclaw_source_channel:
                notification["openclaw_source_channel"] = event.openclaw_source_channel
            return notification
        raise ValueError(f"Unsupported topic: {topic}")

    async def _deliver_telegram_with_retry(self, payload: dict) -> int:
        chat_id = payload["telegram_chat_id"]
        message = payload["message_content"]
        last_error: Exception | None = None

        for attempt in range(self.TELEGRAM_MAX_RETRIES):
            try:
                await self.telegram.send_message(chat_id=chat_id, text=message)
                return attempt
            except Exception as exc:
                last_error = exc
                if attempt < self.TELEGRAM_MAX_RETRIES - 1:
                    await self.sleep(self.BACKOFF_SCHEDULE_SECONDS[attempt])

        assert last_error is not None
        raise last_error

    async def _deliver_webui(self, payload: dict) -> None:
        await self.webui.push_notification(
            connection_id=payload["webui_connection_id"],
            notification=payload,
        )

    async def _emit_delivery_failed(self, payload: dict, envelope, failure_reason: str) -> None:
        failed_payload = dict(payload)
        failed_payload["delivery_status"] = "failed"
        failed_payload["retry_count"] = self.TELEGRAM_MAX_RETRIES if payload["channel"] == "telegram" else 0
        failed_payload["created_at"] = datetime.now(timezone.utc).isoformat()

        validated_failed_payload = NotificationOutPayload.model_validate(failed_payload).model_dump(
            mode="json",
            exclude_none=True,
        )
        error = build_error_payload(
            AegisErrorCode.NOTIFICATION_DELIVERY_FAILED,
            failure_reason,
            details={
                "channel": payload["channel"],
                "original_event_id": envelope.event_id,
            },
        )
        await self.producer.produce_envelope(
            topic="notification.out",
            payload=validated_failed_payload,
            source_service="SVC-14",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
            status="error",
            error=error,
        )

        dlq_payload = {
            "dlq_id": str(uuid4()),
            "original_topic": envelope.event_type,
            "original_event_id": envelope.event_id,
            "original_payload": envelope.to_dict(),
            "failure_reason": f"{AegisErrorCode.NOTIFICATION_DELIVERY_FAILED.value}: {failure_reason}",
            "retry_count": self.TELEGRAM_MAX_RETRIES if payload["channel"] == "telegram" else 0,
            "source_service": "SVC-14",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        DLQ_MESSAGES.labels(topic="task.dlq", source_service="SVC-14").inc()
        await self.producer.produce_envelope(
            topic="task.dlq",
            payload=dlq_payload,
            source_service="SVC-14",
            correlation_id=envelope.correlation_id,
            trace_id=envelope.trace_id,
            status="error",
            error=error,
        )


def validate_notification_payload(payload: dict) -> None:
    NotificationOutPayload.model_validate(payload)


def validate_incoming_payload(topic: str, payload: dict) -> None:
    if topic == "result.ready":
        ResultReadyPayload.model_validate(payload)
    elif topic == "hitl.request":
        HITLRequestPayload.model_validate(payload)
    elif topic == "task.progress":
        TaskProgressPayload.model_validate(payload)
    else:
        raise ValidationError.from_exception_data("NotificationInput", [])
