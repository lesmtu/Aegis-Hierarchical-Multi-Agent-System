from __future__ import annotations

import httpx


class WebUIDeliveryClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.http = httpx.AsyncClient(timeout=10.0)

    async def push_notification(self, connection_id: str, notification: dict) -> dict:
        response = await self.http.post(
            f"{self.base_url}/internal/webui/notifications",
            json={
                "connection_id": connection_id,
                "notification": notification,
            },
        )
        response.raise_for_status()
        return response.json()
