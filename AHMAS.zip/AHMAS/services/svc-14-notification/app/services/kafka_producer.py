from __future__ import annotations

from shared.events.envelope import AegisCanonicalEventEnvelope


class NotificationKafkaProducer:
    def __init__(self, producer):
        self.producer = producer
        self.produced: list[AegisCanonicalEventEnvelope] = []

    async def produce_envelope(
        self,
        topic: str,
        payload: dict,
        source_service: str,
        correlation_id: str,
        trace_id: str,
        *,
        status: str = "success",
        error: dict | None = None,
        idempotency_key: str | None = None,
    ) -> AegisCanonicalEventEnvelope:
        envelope = AegisCanonicalEventEnvelope.create(
            event_type=topic,
            source_service=source_service,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status=status,
            error=error,
            idempotency_key=idempotency_key,
        )
        self.produced.append(envelope)
        if hasattr(self.producer, "send"):
            self.producer.send(topic, envelope.to_dict())
        return envelope
