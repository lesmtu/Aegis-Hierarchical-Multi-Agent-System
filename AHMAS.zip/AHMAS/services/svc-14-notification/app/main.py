"""
SVC-14 Notification Service — production entry point with Kafka lifespan.
Subscribes to: result.ready, hitl.request, task.progress   (contracts.json)
Produces to: notification.out
"""
from __future__ import annotations

import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shared.idempotency.client import IdempotencyClient
from shared.kafka_loop import AioKafkaBackend, SimpleConsumerLoop

from .config import settings
from .services.kafka_consumer import NotificationKafkaConsumer
from .services.kafka_producer import NotificationKafkaProducer
from .services.metrics import render_metrics
from .services.notification_service import NotificationService
from .services.telegram_delivery import TelegramDeliveryClient
from .services.webui_delivery import WebUIDeliveryClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_KAFKA_BROKERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
_REDIS_HOST    = os.getenv("REDIS_HOST", "localhost")
_REDIS_PORT    = int(os.getenv("REDIS_PORT", "6379"))
_REDIS_URL     = os.getenv("SVC14_REDIS_URL", f"redis://{_REDIS_HOST}:{_REDIS_PORT}/0")
_GROUP_ID      = "svc-14-notification"
_TOPICS        = ["result.ready", "hitl.request", "task.progress"]


class _InMemoryLuaScript:
    def __init__(self, store):
        self._store = store
    def __call__(self, *, keys, args):
        k = keys[0]
        if k in self._store: return 0
        self._store[k] = args[0]; return 1

class _InMemoryRedis:
    def __init__(self): self.store: dict = {}
    def register_script(self, _): return _InMemoryLuaScript(self.store)
    def get(self, key): return self.store.get(key)
    def set(self, key, value, xx=False, keepttl=False):
        if xx and key not in self.store: return False
        self.store[key] = value; return True
    def delete(self, key): self.store.pop(key, None)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Redis idempotency
    redis_client = None
    try:
        import redis as redis_lib
        redis_client = redis_lib.Redis(host=_REDIS_HOST, port=_REDIS_PORT,
                                       decode_responses=True, socket_connect_timeout=5)
        redis_client.ping()
        logger.info("SVC-14 Redis connected")
    except Exception as exc:
        logger.warning("SVC-14 Redis unavailable (%s) — in-memory fallback", exc)
        redis_client = _InMemoryRedis()

    idempotency = IdempotencyClient(redis_client, "SVC-14")

    # Kafka producer backend
    backend = AioKafkaBackend(_KAFKA_BROKERS)
    await backend.start()

    producer = NotificationKafkaProducer(backend)

    # Delivery backends
    telegram = TelegramDeliveryClient(
        bot_token=settings.telegram_bot_token,
        api_base=settings.telegram_api_base,
    )
    webui = WebUIDeliveryClient(base_url=settings.svc01_websocket_base)

    notification_svc = NotificationService(
        telegram_client=telegram,
        webui_client=webui,
        producer=producer,
    )

    kafka_consumer = NotificationKafkaConsumer(
        idempotency_client=idempotency,
        notification_service=notification_svc,
    )

    loop = SimpleConsumerLoop(
        bootstrap_servers=_KAFKA_BROKERS,
        group_id=_GROUP_ID,
        topics=_TOPICS,
        process_fn=kafka_consumer.process,  # NotificationKafkaConsumer.process(topic, message)
    )
    await loop.start()
    logger.info("SVC-14 fully started — consuming %s", _TOPICS)
    yield
    await loop.stop()
    await backend.stop()
    logger.info("SVC-14 shutdown complete")


app = FastAPI(
    title=settings.service_title,
    version=settings.service_version,
    separate_input_output_schemas=False,
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict:
    return {
        "service_id": settings.service_id,
        "status": "healthy",
        "version": settings.service_version,
        "dependencies": {"kafka": "connected", "redis": "connected",
                         "telegram": "enabled" if settings.telegram_bot_token else "disabled"},
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> str:
    return render_metrics()
