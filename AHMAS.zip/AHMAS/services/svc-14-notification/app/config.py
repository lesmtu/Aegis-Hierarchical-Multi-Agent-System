from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    service_id: str = "SVC-14"
    service_version: str = "1.0.0"
    service_title: str = "Aegis HMAS SVC-14 Notification Service"
    telegram_bot_token: str = os.getenv("SVC14_TELEGRAM_BOT_TOKEN", "")
    telegram_api_base: str = os.getenv("SVC14_TELEGRAM_API_BASE", "https://api.telegram.org")
    svc01_websocket_base: str = os.getenv("SVC14_SVC01_WEBSOCKET_BASE", "http://svc-01-receptionist:8000")
    kafka_bootstrap_servers: str = os.getenv("SVC14_KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    redis_url: str = os.getenv("SVC14_REDIS_URL", "redis://localhost:6379/0")


settings = Settings()
