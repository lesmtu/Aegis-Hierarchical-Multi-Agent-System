from __future__ import annotations

import asyncio
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[3]
SERVICE_ROOT = Path(__file__).resolve().parents[1]
for path in (PROJECT_ROOT, SERVICE_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from shared.events.envelope import AegisCanonicalEventEnvelope

from app.services.kafka_consumer import NotificationKafkaConsumer
from app.services.kafka_producer import NotificationKafkaProducer
from app.services.notification_service import NotificationDeliveryError, NotificationService


class InMemoryProducerBackend:
    def __init__(self):
        self.messages: list[tuple[str, dict]] = []

    def send(self, topic: str, envelope: dict) -> None:
        self.messages.append((topic, envelope))


class FakeIdempotency:
    def __init__(self):
        self.keys: set[tuple[str, str]] = set()
        self.completed: list[tuple[str, str]] = []
        self.failed: list[tuple[str, str]] = []

    def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        pair = (idempotency_key, event_id)
        if pair in self.keys:
            return False
        self.keys.add(pair)
        return True

    def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        self.completed.append((idempotency_key, event_id))

    def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        self.failed.append((idempotency_key, event_id))


class TelegramMock:
    def __init__(self):
        self.call_count = 0
        self.failures_remaining = 0

    def fail_n_times(self, count: int) -> None:
        self.failures_remaining = count

    def always_fail(self) -> None:
        self.failures_remaining = 99

    async def send_message(self, chat_id: str, text: str) -> dict:
        self.call_count += 1
        if self.failures_remaining > 0:
            self.failures_remaining -= 1
            raise RuntimeError("telegram down")
        return {"ok": True, "chat_id": chat_id, "text": text}


class WebUIClientMock:
    def __init__(self):
        self.push_called = False

    async def push_notification(self, connection_id: str, notification: dict) -> dict:
        self.push_called = True
        return {"ok": True, "connection_id": connection_id, "notification_id": notification["notification_id"]}


def build_envelope(topic: str, payload: dict) -> AegisCanonicalEventEnvelope:
    return AegisCanonicalEventEnvelope.create(
        event_type=topic,
        source_service="SVC-13" if topic == "result.ready" else "SVC-04",
        payload=payload,
        correlation_id=payload["task_id"],
        trace_id=str(uuid4()),
        idempotency_key=str(uuid4()),
    )


def telegram_payload() -> dict:
    return {
        "task_id": str(uuid4()),
        "dag_id": str(uuid4()),
        "user_id": "user-1",
        "session_id": str(uuid4()),
        "channel": "telegram",
        "telegram_chat_id": "chat-1",
        "synthesized_output": "Task complete",
        "reflection_score": 0.99,
        "aggregation_metadata": {
            "total_nodes": 1,
            "conflict_resolutions": 0,
            "sources_used": ["mem-1"],
        },
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def run(coro):
    return asyncio.run(coro)


def test_telegram_retry_3_times():
    telegram_mock = TelegramMock()
    telegram_mock.fail_n_times(3)
    producer = NotificationKafkaProducer(InMemoryProducerBackend())
    sleeps: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    svc = NotificationService(telegram_mock, WebUIClientMock(), producer, sleep=fake_sleep)
    envelope = build_envelope("result.ready", telegram_payload())

    with pytest.raises(NotificationDeliveryError):
        run(svc.handle_event("result.ready", envelope))

    assert telegram_mock.call_count == 3
    assert sleeps == [1.0, 2.0]


def test_delivery_failed_emitted_after_exhaustion():
    telegram_mock = TelegramMock()
    telegram_mock.always_fail()
    producer = NotificationKafkaProducer(InMemoryProducerBackend())

    async def fake_sleep(_: float) -> None:
        return None

    svc = NotificationService(telegram_mock, WebUIClientMock(), producer, sleep=fake_sleep)
    envelope = build_envelope("result.ready", telegram_payload())

    with pytest.raises(NotificationDeliveryError):
        run(svc.handle_event("result.ready", envelope))

    events = [event for event in producer.produced if event.event_type == "notification.out"]
    assert any(event.status == "error" for event in events)
    failed = [event for event in events if event.status == "error"][0]
    assert failed.error["error_code"] == "NOTIFICATION_DELIVERY_FAILED"


def test_exponential_backoff():
    telegram_mock = TelegramMock()
    telegram_mock.always_fail()
    producer = NotificationKafkaProducer(InMemoryProducerBackend())
    delays: list[float] = []

    async def fake_sleep(delay: float) -> None:
        delays.append(delay)

    svc = NotificationService(telegram_mock, WebUIClientMock(), producer, sleep=fake_sleep)
    envelope = build_envelope("result.ready", telegram_payload())

    with pytest.raises(NotificationDeliveryError):
        run(svc.handle_event("result.ready", envelope))

    assert delays == [1.0, 2.0]
    assert NotificationService.BACKOFF_SCHEDULE_SECONDS == (1.0, 2.0, 4.0)


def test_webui_delivery_path():
    producer = NotificationKafkaProducer(InMemoryProducerBackend())
    webui_client = WebUIClientMock()
    svc = NotificationService(TelegramMock(), webui_client, producer)
    envelope = build_envelope(
        "result.ready",
        {
            "task_id": str(uuid4()),
            "dag_id": str(uuid4()),
            "user_id": "user-1",
            "session_id": str(uuid4()),
            "channel": "webui",
            "webui_connection_id": "conn-1",
            "synthesized_output": "Rendered for WebUI",
            "reflection_score": 0.95,
            "aggregation_metadata": {
                "total_nodes": 2,
                "conflict_resolutions": 0,
                "sources_used": ["mem-1"],
            },
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
    )

    run(svc.handle_event("result.ready", envelope))
    assert webui_client.push_called is True


def test_openclaw_emits_notification_out_without_direct_delivery():
    producer = NotificationKafkaProducer(InMemoryProducerBackend())
    telegram = TelegramMock()
    webui_client = WebUIClientMock()
    svc = NotificationService(telegram, webui_client, producer)
    envelope = build_envelope(
        "result.ready",
        {
            "task_id": str(uuid4()),
            "dag_id": str(uuid4()),
            "user_id": "user-1",
            "session_id": str(uuid4()),
            "channel": "openclaw",
            "openclaw_conversation_id": "conv-1",
            "openclaw_message_id": "msg-1",
            "openclaw_source_channel": "telegram",
            "synthesized_output": "Rendered for OpenClaw",
            "reflection_score": 0.95,
            "aggregation_metadata": {
                "total_nodes": 2,
                "conflict_resolutions": 0,
                "sources_used": ["mem-1"],
            },
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
    )

    run(svc.handle_event("result.ready", envelope))
    assert telegram.call_count == 0
    assert webui_client.push_called is False
    delivered = [event for event in producer.produced if event.event_type == "notification.out" and event.status == "success"][0]
    assert delivered.payload["openclaw_conversation_id"] == "conv-1"


def test_idempotency_enforced_before_processing():
    telegram_mock = TelegramMock()
    producer = NotificationKafkaProducer(InMemoryProducerBackend())
    idempotency = FakeIdempotency()
    consumer = NotificationKafkaConsumer(
        idempotency_client=idempotency,
        notification_service=NotificationService(telegram_mock, WebUIClientMock(), producer),
    )
    envelope = build_envelope("result.ready", telegram_payload()).to_dict()

    first = run(consumer.process("result.ready", envelope))
    second = run(consumer.process("result.ready", envelope))

    assert first is True
    assert second is False
    assert telegram_mock.call_count == 1
