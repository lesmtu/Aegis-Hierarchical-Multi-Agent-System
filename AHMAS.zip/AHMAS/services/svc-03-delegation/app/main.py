# FILE: services/svc-03-delegation/app/main.py

"""
SVC-03 Delegation Engine — FastAPI application entry point.

API Endpoints (contracts.json SVC-03.api_endpoints):
  GET /health   — HealthCheckResponse
  GET /metrics  — Prometheus text/plain
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.responses import PlainTextResponse
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from app.config import settings
from app.services.capability_resolver import CapabilityResolverService
from app.services.cost_optimizer import CostOptimizerService
from app.services.dag_builder import DAGBuilder
from app.services.idempotency import IdempotencyService
from app.services.kafka_consumer import DelegationKafkaConsumer
from app.services.kafka_producer import KafkaProducerService
from app.services.rule_checker import RuleCheckerService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)

# Module-level service references (set during lifespan startup)
_redis_client: aioredis.Redis | None = None
_producer: KafkaProducerService | None = None
_consumer: DelegationKafkaConsumer | None = None
_consume_task: asyncio.Task | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle: startup then shutdown."""
    global _redis_client, _producer, _consumer, _consume_task

    # ── Startup ───────────────────────────────────────────────────────────────
    logger.info("Starting %s v%s", settings.SERVICE_ID, settings.SERVICE_VERSION)

    # Redis for idempotency (contracts.json global.idempotency_policy)
    _redis_client = aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
    )
    idempotency = IdempotencyService(_redis_client)

    # Kafka producer
    _producer = KafkaProducerService(settings.KAFKA_BOOTSTRAP_SERVERS)
    await _producer.start()

    # Service integrations
    rule_checker = RuleCheckerService(
        base_url=settings.SVC18_BASE_URL,
        timeout=settings.DEFAULT_HTTP_TIMEOUT,
    )
    cost_optimizer = CostOptimizerService(
        base_url=settings.SVC20_BASE_URL,
        timeout=settings.DEFAULT_HTTP_TIMEOUT,
    )
    capability_resolver = CapabilityResolverService(
        svc19_base_url=settings.SVC19_BASE_URL,
        svc21_base_url=settings.SVC21_BASE_URL,
        default_timeout=settings.DEFAULT_HTTP_TIMEOUT,  # 10s for SVC-19
        svc21_timeout=settings.SVC21_TIMEOUT,            # 38s EXCLUSIVE for SVC-21
        similarity_threshold=settings.PROMPT_SIMILARITY_THRESHOLD,
    )

    dag_builder = DAGBuilder(
        rule_checker=rule_checker,
        capability_resolver=capability_resolver,
        cost_optimizer=cost_optimizer,
        producer=_producer,
    )

    _consumer = DelegationKafkaConsumer(
        dag_builder=dag_builder,
        idempotency=idempotency,
        producer=_producer,
    )
    await _consumer.start()

    # Start consumer loop as background task
    _consume_task = asyncio.create_task(_consumer.consume_loop())
    logger.info("%s startup complete", settings.SERVICE_ID)

    yield  # ── Application running ──────────────────────────────────────────

    # ── Shutdown ──────────────────────────────────────────────────────────────
    logger.info("Shutting down %s", settings.SERVICE_ID)

    if _consume_task:
        _consume_task.cancel()
        try:
            await _consume_task
        except asyncio.CancelledError:
            pass

    if _consumer:
        await _consumer.stop()
    if _producer:
        await _producer.stop()
    if _redis_client:
        await _redis_client.aclose()

    logger.info("%s shutdown complete", settings.SERVICE_ID)


app = FastAPI(
    title="SVC-03 Delegation Engine",
    version=settings.SERVICE_VERSION,
    lifespan=lifespan,
)


@app.get("/health")
async def health_check():
    """
    Health check.
    contracts.json SVC-03.api_endpoints GET /health
    contracts.json HealthCheckResponse required: service_id, status, version, timestamp
    """
    redis_ok = "unknown"
    kafka_ok = "unknown"

    if _redis_client:
        try:
            await _redis_client.ping()
            redis_ok = "healthy"
        except Exception:
            redis_ok = "unhealthy"

    if _producer and _producer._producer:
        kafka_ok = "healthy"

    overall = "healthy"
    if "unhealthy" in (redis_ok, kafka_ok):
        overall = "degraded"

    return {
        "service_id": settings.SERVICE_ID,
        "status": overall,
        "version": settings.SERVICE_VERSION,
        "dependencies": {
            "redis": redis_ok,
            "kafka": kafka_ok,
            "svc18_rule_engine": "unknown",
            "svc19_capability_registry": "unknown",
            "svc20_cost_optimizer": "unknown",
            "svc21_prompt_intelligence": "unknown",
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/metrics")
async def metrics():
    """
    Prometheus metrics.
    contracts.json SVC-03.api_endpoints GET /metrics
    """
    return PlainTextResponse(
        generate_latest(),
        media_type=CONTENT_TYPE_LATEST,
    )