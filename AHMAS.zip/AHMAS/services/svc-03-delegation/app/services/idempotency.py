# FILE: services/svc-03-delegation/app/services/idempotency.py

"""
Redis-based idempotency enforcement for SVC-03.

contracts.json global.idempotency_policy:
- Key schema: idempotency:SVC-03:{idempotency_key}
- TTL: 86400 seconds (24 hours)
- Atomic Lua script for check-and-set
- Stale lock detection: > 10 minutes → overwrite
- Fail-open: if Redis unavailable → proceed with processing
"""
import json
import logging
from datetime import datetime, timezone

import redis.asyncio as aioredis

logger = logging.getLogger(__name__)

# contracts.json global.idempotency_policy.lua_script
_IDEMPOTENCY_LUA = """
local existing = redis.call('GET', KEYS[1])
if existing then
    return 0
else
    redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2])
    return 1
end
"""

_STALE_THRESHOLD_SECONDS = 600  # 10 minutes — contracts.json step_6_on_status_processing_stale


class IdempotencyService:
    """
    Redis idempotency for SVC-03.
    Implements contracts.json global.idempotency_policy.processing_protocol.
    """

    SERVICE_ID = "SVC-03"
    TTL = 86400  # 24 hours

    def __init__(self, redis_client: aioredis.Redis):
        self._redis = redis_client
        self._script = None

    async def _lua(self):
        if self._script is None:
            self._script = self._redis.register_script(_IDEMPOTENCY_LUA)
        return self._script

    def _key(self, idempotency_key: str) -> str:
        return f"idempotency:{self.SERVICE_ID}:{idempotency_key}"

    def _value(self, event_id: str, status: str) -> str:
        return json.dumps({
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": status,
        })

    async def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        """
        Atomic check-and-set.

        Returns True  → new message, proceed with processing.
        Returns False → duplicate, skip (already processed or processing).

        contracts.json processing_protocol steps 1-3 (atomic Lua).
        """
        key = self._key(idempotency_key)
        value = self._value(event_id, "processing")

        try:
            script = await self._lua()
            result = await script(keys=[key], args=[value, str(self.TTL)])

            if result == 1:
                return True  # Key was set — proceed

            # Key exists — check status and stale lock
            raw = await self._redis.get(key)
            if raw:
                data = json.loads(raw)
                status = data.get("status", "")

                if status == "processing":
                    # Check for stale lock (> 10 min)
                    try:
                        processed_at = datetime.fromisoformat(data["processed_at"])
                        age = (datetime.now(timezone.utc) - processed_at).total_seconds()
                        if age > _STALE_THRESHOLD_SECONDS:
                            logger.warning(
                                "Stale idempotency lock detected. Overwriting. "
                                "idempotency_key=%s age_seconds=%.0f",
                                idempotency_key, age,
                            )
                            new_val = self._value(event_id, "processing")
                            await self._redis.set(key, new_val, ex=self.TTL)
                            return True
                    except (KeyError, ValueError):
                        pass

                logger.info(
                    "Duplicate message skipped. idempotency_key=%s status=%s",
                    idempotency_key, status,
                )
            return False

        except Exception as exc:
            # Fail-open: Redis unavailable → process the message
            logger.warning(
                "Redis idempotency unavailable (fail-open). error=%s", exc
            )
            return True

    async def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        """Step 4: update status to 'completed'."""
        key = self._key(idempotency_key)
        try:
            await self._redis.set(key, self._value(event_id, "completed"), xx=True, keepttl=True)
        except Exception as exc:
            logger.warning("Failed to mark idempotency completed: %s", exc)

    async def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        """Step 5: update status to 'failed'."""
        key = self._key(idempotency_key)
        try:
            await self._redis.set(key, self._value(event_id, "failed"), xx=True, keepttl=True)
        except Exception as exc:
            logger.warning("Failed to mark idempotency failed: %s", exc)