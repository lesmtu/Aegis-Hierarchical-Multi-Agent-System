# FILE: services/svc-03-delegation/app/services/rule_checker.py

"""
SVC-18 Rule Engine integration.

contracts.json SVC-03.behavior.rule_engine_call:
    POST /rules/evaluate per sub-task

Timeout: 10s (DEFAULT_HTTP_TIMEOUT — contracts.json SVC-21 timeout_contract).
Fail-open: if SVC-18 unavailable → permissive defaults (audit=True, blocked=False).
"""
import logging
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class RuleCheckerService:
    """Integrates with SVC-18 Rule Engine."""

    def __init__(self, base_url: str, timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def evaluate(
        self,
        sub_task: dict,
        task_id: Optional[str] = None,
    ) -> dict:
        """
        POST /rules/evaluate for a sub-task.

        contracts.json RuleEvaluateRequest required fields:
            sub_task_id, required_capability, complexity, cost_tier, description

        Returns RuleEvaluateResponse.
        On SVC-18 failure: returns permissive defaults (fail-open).
        """
        request_body = {
            "sub_task_id": sub_task["sub_task_id"],
            "task_id": task_id,
            "required_capability": sub_task["required_capability"],
            "complexity": sub_task["complexity"],
            "cost_tier": sub_task["cost_tier"],
            "description": sub_task["description"],
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/rules/evaluate",
                    json=request_body,
                )
                resp.raise_for_status()
                return resp.json()

        except httpx.TimeoutException:
            logger.warning(
                "SVC-18 timeout for sub_task_id=%s. Using permissive defaults.",
                sub_task["sub_task_id"],
            )
        except httpx.HTTPStatusError as exc:
            logger.error(
                "SVC-18 HTTP %s for sub_task_id=%s. Using permissive defaults.",
                exc.response.status_code, sub_task["sub_task_id"],
            )
        except Exception as exc:
            logger.error(
                "SVC-18 unavailable for sub_task_id=%s: %s. Using permissive defaults.",
                sub_task["sub_task_id"], exc,
            )

        # Permissive fail-open defaults
        return {
            "sub_task_id": sub_task["sub_task_id"],
            "triggered_rules": [],
            "requires_audit": True,    # Conservative: always audit
            "requires_hitl": False,
            "requires_anonymize": False,
            "requires_sandbox": False,
            "is_blocked": False,
            "evaluated_at": datetime.now(timezone.utc).isoformat(),
        }