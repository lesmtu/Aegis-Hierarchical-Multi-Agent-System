# FILE: services/svc-03-delegation/app/services/capability_resolver.py

"""
SVC-19 Capability Registry + SVC-21 Prompt Intelligence integration.

contracts.json SVC-03.behavior:
    capability_registry_call: GET /capabilities/{type} per sub-task
    prompt_intelligence_call: POST /prompt/search BEFORE emitting capability.missing
    prompt_similarity_threshold: 0.75

SVC-21 timeout: 38s EXCLUSIVELY for POST /prompt/search.
All other calls (SVC-19): 10s DEFAULT.

Fallback (contracts.json SVC-03 Addendum B):
    HTTP 503 from SVC-21  → treat as found_in='none'
    Timeout after 38s     → treat as found_in='none'
    HTTP 400 from SVC-21  → raise SVC21InvalidRequestError (route to task.dlq)
    Network unreachable   → treat as found_in='none'

Prometheus metric:
    aegis_delegation_svc21_fallback_total{reason} — SVC-03 Addendum B
"""
import logging
from typing import Optional

import httpx
from prometheus_client import Counter

logger = logging.getLogger(__name__)

# contracts.json SVC-03 Addendum B
svc21_fallback_total = Counter(
    "aegis_delegation_svc21_fallback_total",
    "Total SVC-21 POST /prompt/search fallbacks by reason",
    ["reason"],
)

# contracts.json AGENT_TRUST_SCORE_TOO_LOW
MIN_TRUST_SCORE = 0.3

# contracts.json CapabilityMissingPayload.suggested_tool_type enum mapping
CAPABILITY_TO_TOOL_TYPE: dict[str, str] = {
    "research":    "rest_api_wrapper",
    "logic":       "python_function",
    "media":       "python_function",
    "code":        "python_function",
    "tool_builder": "composite_tool",
    "validation":  "python_function",
}

_NOT_FOUND_RESPONSE = {
    "prompt_templates": [],
    "best_match_score": 0.0,
    "found_in": "none",
}


class SVC21InvalidRequestError(Exception):
    """
    SVC-21 returned HTTP 400 — indicates a malformed request from SVC-03.
    contracts.json SVC-03 Addendum B: route task to task.dlq with INVALID_PAYLOAD.
    """


class CapabilityResolverService:
    """
    Resolves capabilities via SVC-19 and SVC-21.

    SVC-21 POST /prompt/search MUST be called BEFORE any capability.missing decision.
    SVC-21 timeout: 38s EXCLUSIVE (contracts.json SVC-21 timeout_contract).
    SVC-19 timeout: 10s default.
    """

    def __init__(
        self,
        svc19_base_url: str,
        svc21_base_url: str,
        default_timeout: float,
        svc21_timeout: float,
        similarity_threshold: float,
    ):
        self.svc19_base_url = svc19_base_url.rstrip("/")
        self.svc21_base_url = svc21_base_url.rstrip("/")
        self.default_timeout = default_timeout    # 10s for SVC-19
        self.svc21_timeout = svc21_timeout        # 38s EXCLUSIVELY for /prompt/search
        self.similarity_threshold = similarity_threshold

    async def get_agent(self, capability_type: str) -> Optional[dict]:
        """
        GET /capabilities/{type} from SVC-19.

        Filters:
            health_status == "healthy"
            trust_score >= MIN_TRUST_SCORE (0.3)

        Returns agent with highest trust_score, or None if none available.
        contracts.json AGENT_TRUST_SCORE_TOO_LOW: bypass agents below threshold.
        """
        try:
            async with httpx.AsyncClient(timeout=self.default_timeout) as client:
                resp = await client.get(
                    f"{self.svc19_base_url}/capabilities/{capability_type}"
                )
                if resp.status_code == 404:
                    logger.info(
                        "SVC-19: no agents registered for capability_type=%s",
                        capability_type,
                    )
                    return None
                resp.raise_for_status()
                data = resp.json()
                agents = data.get("agents", [])

        except httpx.TimeoutException:
            logger.warning(
                "SVC-19 timeout for capability_type=%s", capability_type
            )
            return None
        except httpx.HTTPStatusError as exc:
            logger.error(
                "SVC-19 HTTP %s for capability_type=%s",
                exc.response.status_code, capability_type,
            )
            return None
        except Exception as exc:
            logger.error(
                "SVC-19 unavailable for capability_type=%s: %s",
                capability_type, exc,
            )
            return None

        # Filter: healthy + trust_score >= threshold
        valid = [
            a for a in agents
            if a.get("health_status") == "healthy"
            and float(a.get("trust_score", 0.0)) >= MIN_TRUST_SCORE
        ]
        if not valid:
            logger.info(
                "SVC-19: no valid agents for capability_type=%s "
                "(unhealthy or trust_score < %.1f)",
                capability_type, MIN_TRUST_SCORE,
            )
            return None

        best = max(valid, key=lambda a: float(a.get("trust_score", 0.0)))
        logger.debug(
            "SVC-19: selected agent_id=%s trust_score=%.2f for capability_type=%s",
            best["agent_id"], best.get("trust_score", 0.0), capability_type,
        )
        return best

    async def search_prompt_template(self, sub_task: dict) -> dict:
        """
        POST /prompt/search on SVC-21.

        MANDATORY: Must be called BEFORE any capability.missing emission.
        Timeout: 38s EXCLUSIVELY (contracts.json SVC-21 timeout_contract).
        Threshold: 0.75 (contracts.json prompt_similarity_threshold).

        Fallback policy (contracts.json SVC-03 Addendum B):
            HTTP 503 → return found_in='none'
            Timeout  → return found_in='none'
            HTTP 400 → raise SVC21InvalidRequestError
            Other    → return found_in='none'
        """
        request_body = {
            "query": sub_task["description"],
            "required_capability": sub_task["required_capability"],
            "top_k": 3,
            "similarity_threshold": self.similarity_threshold,
            "prefer_verified": True,
        }

        try:
            async with httpx.AsyncClient(timeout=self.svc21_timeout) as client:
                resp = await client.post(
                    f"{self.svc21_base_url}/prompt/search",
                    json=request_body,
                )
                resp.raise_for_status()
                return resp.json()

        except httpx.TimeoutException:
            logger.warning(
                "SVC-21 timeout (%.0fs) for sub_task_id=%s. Treating as found_in='none'.",
                self.svc21_timeout, sub_task["sub_task_id"],
            )
            svc21_fallback_total.labels(reason="timeout").inc()
            return dict(_NOT_FOUND_RESPONSE)

        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code
            if status_code == 400:
                # SVC-03 Addendum B: HTTP 400 → route task to task.dlq
                logger.error(
                    "SVC-21 HTTP 400 for sub_task_id=%s — SVC-03 sent malformed request.",
                    sub_task["sub_task_id"],
                )
                svc21_fallback_total.labels(reason="http_400").inc()
                raise SVC21InvalidRequestError(
                    f"SVC-21 returned HTTP 400 for sub_task_id={sub_task['sub_task_id']}: "
                    f"{exc.response.text[:200]}"
                )
            if status_code == 503:
                logger.warning(
                    "SVC-21 HTTP 503 for sub_task_id=%s. Treating as found_in='none'.",
                    sub_task["sub_task_id"],
                )
                svc21_fallback_total.labels(reason="503").inc()
            else:
                logger.error(
                    "SVC-21 HTTP %s for sub_task_id=%s. Treating as found_in='none'.",
                    status_code, sub_task["sub_task_id"],
                )
                svc21_fallback_total.labels(reason="http_error").inc()
            return dict(_NOT_FOUND_RESPONSE)

        except Exception as exc:
            logger.error(
                "SVC-21 network error for sub_task_id=%s: %s. Treating as found_in='none'.",
                sub_task["sub_task_id"], exc,
            )
            svc21_fallback_total.labels(reason="network_error").inc()
            return dict(_NOT_FOUND_RESPONSE)