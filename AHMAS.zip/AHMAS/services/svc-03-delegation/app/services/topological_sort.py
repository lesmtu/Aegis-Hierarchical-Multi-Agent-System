# FILE: services/svc-03-delegation/app/services/topological_sort.py

"""
Kahn's algorithm topological sort with cycle detection.

IMMUTABLE RULES:
- SVC-03 MUST implement Kahn's algorithm for topological sort with cycle detection.
- SVC-03 cycle detection: if len(sorted) < len(total) → CYCLIC_DEPENDENCY_IN_PLAN
- Time complexity: O(V+E) — satisfies PC-09 (< 5ms for max 50 nodes)

contracts.json:
- SVC-03.behavior.topological_sort: true
- global_error_codes.CYCLIC_DEPENDENCY_IN_PLAN: produced_by SVC-03
"""
from collections import deque
from typing import Callable, List, Optional, Tuple, TypeVar

T = TypeVar("T")


def kahn_topological_sort(
    nodes: List[T],
    get_id: Callable[[T], str],
    get_deps: Callable[[T], List[str]],
) -> Tuple[List[T], bool]:
    """
    Kahn's algorithm for topological sort with cycle detection.

    Args:
        nodes:    List of node objects.
        get_id:   Callable returning the unique ID of a node.
        get_deps: Callable returning the list of dependency IDs for a node.

    Returns:
        (sorted_nodes, has_cycle)
        sorted_nodes: topologically ordered nodes (partial if cycle exists)
        has_cycle:    True iff len(sorted_nodes) < len(nodes)

    contracts.json CYCLIC_DEPENDENCY_IN_PLAN:
        Condition: len(sorted_nodes) < len(total_nodes)
        This is the EXACT check required — no heuristic substitution.
    """
    if not nodes:
        return [], False

    node_ids = {get_id(n) for n in nodes}
    in_degree: dict[str, int] = {get_id(n): 0 for n in nodes}
    adj: dict[str, List[str]] = {get_id(n): [] for n in nodes}
    node_map: dict[str, T] = {get_id(n): n for n in nodes}

    # Build graph: dep_id → [nodes that depend on dep_id]
    for node in nodes:
        for dep_id in get_deps(node):
            if dep_id in node_ids:
                adj[dep_id].append(get_id(node))
                in_degree[get_id(node)] += 1

    # Initialize queue with zero-in-degree nodes
    queue: deque[str] = deque(
        nid for nid, deg in in_degree.items() if deg == 0
    )
    sorted_nodes: List[T] = []

    while queue:
        nid = queue.popleft()
        sorted_nodes.append(node_map[nid])
        for neighbor in adj[nid]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    # IMMUTABLE RULE: if len(sorted) < len(total) → cycle detected
    has_cycle = len(sorted_nodes) < len(nodes)
    return sorted_nodes, has_cycle


def find_cycle_description(
    nodes: List[T],
    get_id: Callable[[T], str],
    get_deps: Callable[[T], List[str]],
) -> str:
    """
    Locate and describe the first cycle found using DFS.
    Used for HITL context message and error logging.

    Returns a human-readable cycle path string.
    """
    visited: set[str] = set()
    rec_stack: set[str] = set()
    path: List[str] = []
    result: List[str] = []
    node_map = {get_id(n): n for n in nodes}
    node_ids = set(node_map.keys())

    def dfs(node_id: str) -> bool:
        visited.add(node_id)
        rec_stack.add(node_id)
        path.append(node_id)

        node = node_map.get(node_id)
        if node is None:
            path.pop()
            rec_stack.discard(node_id)
            return False

        for dep_id in get_deps(node):
            if dep_id not in node_ids:
                continue
            if dep_id not in visited:
                if dfs(dep_id):
                    return True
            elif dep_id in rec_stack:
                # Cycle found — extract cycle segment
                try:
                    start_idx = path.index(dep_id)
                    cycle_path = path[start_idx:] + [dep_id]
                    result.append(" → ".join(cycle_path))
                except ValueError:
                    result.append(f"{node_id} ↔ {dep_id}")
                return True

        path.pop()
        rec_stack.discard(node_id)
        return False

    for node in nodes:
        nid = get_id(node)
        if nid not in visited:
            if dfs(nid):
                break

    return result[0] if result else "circular dependency detected among sub-tasks"