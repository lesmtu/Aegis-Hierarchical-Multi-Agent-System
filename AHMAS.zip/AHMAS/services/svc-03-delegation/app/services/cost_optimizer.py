# FILE: services/svc-03-delegation/app/services/cost_optimizer.py

"""
SVC-20 Cost Optimizer integration.

contracts.json SVC-03.behavior.cost_optimizer_call:
    POST /optimize per sub-task

Timeout: 10s (DEFAULT_HTTP_TIMEOUT).
Fallback: local routing table from contracts.json SVC-20.routing_table.
"""
import logging
from typing import Optional

import httpx

logger = logging.getLogger(__name__)

# contracts.json SVC-20.routing_table
_ROUTING_TABLE: dict[tuple[str, str], str] = {
    ("low", "cheap"):       "lightweight",
    ("low", "medium"):      "lightweight",
    ("low", "expensive"):   "mid_tier",
    ("medium", "cheap"):    "lightweight",
    ("medium", "medium"):   "mid_tier",
    ("medium", "expensive"): "mid_tier",
    ("high", "cheap"):      "mid_tier",
    ("high", "medium"):     "mid_tier",
    ("high", "expensive"):  "heavy_reasoning",
}


class CostOptimizerService:
    """Integrates with SVC-20 Cost Optimizer."""

    def __init__(self, base_url: str, timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def optimize(self, sub_task: dict) -> dict:
        """
        POST /optimize for a sub-task.

        contracts.json CostOptimizeRequest required fields:
            sub_task_id, complexity, cost_tier, required_capability

        Returns CostOptimizeResponse.
        On failure: local routing table.
        """
        request_body = {
            "sub_task_id": sub_task["sub_task_id"],
            "complexity": sub_task["complexity"],
            "cost_tier": sub_task["cost_tier"],
            "required_capability": sub_task["required_capability"],
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/optimize",
                    json=request_body,
                )
                resp.raise_for_status()
                return resp.json()
        except Exception as exc:
            logger.warning(
                "SVC-20 unavailable for sub_task_id=%s: %s. Using local routing table.",
                sub_task["sub_task_id"], exc,
            )

        # Fallback: local routing table
        key = (
            sub_task.get("complexity", "medium"),
            sub_task.get("cost_tier", "medium"),
        )
        model_tier = _ROUTING_TABLE.get(key, "mid_tier")

        return {
            "sub_task_id": sub_task["sub_task_id"],
            "recommended_model_tier": model_tier,
            "estimated_cost_usd": 0.0,
            "reasoning": "Local routing table (SVC-20 unavailable)",
        }