# FILE: services/svc-03-delegation/app/services/dag_builder.py

"""
SVC-03 Delegation Engine — DAG Builder.

IMMUTABLE RULES implemented here:
  1. Kahn's algorithm topological sort with cycle detection (topological_sort.py).
  2. len(sorted) < len(total) → CYCLIC_DEPENDENCY_IN_PLAN.
  3. SVC-21 POST /prompt/search (38s) BEFORE emitting capability.missing.
  4. DLQ routing: wrap in DLQPayload schema (contracts.json).

contracts.json SVC-03.behavior:
  topological_sort: true
  max_parallel_batch_size: 10  (DC-04)
  max_dag_nodes: 50             (DC-03)
  rule_engine_call: POST /rules/evaluate per sub-task
  capability_registry_call: GET /capabilities/{type} per sub-task
  cost_optimizer_call: POST /optimize per sub-task
  prompt_intelligence_call: POST /prompt/search BEFORE capability.missing
  prompt_similarity_threshold: 0.75
  dag_retry_on_tool_created: true
  dag_retry_on_agent_created: true
"""
import logging
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional, Tuple

from app.config import settings
from app.services.capability_resolver import (
    CAPABILITY_TO_TOOL_TYPE,
    CapabilityResolverService,
    SVC21InvalidRequestError,
)
from app.services.cost_optimizer import CostOptimizerService
from app.services.kafka_producer import KafkaProducerService
from app.services.rule_checker import RuleCheckerService
from app.services.topological_sort import find_cycle_description, kahn_topological_sort

logger = logging.getLogger(__name__)


class BuildStatus(Enum):
    """
    Result classification for a DAG build attempt.
    Used by the consumer to decide next action.
    """
    SUCCESS = "success"                   # DAG ready → emit dag.created
    PENDING_CAPABILITY = "pending"        # Awaiting tool/agent creation
    TERMINAL_FAILURE = "terminal"         # Events already emitted; no further action


class DAGBuilder:
    """
    Builds Execution DAG from Plan.

    Per sub-task processing order (mandatory):
        1. SVC-18 rule evaluation
        2. SVC-20 cost optimization
        3. SVC-21 prompt search  ← BEFORE capability.missing
        4. SVC-19 agent resolution

    If agent not found after step 3 → capability.missing emitted.
    If cycle detected → hitl.request + replan.required (or task.dlq if attempt >= 2).
    """

    def __init__(
        self,
        rule_checker: RuleCheckerService,
        capability_resolver: CapabilityResolverService,
        cost_optimizer: CostOptimizerService,
        producer: KafkaProducerService,
    ):
        self.rules = rule_checker
        self.capabilities = capability_resolver
        self.cost = cost_optimizer
        self.producer = producer

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    async def build_dag(
        self,
        plan: dict,
        correlation_id: str,
        trace_id: str,
        replan_attempt: int,
        original_event: Optional[dict] = None,
    ) -> Tuple[Optional[dict], BuildStatus]:
        """
        Build Execution DAG from Plan.

        Returns:
            (dag_object, BuildStatus.SUCCESS)         → emit dag.created
            (None,       BuildStatus.PENDING_CAPABILITY) → store, await capability
            (None,       BuildStatus.TERMINAL_FAILURE)   → events emitted, no action
        """
        task_id = plan["task_id"]
        sub_tasks = plan.get("sub_tasks", [])

        # ── Guard: max_dag_nodes (DC-03) ──────────────────────────────────────
        if len(sub_tasks) > settings.MAX_DAG_NODES:
            logger.error(
                "Plan %s exceeds max_dag_nodes: %d > %d",
                plan["plan_id"], len(sub_tasks), settings.MAX_DAG_NODES,
            )
            await self._emit_task_dlq(
                plan=plan, correlation_id=correlation_id, trace_id=trace_id,
                failure_reason=(
                    f"Plan exceeds max_dag_nodes: {len(sub_tasks)} > {settings.MAX_DAG_NODES}"
                ),
                error_code="INVALID_PAYLOAD",
                retry_count=0,
                original_event=original_event,
            )
            return None, BuildStatus.TERMINAL_FAILURE

        # ── Step 1: Kahn's topological sort + cycle detection ─────────────────
        sorted_tasks, has_cycle = kahn_topological_sort(
            nodes=sub_tasks,
            get_id=lambda t: t["sub_task_id"],
            get_deps=lambda t: t.get("dependencies", []),
        )

        if has_cycle:
            cycle_desc = find_cycle_description(
                nodes=sub_tasks,
                get_id=lambda t: t["sub_task_id"],
                get_deps=lambda t: t.get("dependencies", []),
            )
            logger.error(
                "CYCLIC_DEPENDENCY_IN_PLAN in plan=%s: %s",
                plan["plan_id"], cycle_desc,
            )
            await self._handle_cycle_detected(
                plan=plan,
                correlation_id=correlation_id,
                trace_id=trace_id,
                cycle_desc=cycle_desc,
                replan_attempt=replan_attempt,
                original_event=original_event,
            )
            return None, BuildStatus.TERMINAL_FAILURE

        # Pre-generate dag_id (needed in capability.missing payload before DAG exists)
        dag_id = str(uuid.uuid4())

        # ── Step 2: Per-sub-task processing ──────────────────────────────────
        # Pairs of (sub_task, dag_node) for dependency resolution
        task_node_pairs: List[Tuple[dict, dict]] = []
        # sub_task_id → dag_node for dependency resolution
        sub_task_id_to_node: Dict[str, dict] = {}
        # Sub-tasks with no available agent
        pending_capabilities: List[dict] = []

        for sub_task in sorted_tasks:
            # 2a. SVC-18: Rule Engine evaluation (per sub-task)
            rule_result = await self.rules.evaluate(
                sub_task=sub_task, task_id=task_id
            )

            if rule_result.get("is_blocked", False):
                triggered = [
                    r.get("rule_name", "unknown")
                    for r in rule_result.get("triggered_rules", [])
                ]
                logger.warning(
                    "Sub-task %s blocked by Rule Engine. rules=%s",
                    sub_task["sub_task_id"], triggered,
                )
                await self._emit_task_dlq(
                    plan=plan, correlation_id=correlation_id, trace_id=trace_id,
                    failure_reason=(
                        f"Sub-task {sub_task['sub_task_id']} blocked by rules: {triggered}"
                    ),
                    error_code="RULE_BLOCKED",
                    retry_count=0,
                    original_event=original_event,
                )
                return None, BuildStatus.TERMINAL_FAILURE

            # 2b. SVC-20: Cost optimization (per sub-task)
            cost_result = await self.cost.optimize(sub_task=sub_task)
            model_tier = cost_result.get("recommended_model_tier", "mid_tier")

            # 2c. SVC-21: Prompt search — MANDATORY BEFORE capability.missing
            # contracts.json: prompt_intelligence_call BEFORE emitting capability.missing
            try:
                prompt_result = await self.capabilities.search_prompt_template(
                    sub_task=sub_task
                )
            except SVC21InvalidRequestError as exc:
                # HTTP 400 from SVC-21 → route to task.dlq
                logger.error(
                    "SVC-21 HTTP 400 for sub_task_id=%s. Routing to task.dlq.",
                    sub_task["sub_task_id"],
                )
                await self._emit_task_dlq(
                    plan=plan, correlation_id=correlation_id, trace_id=trace_id,
                    failure_reason=str(exc),
                    error_code="INVALID_PAYLOAD",
                    retry_count=0,
                    original_event=original_event,
                )
                return None, BuildStatus.TERMINAL_FAILURE

            # 2d. SVC-19: Capability resolution (per sub-task)
            agent = await self.capabilities.get_agent(
                capability_type=sub_task["required_capability"]
            )

            if agent is None:
                # No capable agent — will emit capability.missing after loop
                pending_capabilities.append({
                    "sub_task": sub_task,
                    "dag_id": dag_id,
                    "prompt_result": prompt_result,
                })
                continue

            # 2e. Build DAGNode — contracts.json DAGNode ALL required fields
            node_id = str(uuid.uuid4())
            dag_node: dict = {
                "node_id": node_id,
                "sub_task_id": sub_task["sub_task_id"],
                "priority": plan["priority"],
                "agent_type": sub_task["required_capability"],
                "agent_id": agent["agent_id"],
                "model_tier": model_tier,
                "dependencies": [],       # Resolved in step 3
                "parallel_group": None,   # Assigned in step 4
                "requires_audit": rule_result.get("requires_audit", True),
                "requires_hitl": rule_result.get("requires_hitl", False),
                "retry_policy": {
                    "max_retries": 3,          # PC-07 default
                    "backoff_strategy": "exponential",
                },
            }
            task_node_pairs.append((sub_task, dag_node))
            sub_task_id_to_node[sub_task["sub_task_id"]] = dag_node

        # ── Step 3: Handle pending capabilities ───────────────────────────────
        if pending_capabilities:
            for pending in pending_capabilities:
                await self._emit_capability_missing(
                    sub_task=pending["sub_task"],
                    plan=plan,
                    dag_id=pending["dag_id"],
                    correlation_id=correlation_id,
                    trace_id=trace_id,
                )
            logger.info(
                "DAG construction paused: %d capabilities missing. task_id=%s",
                len(pending_capabilities), task_id,
            )
            return None, BuildStatus.PENDING_CAPABILITY

        # ── Step 4: Resolve sub_task_id deps → node_id deps ──────────────────
        dag_nodes: List[dict] = []
        for sub_task, dag_node in task_node_pairs:
            resolved: List[str] = []
            for dep_sub_task_id in sub_task.get("dependencies", []):
                dep_node = sub_task_id_to_node.get(dep_sub_task_id)
                if dep_node:
                    resolved.append(dep_node["node_id"])
                else:
                    logger.warning(
                        "Dependency sub_task_id=%s not found in node map for sub_task_id=%s",
                        dep_sub_task_id, sub_task["sub_task_id"],
                    )
            dag_node["dependencies"] = resolved
            dag_nodes.append(dag_node)

        # ── Step 5: Assign parallel groups (DC-04: max 10 per group) ─────────
        dag_nodes = self._assign_parallel_groups(dag_nodes)

        # ── Step 6: Build edges from node dependencies ────────────────────────
        edges = self._build_edges(dag_nodes)

        # ── Step 7: Assemble final DAG — contracts.json DAG ALL 7 required fields
        dag = {
            "dag_id": dag_id,
            "plan_id": plan["plan_id"],
            "task_id": task_id,
            "nodes": dag_nodes,
            "edges": edges,
            "version": "1.0.0",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        logger.info(
            "DAG built. dag_id=%s task_id=%s nodes=%d edges=%d",
            dag_id, task_id, len(dag_nodes), len(edges),
        )
        return dag, BuildStatus.SUCCESS

    # ─────────────────────────────────────────────────────────────────────────
    # Private helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _assign_parallel_groups(self, dag_nodes: List[dict]) -> List[dict]:
        """
        Assign parallel_group integers to nodes.

        Algorithm:
          1. Compute depth via iterative BFS.
          2. Nodes at same depth → parallel (if > 1 at that depth).
          3. Batch by MAX_PARALLEL_BATCH_SIZE (DC-04: max 10).
          4. Single node at depth → parallel_group = null.

        contracts.json DAGNode.parallel_group:
          non-null integer → nodes MAY execute concurrently.
          null → no parallel grouping.
        """
        if not dag_nodes:
            return dag_nodes

        # Iterative depth computation (safe for acyclic graphs)
        depth: Dict[str, int] = {}

        for node in dag_nodes:
            if not node["dependencies"]:
                depth[node["node_id"]] = 0

        changed = True
        while changed:
            changed = False
            for node in dag_nodes:
                nid = node["node_id"]
                if nid in depth:
                    continue
                deps = node["dependencies"]
                if deps and all(d in depth for d in deps):
                    depth[nid] = max(depth[d] for d in deps) + 1
                    changed = True

        # Group nodes by depth
        depth_groups: Dict[int, List[str]] = defaultdict(list)
        for node in dag_nodes:
            d = depth.get(node["node_id"], 0)
            depth_groups[d].append(node["node_id"])

        # Assign group IDs
        group_counter = 0
        node_to_group: Dict[str, Optional[int]] = {}

        for d in sorted(depth_groups.keys()):
            nodes_at_depth = depth_groups[d]
            if len(nodes_at_depth) <= 1:
                node_to_group[nodes_at_depth[0]] = None  # No parallelism
            else:
                # Batch into groups of max MAX_PARALLEL_BATCH_SIZE
                for i in range(0, len(nodes_at_depth), settings.MAX_PARALLEL_BATCH_SIZE):
                    batch = nodes_at_depth[i: i + settings.MAX_PARALLEL_BATCH_SIZE]
                    for nid in batch:
                        node_to_group[nid] = group_counter
                    group_counter += 1

        for node in dag_nodes:
            node["parallel_group"] = node_to_group.get(node["node_id"])

        return dag_nodes

    def _build_edges(self, dag_nodes: List[dict]) -> List[dict]:
        """
        Build DAGEdge list from resolved node dependencies.

        contracts.json DAGEdge:
          from: source node_id (must complete first)
          to:   destination node_id (unblocked when source completes)
        """
        edges = []
        for node in dag_nodes:
            for dep_id in node.get("dependencies", []):
                edges.append({"from": dep_id, "to": node["node_id"]})
        return edges

    async def _handle_cycle_detected(
        self,
        plan: dict,
        correlation_id: str,
        trace_id: str,
        cycle_desc: str,
        replan_attempt: int,
        original_event: Optional[dict] = None,
    ) -> None:
        """
        Handle CYCLIC_DEPENDENCY_IN_PLAN.

        contracts.json SVC-03 Addendum A + SVC-03 output_schema:

        ALWAYS emit hitl.request (trigger_reason='planner_failure').

        If replan_attempt >= 2:
            emit task.dlq (CYCLIC_DEPENDENCY_IN_PLAN)  ← instead of replan.required
        Else:
            emit replan.required (replan_source='delegation_engine')

        ReplanRequiredPayload for delegation_engine (contracts.json):
            dag_id:              null  (DAG not created)
            failed_node_id:      null  (no nodes dispatched)
            completed_node_ids:  []    (no nodes completed)
            replan_source:       "delegation_engine"
        """
        task_id = plan["task_id"]

        # ── Always emit hitl.request ──────────────────────────────────────────
        # contracts.json HITLRequestPayload ALL required fields
        hitl_id = str(uuid.uuid4())
        hitl_payload = {
            "hitl_id": hitl_id,
            "task_id": task_id,
            "node_id": None,           # null — no node dispatched
            "user_id": "system",       # SVC-03 has no user context in Plan
            "session_id": str(uuid.uuid4()),
            "trigger_reason": "planner_failure",
            "risk_classification": "high",
            "context": (
                f"Cyclic dependency detected in plan {plan['plan_id']}. "
                f"Cycle: {cycle_desc}. "
                f"Current replan_attempt={replan_attempt} (max=2). "
                "Replanning required."
            ),
            "current_output": None,
            "confidence_score": None,
            "available_actions": ["approve", "reject"],
            "timeout_hours": 2,  # high risk → SVC-15 overrides to 120 min
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        await self.producer.produce(
            topic="hitl.request",
            payload=hitl_payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            message_key=hitl_id,  # contracts.json hitl.request.message_key_field: hitl_id
        )
        logger.info(
            "Emitted hitl.request for CYCLIC_DEPENDENCY_IN_PLAN. "
            "task_id=%s hitl_id=%s replan_attempt=%d",
            task_id, hitl_id, replan_attempt,
        )

        # ── Check replan limit (PC-08: max 2) ─────────────────────────────────
        if replan_attempt >= 2:
            logger.error(
                "Replan limit exceeded (replan_attempt=%d). Routing task_id=%s to task.dlq.",
                replan_attempt, task_id,
            )
            await self._emit_task_dlq(
                plan=plan,
                correlation_id=correlation_id,
                trace_id=trace_id,
                failure_reason=(
                    f"CYCLIC_DEPENDENCY_IN_PLAN after {replan_attempt} replan attempts: "
                    f"{cycle_desc}"
                ),
                error_code="CYCLIC_DEPENDENCY_IN_PLAN",
                retry_count=replan_attempt,
                original_event=original_event,
            )
            return

        # ── Emit replan.required ──────────────────────────────────────────────
        # contracts.json ReplanRequiredPayload required fields
        replan_payload = {
            "task_id": task_id,
            "dag_id": None,             # NULL — DAG not created (cycle in plan)
            "failed_node_id": None,     # NULL — no nodes dispatched
            "failure_context": f"CYCLIC_DEPENDENCY_IN_PLAN: {cycle_desc}",
            "replan_attempt": replan_attempt + 1,  # min=1, max=2 per contracts.json
            "original_plan_id": plan["plan_id"],
            "completed_node_ids": [],   # Empty — no nodes completed
            "replan_source": "delegation_engine",  # contracts.json enum
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        await self.producer.produce(
            topic="replan.required",
            payload=replan_payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            message_key=task_id,  # contracts.json replan.required.message_key_field: task_id
        )
        logger.info(
            "Emitted replan.required. task_id=%s replan_attempt=%d replan_source=delegation_engine",
            task_id, replan_attempt + 1,
        )

    async def _emit_capability_missing(
        self,
        sub_task: dict,
        plan: dict,
        dag_id: str,
        correlation_id: str,
        trace_id: str,
    ) -> None:
        """
        Emit capability.missing to Kafka.

        Pre-condition (MANDATORY): SVC-21 POST /prompt/search already called
        and returned found_in='none' (or SVC-21 was unavailable).

        contracts.json CapabilityMissingPayload ALL required fields:
            capability_request_id, task_id, dag_id, required_capability,
            description, sub_task_id, suggested_tool_type, created_at
        """
        capability_type = sub_task["required_capability"]
        capability_request_id = str(uuid.uuid4())

        payload = {
            "capability_request_id": capability_request_id,
            "task_id": plan["task_id"],
            "dag_id": dag_id,
            "required_capability": capability_type,
            "description": sub_task["description"],
            "sub_task_id": sub_task["sub_task_id"],
            "suggested_tool_type": CAPABILITY_TO_TOOL_TYPE.get(capability_type, "python_function"),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        await self.producer.produce(
            topic="capability.missing",
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            message_key=capability_request_id,  # contracts.json message_key_field
        )
        logger.info(
            "Emitted capability.missing. task_id=%s required_capability=%s sub_task_id=%s",
            plan["task_id"], capability_type, sub_task["sub_task_id"],
        )

    async def _emit_task_dlq(
        self,
        plan: dict,
        correlation_id: str,
        trace_id: str,
        failure_reason: str,
        error_code: str,
        retry_count: int,
        original_event: Optional[dict] = None,
    ) -> None:
        """
        Emit to task.dlq.

        IMMUTABLE RULE: DLQ routing: wrap in DLQPayload schema from contracts.json.

        contracts.json DLQPayload ALL required fields:
            dlq_id, original_topic, original_event_id, original_payload,
            failure_reason, retry_count, source_service, created_at
        """
        dlq_id = str(uuid.uuid4())
        original_event_id = (
            original_event.get("event_id", str(uuid.uuid4()))
            if original_event
            else str(uuid.uuid4())
        )

        dlq_payload = {
            "dlq_id": dlq_id,
            "original_topic": "plan.created",
            "original_event_id": original_event_id,
            "original_payload": original_event if original_event else {"plan": plan},
            "failure_reason": f"{error_code}: {failure_reason}",
            "retry_count": retry_count,
            "source_service": "SVC-03",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # contracts.json ErrorSchema — error_type and retryable per error code
        _meta: dict[str, tuple[str, bool]] = {
            "CYCLIC_DEPENDENCY_IN_PLAN": ("validation", True),
            "INVALID_PAYLOAD":           ("validation", False),
            "RULE_BLOCKED":              ("validation", False),
            "REPLAN_LIMIT_EXCEEDED":     ("agent",      False),
        }
        error_type, retryable = _meta.get(error_code, ("system", False))

        await self.producer.produce(
            topic="task.dlq",
            payload=dlq_payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            message_key=original_event_id,  # contracts.json task.dlq.message_key_field
            status="error",
            error={
                "error_code": error_code,
                "error_type": error_type,
                "retryable": retryable,
                "message": failure_reason,
            },
        )
        logger.error(
            "Emitted to task.dlq. dlq_id=%s task_id=%s error_code=%s",
            dlq_id, plan["task_id"], error_code,
        )