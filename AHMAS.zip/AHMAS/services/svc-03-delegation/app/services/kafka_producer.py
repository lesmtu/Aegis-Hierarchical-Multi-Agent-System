# FILE: services/svc-03-delegation/app/services/kafka_producer.py

"""
Kafka producer for SVC-03 Delegation Engine.

Produces to:
  dag.created, capability.missing, hitl.request, replan.required, task.dlq

All messages use AegisCanonicalEventEnvelope (contracts.json global.event_schema).
Required envelope fields: event_id, event_type, schema_version, payload_version,
timestamp, source_service, correlation_id, trace_id, idempotency_key, status,
payload, error (null on success).
"""
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

from aiokafka import AIOKafkaProducer

logger = logging.getLogger(__name__)


def build_envelope(
    event_type: str,
    payload: dict,
    correlation_id: str,
    trace_id: str,
    status: str = "success",
    error: Optional[dict] = None,
) -> dict:
    """
    Build AegisCanonicalEventEnvelope.
    contracts.json global.event_schema — ALL required fields.

    correlation_id MUST equal originating task_id.
    MUST NOT be modified by any intermediate service (C-05).
    """
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": "SVC-03",          # pattern: ^SVC-[0-9]{2}$
        "correlation_id": correlation_id,     # MUST equal task_id — never modified
        "trace_id": trace_id,
        "idempotency_key": str(uuid.uuid4()),  # unique per produced message
        "status": status,                      # "success" | "error"
        "payload": payload,
        "error": error if status == "error" else None,  # null when success
    }


class KafkaProducerService:
    """Kafka producer wrapping canonical envelope construction."""

    def __init__(self, bootstrap_servers: str):
        self.bootstrap_servers = bootstrap_servers
        self._producer: Optional[AIOKafkaProducer] = None

    async def start(self) -> None:
        self._producer = AIOKafkaProducer(
            bootstrap_servers=self.bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks="all",
            enable_idempotence=True,
        )
        await self._producer.start()
        logger.info("KafkaProducerService started")

    async def stop(self) -> None:
        if self._producer:
            await self._producer.stop()
            logger.info("KafkaProducerService stopped")

    async def produce(
        self,
        topic: str,
        payload: dict,
        correlation_id: str,
        trace_id: str,
        message_key: Optional[str] = None,
        status: str = "success",
        error: Optional[dict] = None,
    ) -> None:
        """Produce message to Kafka topic with canonical envelope."""
        if self._producer is None:
            raise RuntimeError("KafkaProducerService not started")

        envelope = build_envelope(
            event_type=topic,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status=status,
            error=error,
        )
        await self._producer.send_and_wait(
            topic=topic,
            value=envelope,
            key=message_key,
        )
        logger.info(
            "Produced event topic=%s event_id=%s correlation_id=%s",
            topic, envelope["event_id"], correlation_id,
        )