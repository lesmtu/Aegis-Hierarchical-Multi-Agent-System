# FILE: services/svc-03-delegation/app/services/kafka_consumer.py

"""
Kafka consumer for SVC-03 Delegation Engine.

Consumes: plan.created, tool.created, agent.created

contracts.json SVC-03.consumes_topics: ["plan.created", "tool.created", "agent.created"]
contracts.json SVC-03.behavior.dag_retry_on_tool_created: true
contracts.json SVC-03.behavior.dag_retry_on_agent_created: true

Idempotency: implemented on ALL consumed topics
  (contracts.json global.idempotency_policy.services_required_to_implement includes SVC-03)

Pending DAG state:
  _pending_dags: task_id → (plan, correlation_id, trace_id, replan_attempt, original_event)
  Stored when build_dag returns PENDING_CAPABILITY.
  Retried on tool.created / agent.created events.
"""
import asyncio
import json
import logging
from typing import Dict, List, Optional, Tuple

try:
    from aiokafka import AIOKafkaConsumer
except ImportError:  # pragma: no cover - import-safe fallback for test runtime
    class AIOKafkaConsumer:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            self._messages = []

        async def start(self) -> None:
            return None

        async def stop(self) -> None:
            return None

        async def commit(self) -> None:
            return None

        def __aiter__(self):
            return self

        async def __anext__(self):
            raise StopAsyncIteration

from app.config import settings
from app.services.dag_builder import BuildStatus, DAGBuilder
from app.services.idempotency import IdempotencyService
from app.services.kafka_producer import KafkaProducerService

logger = logging.getLogger(__name__)

TOPICS = ["plan.created", "tool.created", "agent.created"]


class DelegationKafkaConsumer:
    """
    Kafka consumer for SVC-03.

    plan.created   → build_dag() → emit dag.created OR store pending
    tool.created   → retry all pending DAG builds
    agent.created  → retry all pending DAG builds
    """

    def __init__(
        self,
        dag_builder: DAGBuilder,
        idempotency: IdempotencyService,
        producer: KafkaProducerService,
    ):
        self.builder = dag_builder
        self.idempotency = idempotency
        self.producer = producer

        # In-memory pending state:
        # task_id → (plan, correlation_id, trace_id, replan_attempt, original_event)
        self._pending_dags: Dict[
            str,
            Tuple[dict, str, str, int, Optional[dict]],
        ] = {}

        self._consumer: Optional[AIOKafkaConsumer] = None
        self._running = False

    async def start(self) -> None:
        self._consumer = AIOKafkaConsumer(
            *TOPICS,
            bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
            group_id=settings.KAFKA_CONSUMER_GROUP,
            auto_offset_reset=settings.KAFKA_AUTO_OFFSET_RESET,
            enable_auto_commit=False,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        )
        await self._consumer.start()
        self._running = True
        logger.info(
            "DelegationKafkaConsumer started. topics=%s group=%s",
            TOPICS, settings.KAFKA_CONSUMER_GROUP,
        )

    async def stop(self) -> None:
        self._running = False
        if self._consumer:
            await self._consumer.stop()
            logger.info("DelegationKafkaConsumer stopped")

    async def consume_loop(self) -> None:
        """Main consumption loop. Processes one message at a time."""
        if self._consumer is None:
            raise RuntimeError("Consumer not started")

        async for msg in self._consumer:
            if not self._running:
                break
            try:
                envelope = msg.value
                topic = msg.topic

                if topic == "plan.created":
                    await self._handle_plan_created(envelope)
                elif topic == "tool.created":
                    await self._handle_tool_created(envelope)
                elif topic == "agent.created":
                    await self._handle_agent_created(envelope)
                else:
                    logger.warning("Unexpected topic: %s", topic)

                # Manual offset commit after successful processing
                await self._consumer.commit()

            except Exception as exc:
                logger.error(
                    "Error processing message from topic=%s: %s",
                    msg.topic, exc, exc_info=True,
                )
                # Commit to avoid infinite retry on poison pill
                # (idempotency + DLQ handle legitimate failures)
                try:
                    await self._consumer.commit()
                except Exception:
                    pass

    # ─────────────────────────────────────────────────────────────────────────
    # Topic handlers
    # ─────────────────────────────────────────────────────────────────────────

    async def _handle_plan_created(self, envelope: dict) -> None:
        """
        Process plan.created event.

        1. Idempotency check (contracts.json global.idempotency_policy)
        2. Extract plan, build DAG
        3. SUCCESS         → emit dag.created
        4. PENDING         → store in _pending_dags
        5. TERMINAL        → no action (events already emitted)
        """
        idempotency_key = envelope.get("idempotency_key", "")
        event_id = envelope.get("event_id", "")

        if not await self.idempotency.check_and_set(idempotency_key, event_id):
            logger.info(
                "Skipping duplicate plan.created. idempotency_key=%s", idempotency_key
            )
            return

        try:
            plan = envelope.get("payload", {})
            correlation_id = envelope.get("correlation_id", plan.get("task_id", ""))
            trace_id = envelope.get("trace_id", "")
            replan_attempt = plan.get("replan_attempt", 0)
            task_id = plan.get("task_id", "")

            dag, status = await self.builder.build_dag(
                plan=plan,
                correlation_id=correlation_id,
                trace_id=trace_id,
                replan_attempt=replan_attempt,
                original_event=envelope,
            )

            if status == BuildStatus.SUCCESS and dag is not None:
                # Emit dag.created — contracts.json dag.created.message_key_field: task_id
                await self.producer.produce(
                    topic="dag.created",
                    payload=dag,
                    correlation_id=correlation_id,
                    trace_id=trace_id,
                    message_key=dag["task_id"],
                )
                logger.info(
                    "Emitted dag.created. dag_id=%s task_id=%s",
                    dag["dag_id"], task_id,
                )
                self._pending_dags.pop(task_id, None)

            elif status == BuildStatus.PENDING_CAPABILITY:
                # Store pending state for retry on tool.created / agent.created
                self._pending_dags[task_id] = (
                    plan, correlation_id, trace_id, replan_attempt, envelope
                )
                logger.info(
                    "DAG construction pending for task_id=%s. "
                    "Awaiting capability creation. pending_count=%d",
                    task_id, len(self._pending_dags),
                )

            # TERMINAL_FAILURE: events already emitted by DAGBuilder

            await self.idempotency.mark_completed(idempotency_key, event_id)

        except Exception as exc:
            logger.error("Error in _handle_plan_created: %s", exc, exc_info=True)
            await self.idempotency.mark_failed(idempotency_key, event_id)
            raise

    async def _handle_tool_created(self, envelope: dict) -> None:
        """
        Process tool.created event.
        contracts.json SVC-03.behavior.dag_retry_on_tool_created: true
        """
        idempotency_key = envelope.get("idempotency_key", "")
        event_id = envelope.get("event_id", "")

        if not await self.idempotency.check_and_set(idempotency_key, event_id):
            return

        try:
            logger.info(
                "tool.created received. Retrying %d pending DAG(s).",
                len(self._pending_dags),
            )
            await self._retry_pending_dags()
            await self.idempotency.mark_completed(idempotency_key, event_id)

        except Exception as exc:
            logger.error("Error in _handle_tool_created: %s", exc, exc_info=True)
            await self.idempotency.mark_failed(idempotency_key, event_id)
            raise

    async def _handle_agent_created(self, envelope: dict) -> None:
        """
        Process agent.created event.
        contracts.json SVC-03.behavior.dag_retry_on_agent_created: true
        """
        idempotency_key = envelope.get("idempotency_key", "")
        event_id = envelope.get("event_id", "")

        if not await self.idempotency.check_and_set(idempotency_key, event_id):
            return

        try:
            logger.info(
                "agent.created received. Retrying %d pending DAG(s).",
                len(self._pending_dags),
            )
            await self._retry_pending_dags()
            await self.idempotency.mark_completed(idempotency_key, event_id)

        except Exception as exc:
            logger.error("Error in _handle_agent_created: %s", exc, exc_info=True)
            await self.idempotency.mark_failed(idempotency_key, event_id)
            raise

    async def _retry_pending_dags(self) -> None:
        """
        Retry all pending DAG constructions after new capability available.
        Removes task from pending if SUCCESS or TERMINAL.
        Keeps in pending if still PENDING_CAPABILITY.
        """
        completed: List[str] = []

        for task_id, (
            plan, correlation_id, trace_id, replan_attempt, original_event
        ) in list(self._pending_dags.items()):
            logger.info("Retrying DAG construction for task_id=%s", task_id)

            try:
                dag, status = await self.builder.build_dag(
                    plan=plan,
                    correlation_id=correlation_id,
                    trace_id=trace_id,
                    replan_attempt=replan_attempt,
                    original_event=original_event,
                )

                if status == BuildStatus.SUCCESS and dag is not None:
                    await self.producer.produce(
                        topic="dag.created",
                        payload=dag,
                        correlation_id=correlation_id,
                        trace_id=trace_id,
                        message_key=dag["task_id"],
                    )
                    logger.info(
                        "DAG retry succeeded. task_id=%s dag_id=%s",
                        task_id, dag["dag_id"],
                    )
                    completed.append(task_id)

                elif status == BuildStatus.TERMINAL_FAILURE:
                    completed.append(task_id)  # Remove from pending

                # PENDING_CAPABILITY → keep in _pending_dags for next retry

            except Exception as exc:
                logger.error(
                    "Error retrying DAG for task_id=%s: %s", task_id, exc, exc_info=True
                )

        for task_id in completed:
            self._pending_dags.pop(task_id, None)
