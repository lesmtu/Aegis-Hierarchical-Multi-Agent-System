# FILE: services/svc-03-delegation/app/config.py

"""
SVC-03 Delegation Engine — Configuration.
contracts.json SVC-03.behavior constraints.
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    SERVICE_ID: str = "SVC-03"
    SERVICE_VERSION: str = "1.0.0"
    SCHEMA_VERSION: str = "1.0.0"

    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"
    KAFKA_CONSUMER_GROUP: str = "svc-03-delegation-engine"
    KAFKA_AUTO_OFFSET_RESET: str = "earliest"

    # Redis (idempotency — contracts.json global.idempotency_policy)
    REDIS_URL: str = "redis://localhost:6379"
    IDEMPOTENCY_TTL: int = 86400  # 24 hours

    # Downstream service URLs
    SVC18_BASE_URL: str = "http://svc-18:8080"
    SVC19_BASE_URL: str = "http://svc-19:8080"
    SVC20_BASE_URL: str = "http://svc-20:8080"
    SVC21_BASE_URL: str = "http://svc-21:8080"

    # HTTP timeouts
    # contracts.json SVC-21 timeout_contract:
    # "38 seconds EXCLUSIVELY for POST /prompt/search.
    #  All other SVC-03 REST calls retain the system default 10-second timeout."
    DEFAULT_HTTP_TIMEOUT: float = 10.0
    SVC21_TIMEOUT: float = 38.0  # EXCLUSIVE — do NOT use for any other endpoint

    # DAG constraints (contracts.json DC-03, DC-04)
    MAX_DAG_NODES: int = 50           # DC-03
    MAX_PARALLEL_BATCH_SIZE: int = 10  # DC-04

    # SVC-21 similarity threshold (contracts.json SVC-03.behavior)
    PROMPT_SIMILARITY_THRESHOLD: float = 0.75

    # Agent trust score minimum (contracts.json AGENT_TRUST_SCORE_TOO_LOW)
    MIN_AGENT_TRUST_SCORE: float = 0.3

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()