# FILE: services/svc-03-delegation/tests/test_dag_builder.py

"""
Tests for DAGBuilder.
VALIDATION section from STEP-6.2.txt.
"""
import uuid
from datetime import datetime, timezone
from typing import List, Optional
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from app.services.dag_builder import BuildStatus, DAGBuilder
from app.services.capability_resolver import CapabilityResolverService


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _uuid() -> str:
    return str(uuid.uuid4())


def _plan(sub_tasks: list, replan_attempt: int = 0) -> dict:
    return {
        "plan_id": _uuid(),
        "task_id": _uuid(),
        "goal": "Test goal",
        "priority": "normal",
        "sub_tasks": sub_tasks,
        "reflection_score": 0.9,
        "version": "1.0.0",
        "replan_attempt": replan_attempt,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def _sub_task(
    sid: Optional[str] = None,
    deps: Optional[list] = None,
    cap: str = "logic",
) -> dict:
    return {
        "sub_task_id": sid or _uuid(),
        "name": "Test task",
        "description": "Do something useful for testing purposes",
        "required_capability": cap,
        "complexity": "low",
        "cost_tier": "cheap",
        "dependencies": deps or [],
        "estimated_tokens": 100,
    }


def _agent(cap: str = "logic") -> dict:
    return {
        "agent_id": f"agent-{cap}-001",
        "agent_type": cap,
        "capability_type": cap,
        "model_tier": "mid_tier",
        "llm_config": {"model_tier": "mid_tier", "max_tokens": 4096, "temperature": 0.7},
        "tool_ids": [],
        "health_status": "healthy",
        "trust_score": 0.9,
        "version": "1.0.0",
        "registered_at": datetime.now(timezone.utc).isoformat(),
    }


def _rule_ok(sub_task_id: str) -> dict:
    return {
        "sub_task_id": sub_task_id,
        "triggered_rules": [],
        "requires_audit": True,
        "requires_hitl": False,
        "requires_anonymize": False,
        "requires_sandbox": False,
        "is_blocked": False,
        "evaluated_at": datetime.now(timezone.utc).isoformat(),
    }


def _cost_ok(sub_task_id: str) -> dict:
    return {
        "sub_task_id": sub_task_id,
        "recommended_model_tier": "mid_tier",
        "estimated_cost_usd": 0.01,
        "reasoning": "test",
    }


def _prompt_not_found() -> dict:
    return {"prompt_templates": [], "best_match_score": 0.0, "found_in": "none"}


def _prompt_found() -> dict:
    return {
        "prompt_templates": [{"prompt_id": _uuid()}],
        "best_match_score": 0.85,
        "found_in": "local_vault",
    }


class MockProducer:
    """Records all produced messages."""

    def __init__(self):
        self.produced: List[dict] = []

    async def produce(self, topic, payload, correlation_id, trace_id,
                      message_key=None, status="success", error=None):
        self.produced.append({
            "topic": topic,
            "payload": payload,
            "correlation_id": correlation_id,
            "status": status,
            "error": error,
        })

    def topics(self) -> List[str]:
        return [m["topic"] for m in self.produced]

    def by_topic(self, topic: str) -> List[dict]:
        return [m for m in self.produced if m["topic"] == topic]


def _builder(producer, rules, cap_resolver, cost_opt):
    return DAGBuilder(
        rule_checker=rules,
        capability_resolver=cap_resolver,
        cost_optimizer=cost_opt,
        producer=producer,
    )


# ─── Tests ───────────────────────────────────────────────────────────────────

class TestCycleDetection:
    """
    VALIDATION: test_cycle_emits_hitl_and_replan
                test_cycle_emits_task_dlq_at_replan_attempt_2
    """

    @pytest.mark.asyncio
    async def test_cycle_at_attempt_0_emits_hitl_and_replan(self):
        """
        VALIDATION: test_cycle_emits_hitl_and_replan
        A↔B cycle, replan_attempt=0 → hitl.request + replan.required (NOT task.dlq)
        """
        st_a = _sub_task("A", deps=["B"])
        st_b = _sub_task("B", deps=["A"])
        plan = _plan([st_a, st_b], replan_attempt=0)

        prod = MockProducer()
        rules = AsyncMock()
        cap = AsyncMock()
        cost = AsyncMock()

        builder = _builder(prod, rules, cap, cost)
        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            replan_attempt=0,
        )

        assert dag is None
        assert status == BuildStatus.TERMINAL_FAILURE
        assert "hitl.request" in prod.topics()
        assert "replan.required" in prod.topics()
        assert "task.dlq" not in prod.topics()

    @pytest.mark.asyncio
    async def test_cycle_at_attempt_1_emits_hitl_and_replan_attempt_2(self):
        """replan_attempt=1 → replan.required with replan_attempt=2."""
        st_a = _sub_task("A", deps=["B"])
        st_b = _sub_task("B", deps=["A"])
        plan = _plan([st_a, st_b], replan_attempt=1)

        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            replan_attempt=1,
        )

        assert dag is None
        assert status == BuildStatus.TERMINAL_FAILURE
        assert "hitl.request" in prod.topics()
        assert "replan.required" in prod.topics()
        assert "task.dlq" not in prod.topics()

        replan_events = prod.by_topic("replan.required")
        assert len(replan_events) == 1
        assert replan_events[0]["payload"]["replan_attempt"] == 2

    @pytest.mark.asyncio
    async def test_cycle_at_attempt_2_emits_task_dlq_not_replan(self):
        """
        VALIDATION: test_cycle_emits_task_dlq_at_replan_attempt_2
        replan_attempt=2 → hitl.request + task.dlq (NO replan.required)
        """
        st_a = _sub_task("A", deps=["B"])
        st_b = _sub_task("B", deps=["A"])
        plan = _plan([st_a, st_b], replan_attempt=2)

        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            replan_attempt=2,
        )

        assert dag is None
        assert status == BuildStatus.TERMINAL_FAILURE
        assert "hitl.request" in prod.topics(), "hitl.request always emitted"
        assert "task.dlq" in prod.topics(), "task.dlq at replan_attempt=2"
        assert "replan.required" not in prod.topics(), "NO replan.required at attempt 2"


class TestReplanRequiredPayload:
    """
    VALIDATION: test_replan_required_has_correct_fields_for_delegation_engine
    """

    @pytest.mark.asyncio
    async def test_delegation_engine_fields(self):
        """
        contracts.json ReplanRequiredPayload for delegation_engine:
          dag_id: null
          failed_node_id: null
          completed_node_ids: []
          replan_source: "delegation_engine"
        """
        plan = _plan([_sub_task("A", ["B"]), _sub_task("B", ["A"])], replan_attempt=0)
        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        await builder._handle_cycle_detected(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            cycle_desc="A → B → A",
            replan_attempt=0,
        )

        replan_msgs = prod.by_topic("replan.required")
        assert len(replan_msgs) == 1
        payload = replan_msgs[0]["payload"]

        assert payload["dag_id"] is None, "dag_id MUST be null for delegation_engine"
        assert payload["failed_node_id"] is None, "failed_node_id MUST be null"
        assert payload["replan_source"] == "delegation_engine"
        assert payload["completed_node_ids"] == []
        assert payload["replan_attempt"] == 1
        assert payload["task_id"] == plan["task_id"]
        assert payload["original_plan_id"] == plan["plan_id"]
        assert "CYCLIC_DEPENDENCY_IN_PLAN" in payload["failure_context"]
        assert "created_at" in payload


class TestSVC21CalledBeforeCapabilityMissing:
    """
    VALIDATION: test_svc21_called_before_capability_missing
    """

    @pytest.mark.asyncio
    async def test_svc21_called_before_capability_missing(self):
        """
        SVC-21 POST /prompt/search MUST be called BEFORE capability.missing.
        contracts.json: prompt_intelligence_call BEFORE emitting capability.missing
        """
        sub_task = _sub_task("T1")
        plan = _plan([sub_task])
        call_order: List[str] = []

        rules = AsyncMock()
        rules.evaluate.return_value = _rule_ok(sub_task["sub_task_id"])

        cost = AsyncMock()
        cost.optimize.return_value = _cost_ok(sub_task["sub_task_id"])

        cap = AsyncMock()

        async def track_svc21(*args, **kwargs):
            call_order.append("svc21")
            return _prompt_not_found()

        async def track_svc19(*args, **kwargs):
            call_order.append("svc19")
            return None  # No agent → capability.missing

        cap.search_prompt_template.side_effect = track_svc21
        cap.get_agent.side_effect = track_svc19

        prod = MockProducer()
        builder = _builder(prod, rules, cap, cost)

        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            replan_attempt=0,
        )

        assert status == BuildStatus.PENDING_CAPABILITY
        assert "capability.missing" in prod.topics()

        # CRITICAL: SVC-21 must appear before SVC-19 in call order
        assert "svc21" in call_order
        assert "svc19" in call_order
        assert call_order.index("svc21") < call_order.index("svc19"), \
            "SVC-21 MUST be called BEFORE SVC-19 capability resolution"


class TestSVC21Timeout:
    """
    VALIDATION: test_svc21_timeout_38s_treats_as_not_found
    """

    @pytest.mark.asyncio
    async def test_svc21_timeout_returns_not_found(self):
        """
        contracts.json SVC-03 Addendum B: 38s timeout → found_in='none'
        """
        sub_task = _sub_task("T1")
        resolver = CapabilityResolverService(
            svc19_base_url="http://fake-svc19",
            svc21_base_url="http://fake-svc21",
            default_timeout=10.0,
            svc21_timeout=38.0,
            similarity_threshold=0.75,
        )

        with patch("httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__.return_value.post.side_effect = (
                httpx.TimeoutException("connection timeout")
            )
            result = await resolver.search_prompt_template(sub_task)

        assert result["found_in"] == "none"
        assert result["prompt_templates"] == []
        assert result["best_match_score"] == 0.0

    @pytest.mark.asyncio
    async def test_svc21_503_returns_not_found(self):
        """SVC-21 HTTP 503 → treat as found_in='none' (SVC-03 Addendum B)."""
        sub_task = _sub_task("T1")
        resolver = CapabilityResolverService(
            svc19_base_url="http://fake",
            svc21_base_url="http://fake",
            default_timeout=10.0,
            svc21_timeout=38.0,
            similarity_threshold=0.75,
        )

        mock_resp = AsyncMock()
        mock_resp.status_code = 503
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "503", request=None, response=mock_resp
        )

        with patch("httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__.return_value.post.return_value = mock_resp
            mock_client.return_value.__aenter__.return_value.post.side_effect = (
                httpx.HTTPStatusError("503", request=None, response=mock_resp)
            )
            result = await resolver.search_prompt_template(sub_task)

        assert result["found_in"] == "none"


class TestDAGRequiredFields:
    """
    VALIDATION: test_dag_all_required_fields
    """

    @pytest.mark.asyncio
    async def test_dag_has_all_7_required_fields(self):
        """
        contracts.json DAG required: dag_id, plan_id, task_id, nodes, edges,
                                     version, created_at
        """
        sub_task = _sub_task("T1")
        plan = _plan([sub_task])

        rules = AsyncMock()
        rules.evaluate.return_value = _rule_ok(sub_task["sub_task_id"])
        cost = AsyncMock()
        cost.optimize.return_value = _cost_ok(sub_task["sub_task_id"])
        cap = AsyncMock()
        cap.search_prompt_template.return_value = _prompt_found()
        cap.get_agent.return_value = _agent("logic")

        prod = MockProducer()
        builder = _builder(prod, rules, cap, cost)

        dag, status = await builder.build_dag(
            plan=plan,
            correlation_id=plan["task_id"],
            trace_id=_uuid(),
            replan_attempt=0,
        )

        assert status == BuildStatus.SUCCESS
        assert dag is not None

        # VALIDATION: ALL 7 required fields
        for field in ["dag_id", "plan_id", "task_id", "nodes", "edges", "version", "created_at"]:
            assert field in dag, f"Missing required DAG field: {field}"

        assert isinstance(dag["nodes"], list)
        assert isinstance(dag["edges"], list)
        assert len(dag["nodes"]) == 1
        assert dag["plan_id"] == plan["plan_id"]
        assert dag["task_id"] == plan["task_id"]

    @pytest.mark.asyncio
    async def test_dag_node_has_all_required_fields(self):
        """contracts.json DAGNode required fields."""
        sub_task = _sub_task("T1")
        plan = _plan([sub_task])

        rules = AsyncMock()
        rules.evaluate.return_value = _rule_ok(sub_task["sub_task_id"])
        cost = AsyncMock()
        cost.optimize.return_value = _cost_ok(sub_task["sub_task_id"])
        cap = AsyncMock()
        cap.search_prompt_template.return_value = _prompt_found()
        cap.get_agent.return_value = _agent("logic")

        prod = MockProducer()
        builder = _builder(prod, rules, cap, cost)
        dag, _ = await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=0,
        )

        node = dag["nodes"][0]
        required = [
            "node_id", "sub_task_id", "priority", "agent_type",
            "agent_id", "model_tier", "dependencies", "requires_audit",
            "requires_hitl", "retry_policy",
        ]
        for field in required:
            assert field in node, f"Missing required DAGNode field: {field}"

        assert node["agent_type"] == "logic"
        assert node["priority"] == "normal"
        assert isinstance(node["dependencies"], list)
        assert isinstance(node["requires_audit"], bool)
        assert isinstance(node["requires_hitl"], bool)


class TestDLQPayloadSchema:
    """IMMUTABLE RULE: DLQ routing: wrap in DLQPayload schema from contracts.json."""

    @pytest.mark.asyncio
    async def test_task_dlq_uses_dlq_payload_schema(self):
        """
        task.dlq events MUST use DLQPayload schema.
        contracts.json DLQPayload required fields verified.
        """
        plan = _plan([_sub_task("A", ["B"]), _sub_task("B", ["A"])], replan_attempt=2)
        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=2,
        )

        dlq_msgs = prod.by_topic("task.dlq")
        assert len(dlq_msgs) == 1
        payload = dlq_msgs[0]["payload"]

        # contracts.json DLQPayload ALL required fields
        for field in [
            "dlq_id", "original_topic", "original_event_id",
            "original_payload", "failure_reason", "retry_count",
            "source_service", "created_at",
        ]:
            assert field in payload, f"Missing DLQPayload field: {field}"

        assert payload["source_service"] == "SVC-03"
        assert payload["original_topic"] == "plan.created"
        assert isinstance(payload["retry_count"], int)

    @pytest.mark.asyncio
    async def test_task_dlq_error_envelope_field(self):
        """task.dlq envelope must have status='error' and error field populated."""
        plan = _plan([_sub_task("A", ["B"]), _sub_task("B", ["A"])], replan_attempt=2)
        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=2,
        )

        dlq_msgs = prod.by_topic("task.dlq")
        assert dlq_msgs[0]["status"] == "error"
        assert dlq_msgs[0]["error"] is not None
        assert dlq_msgs[0]["error"]["error_code"] == "CYCLIC_DEPENDENCY_IN_PLAN"


class TestMaxDAGNodes:
    """contracts.json DC-03: max_dag_nodes = 50."""

    @pytest.mark.asyncio
    async def test_exceeding_max_nodes_routes_to_dlq(self):
        """51 nodes → task.dlq with INVALID_PAYLOAD."""
        sub_tasks = [_sub_task() for _ in range(51)]
        plan = _plan(sub_tasks)

        prod = MockProducer()
        builder = _builder(prod, AsyncMock(), AsyncMock(), AsyncMock())

        dag, status = await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=0,
        )

        assert dag is None
        assert status == BuildStatus.TERMINAL_FAILURE
        assert "task.dlq" in prod.topics()


class TestParallelGroupAssignment:
    """contracts.json DC-04: max_parallel_batch_size = 10."""

    @pytest.mark.asyncio
    async def test_parallel_nodes_get_same_group(self):
        """Two independent nodes → same parallel_group."""
        st1 = _sub_task("T1")
        st2 = _sub_task("T2")
        plan = _plan([st1, st2])

        rules = AsyncMock()
        rules.evaluate.side_effect = lambda sub_task, **kw: _rule_ok(sub_task["sub_task_id"])
        cost = AsyncMock()
        cost.optimize.side_effect = lambda sub_task: _cost_ok(sub_task["sub_task_id"])
        cap = AsyncMock()
        cap.search_prompt_template.return_value = _prompt_found()
        cap.get_agent.return_value = _agent("logic")

        prod = MockProducer()
        builder = _builder(prod, rules, cap, cost)

        dag, status = await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=0,
        )

        assert status == BuildStatus.SUCCESS
        groups = [n["parallel_group"] for n in dag["nodes"]]
        assert all(g is not None for g in groups)
        assert groups[0] == groups[1]  # Same parallel group

    @pytest.mark.asyncio
    async def test_sequential_nodes_get_null_groups(self):
        """T1 → T2 (sequential): both get parallel_group=None (single at each depth)."""
        st1 = _sub_task("T1")
        st2 = _sub_task("T2", deps=["T1"])
        plan = _plan([st1, st2])

        rules = AsyncMock()
        rules.evaluate.side_effect = lambda sub_task, **kw: _rule_ok(sub_task["sub_task_id"])
        cost = AsyncMock()
        cost.optimize.side_effect = lambda sub_task: _cost_ok(sub_task["sub_task_id"])
        cap = AsyncMock()
        cap.search_prompt_template.return_value = _prompt_found()
        cap.get_agent.return_value = _agent("logic")

        prod = MockProducer()
        builder = _builder(prod, rules, cap, cost)

        dag, status = await builder.build_dag(
            plan=plan, correlation_id=plan["task_id"],
            trace_id=_uuid(), replan_attempt=0,
        )

        assert status == BuildStatus.SUCCESS
        groups = {n["sub_task_id"]: n["parallel_group"] for n in dag["nodes"]}
        assert groups["T1"] is None
        assert groups["T2"] is None