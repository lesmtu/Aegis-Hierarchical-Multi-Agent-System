# FILE: services/svc-03-delegation/tests/test_topological_sort.py

"""
Tests for Kahn's topological sort.
VALIDATION section from STEP-6.2.txt: test_cycle_detection_kahn
"""
import pytest
from app.services.topological_sort import find_cycle_description, kahn_topological_sort


def _tasks(deps: dict) -> list:
    """Build minimal SubTask list from {id: [dep_ids]} mapping."""
    return [
        {
            "sub_task_id": k,
            "dependencies": v,
            "name": k,
            "description": f"Task {k}",
            "required_capability": "logic",
            "complexity": "low",
            "cost_tier": "cheap",
            "estimated_tokens": 100,
        }
        for k, v in deps.items()
    ]


_get_id = lambda t: t["sub_task_id"]
_get_deps = lambda t: t.get("dependencies", [])


class TestKahnTopologicalSort:

    def test_linear_chain_no_cycle(self):
        """A → B → C: sorted length = 3, no cycle."""
        tasks = _tasks({"A": [], "B": ["A"], "C": ["B"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is False
        assert len(sorted_tasks) == 3
        ids = [t["sub_task_id"] for t in sorted_tasks]
        assert ids.index("A") < ids.index("B") < ids.index("C")

    def test_direct_two_node_cycle(self):
        """
        VALIDATION: test_cycle_detection_kahn
        A depends on B, B depends on A → cycle.
        contracts.json: len(sorted) < len(total) → has_cycle=True
        """
        tasks = _tasks({"A": ["B"], "B": ["A"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is True
        assert len(sorted_tasks) < len(tasks)

    def test_three_node_cycle(self):
        """A→B→C→A: all three in cycle."""
        tasks = _tasks({"A": ["C"], "B": ["A"], "C": ["B"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is True
        assert len(sorted_tasks) < len(tasks)

    def test_self_dependency_cycle(self):
        """A depends on itself."""
        tasks = _tasks({"A": ["A"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is True
        assert len(sorted_tasks) == 0

    def test_parallel_tasks(self):
        """A, B parallel; C depends on both."""
        tasks = _tasks({"A": [], "B": [], "C": ["A", "B"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is False
        assert len(sorted_tasks) == 3
        ids = [t["sub_task_id"] for t in sorted_tasks]
        assert ids.index("A") < ids.index("C")
        assert ids.index("B") < ids.index("C")

    def test_diamond_pattern(self):
        """A→B, A→C, B→D, C→D."""
        tasks = _tasks({"A": [], "B": ["A"], "C": ["A"], "D": ["B", "C"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is False
        assert len(sorted_tasks) == 4
        ids = [t["sub_task_id"] for t in sorted_tasks]
        assert ids.index("A") < ids.index("B")
        assert ids.index("A") < ids.index("C")
        assert ids.index("B") < ids.index("D")
        assert ids.index("C") < ids.index("D")

    def test_empty_nodes(self):
        """Empty input returns empty, no cycle."""
        sorted_tasks, has_cycle = kahn_topological_sort([], _get_id, _get_deps)
        assert has_cycle is False
        assert sorted_tasks == []

    def test_single_node_no_deps(self):
        tasks = _tasks({"A": []})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is False
        assert len(sorted_tasks) == 1

    def test_max_50_nodes_chain(self):
        """DC-03: max 50 nodes. Chain of 50 should complete without cycle."""
        deps = {f"T{i:02d}": ([f"T{i-1:02d}"] if i > 0 else []) for i in range(50)}
        tasks = _tasks(deps)
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is False
        assert len(sorted_tasks) == 50

    def test_partial_cycle_in_subgraph(self):
        """B↔C cycle; A and D are clean."""
        tasks = _tasks({"A": [], "B": ["A", "C"], "C": ["B"], "D": ["A"]})
        sorted_tasks, has_cycle = kahn_topological_sort(tasks, _get_id, _get_deps)
        assert has_cycle is True
        assert len(sorted_tasks) < 4


class TestFindCycleDescription:

    def test_describes_two_node_cycle(self):
        tasks = _tasks({"A": ["B"], "B": ["A"]})
        desc = find_cycle_description(tasks, _get_id, _get_deps)
        assert isinstance(desc, str)
        assert len(desc) > 0

    def test_returns_string_for_acyclic(self):
        tasks = _tasks({"A": [], "B": ["A"]})
        desc = find_cycle_description(tasks, _get_id, _get_deps)
        assert isinstance(desc, str)