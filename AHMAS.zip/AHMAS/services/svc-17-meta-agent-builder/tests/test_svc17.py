# FILE: services/svc-17-meta-agent-builder/tests/test_svc17.py

"""
SVC-17 Meta-Agent Builder — Full Validation Test Suite.

Covers ALL requirements from STEP-9.3:
  ✓ Kill switch blocks ALL creation
  ✓ Rate limit = 5/hour
  ✓ trust_score = 0.5
  ✓ is_dynamic = True
  ✓ saved_by = 'SVC-17'
  ✓ agent.created emitted on success
  ✓ meta.agent.failed emitted on failure
  ✓ SVC-19 failure → META_AGENT_CREATION_FAILED
  ✓ Idempotency before processing
  ✓ AgentSpec validation enforces constraints
  ✓ agent.created emitted ONLY on success
  ✓ Processing order: kill switch → rate limit → LLM → ...
"""
from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.models import AgentLLMConfig, AgentSpec, ModelTier
from app.services.agent_spec_generator import AgentSpecGenerator
from app.services.kill_switch import KillSwitch
from app.services.meta_agent_builder import (
    BOOTSTRAP_TRUST_SCORE,
    IS_DYNAMIC,
    MetaAgentBuilder,
)
from app.services.rate_limiter import MetaAgentRateLimiter
from app.utils.idempotency import IdempotencyChecker


# ═══════════════════════════════════════════════════════════════════════════════
# Mock infrastructure
# ═══════════════════════════════════════════════════════════════════════════════

class MockRedis:
    """
    In-memory Redis mock that correctly simulates:
    - GET / SET / EXISTS / DELETE / INCR / DECR / EXPIRE / PING
    - register_script() → Lua simulation for idempotency + rate limit scripts
    """

    def __init__(self) -> None:
        self._store: Dict[str, str] = {}

    # ── Basic ops ─────────────────────────────────────────────────────

    def get(self, key: str) -> Optional[bytes]:
        v = self._store.get(key)
        return v.encode() if v is not None else None

    def set(
        self,
        key: str,
        value: Any,
        ex: int = None,
        xx: bool = False,
        nx: bool = False,
        keepttl: bool = False,
    ) -> bool:
        if nx and key in self._store:
            return False
        if xx and key not in self._store:
            return False
        self._store[key] = str(value.decode() if isinstance(value, bytes) else value)
        return True

    def exists(self, key: str) -> int:
        return 1 if key in self._store else 0

    def delete(self, key: str) -> int:
        return 1 if self._store.pop(key, None) is not None else 0

    def incr(self, key: str) -> int:
        n = int(self._store.get(key, "0")) + 1
        self._store[key] = str(n)
        return n

    def decr(self, key: str) -> int:
        n = int(self._store.get(key, "0")) - 1
        self._store[key] = str(n)
        return n

    def expire(self, key: str, seconds: int) -> int:
        return 1 if key in self._store else 0

    def ping(self) -> bool:
        return True

    def register_script(self, script: str):  # noqa: ANN001
        store = self

        class _LuaScript:
            def __call__(self, keys: list, args: list) -> int:
                # ── Idempotency script detection ──────────────────────
                # contracts.json lua: "if existing then return 0; else SET NX; return 1"
                if "existing" in script:
                    existing = store.get(keys[0])
                    if existing is not None:
                        return 0  # duplicate
                    val = args[0] if isinstance(args[0], str) else args[0].decode()
                    ttl = int(args[1])
                    store.set(keys[0], val, ex=ttl)
                    return 1  # new
                # ── Rate-limit script detection ───────────────────────
                # "if current >= max then return 0; INCR; EXPIRE on first"
                elif "tonumber" in script:
                    key = keys[0]
                    max_count = int(args[0])
                    window = int(args[1])
                    raw = store.get(key)
                    current = int(raw.decode()) if raw else 0
                    if current >= max_count:
                        return 0  # rate limited
                    new_count = store.incr(key)
                    if new_count == 1:
                        store.expire(key, window)
                    return new_count
                return 1

        return _LuaScript()


class MockKafkaProducer:
    """Captures produced events for assertion."""

    def __init__(self) -> None:
        self.events: List[Dict[str, Any]] = []

    def produce_agent_created(
        self, *, meta_request_id, agent_spec, sandbox_test_results,
        correlation_id, trace_id,
    ) -> None:
        self.events.append({
            "event_type": "agent.created",
            "meta_request_id": meta_request_id,
            "agent_spec": agent_spec,
            "sandbox_test_results": sandbox_test_results,
        })

    def produce_meta_agent_failed(
        self, *, meta_request_id, task_id, required_capability,
        failure_reason, error_code, correlation_id, trace_id,
    ) -> None:
        self.events.append({
            "event_type": "meta.agent.failed",
            "meta_request_id": meta_request_id,
            "task_id": task_id,
            "required_capability": required_capability,
            "failure_reason": failure_reason,
            "error_code": error_code,
        })

    def flush(self) -> None:
        pass

    def of_type(self, event_type: str) -> List[Dict[str, Any]]:
        return [e for e in self.events if e["event_type"] == event_type]

    def clear(self) -> None:
        self.events.clear()


# ═══════════════════════════════════════════════════════════════════════════════
# Factory helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _make_envelope(
    *,
    required_capability: str = "logic",
    meta_request_id: str = None,
    task_id: str = None,
    idempotency_key: str = None,
) -> Dict[str, Any]:
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": "meta.agent.request",
        "schema_version": "1.0.0",
        "payload_version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source_service": "SVC-04",
        "correlation_id": str(uuid.uuid4()),
        "trace_id": str(uuid.uuid4()),
        "idempotency_key": idempotency_key or str(uuid.uuid4()),
        "status": "success",
        "payload": {
            "meta_request_id": meta_request_id or str(uuid.uuid4()),
            "task_id": task_id or str(uuid.uuid4()),
            "trigger_reason": "tool_generation_failed",
            "required_capability": required_capability,
            "failure_pattern_description": "Tool generation failed after 3 retries",
            "historical_failure_count": 3,
            "historical_failure_logs": ["attempt 1", "attempt 2", "attempt 3"],
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
        "error": None,
    }


def _make_builder(
    *,
    redis_mock: MockRedis = None,
    producer: MockKafkaProducer = None,
    svc19_fail: bool = False,
    svc19_status: int = 201,
) -> tuple:
    if redis_mock is None:
        redis_mock = MockRedis()
    if producer is None:
        producer = MockKafkaProducer()

    kill_switch = KillSwitch(redis_mock)
    rate_limiter = MetaAgentRateLimiter(redis_mock)
    idempotency = IdempotencyChecker(redis_mock)
    generator = AgentSpecGenerator(llm_client=None)

    # SVC-19 mock
    svc19 = AsyncMock()
    if svc19_fail:
        svc19.post = AsyncMock(side_effect=Exception("SVC-19 unreachable"))
    else:
        resp19 = MagicMock()
        resp19.status_code = svc19_status
        resp19.json.return_value = {
            "agent_id": str(uuid.uuid4()),
            "registered_at": datetime.now(timezone.utc).isoformat(),
        }
        resp19.text = "OK"
        svc19.post = AsyncMock(return_value=resp19)

    # SVC-21 mock
    svc21 = AsyncMock()
    resp21 = MagicMock()
    resp21.status_code = 201
    resp21.json.return_value = {
        "prompt_id": str(uuid.uuid4()),
        "saved_to": "/data/prompt-vault/generated/x.json",
        "indexed": True,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    svc21.post = AsyncMock(return_value=resp21)

    builder = MetaAgentBuilder(
        kill_switch=kill_switch,
        rate_limiter=rate_limiter,
        agent_spec_generator=generator,
        kafka_producer=producer,
        idempotency_checker=idempotency,
        svc19_client=svc19,
        svc21_client=svc21,
    )
    return builder, redis_mock, producer, svc19, svc21


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 1 — Kill switch blocks ALL creation
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_kill_switch_blocks_all_creation():
    """IMMUTABLE RULE: META_AGENT_KILL_SWITCH_ACTIVE MUST prevent ALL agent creation."""
    builder, redis_mock, producer, svc19, svc21 = _make_builder()

    redis_mock.set("meta_agent:kill_switch", "1")

    await builder.handle_meta_agent_request(_make_envelope())

    assert len(producer.of_type("agent.created")) == 0, \
        "agent.created MUST NOT be emitted when kill switch is active"

    failed = producer.of_type("meta.agent.failed")
    assert len(failed) == 1
    assert failed[0]["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"

    svc19.post.assert_not_called()
    svc21.post.assert_not_called()


@pytest.mark.asyncio
async def test_kill_switch_uses_exact_redis_key():
    """Kill switch MUST use EXACT key 'meta_agent:kill_switch' — no variations."""
    builder, redis_mock, producer, _, _ = _make_builder()

    # Wrong keys — must NOT activate kill switch
    for wrong in ("kill_switch", "meta_agent_kill_switch", "meta_agent:kill_switch_v2"):
        redis_mock.set(wrong, "1")

    await builder.handle_meta_agent_request(_make_envelope())

    # No kill-switch error
    ks_failures = [
        e for e in producer.of_type("meta.agent.failed")
        if e["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"
    ]
    assert len(ks_failures) == 0, \
        "Kill switch MUST check ONLY 'meta_agent:kill_switch'"

    # Now set correct key
    producer.clear()
    redis_mock.set("meta_agent:kill_switch", "1")
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )
    ks_failures2 = [
        e for e in producer.of_type("meta.agent.failed")
        if e["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"
    ]
    assert len(ks_failures2) == 1


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 2 — Rate limit = 5/hour
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_rate_limit_5_per_hour():
    """
    IMMUTABLE RULE 7: META_AGENT_RATE_LIMIT_EXCEEDED after 5 agents/hour.
    First 5 succeed; 6th MUST be rejected.
    """
    builder, _, producer, _, _ = _make_builder()

    for _ in range(5):
        await builder.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )

    assert len(producer.of_type("agent.created")) == 5, \
        "Exactly 5 agents MUST be created before rate limit"

    # 6th request
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )

    rl_failures = [
        e for e in producer.of_type("meta.agent.failed")
        if e["error_code"] == "META_AGENT_RATE_LIMIT_EXCEEDED"
    ]
    assert len(rl_failures) >= 1, \
        "6th request MUST fail with META_AGENT_RATE_LIMIT_EXCEEDED"

    assert len(producer.of_type("agent.created")) == 5, \
        "agent.created MUST still be exactly 5 after rate-limited 6th request"


@pytest.mark.asyncio
async def test_rate_limit_5th_succeeds_6th_fails():
    """Boundary: 5th request MUST succeed; 6th MUST fail."""
    builder, _, producer, _, _ = _make_builder()

    for _ in range(4):
        await builder.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )

    # 5th must succeed
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )
    assert len(producer.of_type("agent.created")) == 5
    assert not any(
        e["error_code"] == "META_AGENT_RATE_LIMIT_EXCEEDED"
        for e in producer.of_type("meta.agent.failed")
    ), "5th request MUST NOT be rate limited"

    # 6th must fail
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )
    assert any(
        e["error_code"] == "META_AGENT_RATE_LIMIT_EXCEEDED"
        for e in producer.of_type("meta.agent.failed")
    )


def test_rate_limiter_max_per_hour_constant():
    """MAX_PER_HOUR constant MUST be exactly 5."""
    assert MetaAgentRateLimiter.MAX_PER_HOUR == 5


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 3 — trust_score = 0.5
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_bootstrap_trust_score_exactly_05():
    """
    IMMUTABLE: trust_score MUST be EXACTLY 0.5 in SVC-19 registration.
    """
    builder, _, producer, svc19, _ = _make_builder()

    await builder.handle_meta_agent_request(_make_envelope())

    svc19.post.assert_called_once()
    payload = svc19.post.call_args.kwargs.get("json", {})

    assert "trust_score" in payload
    assert payload["trust_score"] == 0.5, \
        f"trust_score MUST be 0.5, got {payload['trust_score']}"
    assert payload["trust_score"] == BOOTSTRAP_TRUST_SCORE


def test_bootstrap_trust_score_constant():
    """BOOTSTRAP_TRUST_SCORE module-level constant MUST equal 0.5."""
    assert BOOTSTRAP_TRUST_SCORE == 0.5


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 4 — is_dynamic = True
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_is_dynamic_true_for_all_capabilities():
    """
    IMMUTABLE: is_dynamic MUST be True for ALL meta-agent created agents,
    regardless of capability type.
    """
    for cap in ["research", "logic", "media", "code", "tool_builder", "validation"]:
        builder, _, producer, svc19, _ = _make_builder()

        await builder.handle_meta_agent_request(
            _make_envelope(required_capability=cap)
        )

        if svc19.post.called:
            payload = svc19.post.call_args.kwargs.get("json", {})
            assert payload.get("is_dynamic") is True, \
                f"is_dynamic MUST be True for capability '{cap}'"


def test_is_dynamic_constant():
    """IS_DYNAMIC module-level constant MUST be True."""
    assert IS_DYNAMIC is True


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 5 — saved_by = 'SVC-17'
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_svc21_saved_by_is_svc17():
    """
    IMMUTABLE: POST /prompt/save MUST use saved_by='SVC-17'.
    contracts.json OC-03: only SVC-11 and SVC-17 are authorized callers.
    """
    builder, _, _, _, svc21 = _make_builder()

    await builder.handle_meta_agent_request(_make_envelope())

    svc21.post.assert_called_once()
    payload = svc21.post.call_args.kwargs.get("json", {})

    assert payload.get("saved_by") == "SVC-17", \
        f"saved_by MUST be 'SVC-17', got {payload.get('saved_by')!r}"


@pytest.mark.asyncio
async def test_svc21_endpoint_is_prompt_save():
    """SVC-21 MUST be called at /prompt/save."""
    builder, _, _, _, svc21 = _make_builder()
    await builder.handle_meta_agent_request(_make_envelope())
    endpoint = svc21.post.call_args.args[0]
    assert "/prompt/save" in endpoint


@pytest.mark.asyncio
async def test_svc21_source_is_generated_and_is_agent_template():
    """PromptSaveRequest.source MUST be 'generated'; is_agent_template MUST be True."""
    builder, _, _, _, svc21 = _make_builder()
    await builder.handle_meta_agent_request(_make_envelope())
    payload = svc21.post.call_args.kwargs.get("json", {})
    assert payload.get("source") == "generated"
    assert payload.get("is_agent_template") is True


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 6 — agent.created emitted on success
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_agent_created_emitted_on_success():
    """IMMUTABLE RULE 9: agent.created MUST be emitted on success."""
    builder, _, producer, _, _ = _make_builder()
    await builder.handle_meta_agent_request(_make_envelope())
    assert len(producer.of_type("agent.created")) == 1
    assert len(producer.of_type("meta.agent.failed")) == 0


@pytest.mark.asyncio
async def test_agent_created_not_emitted_when_kill_switch_active():
    """agent.created MUST NOT be emitted when kill switch is active."""
    builder, redis_mock, producer, _, _ = _make_builder()
    redis_mock.set("meta_agent:kill_switch", "1")
    await builder.handle_meta_agent_request(_make_envelope())
    assert len(producer.of_type("agent.created")) == 0


@pytest.mark.asyncio
async def test_agent_created_not_emitted_when_rate_limited():
    """agent.created MUST NOT be emitted when rate limit exceeded."""
    builder, _, producer, _, _ = _make_builder()
    for _ in range(5):
        await builder.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )
    count_before = len(producer.of_type("agent.created"))
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )
    assert len(producer.of_type("agent.created")) == count_before, \
        "agent.created MUST NOT be emitted when rate limited"


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 7 — meta.agent.failed emitted on failure
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_meta_agent_failed_on_svc19_failure():
    """
    SVC-19 failure MUST emit meta.agent.failed with META_AGENT_CREATION_FAILED.
    IMMUTABLE RULE 10.
    """
    builder, _, producer, _, _ = _make_builder(svc19_fail=True)
    await builder.handle_meta_agent_request(_make_envelope())

    failed = producer.of_type("meta.agent.failed")
    assert len(failed) == 1
    assert failed[0]["error_code"] == "META_AGENT_CREATION_FAILED"
    assert len(producer.of_type("agent.created")) == 0


@pytest.mark.asyncio
async def test_meta_agent_failed_on_svc19_400():
    """SVC-19 returning HTTP 400 MUST emit META_AGENT_CREATION_FAILED."""
    builder, _, producer, _, _ = _make_builder(svc19_status=400)
    await builder.handle_meta_agent_request(_make_envelope())
    failed = producer.of_type("meta.agent.failed")
    assert len(failed) == 1
    assert failed[0]["error_code"] == "META_AGENT_CREATION_FAILED"


@pytest.mark.asyncio
async def test_all_failure_error_codes_are_contract_defined():
    """
    ALL error codes MUST be from contracts.json global_error_codes.
    No invented codes allowed.
    """
    allowed = {
        "META_AGENT_KILL_SWITCH_ACTIVE",
        "META_AGENT_RATE_LIMIT_EXCEEDED",
        "META_AGENT_CREATION_FAILED",
    }

    # Kill switch
    b1, r1, p1, _, _ = _make_builder()
    r1.set("meta_agent:kill_switch", "1")
    await b1.handle_meta_agent_request(_make_envelope())
    for e in p1.of_type("meta.agent.failed"):
        assert e["error_code"] in allowed, f"Illegal error code: {e['error_code']!r}"
    assert any(e["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE"
               for e in p1.of_type("meta.agent.failed"))

    # Rate limit
    b2, _, p2, _, _ = _make_builder()
    for _ in range(5):
        await b2.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )
    await b2.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )
    for e in p2.of_type("meta.agent.failed"):
        assert e["error_code"] in allowed
    assert any(e["error_code"] == "META_AGENT_RATE_LIMIT_EXCEEDED"
               for e in p2.of_type("meta.agent.failed"))

    # SVC-19 failure
    b3, _, p3, _, _ = _make_builder(svc19_fail=True)
    await b3.handle_meta_agent_request(_make_envelope())
    for e in p3.of_type("meta.agent.failed"):
        assert e["error_code"] in allowed
    assert any(e["error_code"] == "META_AGENT_CREATION_FAILED"
               for e in p3.of_type("meta.agent.failed"))


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 8 — Idempotency before processing
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_idempotency_skips_duplicate():
    """Same idempotency_key MUST NOT be processed twice."""
    builder, _, producer, svc19, _ = _make_builder()
    ikey = str(uuid.uuid4())

    await builder.handle_meta_agent_request(_make_envelope(idempotency_key=ikey))
    first_events = len(producer.events)
    first_svc19_calls = svc19.post.call_count

    # Duplicate
    await builder.handle_meta_agent_request(_make_envelope(idempotency_key=ikey))

    assert len(producer.events) == first_events, \
        "Duplicate message MUST NOT produce additional events"
    assert svc19.post.call_count == first_svc19_calls, \
        "SVC-19 MUST NOT be called for duplicates"


@pytest.mark.asyncio
async def test_idempotency_key_stored_with_correct_schema():
    """Idempotency key schema: idempotency:SVC-17:{idempotency_key}."""
    redis_mock = MockRedis()
    checker = IdempotencyChecker(redis_mock)

    ikey = "test-key-123"
    eid = str(uuid.uuid4())

    result = checker.check_and_set(ikey, eid)
    assert result is True

    expected = f"idempotency:SVC-17:{ikey}"
    assert expected in redis_mock._store, \
        f"Key MUST be stored as '{expected}'"

    result2 = checker.check_and_set(ikey, eid)
    assert result2 is False, "Second call with same key MUST return False"


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 9 — Processing order: kill switch FIRST, rate limit SECOND
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_kill_switch_fires_before_rate_limit():
    """
    When both kill switch and rate limit would trigger,
    kill switch MUST fire first (step 1 < step 2).
    """
    builder, redis_mock, producer, _, _ = _make_builder()

    # Exhaust rate limit
    for _ in range(5):
        await builder.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )
    producer.clear()

    # Activate kill switch AFTER rate limit exhaustion
    redis_mock.set("meta_agent:kill_switch", "1")

    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )

    failed = producer.of_type("meta.agent.failed")
    assert len(failed) == 1
    assert failed[0]["error_code"] == "META_AGENT_KILL_SWITCH_ACTIVE", \
        f"Kill switch MUST fire before rate limit; got {failed[0]['error_code']!r}"


@pytest.mark.asyncio
async def test_rate_limit_fires_before_llm():
    """
    Rate limit (step 2) MUST block before LLM is called (step 3).
    """
    redis_mock = MockRedis()
    producer = MockKafkaProducer()

    llm_call_count = []

    class TrackingGenerator(AgentSpecGenerator):
        async def generate(self, payload):
            llm_call_count.append(1)
            return await super().generate(payload)

    svc19 = AsyncMock()
    resp19 = MagicMock()
    resp19.status_code = 201
    resp19.json.return_value = {"agent_id": str(uuid.uuid4()),
                                "registered_at": datetime.now(timezone.utc).isoformat()}
    resp19.text = "OK"
    svc19.post = AsyncMock(return_value=resp19)

    svc21 = AsyncMock()
    resp21 = MagicMock()
    resp21.status_code = 201
    svc21.post = AsyncMock(return_value=resp21)

    builder = MetaAgentBuilder(
        kill_switch=KillSwitch(redis_mock),
        rate_limiter=MetaAgentRateLimiter(redis_mock),
        agent_spec_generator=TrackingGenerator(llm_client=None),
        kafka_producer=producer,
        idempotency_checker=IdempotencyChecker(redis_mock),
        svc19_client=svc19,
        svc21_client=svc21,
    )

    # Exhaust rate limit
    for _ in range(5):
        await builder.handle_meta_agent_request(
            _make_envelope(idempotency_key=str(uuid.uuid4()))
        )

    llm_before = len(llm_call_count)

    # 6th request — rate limited, LLM must NOT be called
    await builder.handle_meta_agent_request(
        _make_envelope(idempotency_key=str(uuid.uuid4()))
    )

    assert len(llm_call_count) == llm_before, \
        "LLM MUST NOT be called when rate limit is exceeded"


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 10 — AgentSpec validation enforces enum constraints
# ═══════════════════════════════════════════════════════════════════════════════

def test_agent_spec_validation_passes_valid_spec():
    """Valid AgentSpec MUST pass validation without exception."""
    gen = AgentSpecGenerator(llm_client=None)
    spec = AgentSpec(
        agent_spec_id=str(uuid.uuid4()),
        name="Test Logic Agent",
        capability_type="logic",
        llm_config=AgentLLMConfig(
            model_tier=ModelTier.MID_TIER,
            max_tokens=4096,
            temperature=0.1,
        ),
        tool_ids=[],
        system_prompt_template="You are a logic reasoning agent.",
        version="1.0.0",
    )
    gen.validate_agent_spec(spec)  # must not raise


def test_agent_spec_validation_rejects_bad_version():
    """Invalid semver version MUST raise ValueError."""
    gen = AgentSpecGenerator(llm_client=None)
    spec = AgentSpec.model_construct(
        agent_spec_id=str(uuid.uuid4()),
        name="Agent",
        capability_type="logic",
        llm_config=AgentLLMConfig(
            model_tier=ModelTier.MID_TIER,
            max_tokens=4096,
            temperature=0.1,
        ),
        tool_ids=[],
        system_prompt_template="System prompt.",
        version="bad-version",
    )
    with pytest.raises(ValueError, match="version"):
        gen.validate_agent_spec(spec)


def test_agent_spec_validation_rejects_empty_prompt():
    """Empty system_prompt_template MUST raise ValueError."""
    gen = AgentSpecGenerator(llm_client=None)
    with pytest.raises(Exception):
        AgentSpec(
            agent_spec_id=str(uuid.uuid4()),
            name="Agent",
            capability_type="logic",
            llm_config=AgentLLMConfig(
                model_tier=ModelTier.MID_TIER, max_tokens=4096, temperature=0.1,
            ),
            tool_ids=[],
            system_prompt_template="",   # invalid: min_length=1
            version="1.0.0",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 11 — SVC-19 payload completeness
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_svc19_payload_contains_all_required_fields():
    """
    SVC-19 registration payload MUST include all CapabilityRegistryEntry required fields.
    """
    builder, _, producer, svc19, _ = _make_builder()
    await builder.handle_meta_agent_request(_make_envelope())

    svc19.post.assert_called_once()
    payload = svc19.post.call_args.kwargs.get("json", {})

    required = [
        "agent_id", "agent_type", "capability_type", "model_tier",
        "llm_config", "tool_ids", "health_status", "trust_score",
        "version", "is_dynamic", "registered_at",
    ]
    for field in required:
        assert field in payload, f"SVC-19 payload MUST contain '{field}'"

    assert payload["trust_score"] == 0.5
    assert payload["is_dynamic"] is True
    assert payload["health_status"] == "healthy"
    assert payload["agent_type"] in {
        "research", "logic", "media", "code", "tool_builder", "validation"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 12 — Full happy-path integration
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_full_happy_path_integration():
    """
    End-to-end: meta.agent.request → [kill switch OK] → [rate limit OK]
    → [LLM gen] → [validate] → [SVC-19] → [SVC-21] → agent.created
    """
    builder, _, producer, svc19, svc21 = _make_builder()
    mid = str(uuid.uuid4())
    tid = str(uuid.uuid4())

    await builder.handle_meta_agent_request(
        _make_envelope(
            required_capability="code",
            meta_request_id=mid,
            task_id=tid,
        )
    )

    # No error events
    assert len(producer.of_type("meta.agent.failed")) == 0

    # agent.created emitted with correct meta_request_id
    created = producer.of_type("agent.created")
    assert len(created) == 1
    assert created[0]["meta_request_id"] == mid

    # SVC-19 called with trust_score=0.5, is_dynamic=True
    p19 = svc19.post.call_args.kwargs.get("json", {})
    assert p19["trust_score"] == 0.5
    assert p19["is_dynamic"] is True

    # SVC-21 called with saved_by='SVC-17'
    p21 = svc21.post.call_args.kwargs.get("json", {})
    assert p21["saved_by"] == "SVC-17"
    assert p21["source"] == "generated"
    assert p21["is_agent_template"] is True