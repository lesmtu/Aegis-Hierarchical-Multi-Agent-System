# FILE: services/svc-17-meta-agent-builder/app/utils/idempotency.py

"""
Redis idempotency checker.
Implements contracts.json idempotency_policy exactly:
  key_schema: idempotency:{service_id}:{idempotency_key}
  ttl_seconds: 86400
  lua_script: atomic SET NX
"""
import json
import logging
from datetime import datetime, timezone

import redis as redis_module

logger = logging.getLogger(__name__)

# Exact Lua script from contracts.json idempotency_policy.lua_script
_IDEMPOTENCY_LUA = (
    "local existing = redis.call('GET', KEYS[1]); "
    "if existing then return 0; "
    "else redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2]); return 1; end"
)


class IdempotencyChecker:
    """
    Redis-based idempotency per contracts.json idempotency_policy.
    Key: idempotency:SVC-17:{idempotency_key}
    TTL: 86400 s (24 h)
    """

    SERVICE_ID = "SVC-17"
    TTL_SECONDS = 86400

    def __init__(self, redis_client: redis_module.Redis) -> None:
        self._redis = redis_client
        self._script = redis_client.register_script(_IDEMPOTENCY_LUA)

    # ── Public API ────────────────────────────────────────────────────

    def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        """
        Atomically check and set idempotency key.
        Returns True  → key was new; proceed with processing.
        Returns False → key existed; skip (duplicate).
        """
        key = self._make_key(idempotency_key)
        value = json.dumps({
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": "processing",
        })
        result = self._script(keys=[key], args=[value, str(self.TTL_SECONDS)])
        if result == 0:
            logger.info(
                "Idempotency: duplicate message skipped",
                extra={"idempotency_key": idempotency_key, "event_id": event_id},
            )
            return False
        return True

    def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        """Update status → 'completed' per contracts.json step_4."""
        self._update_status(idempotency_key, event_id, "completed")

    def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        """Update status → 'failed' per contracts.json step_5."""
        self._update_status(idempotency_key, event_id, "failed")

    # ── Internals ─────────────────────────────────────────────────────

    def _make_key(self, idempotency_key: str) -> str:
        return f"idempotency:{self.SERVICE_ID}:{idempotency_key}"

    def _update_status(
        self, idempotency_key: str, event_id: str, status: str
    ) -> None:
        key = self._make_key(idempotency_key)
        value = json.dumps({
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "service_id": self.SERVICE_ID,
            "event_id": event_id,
            "status": status,
        })
        # XX = only update if key exists; KEEPTTL = preserve original TTL
        self._redis.set(key, value, xx=True, keepttl=True)