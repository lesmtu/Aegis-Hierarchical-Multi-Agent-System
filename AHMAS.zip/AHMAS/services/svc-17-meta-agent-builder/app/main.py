# FILE: services/svc-17-meta-agent-builder/app/main.py

"""
SVC-17 Meta-Agent Builder — FastAPI application entry point.
"""
from __future__ import annotations

import logging
import threading
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import httpx
import redis
from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

from app.config import config
from app.services.agent_spec_generator import AgentSpecGenerator
from app.services.kafka_consumer import KafkaEventConsumer
from app.services.kafka_producer import KafkaEventProducer
from app.services.kill_switch import KillSwitch
from app.services.meta_agent_builder import MetaAgentBuilder
from app.services.rate_limiter import MetaAgentRateLimiter
from app.utils.idempotency import IdempotencyChecker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


def _make_redis() -> redis.Redis:
    return redis.Redis(
        host=config.REDIS_HOST,
        port=config.REDIS_PORT,
        db=config.REDIS_DB,
        password=config.REDIS_PASSWORD,
        decode_responses=False,
        socket_connect_timeout=5,
        socket_timeout=5,
    )


def build_app() -> FastAPI:
    redis_client = _make_redis()

    svc19 = httpx.AsyncClient(base_url=config.SVC19_BASE_URL)
    svc21 = httpx.AsyncClient(base_url=config.SVC21_BASE_URL)
    llm = httpx.AsyncClient(timeout=60.0)

    kill_switch = KillSwitch(redis_client)
    rate_limiter = MetaAgentRateLimiter(redis_client)
    idempotency = IdempotencyChecker(redis_client)
    generator = AgentSpecGenerator(llm_client=llm)
    producer = KafkaEventProducer()

    builder = MetaAgentBuilder(
        kill_switch=kill_switch,
        rate_limiter=rate_limiter,
        agent_spec_generator=generator,
        kafka_producer=producer,
        idempotency_checker=idempotency,
        svc19_client=svc19,
        svc21_client=svc21,
    )

    consumer = KafkaEventConsumer()
    consumer.register_handler("meta.agent.request", builder.handle_meta_agent_request)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):  # noqa: ANN001
        t = threading.Thread(target=consumer.start, daemon=True, name="kafka-consumer")
        t.start()
        logger.info("SVC-17 started")
        yield
        consumer.stop()
        producer.flush()
        await svc19.aclose()
        await svc21.aclose()
        await llm.aclose()
        logger.info("SVC-17 stopped")

    application = FastAPI(
        title="SVC-17 Meta-Agent Builder",
        version=config.SERVICE_VERSION,
        lifespan=lifespan,
    )
    application.state.redis = redis_client
    application.state.kill_switch = kill_switch
    application.state.rate_limiter = rate_limiter

    @application.get("/health")
    async def health() -> dict:
        try:
            redis_ok = application.state.redis.ping()
            r_status = "healthy" if redis_ok else "degraded"
        except Exception:
            r_status = "unhealthy"

        overall = "healthy" if r_status == "healthy" else "degraded"
        return {
            "service_id": config.SERVICE_ID,
            "status": overall,
            "version": config.SERVICE_VERSION,
            "dependencies": {"redis": r_status},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    @application.get("/metrics")
    async def metrics() -> PlainTextResponse:
        ks = 1 if application.state.kill_switch.is_active() else 0
        rem = application.state.rate_limiter.get_remaining()
        body = (
            "# HELP aegis_meta_agent_kill_switch_active Kill switch (1=active)\n"
            "# TYPE aegis_meta_agent_kill_switch_active gauge\n"
            f"aegis_meta_agent_kill_switch_active {ks}\n"
            "# HELP aegis_meta_agent_rate_limit_remaining Remaining creations this hour\n"
            "# TYPE aegis_meta_agent_rate_limit_remaining gauge\n"
            f"aegis_meta_agent_rate_limit_remaining {rem}\n"
            "# HELP aegis_meta_agent_creations_total Agents created\n"
            "# TYPE aegis_meta_agent_creations_total counter\n"
            f"aegis_meta_agent_creations_total "
            f"{application.state.rate_limiter.get_current_count()}\n"
        )
        return PlainTextResponse(body, media_type="text/plain; version=0.0.4")

    return application


app = build_app()