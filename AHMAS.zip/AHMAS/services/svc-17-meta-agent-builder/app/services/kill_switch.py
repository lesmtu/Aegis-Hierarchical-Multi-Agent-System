# FILE: services/svc-17-meta-agent-builder/app/services/kill_switch.py

"""
Meta-Agent kill switch.
contracts.json SVC-17.kill_switch:
  redis_key: "meta_agent:kill_switch"  ← EXACT, IMMUTABLE
  active_value: "1"
  check: GET before ANY processing
"""
import logging

import redis as redis_module

logger = logging.getLogger(__name__)


class KillSwitch:
    """
    Emergency kill switch that MUST be checked FIRST before any
    meta-agent processing.  A single Redis GET is performed atomically
    before any processing lock is acquired, per contracts.json spec.
    """

    # EXACT Redis key — contracts.json SVC-17.kill_switch.redis_key
    REDIS_KEY: str = "meta_agent:kill_switch"
    ACTIVE_VALUE: str = "1"

    def __init__(self, redis_client: redis_module.Redis) -> None:
        self._redis = redis_client

    def is_active(self) -> bool:
        """
        Returns True when kill switch is active ('1').
        Returns False when value is '0' or key does not exist.

        Per contracts.json:
          "The kill switch check MUST be atomic with respect to the
           processing start. Use a single Redis GET before acquiring
           any processing lock."
        """
        raw = self._redis.get(self.REDIS_KEY)
        if raw is None:
            return False
        value = raw.decode("utf-8") if isinstance(raw, bytes) else str(raw)
        active = value == self.ACTIVE_VALUE
        if active:
            logger.critical(
                "META-AGENT KILL SWITCH IS ACTIVE — blocking all agent creation",
                extra={"redis_key": self.REDIS_KEY},
            )
        return active

    # ── Operational helpers (for admin endpoint / automated detection) ─

    def activate(self) -> None:
        self._redis.set(self.REDIS_KEY, self.ACTIVE_VALUE)
        logger.critical(
            "Meta-agent kill switch ACTIVATED",
            extra={"redis_key": self.REDIS_KEY},
        )

    def deactivate(self) -> None:
        self._redis.set(self.REDIS_KEY, "0")
        logger.info(
            "Meta-agent kill switch deactivated",
            extra={"redis_key": self.REDIS_KEY},
        )