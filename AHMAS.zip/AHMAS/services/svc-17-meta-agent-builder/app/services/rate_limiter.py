# FILE: services/svc-17-meta-agent-builder/app/services/rate_limiter.py

"""
Rate limiter for Meta-Agent creation.
IMMUTABLE RULE 7: 5 agents/hour → META_AGENT_RATE_LIMIT_EXCEEDED.
Atomic Redis Lua script prevents race conditions in scaled deployments.
"""
import logging
import time

import redis as redis_module

logger = logging.getLogger(__name__)

# Atomic Lua: check counter, increment only if under limit, set TTL on first use
_RATE_LIMIT_LUA = """
local current = redis.call('GET', KEYS[1])
if current and tonumber(current) >= tonumber(ARGV[1]) then
    return 0
end
local n = redis.call('INCR', KEYS[1])
if n == 1 then
    redis.call('EXPIRE', KEYS[1], ARGV[2])
end
return n
"""


class MetaAgentRateLimiter:
    """
    Sliding-window rate limiter.
    MAX_PER_HOUR = 5  ← IMMUTABLE per STEP-9.3 and system IMMUTABLE RULES.
    Window resets each calendar hour via a time-bucketed Redis key.
    """

    MAX_PER_HOUR: int = 5          # IMMUTABLE
    WINDOW_SECONDS: int = 3600     # 1 hour

    def __init__(self, redis_client: redis_module.Redis) -> None:
        self._redis = redis_client
        self._script = redis_client.register_script(_RATE_LIMIT_LUA)

    # ── Public API ────────────────────────────────────────────────────

    def check_and_increment(self) -> bool:
        """
        Atomically check limit and increment counter.
        Returns True  → within limit; proceed.
        Returns False → limit exceeded; emit META_AGENT_RATE_LIMIT_EXCEEDED.
        """
        key = self._current_key()
        result = self._script(
            keys=[key],
            args=[str(self.MAX_PER_HOUR), str(self.WINDOW_SECONDS)],
        )
        if result == 0:
            logger.warning(
                "Meta-agent rate limit exceeded",
                extra={
                    "max_per_hour": self.MAX_PER_HOUR,
                    "window_key": key,
                    "current_count": self.get_current_count(),
                },
            )
            return False
        logger.debug(
            "Rate limit check passed",
            extra={"count": result, "max": self.MAX_PER_HOUR},
        )
        return True

    def get_current_count(self) -> int:
        raw = self._redis.get(self._current_key())
        return int(raw) if raw else 0

    def get_remaining(self) -> int:
        return max(0, self.MAX_PER_HOUR - self.get_current_count())

    # ── Internals ─────────────────────────────────────────────────────

    def _current_key(self) -> str:
        """Time-bucketed key; resets each calendar hour automatically."""
        hour_epoch = int(time.time() // self.WINDOW_SECONDS)
        return f"meta_agent:rate_limit:global:{hour_epoch}"