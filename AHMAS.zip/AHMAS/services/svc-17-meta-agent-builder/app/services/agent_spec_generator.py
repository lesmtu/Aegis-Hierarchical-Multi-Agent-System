# FILE: services/svc-17-meta-agent-builder/app/services/agent_spec_generator.py

"""
AgentSpec generator using heavy_reasoning LLM.
contracts.json SVC-17.dependencies.llm = "heavy_reasoning"
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any, Dict, Optional

import httpx

from app.config import config
from app.models import AgentLLMConfig, AgentSpec, AgentType, ModelTier

logger = logging.getLogger(__name__)

# Valid enum values from contracts.json
_VALID_AGENT_TYPES = {at.value for at in AgentType}
_VALID_MODEL_TIERS = {mt.value for mt in ModelTier}

# Capability → AgentType mapping
_CAPABILITY_MAP: Dict[str, str] = {
    "research": "research",
    "search": "research",
    "retrieval": "research",
    "logic": "logic",
    "reasoning": "logic",
    "math": "logic",
    "calculation": "logic",
    "media": "media",
    "image": "media",
    "audio": "media",
    "video": "media",
    "code": "code",
    "programming": "code",
    "script": "code",
    "tool_builder": "tool_builder",
    "tool": "tool_builder",
    "validation": "validation",
    "verify": "validation",
    "audit": "validation",
}


class AgentSpecGenerator:
    """Generate and validate AgentSpec via heavy_reasoning LLM."""

    def __init__(self, llm_client: Optional[httpx.AsyncClient] = None) -> None:
        self._llm = llm_client

    # ── Public API ────────────────────────────────────────────────────

    async def generate(self, request_payload: Dict[str, Any]) -> AgentSpec:
        """
        Step 3: Generate AgentSpec using heavy_reasoning LLM.
        Falls back to deterministic default when llm_client is None (tests/degraded).
        """
        required_capability: str = request_payload.get("required_capability", "logic")
        failure_pattern: str = request_payload.get("failure_pattern_description", "")
        logs: list = request_payload.get("historical_failure_logs", [])

        prompt = self._build_prompt(required_capability, failure_pattern, logs)
        raw_json = await self._call_llm(prompt, required_capability)
        raw = self._parse(raw_json)
        spec = self._assemble(raw, required_capability)

        logger.info(
            "AgentSpec generated",
            extra={
                "agent_spec_id": spec.agent_spec_id,
                "capability_type": spec.capability_type,
            },
        )
        return spec

    def validate_agent_spec(self, spec: AgentSpec) -> None:
        """
        Step 4: Validate AgentSpec against contracts.json schema.
        Raises ValueError on violation.
        """
        if not spec.agent_spec_id:
            raise ValueError("AgentSpec.agent_spec_id is required")
        if not spec.name:
            raise ValueError("AgentSpec.name is required")
        if not spec.capability_type:
            raise ValueError("AgentSpec.capability_type is required")
        if not spec.system_prompt_template:
            raise ValueError("AgentSpec.system_prompt_template is required")
        if spec.llm_config.model_tier.value not in _VALID_MODEL_TIERS:
            raise ValueError(f"Invalid model_tier: {spec.llm_config.model_tier}")
        if not (1 <= spec.llm_config.max_tokens <= 128000):
            raise ValueError(f"max_tokens out of range: {spec.llm_config.max_tokens}")
        if not (0.0 <= spec.llm_config.temperature <= 2.0):
            raise ValueError(f"temperature out of range: {spec.llm_config.temperature}")
        if not re.match(r"^\d+\.\d+\.\d+$", spec.version):
            raise ValueError(f"Invalid version format: {spec.version!r}")

    # ── Internals ─────────────────────────────────────────────────────

    def _build_prompt(
        self, required_capability: str, failure_pattern: str, logs: list
    ) -> str:
        agent_type = self._map_capability(required_capability)
        logs_summary = "\n".join(logs[:5]) if logs else "None"
        return (
            f"Design a new Aegis HMAS agent.\n"
            f"Required capability: {required_capability}\n"
            f"Agent type: {agent_type}\n"
            f"Failure pattern: {failure_pattern}\n"
            f"Recent failure logs:\n{logs_summary}\n\n"
            f"Return ONLY valid JSON matching:\n"
            f'{{"name":"<str>","capability_type":"{required_capability}",'
            f'"agent_type":"{agent_type}","model_tier":"<lightweight|mid_tier|heavy_reasoning>",'
            f'"max_tokens":<int>,"temperature":<float>,'
            f'"system_prompt_template":"<str>","version":"1.0.0"}}'
        )

    async def _call_llm(self, prompt: str, required_capability: str) -> str:
        if self._llm is None:
            return self._default_spec(required_capability)
        try:
            resp = await self._llm.post(
                f"{config.LLM_API_BASE}/chat/completions",
                json={
                    "model": config.LLM_MODEL,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": config.LLM_MAX_TOKENS,
                    "temperature": config.LLM_TEMPERATURE,
                    "response_format": {"type": "json_object"},
                },
                headers={"Authorization": f"Bearer {config.LLM_API_KEY}"},
                timeout=60.0,
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]
        except Exception as exc:
            logger.error(f"LLM call failed, using default spec: {exc}")
            return self._default_spec(required_capability)

    def _default_spec(self, required_capability: str) -> str:
        """Deterministic fallback for degraded mode / tests."""
        agent_type = self._map_capability(required_capability)
        cap = required_capability if required_capability in _VALID_AGENT_TYPES else agent_type
        return json.dumps({
            "name": f"Dynamic {cap.replace('_', ' ').title()} Agent",
            "capability_type": cap,
            "agent_type": agent_type,
            "model_tier": "mid_tier",
            "max_tokens": 4096,
            "temperature": 0.1,
            "system_prompt_template": (
                f"You are a specialized {cap} agent in the Aegis HMAS system. "
                "Execute assigned tasks precisely and return structured results."
            ),
            "version": "1.0.0",
        })

    def _parse(self, raw: str) -> Dict[str, Any]:
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"LLM returned invalid JSON: {exc}") from exc

    def _assemble(self, raw: Dict[str, Any], required_capability: str) -> AgentSpec:
        """Assemble and coerce AgentSpec from raw LLM dict."""
        agent_type = raw.get("agent_type", "")
        if agent_type not in _VALID_AGENT_TYPES:
            agent_type = self._map_capability(required_capability)

        model_tier = raw.get("model_tier", "mid_tier")
        if model_tier not in _VALID_MODEL_TIERS:
            model_tier = "mid_tier"

        max_tokens = raw.get("max_tokens", 4096)
        if not isinstance(max_tokens, int) or not (1 <= max_tokens <= 128000):
            max_tokens = 4096

        temperature = float(raw.get("temperature", 0.1))
        if not (0.0 <= temperature <= 2.0):
            temperature = 0.1

        capability_type = raw.get("capability_type", required_capability)
        if capability_type not in _VALID_AGENT_TYPES:
            capability_type = agent_type

        return AgentSpec(
            agent_spec_id=str(uuid.uuid4()),
            name=raw.get("name", f"Dynamic {capability_type.title()} Agent"),
            capability_type=capability_type,
            llm_config=AgentLLMConfig(
                model_tier=ModelTier(model_tier),
                max_tokens=max_tokens,
                temperature=temperature,
            ),
            tool_ids=[],
            system_prompt_template=raw.get(
                "system_prompt_template",
                "You are a specialized agent. Execute tasks precisely.",
            ),
            version=raw.get("version", "1.0.0"),
        )

    @staticmethod
    def _map_capability(required_capability: str) -> str:
        lower = required_capability.lower()
        if lower in _VALID_AGENT_TYPES:
            return lower
        for key, val in _CAPABILITY_MAP.items():
            if key in lower:
                return val
        return "logic"  # safe default