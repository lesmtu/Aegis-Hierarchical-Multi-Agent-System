# FILE: services/svc-17-meta-agent-builder/app/services/kafka_producer.py

"""
Kafka event producer for SVC-17.
Produces to: agent.created, meta.agent.failed
All messages wrapped in contracts.json canonical event envelope.
"""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from confluent_kafka import Producer

from app.config import config

logger = logging.getLogger(__name__)

# Error metadata from contracts.json global_error_codes
_ERROR_META: Dict[str, Dict[str, Any]] = {
    "META_AGENT_KILL_SWITCH_ACTIVE": {
        "error_type": "system",
        "retryable": False,
    },
    "META_AGENT_RATE_LIMIT_EXCEEDED": {
        "error_type": "system",
        "retryable": True,
    },
    "META_AGENT_CREATION_FAILED": {
        "error_type": "agent",
        "retryable": False,
    },
}


class KafkaEventProducer:
    """
    Wraps confluent_kafka.Producer; produces canonical event envelopes.
    """

    def __init__(self, producer: Optional[Producer] = None) -> None:
        self._producer = producer or Producer({
            "bootstrap.servers": config.KAFKA_BOOTSTRAP_SERVERS,
            "acks": "all",
            "retries": 3,
            "retry.backoff.ms": 1000,
            "enable.idempotence": True,
        })

    # ── Public emit methods ───────────────────────────────────────────

    def produce_agent_created(
        self,
        *,
        meta_request_id: str,
        agent_spec: Dict[str, Any],
        sandbox_test_results: Dict[str, Any],
        correlation_id: str,
        trace_id: str,
    ) -> None:
        """
        Emit agent.created on success.
        IMMUTABLE RULE 9: emit agent.created Kafka event on success.
        """
        payload: Dict[str, Any] = {
            "meta_request_id": meta_request_id,
            "agent_spec": agent_spec,
            "sandbox_test_results": sandbox_test_results,
            "created_at": _utcnow(),
        }
        envelope = self._build_envelope(
            event_type=config.KAFKA_TOPIC_AGENT_CREATED,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status="success",
            error=None,
        )
        self._produce(config.KAFKA_TOPIC_AGENT_CREATED, meta_request_id, envelope)
        logger.info(
            "agent.created produced",
            extra={
                "meta_request_id": meta_request_id,
                "agent_spec_id": agent_spec.get("agent_spec_id"),
            },
        )

    def produce_meta_agent_failed(
        self,
        *,
        meta_request_id: str,
        task_id: str,
        required_capability: str,
        failure_reason: str,
        error_code: str,
        correlation_id: str,
        trace_id: str,
    ) -> None:
        """
        Emit meta.agent.failed on any failure.
        IMMUTABLE RULE 10: emit meta.agent.failed on failure with contract error code.
        error_code MUST be one of:
          META_AGENT_KILL_SWITCH_ACTIVE | META_AGENT_RATE_LIMIT_EXCEEDED | META_AGENT_CREATION_FAILED
        """
        assert error_code in _ERROR_META, (
            f"error_code {error_code!r} is not a contract-defined code"
        )
        payload: Dict[str, Any] = {
            "meta_request_id": meta_request_id,
            "task_id": task_id,
            "required_capability": required_capability,
            "failure_reason": failure_reason,
            "created_at": _utcnow(),
        }
        meta = _ERROR_META[error_code]
        error: Dict[str, Any] = {
            "error_code": error_code,
            "error_type": meta["error_type"],
            "retryable": meta["retryable"],
            "message": failure_reason,
        }
        envelope = self._build_envelope(
            event_type=config.KAFKA_TOPIC_META_AGENT_FAILED,
            payload=payload,
            correlation_id=correlation_id,
            trace_id=trace_id,
            status="error",
            error=error,
        )
        self._produce(config.KAFKA_TOPIC_META_AGENT_FAILED, meta_request_id, envelope)
        logger.warning(
            "meta.agent.failed produced",
            extra={"meta_request_id": meta_request_id, "error_code": error_code},
        )

    def flush(self, timeout: float = 10.0) -> None:
        self._producer.flush(timeout=timeout)

    # ── Internals ─────────────────────────────────────────────────────

    def _build_envelope(
        self,
        *,
        event_type: str,
        payload: Dict[str, Any],
        correlation_id: str,
        trace_id: str,
        status: str,
        error: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        return {
            "event_id": str(uuid.uuid4()),
            "event_type": event_type,
            "schema_version": config.SCHEMA_VERSION,
            "payload_version": config.PAYLOAD_VERSION,
            "timestamp": _utcnow(),
            "source_service": config.SERVICE_ID,
            "correlation_id": correlation_id,
            "trace_id": trace_id,
            "idempotency_key": str(uuid.uuid4()),
            "status": status,
            "payload": payload,
            "error": error,
        }

    def _produce(
        self, topic: str, key: str, envelope: Dict[str, Any]
    ) -> None:
        try:
            self._producer.produce(
                topic=topic,
                key=key.encode("utf-8"),
                value=json.dumps(envelope, default=str).encode("utf-8"),
                on_delivery=self._on_delivery,
            )
            self._producer.poll(0)
        except Exception as exc:
            logger.error(f"Kafka produce failed [{topic}]: {exc}")
            raise

    @staticmethod
    def _on_delivery(err: Any, msg: Any) -> None:
        if err:
            logger.error(
                f"Kafka delivery failed: {err}",
                extra={"topic": msg.topic() if msg else "unknown"},
            )


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()