# FILE: services/svc-17-meta-agent-builder/app/services/kafka_consumer.py

"""
Kafka consumer for SVC-17.
Consumes: meta.agent.request, tool.generation.failed, task.failed
Implements manual offset commit (at-least-once) + idempotency for safety.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable, Coroutine, Dict, Optional

from confluent_kafka import Consumer, KafkaError, KafkaException

from app.config import config

logger = logging.getLogger(__name__)

Handler = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]


class KafkaEventConsumer:
    """
    Wraps confluent_kafka.Consumer.
    Handlers are async coroutines run via asyncio.
    """

    def __init__(self, consumer: Optional[Consumer] = None) -> None:
        self._consumer = consumer or Consumer({
            "bootstrap.servers": config.KAFKA_BOOTSTRAP_SERVERS,
            "group.id": config.KAFKA_CONSUMER_GROUP,
            "auto.offset.reset": "earliest",
            "enable.auto.commit": False,  # manual commit for at-least-once
            "max.poll.interval.ms": 300_000,
        })
        self._handlers: Dict[str, Handler] = {}
        self._running = False

    def register_handler(self, topic: str, handler: Handler) -> None:
        self._handlers[topic] = handler

    def start(self) -> None:
        topics = list(self._handlers.keys())
        self._consumer.subscribe(topics)
        self._running = True
        logger.info("Kafka consumer started", extra={"topics": topics})
        self._loop()

    def stop(self) -> None:
        self._running = False
        self._consumer.close()
        logger.info("Kafka consumer stopped")

    # ── Internal loop ─────────────────────────────────────────────────

    def _loop(self) -> None:
        loop = asyncio.new_event_loop()
        try:
            while self._running:
                msg = self._consumer.poll(timeout=1.0)
                if msg is None:
                    continue
                if msg.error():
                    if msg.error().code() != KafkaError._PARTITION_EOF:
                        logger.error(f"Kafka error: {msg.error()}")
                    continue

                topic = msg.topic()
                try:
                    envelope = json.loads(msg.value().decode("utf-8"))
                    handler = self._handlers.get(topic)
                    if handler:
                        loop.run_until_complete(handler(envelope))
                    self._consumer.commit(message=msg, asynchronous=False)
                except json.JSONDecodeError as exc:
                    logger.error(f"Bad JSON from {topic}: {exc}")
                    self._consumer.commit(message=msg, asynchronous=False)
                except Exception as exc:  # noqa: BLE001
                    logger.error(f"Handler error [{topic}]: {exc}")
                    self._consumer.commit(message=msg, asynchronous=False)
        except KafkaException as exc:
            logger.error(f"Kafka exception: {exc}")
        finally:
            loop.close()