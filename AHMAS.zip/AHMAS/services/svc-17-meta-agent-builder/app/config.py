# FILE: services/svc-17-meta-agent-builder/app/config.py

"""
SVC-17 Configuration.
All constants are immutable per contracts.json and system_spec.md.
"""
import os


class Config:
    # ── Service Identity ────────────────────────────────────────────
    SERVICE_ID: str = "SVC-17"
    SERVICE_VERSION: str = "1.0.0"
    SCHEMA_VERSION: str = "1.0.0"
    PAYLOAD_VERSION: str = "1.0.0"

    # ── Kafka ────────────────────────────────────────────────────────
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv(
        "KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"
    )
    KAFKA_CONSUMER_GROUP: str = "svc-17-meta-agent-builder"
    KAFKA_TOPIC_CONSUME: list = [
        "meta.agent.request",
        "tool.generation.failed",
        "task.failed",
    ]
    KAFKA_TOPIC_AGENT_CREATED: str = "agent.created"
    KAFKA_TOPIC_META_AGENT_FAILED: str = "meta.agent.failed"

    # ── Redis ────────────────────────────────────────────────────────
    REDIS_HOST: str = os.getenv("REDIS_HOST", "localhost")
    REDIS_PORT: int = int(os.getenv("REDIS_PORT", "6379"))
    REDIS_DB: int = int(os.getenv("REDIS_DB", "0"))
    REDIS_PASSWORD: str = os.getenv("REDIS_PASSWORD", None)

    # ── Kill Switch — EXACT key from contracts.json SVC-17.kill_switch ──
    KILL_SWITCH_REDIS_KEY: str = "meta_agent:kill_switch"  # IMMUTABLE

    # ── Rate Limit — IMMUTABLE: 5 agents/hour ────────────────────────
    RATE_LIMIT_PER_HOUR: int = 5        # IMMUTABLE per STEP-9.3 + system rules
    RATE_LIMIT_WINDOW_SECONDS: int = 3600

    # ── Idempotency — contracts.json idempotency_policy ──────────────
    IDEMPOTENCY_TTL_SECONDS: int = 86400  # 24 h

    # ── Trust Score — IMMUTABLE: 0.5 ─────────────────────────────────
    BOOTSTRAP_TRUST_SCORE: float = 0.5  # EXACT per contracts.json SVC-17

    # ── External Services ─────────────────────────────────────────────
    SVC19_BASE_URL: str = os.getenv("SVC19_BASE_URL", "http://svc-19:8080")
    SVC19_TIMEOUT_SECONDS: int = 10

    SVC21_BASE_URL: str = os.getenv("SVC21_BASE_URL", "http://svc-21:8080")
    SVC21_TIMEOUT_SECONDS: int = 10

    # ── LLM (heavy_reasoning) ─────────────────────────────────────────
    LLM_API_BASE: str = os.getenv("LLM_API_BASE", "https://api.openai.com/v1")
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o")
    LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "4096"))
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.0"))

    # ── API Server ────────────────────────────────────────────────────
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8080"))


config = Config()