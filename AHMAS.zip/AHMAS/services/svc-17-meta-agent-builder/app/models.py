# FILE: services/svc-17-meta-agent-builder/app/models.py

"""
Pydantic models derived STRICTLY from contracts.json shared_schemas.
No invented fields. No deviations from contract.
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


# ── Enumerations from contracts.json ────────────────────────────────────────

class AgentType(str, Enum):
    RESEARCH = "research"
    LOGIC = "logic"
    MEDIA = "media"
    CODE = "code"
    TOOL_BUILDER = "tool_builder"
    VALIDATION = "validation"


class ModelTier(str, Enum):
    LIGHTWEIGHT = "lightweight"
    MID_TIER = "mid_tier"
    HEAVY_REASONING = "heavy_reasoning"


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    DISABLED = "disabled"


# ── contracts.json: AgentLLMConfig ──────────────────────────────────────────

class AgentLLMConfig(BaseModel):
    model_tier: ModelTier
    max_tokens: int = Field(ge=1, le=128000)
    temperature: float = Field(ge=0.0, le=2.0)


# ── contracts.json: AgentSpec ────────────────────────────────────────────────

class AgentSpec(BaseModel):
    agent_spec_id: str
    name: str = Field(min_length=1)
    capability_type: str = Field(min_length=1)
    llm_config: AgentLLMConfig
    tool_ids: List[str]
    system_prompt_template: str = Field(min_length=1)
    version: str

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        if not re.match(r"^\d+\.\d+\.\d+$", v):
            raise ValueError(f"version must be semver format (X.Y.Z), got: {v!r}")
        return v


# ── contracts.json: SandboxTestResults ──────────────────────────────────────

class SandboxTestResults(BaseModel):
    passed: bool
    unit_tests_passed: bool
    integration_tests_passed: bool
    static_analysis_passed: bool
    execution_time_ms: int = Field(ge=0)
    failure_details: Optional[str] = None


# ── contracts.json: AgentCreatedPayload ─────────────────────────────────────

class AgentCreatedPayload(BaseModel):
    meta_request_id: str
    agent_spec: AgentSpec
    sandbox_test_results: SandboxTestResults
    created_at: str


# ── contracts.json: MetaAgentFailedPayload ───────────────────────────────────

class MetaAgentFailedPayload(BaseModel):
    meta_request_id: str
    task_id: str
    required_capability: str = Field(min_length=1)
    failure_reason: str = Field(min_length=1)
    created_at: str


# ── contracts.json: MetaAgentRequestPayload ──────────────────────────────────

class MetaAgentRequestPayload(BaseModel):
    meta_request_id: str
    task_id: str
    trigger_reason: str
    required_capability: str = Field(min_length=1)
    failure_pattern_description: str = Field(min_length=1)
    historical_failure_count: int = Field(ge=0)
    historical_failure_logs: List[str]
    created_at: str


# ── contracts.json: CapabilityRegistryEntry ──────────────────────────────────

class CapabilityRegistryEntry(BaseModel):
    agent_id: str
    agent_type: AgentType
    capability_type: str = Field(min_length=1)
    model_tier: ModelTier
    llm_config: AgentLLMConfig
    tool_ids: List[str]
    health_status: HealthStatus
    trust_score: float = Field(ge=0.0, le=1.0)
    version: str
    is_dynamic: bool
    registered_at: str


# ── Canonical Event Envelope (contracts.json event_schema) ───────────────────

class CanonicalEnvelope(BaseModel):
    event_id: str
    event_type: str
    schema_version: str
    payload_version: str
    timestamp: str
    source_service: str
    correlation_id: str
    trace_id: str
    idempotency_key: str
    status: str
    payload: Dict[str, Any]
    error: Optional[Dict[str, Any]] = None