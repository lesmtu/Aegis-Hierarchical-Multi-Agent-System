from __future__ import annotations

import asyncio
import inspect
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SVC17_ROOT = ROOT / "services" / "svc-17-meta-agent-builder"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _reset_service_paths() -> None:
    sys.path[:] = [
        entry
        for entry in sys.path
        if "/home/g/AHMAS/services/svc-" not in entry
    ]
    if str(SVC17_ROOT) not in sys.path:
        sys.path.insert(0, str(SVC17_ROOT))


_reset_service_paths()


if "prometheus_client" not in sys.modules:
    fake = types.ModuleType("prometheus_client")

    class _FakeMetric:
        def __init__(self, name: str, documentation: str, labelnames=(), buckets=None):
            self.name = name
            self.documentation = documentation
            self.labelnames = tuple(labelnames)
            self.values: dict[tuple[tuple[str, str], ...], float] = {}

        def labels(self, **kwargs):
            metric = self

            class _Child:
                def inc(self, amount: float = 1.0) -> None:
                    key = tuple(sorted(kwargs.items()))
                    metric.values[key] = metric.values.get(key, 0.0) + amount

                def set(self, amount: float) -> None:
                    metric.values[tuple(sorted(kwargs.items()))] = amount

                def observe(self, amount: float) -> None:
                    self.inc(amount)

            return _Child()

        def inc(self, amount: float = 1.0) -> None:
            self.values[tuple()] = self.values.get(tuple(), 0.0) + amount

        def set(self, amount: float) -> None:
            self.values[tuple()] = amount

        def observe(self, amount: float) -> None:
            self.inc(amount)

    class _Registry:
        def __init__(self) -> None:
            self._collector_to_names: dict[object, set[str]] = {}

        def register(self, collector: object, name: str) -> None:
            self._collector_to_names[collector] = {name}

        def unregister(self, collector: object) -> None:
            self._collector_to_names.pop(collector, None)

    registry = _Registry()
    metrics: list[_FakeMetric] = []

    def _make_metric(name: str, documentation: str, labelnames=(), buckets=None, **_kwargs):
        metric = _FakeMetric(name, documentation, labelnames, buckets)
        metrics.append(metric)
        registry.register(metric, name)
        return metric

    def _generate_latest(*_args, **_kwargs) -> bytes:
        lines = []
        for metric in metrics:
            lines.append(f"# HELP {metric.name} {metric.documentation}")
            lines.append(f"# TYPE {metric.name} untyped")
            if metric.values:
                for labels, value in metric.values.items():
                    if labels:
                        rendered = ",".join(f'{key}="{value_}"' for key, value_ in labels)
                        lines.append(f"{metric.name}{{{rendered}}} {value}")
                    else:
                        lines.append(f"{metric.name} {value}")
            else:
                lines.append(f"{metric.name} 0")
        return ("\n".join(lines) + "\n").encode("utf-8")

    fake.Counter = _make_metric
    fake.Gauge = _make_metric
    fake.Histogram = _make_metric
    fake.Summary = _make_metric
    fake.CollectorRegistry = object
    fake.generate_latest = _generate_latest
    fake.CONTENT_TYPE_LATEST = "text/plain; version=0.0.4"
    fake.REGISTRY = registry
    sys.modules["prometheus_client"] = fake


def pytest_runtest_setup(item):
    _reset_service_paths()


def pytest_pyfunc_call(pyfuncitem):
    test_function = pyfuncitem.obj
    if not inspect.iscoroutinefunction(test_function):
        return None
    asyncio.run(test_function(**pyfuncitem.funcargs))
    return True
