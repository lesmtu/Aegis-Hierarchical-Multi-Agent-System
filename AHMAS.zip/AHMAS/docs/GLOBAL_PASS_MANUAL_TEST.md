# Global Pass Manual Test

## Scope
This runbook validates the production-facing behaviors required by `GLOBAL-PASS-CONFIRMATION.txt` against the authoritative contracts in `contracts.json` and `system_spec.md`.

## Prerequisites
- Services are reachable on their deployed base URLs.
- Kafka CLI tools are installed and pointed at the target cluster.
- Redis CLI can reach the idempotency cluster.
- `psql` can reach the PostgreSQL instance that hosts `dlq_audit`.

## 1. Health And Readiness

### All service health endpoints
Run for each service URL:

```bash
curl -sS http://svc-01:8080/health | jq
curl -sS http://svc-02:8080/health | jq
curl -sS http://svc-03:8080/health | jq
curl -sS http://svc-04:8080/health | jq
curl -sS http://svc-05:8080/health | jq
curl -sS http://svc-06:8080/health | jq
curl -sS http://svc-07:8080/health | jq
curl -sS http://svc-08:8080/health | jq
curl -sS http://svc-09:8080/health | jq
curl -sS http://svc-10:8080/health | jq
curl -sS http://svc-11:8080/health | jq
curl -sS http://svc-12:8080/health | jq
curl -sS http://svc-13:8080/health | jq
curl -sS http://svc-14:8080/health | jq
curl -sS http://svc-15:8080/health | jq
curl -sS http://svc-16:8080/health | jq
curl -sS http://svc-17:8080/health | jq
curl -sS http://svc-18:8080/health | jq
curl -sS http://svc-19:8080/health | jq
curl -sS http://svc-20:8080/health | jq
curl -sS http://svc-21:8080/health | jq
curl -sS http://svc-22:8080/health | jq
```

Expected:
- HTTP `200` for healthy or degraded services.
- Response matches `HealthCheckResponse`.
- `service_id` matches the service queried.

### SVC-21 startup sequence

```bash
curl -i http://svc-21:8080/ready
sleep 5
curl -i http://svc-21:8080/ready
```

Expected:
- During startup: HTTP `503` and header `Retry-After: 10`.
- After startup finishes: HTTP `200`.

## 2. Prompt Intelligence

### Reject unauthorized prompt save

```bash
curl -sS -o /tmp/svc21_unauth.json -w "%{http_code}\n" \
  -X POST http://svc-21:8080/prompt/save \
  -H 'Content-Type: application/json' \
  -d '{
    "description":"Reusable code generation prompt",
    "template":"Generate Python code for {task}",
    "capability_type":"code",
    "tags":["python"],
    "source":"generated",
    "saved_by":"SVC-03",
    "is_verified":true
  }'
cat /tmp/svc21_unauth.json
```

Expected:
- HTTP `403`.

### Verify metrics

```bash
curl -sS http://svc-21:8080/metrics | rg 'aegis_prompt_'
```

Expected:
- All 15 SVC-21 metrics are present.

## 3. Memory Retrieval

### SVC-16 retrieve path

```bash
curl -sS -X POST http://svc-16:8080/memory/retrieve \
  -H 'Content-Type: application/json' \
  -d '{
    "query":"Find relevant memory for the current task",
    "memory_types":["episodic","semantic"],
    "session_id":"123e4567-e89b-12d3-a456-426614174000",
    "task_id":"123e4567-e89b-12d3-a456-426614174001",
    "top_k":5
  }' | jq
```

Expected:
- No HTTP `5xx`.
- Response contains `context_chunks`, `source_ids`, `retrieval_scores`, `degraded_mode`.
- Result count is at most `5`.

Failure scenario:
- Stop Qdrant or Redis backend and repeat.
- Expected: request still returns a non-5xx response and sets `degraded_mode=true`.

## 4. Kafka Event Flow

### Produce a canonical `task.received`

```bash
kcat -P -b localhost:9092 -t task.received <<'EOF'
{"event_id":"11111111-1111-4111-8111-111111111111","event_type":"task.received","schema_version":"1.0.0","payload_version":"1.0.0","timestamp":"2026-03-31T00:00:00Z","source_service":"SVC-01","correlation_id":"22222222-2222-4222-8222-222222222222","trace_id":"33333333-3333-4333-8333-333333333333","idempotency_key":"44444444-4444-4444-8444-444444444444","status":"success","payload":{"task_id":"22222222-2222-4222-8222-222222222222","user_id":"user-1","session_id":"55555555-5555-4555-8555-555555555555","channel":"telegram","raw_input":"Research AI history","parsed_intent":"research ai history","intent_type":"task","context_chunks":["ctx"],"rag_source_ids":["note-1"],"preliminary_confidence":0.86,"is_ambiguous":false,"pii_detected":false,"telegram_chat_id":"456","created_at":"2026-03-31T00:00:00Z"},"error":null}
EOF
```

### Consume orchestration topics

```bash
kcat -C -b localhost:9092 -t plan.created -o end -e -q
kcat -C -b localhost:9092 -t dag.created -o end -e -q
kcat -C -b localhost:9092 -t task.dispatched -o end -e -q
kcat -C -b localhost:9092 -t task.progress -o end -e -q
```

Expected:
- `plan.created`, `dag.created`, `task.dispatched`, and `task.progress` appear for the same `correlation_id`.

### Cycle detection failure scenario

Produce a plan with cyclic dependencies and confirm:

```bash
kcat -C -b localhost:9092 -t hitl.request -o end -e -q
kcat -C -b localhost:9092 -t replan.required -o end -e -q
```

Expected:
- `hitl.request` emitted.
- `replan.required` emitted with `replan_source="delegation_engine"`.

## 5. Redis Validation

### Verify idempotency key shape and TTL

```bash
redis-cli -c --raw GET idempotency:SVC-03:44444444-4444-4444-8444-444444444444
redis-cli -c TTL idempotency:SVC-03:44444444-4444-4444-8444-444444444444
```

Expected:
- Stored JSON contains `processed_at`, `service_id`, `event_id`, `status`.
- TTL is close to `86400`.

Failure scenario:
- Produce the same Kafka envelope twice with the same `idempotency_key`.
- Expected: first message processes, duplicate is skipped and does not go to DLQ.

## 6. PostgreSQL Validation

### HITL audit trail

```bash
psql "$AEGIS_POSTGRES_DSN" -c "SELECT * FROM hitl_audit.hitl_requests ORDER BY created_at DESC LIMIT 5;"
```

Expected:
- New HITL rows appear after a HITL request is created or auto-rejected.

### DLQ audit schema

```bash
psql "$AEGIS_POSTGRES_DSN" -c "SELECT schemaname, tablename FROM pg_tables WHERE schemaname='dlq_audit';"
psql "$AEGIS_POSTGRES_DSN" -c "SELECT dlq_id, error_code, status, created_at FROM dlq_audit.dlq_events ORDER BY created_at DESC LIMIT 10;"
```

Expected:
- Schema `dlq_audit` exists.
- `dlq_events` exists and stores DLQ traffic.

### Duplicate DLQ suppression

```bash
psql "$AEGIS_POSTGRES_DSN" -c "SELECT dlq_id, COUNT(*) FROM dlq_audit.dlq_events GROUP BY dlq_id HAVING COUNT(*) > 1;"
```

Expected:
- No rows returned.

## 7. DLQ Manager

### Summary endpoint

```bash
curl -sS http://svc-22:8080/dlq/summary | jq
```

Expected:
- Aggregates include `by_error_code`.
- Aggregates reflect status buckets.

### Non-retryable failure scenario

Attempt to retry a DLQ event with a non-retryable error code:

```bash
curl -sS -o /tmp/dlq_retry.json -w "%{http_code}\n" \
  -X POST http://svc-22:8080/dlq/events/<dlq_id>/retry \
  -H 'Content-Type: application/json' \
  -d '{
    "operator_id":"operator-1",
    "retry_justification":"Validating that non-retryable events are blocked from republish."
  }'
cat /tmp/dlq_retry.json
```

Expected:
- HTTP `422`.
- Event is not re-published.

## 8. HITL Timeout

### Verify auto-reject

```bash
curl -sS http://svc-15:8080/health | jq
psql "$AEGIS_POSTGRES_DSN" -c "SELECT hitl_id, status, decision, updated_at FROM hitl_audit.hitl_requests ORDER BY updated_at DESC LIMIT 10;"
```

Expected:
- Timed-out HITL requests show decision `timeout_auto_reject`.

## 9. Meta-Agent Kill Switch

### Activate the kill switch

```bash
redis-cli -c SET meta_agent:kill_switch 1
```

Send a `meta.agent.request`, then inspect:

```bash
kcat -C -b localhost:9092 -t meta.agent.failed -o end -e -q
kcat -C -b localhost:9092 -t agent.created -o end -e -q
```

Expected:
- `meta.agent.failed` contains `META_AGENT_KILL_SWITCH_ACTIVE`.
- No `agent.created` event is emitted.

### Clear the kill switch

```bash
redis-cli -c DEL meta_agent:kill_switch
```

## 10. Expected Final Outcome
- All automated compliance tests pass.
- Manual endpoint, Kafka, Redis, and PostgreSQL checks match the expectations above.
- Any checklist item that differs from `contracts.json` or `system_spec.md` must be recorded as a checklist inconsistency, with the contract/spec treated as authoritative.
