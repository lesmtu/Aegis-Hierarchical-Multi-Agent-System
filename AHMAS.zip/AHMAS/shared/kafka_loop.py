"""
Shared Kafka consumer loop helper — used by SVC-11, 12, 13, 14, 22.
Mirrors the SVC-01 ReceptionistConsumerLoop pattern.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Awaitable, Callable

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer, TopicPartition

logger = logging.getLogger(__name__)

_RESTART_DELAY = 5


class AioKafkaBackend:
    """Thin backend that matches shared.events.producer.KafkaEventProducer interface."""

    def __init__(self, bootstrap_servers: str):
        self._bs = bootstrap_servers
        self._producer: AIOKafkaProducer | None = None

    async def start(self) -> None:
        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bs,
            value_serializer=lambda v: json.dumps(v).encode(),
            key_serializer=lambda k: k.encode() if k else None,
            acks="all",
        )
        await self._producer.start()
        logger.info("AioKafkaBackend started — brokers=%s", self._bs)

    async def stop(self) -> None:
        if self._producer:
            await self._producer.stop()
            logger.info("AioKafkaBackend stopped")

    def send(self, topic: str, payload: dict) -> None:
        if not self._producer:
            raise RuntimeError("Producer not started")
        key = payload.get("correlation_id") or payload.get("event_id")
        prod = self._producer

        async def _fire() -> None:
            try:
                await prod.send(topic, value=payload, key=key)
                logger.debug("Produced topic=%s corr=%s", topic, key)
            except Exception as exc:
                logger.error("Produce failed topic=%s: %s", topic, exc, exc_info=True)

        asyncio.ensure_future(_fire())


class SimpleConsumerLoop:
    """
    Generic consumer loop for services whose consumer exposes:
        await consumer.process(topic: str, message: dict) -> bool
    OR:
        await consumer.consume(envelope: dict) -> bool   (older interface)
    """

    def __init__(
        self,
        *,
        bootstrap_servers: str,
        group_id: str,
        topics: list[str],
        process_fn: Callable[[str, dict], Awaitable],
        auto_offset_reset: str = "earliest",
    ) -> None:
        self._bs = bootstrap_servers
        self._group_id = group_id
        self._topics = topics
        self._process = process_fn
        self._offset_reset = auto_offset_reset
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._run_with_restart(), name=f"kafka-{self._group_id}")
        logger.info("ConsumerLoop starting — topics=%s group=%s", self._topics, self._group_id)

    async def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        logger.info("ConsumerLoop stopped — group=%s", self._group_id)

    async def _run_with_restart(self) -> None:
        while self._running:
            try:
                await self._run()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("ConsumerLoop crashed (%s): %s. Restarting in %ds",
                             self._group_id, exc, _RESTART_DELAY, exc_info=True)
                if self._running:
                    await asyncio.sleep(_RESTART_DELAY)

    async def _run(self) -> None:
        kafka = AIOKafkaConsumer(
            *self._topics,
            bootstrap_servers=self._bs,
            group_id=self._group_id,
            auto_offset_reset=self._offset_reset,
            enable_auto_commit=False,
            value_deserializer=lambda raw: json.loads(raw.decode("utf-8")),
            session_timeout_ms=30_000,
            heartbeat_interval_ms=10_000,
            max_poll_records=10,
        )
        try:
            await kafka.start()
            logger.info("AIOKafkaConsumer connected — group=%s topics=%s", self._group_id, self._topics)
            async for msg in kafka:
                if not self._running:
                    break
                try:
                    await self._process(msg.topic, msg.value)
                except Exception as exc:
                    logger.error("Message handling error topic=%s offset=%d: %s",
                                 msg.topic, msg.offset, exc, exc_info=True)
                finally:
                    tp = TopicPartition(msg.topic, msg.partition)
                    await kafka.commit({tp: msg.offset + 1})
        finally:
            await kafka.stop()
