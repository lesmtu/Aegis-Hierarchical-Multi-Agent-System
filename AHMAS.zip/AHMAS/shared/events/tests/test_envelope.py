import json
import uuid
from pathlib import Path

from shared.events.consumer import KafkaEventConsumer
from shared.events.envelope import AegisCanonicalEventEnvelope, REQUIRED_FIELDS
from shared.events.error_codes import AegisErrorCode, ERROR_RETRYABLE, ERROR_TYPE, build_error_payload
from shared.events.schemas import event_schema, global_error_codes
from shared.events.versioning import CURRENT_ENVELOPE_VERSION, negotiate_schema_version


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _contracts() -> dict:
    return json.loads((_project_root() / "contracts.json").read_text(encoding="utf-8"))


def _uuid() -> str:
    return str(uuid.uuid4())


def _valid_envelope_kwargs() -> dict:
    return {
        "event_type": "task.received",
        "source_service": "SVC-01",
        "payload": {"task_id": _uuid()},
        "correlation_id": _uuid(),
        "trace_id": _uuid(),
        "payload_version": "1.0.0",
        "status": "success",
        "error": None,
        "idempotency_key": _uuid(),
    }


def test_envelope_required_fields_enforced():
    env = AegisCanonicalEventEnvelope.create(**_valid_envelope_kwargs())
    expected = tuple(_contracts()["global"]["event_schema"]["required"])
    assert REQUIRED_FIELDS == expected
    data = env.to_dict()
    for field_name in expected:
        invalid = dict(data)
        invalid.pop(field_name)
        try:
            AegisCanonicalEventEnvelope(**invalid).validate()
            raise AssertionError(f"missing field {field_name} did not raise")
        except (ValueError, TypeError):
            pass


def test_source_service_pattern():
    valid = ["SVC-01", "SVC-22"]
    invalid = ["SVC-1", "SVC-001", "svc-01", "SVC-0A"]
    for value in valid:
        kwargs = _valid_envelope_kwargs()
        kwargs["source_service"] = value
        AegisCanonicalEventEnvelope.create(**kwargs)
    for value in invalid:
        kwargs = _valid_envelope_kwargs()
        kwargs["source_service"] = value
        try:
            AegisCanonicalEventEnvelope.create(**kwargs)
            raise AssertionError(f"invalid source_service {value} did not raise")
        except ValueError:
            pass


def test_error_null_on_success():
    kwargs = _valid_envelope_kwargs()
    kwargs["error"] = {"error_code": "INTERNAL_ERROR"}
    try:
        AegisCanonicalEventEnvelope.create(**kwargs)
        raise AssertionError("success envelope accepted non-null error")
    except ValueError:
        pass


def test_error_codes_match_contracts():
    expected = set(global_error_codes().keys())
    actual = {code.value for code in AegisErrorCode}
    assert actual == expected
    assert len(actual) == 25


def test_retryable_flags_match_contracts():
    contracts = global_error_codes()
    for name, definition in contracts.items():
        assert ERROR_RETRYABLE[AegisErrorCode[name]] == definition["retryable"]


def test_error_type_values_match_contracts():
    contracts = global_error_codes()
    allowed = {"system", "agent", "validation", "timeout"}
    for name, definition in contracts.items():
        assert ERROR_TYPE[AegisErrorCode[name]] == definition["error_type"]
        assert ERROR_TYPE[AegisErrorCode[name]] in allowed


def test_additional_properties_false_enforced():
    env = AegisCanonicalEventEnvelope.create(**_valid_envelope_kwargs())
    env.unexpected = "x"
    try:
        env.validate()
        raise AssertionError("additional property did not raise")
    except ValueError:
        pass


def test_major_version_negotiation_routes_to_event_dlq():
    should_process, route_topic, error_payload = negotiate_schema_version("2.0.0")
    assert should_process is False
    assert route_topic == "event.dlq"
    assert error_payload["error_code"] == "SCHEMA_VERSION_MISMATCH"


def test_minor_and_patch_versions_are_processed():
    current_major = CURRENT_ENVELOPE_VERSION.split(".")[0]
    should_process_minor, route_topic_minor, error_payload_minor = negotiate_schema_version(f"{current_major}.1.0")
    should_process_patch, route_topic_patch, error_payload_patch = negotiate_schema_version(f"{current_major}.0.1")
    assert should_process_minor is True
    assert route_topic_minor is None
    assert error_payload_minor is None
    assert should_process_patch is True
    assert route_topic_patch is None
    assert error_payload_patch is None


def test_consumer_rejects_major_version_mismatch_to_dlq():
    message = AegisCanonicalEventEnvelope.create(**_valid_envelope_kwargs()).to_dict()
    message["schema_version"] = "2.0.0"
    should_process, route_topic, payload = KafkaEventConsumer().consume(message)
    assert should_process is False
    assert route_topic == "event.dlq"
    assert payload["error_code"] == "SCHEMA_VERSION_MISMATCH"


def test_build_error_payload_matches_contract_metadata():
    payload = build_error_payload(AegisErrorCode.INTERNAL_ERROR, "boom")
    contract = _contracts()["global"]["global_error_codes"]["codes"]["INTERNAL_ERROR"]
    assert payload["error_code"] == contract["code"]
    assert payload["retryable"] == contract["retryable"]
    assert payload["error_type"] == contract["error_type"]


def test_event_schema_has_11_required_fields():
    assert len(event_schema()["required"]) == 11
