import json
from pathlib import Path


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _contracts_path() -> Path:
    return _project_root() / "contracts.json"


def load_contracts() -> dict:
    return json.loads(_contracts_path().read_text(encoding="utf-8"))


def event_schema() -> dict:
    return load_contracts()["global"]["event_schema"]


def shared_schemas() -> dict:
    return load_contracts()["global"]["shared_schemas"]


def versioning_policy() -> dict:
    return load_contracts()["global"]["versioning_policy"]


def global_error_codes() -> dict:
    return load_contracts()["global"]["global_error_codes"]["codes"]
