from .envelope import AegisCanonicalEventEnvelope


class KafkaEventProducer:
    def __init__(self, producer):
        self.producer = producer

    def send(self, topic: str, envelope: AegisCanonicalEventEnvelope):
        envelope.validate()
        payload = envelope.to_dict()
        self.producer.send(topic, payload)
        return payload
