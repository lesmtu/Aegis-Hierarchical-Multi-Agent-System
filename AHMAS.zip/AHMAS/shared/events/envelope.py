import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from .schemas import event_schema
from .versioning import CURRENT_ENVELOPE_VERSION


EVENT_SCHEMA = event_schema()
REQUIRED_FIELDS = tuple(EVENT_SCHEMA["required"])
SOURCE_SERVICE_PATTERN = re.compile(EVENT_SCHEMA["properties"]["source_service"]["pattern"])
SEMVER_PATTERN = re.compile(EVENT_SCHEMA["properties"]["schema_version"]["pattern"])
STATUS_VALUES = tuple(EVENT_SCHEMA["properties"]["status"]["enum"])


@dataclass
class AegisCanonicalEventEnvelope:
    event_id: str
    event_type: str
    schema_version: str
    payload_version: str
    timestamp: str
    source_service: str
    correlation_id: str
    trace_id: str
    idempotency_key: str
    status: str
    payload: dict
    error: dict | None = None

    @classmethod
    def create(
        cls,
        event_type: str,
        source_service: str,
        payload: dict,
        correlation_id: str,
        trace_id: str,
        payload_version: str = "1.0.0",
        status: str = "success",
        error: dict | None = None,
        idempotency_key: str | None = None,
    ) -> "AegisCanonicalEventEnvelope":
        envelope = cls(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            schema_version=CURRENT_ENVELOPE_VERSION,
            payload_version=payload_version,
            timestamp=datetime.now(timezone.utc).isoformat(),
            source_service=source_service,
            correlation_id=correlation_id,
            trace_id=trace_id,
            idempotency_key=idempotency_key or str(uuid.uuid4()),
            status=status,
            payload=payload,
            error=error,
        )
        envelope.validate()
        return envelope

    def validate(self) -> None:
        raw_data = dict(self.__dict__)
        if set(raw_data.keys()) - set(EVENT_SCHEMA["properties"].keys()):
            raise ValueError("additionalProperties must be false")
        data = self.to_dict()
        for field_name in REQUIRED_FIELDS:
            if field_name not in data:
                raise ValueError(f"Missing required field: {field_name}")
        for uuid_field in ("event_id", "correlation_id", "trace_id", "idempotency_key"):
            value = getattr(self, uuid_field)
            if not isinstance(value, str):
                raise ValueError(f"{uuid_field} must be a string")
            uuid.UUID(value)
        if not isinstance(self.event_type, str) or len(self.event_type) < 1:
            raise ValueError("event_type must be a non-empty string")
        if not isinstance(self.timestamp, str):
            raise ValueError("timestamp must be a string")
        datetime.fromisoformat(self.timestamp.replace("Z", "+00:00"))
        if not SOURCE_SERVICE_PATTERN.fullmatch(self.source_service):
            raise ValueError("source_service must match ^SVC-[0-9]{2}$")
        if not SEMVER_PATTERN.fullmatch(self.schema_version):
            raise ValueError("schema_version must match semantic version pattern")
        if not SEMVER_PATTERN.fullmatch(self.payload_version):
            raise ValueError("payload_version must match semantic version pattern")
        if self.status not in STATUS_VALUES:
            raise ValueError("status must be success or error")
        if not isinstance(self.payload, dict):
            raise ValueError("payload must be an object")
        if self.status == "success" and self.error is not None:
            raise ValueError("error MUST be null when status='success'")
        if self.status == "error" and self.error is None:
            raise ValueError("error MUST be non-null when status='error'")

    def to_dict(self) -> dict:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "schema_version": self.schema_version,
            "payload_version": self.payload_version,
            "timestamp": self.timestamp,
            "source_service": self.source_service,
            "correlation_id": self.correlation_id,
            "trace_id": self.trace_id,
            "idempotency_key": self.idempotency_key,
            "status": self.status,
            "payload": self.payload,
            "error": self.error,
        }
