from .envelope import AegisCanonicalEventEnvelope
from .versioning import negotiate_schema_version


class KafkaEventConsumer:
    def __init__(self, dlq_topic: str = "event.dlq"):
        self.dlq_topic = dlq_topic

    def consume(self, message: dict) -> tuple[bool, str | None, dict]:
        should_process, route_topic, error_payload = negotiate_schema_version(message["schema_version"])
        if not should_process:
            return False, route_topic or self.dlq_topic, error_payload
        envelope = AegisCanonicalEventEnvelope(**message)
        envelope.validate()
        return True, None, envelope.to_dict()
