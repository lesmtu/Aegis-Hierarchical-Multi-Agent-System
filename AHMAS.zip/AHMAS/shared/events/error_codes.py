from enum import Enum

from .schemas import global_error_codes


ERROR_CODE_DEFINITIONS = global_error_codes()

AegisErrorCode = Enum(
    "AegisErrorCode",
    {name: definition["code"] for name, definition in ERROR_CODE_DEFINITIONS.items()},
    type=str,
)

ERROR_RETRYABLE = {
    AegisErrorCode[name]: definition["retryable"]
    for name, definition in ERROR_CODE_DEFINITIONS.items()
}

ERROR_TYPE = {
    AegisErrorCode[name]: definition["error_type"]
    for name, definition in ERROR_CODE_DEFINITIONS.items()
}


def build_error_payload(error_code: AegisErrorCode, message: str, details: dict | None = None) -> dict:
    payload = {
        "error_code": error_code.value,
        "error_type": ERROR_TYPE[error_code],
        "retryable": ERROR_RETRYABLE[error_code],
        "message": message,
    }
    if details is not None:
        payload["details"] = details
    return payload
