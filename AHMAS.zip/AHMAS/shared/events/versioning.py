import logging

from .error_codes import AegisErrorCode, build_error_payload
from .schemas import versioning_policy


VERSIONING_POLICY = versioning_policy()
CURRENT_ENVELOPE_VERSION = VERSIONING_POLICY["current_envelope_version"]
LOGGER = logging.getLogger(__name__)


def negotiate_schema_version(incoming_version: str) -> tuple[bool, str | None, dict | None]:
    current_major, current_minor, _ = CURRENT_ENVELOPE_VERSION.split(".")
    incoming_major, incoming_minor, _ = incoming_version.split(".")
    if incoming_major != current_major:
        return (
            False,
            "event.dlq",
            build_error_payload(
                AegisErrorCode.SCHEMA_VERSION_MISMATCH,
                f"Schema version {incoming_version} is incompatible with supported version {CURRENT_ENVELOPE_VERSION}.",
            ),
        )
    if incoming_minor != current_minor:
        LOGGER.warning(
            "Processing MINOR schema version mismatch: incoming=%s supported=%s",
            incoming_version,
            CURRENT_ENVELOPE_VERSION,
        )
    return True, None, None
