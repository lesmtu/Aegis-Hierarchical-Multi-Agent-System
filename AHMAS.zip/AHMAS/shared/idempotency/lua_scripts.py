import json
from pathlib import Path


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _contracts_path() -> Path:
    return _project_root() / "contracts.json"


def _load_lua_script() -> str:
    contracts = json.loads(_contracts_path().read_text(encoding="utf-8"))
    return contracts["global"]["idempotency_policy"]["lua_script"]


def _load_services_required_to_implement():
    contracts = json.loads(_contracts_path().read_text(encoding="utf-8"))
    return tuple(contracts["global"]["idempotency_policy"]["services_required_to_implement"])


IDEMPOTENCY_LUA_SCRIPT = _load_lua_script()
SERVICES_REQUIRED_TO_IMPLEMENT = _load_services_required_to_implement()
