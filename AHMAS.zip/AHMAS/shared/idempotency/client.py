import json
import re
from datetime import datetime, timezone

from .exceptions import DuplicateMessageException
from .lua_scripts import IDEMPOTENCY_LUA_SCRIPT, SERVICES_REQUIRED_TO_IMPLEMENT


class IdempotencyClient:
    TTL_SECONDS = 86400
    STALE_LOCK_SECONDS = 600
    SERVICE_ID_PATTERN = re.compile(r"^SVC-[0-9]{2}$")

    def __init__(self, redis_client, service_id: str):
        if not self.SERVICE_ID_PATTERN.fullmatch(service_id):
            raise ValueError("service_id must match ^SVC-[0-9]{2}$")
        if service_id not in SERVICES_REQUIRED_TO_IMPLEMENT:
            raise ValueError("service_id must be listed in contracts.json idempotency_policy.services_required_to_implement")
        self.redis = redis_client
        self.service_id = service_id
        self._lua = self.redis.register_script(IDEMPOTENCY_LUA_SCRIPT)

    def _redis_key(self, idempotency_key: str) -> str:
        return f"idempotency:{self.service_id}:{idempotency_key}"

    def _value(self, event_id: str, status: str) -> str:
        return json.dumps(
            {
                "processed_at": datetime.now(timezone.utc).isoformat(),
                "service_id": self.service_id,
                "event_id": event_id,
                "status": status,
            }
        )

    def check_and_set(self, idempotency_key: str, event_id: str) -> bool:
        redis_key = self._redis_key(idempotency_key)
        value = self._value(event_id, "processing")
        result = self._lua(keys=[redis_key], args=[value, str(self.TTL_SECONDS)])
        if result == 1:
            return True
        raw = self.redis.get(redis_key)
        if raw is None:
            return False
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        if data["status"] == "processing" and self.check_stale_lock(idempotency_key):
            self.redis.delete(redis_key)
            return self._lua(keys=[redis_key], args=[value, str(self.TTL_SECONDS)]) == 1
        if data["status"] in {"completed", "processing"}:
            return False
        if data["status"] == "failed":
            self.redis.set(redis_key, value, xx=True, keepttl=True)
            return True
        raise DuplicateMessageException(redis_key)

    def mark_completed(self, idempotency_key: str, event_id: str) -> None:
        redis_key = self._redis_key(idempotency_key)
        self.redis.set(redis_key, self._value(event_id, "completed"), xx=True, keepttl=True)

    def mark_failed(self, idempotency_key: str, event_id: str) -> None:
        redis_key = self._redis_key(idempotency_key)
        self.redis.set(redis_key, self._value(event_id, "failed"), xx=True, keepttl=True)

    def check_stale_lock(self, idempotency_key: str) -> bool:
        redis_key = self._redis_key(idempotency_key)
        raw = self.redis.get(redis_key)
        if raw is None:
            return False
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        if data["status"] != "processing":
            return False
        processed_at = datetime.fromisoformat(data["processed_at"])
        age_seconds = (datetime.now(timezone.utc) - processed_at).total_seconds()
        return age_seconds > self.STALE_LOCK_SECONDS
