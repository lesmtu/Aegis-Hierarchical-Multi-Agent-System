class DuplicateMessageException(Exception):
    pass
