import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from shared.idempotency.client import IdempotencyClient
from shared.idempotency.lua_scripts import IDEMPOTENCY_LUA_SCRIPT, SERVICES_REQUIRED_TO_IMPLEMENT


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _contracts():
    return json.loads((_project_root() / "contracts.json").read_text(encoding="utf-8"))


class FakeRedis:
    def __init__(self):
        self.store = {}
        self.expiry = {}

    def register_script(self, script):
        def _runner(keys, args):
            key = keys[0]
            value = args[0]
            ttl = int(args[1])
            if key in self.store:
                return 0
            self.store[key] = value
            self.expiry[key] = ttl
            return 1

        return _runner

    def get(self, key):
        return self.store.get(key)

    def set(self, key, value, ex=None, xx=False, keepttl=False):
        if xx and key not in self.store:
            return False
        self.store[key] = value
        if ex is not None:
            self.expiry[key] = ex
        elif not keepttl and key in self.expiry:
            del self.expiry[key]
        return True

    def ttl(self, key):
        return self.expiry[key]

    def exists(self, key):
        return 1 if key in self.store else 0


def test_lua_script_matches_contracts_exactly():
    assert IDEMPOTENCY_LUA_SCRIPT == _contracts()["global"]["idempotency_policy"]["lua_script"]


def test_services_required_to_implement_match_contracts_exactly():
    assert SERVICES_REQUIRED_TO_IMPLEMENT == tuple(_contracts()["global"]["idempotency_policy"]["services_required_to_implement"])


def test_lua_script_returns_1_on_new_key():
    client = IdempotencyClient(FakeRedis(), "SVC-01")
    assert client.check_and_set("test-key-1", "550e8400-e29b-41d4-a716-446655440001") is True


def test_lua_script_returns_0_on_existing_key():
    client = IdempotencyClient(FakeRedis(), "SVC-01")
    client.check_and_set("test-key-2", "550e8400-e29b-41d4-a716-446655440002")
    assert client.check_and_set("test-key-2", "550e8400-e29b-41d4-a716-446655440002") is False


def test_key_schema_matches_contracts():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-05")
    client.check_and_set("abc-key", "550e8400-e29b-41d4-a716-446655440003")
    assert redis_client.exists("idempotency:SVC-05:abc-key") == 1


def test_ttl_is_86400():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-01")
    client.check_and_set("ttl-key", "550e8400-e29b-41d4-a716-446655440004")
    ttl = redis_client.ttl("idempotency:SVC-01:ttl-key")
    assert ttl == 86400


def test_mark_completed_keeps_ttl():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-01")
    client.check_and_set("done-key", "550e8400-e29b-41d4-a716-446655440005")
    client.mark_completed("done-key", "550e8400-e29b-41d4-a716-446655440005")
    ttl = redis_client.ttl("idempotency:SVC-01:done-key")
    payload = json.loads(redis_client.get("idempotency:SVC-01:done-key"))
    assert ttl == 86400
    assert payload["status"] == "completed"


def test_mark_failed_keeps_ttl():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-01")
    client.check_and_set("failed-key", "550e8400-e29b-41d4-a716-446655440006")
    client.mark_failed("failed-key", "550e8400-e29b-41d4-a716-446655440006")
    ttl = redis_client.ttl("idempotency:SVC-01:failed-key")
    payload = json.loads(redis_client.get("idempotency:SVC-01:failed-key"))
    assert ttl == 86400
    assert payload["status"] == "failed"


def test_stale_lock_detection_at_10_minutes():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-01")
    stale_time = (datetime.now(timezone.utc) - timedelta(seconds=601)).isoformat()
    redis_client.set(
        "idempotency:SVC-01:stale-key",
        json.dumps(
            {
                "processed_at": stale_time,
                "service_id": "SVC-01",
                "event_id": "550e8400-e29b-41d4-a716-446655440007",
                "status": "processing",
            }
        ),
        ex=86400,
    )
    assert client.check_stale_lock("stale-key") is True


def test_non_stale_processing_lock_under_10_minutes():
    redis_client = FakeRedis()
    client = IdempotencyClient(redis_client, "SVC-01")
    fresh_time = (datetime.now(timezone.utc) - timedelta(seconds=599)).isoformat()
    redis_client.set(
        "idempotency:SVC-01:fresh-key",
        json.dumps(
            {
                "processed_at": fresh_time,
                "service_id": "SVC-01",
                "event_id": "550e8400-e29b-41d4-a716-446655440008",
                "status": "processing",
            }
        ),
        ex=86400,
    )
    assert client.check_stale_lock("fresh-key") is False
