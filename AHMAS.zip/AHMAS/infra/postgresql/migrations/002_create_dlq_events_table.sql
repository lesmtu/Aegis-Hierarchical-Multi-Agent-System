CREATE TABLE IF NOT EXISTS dlq_audit.dlq_events (
    dlq_id UUID PRIMARY KEY,
    origin_topic VARCHAR(50) NOT NULL CHECK (origin_topic IN ('task.dlq', 'event.dlq')),
    producer_service VARCHAR(10) NOT NULL,
    original_event_id UUID NOT NULL,
    task_id UUID,
    error_code VARCHAR(100) NOT NULL,
    error_details TEXT NOT NULL,
    original_payload JSONB NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'pending_manual_review'
        CHECK (status IN ('pending_manual_review','pending_retry','retried','resolved','retry_failed')),
    last_retry_at TIMESTAMPTZ,
    resolved_by TEXT,
    resolution_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS dlq_events_dlq_id_unique ON dlq_audit.dlq_events(dlq_id);
CREATE INDEX IF NOT EXISTS dlq_events_status_idx ON dlq_audit.dlq_events(status);
CREATE INDEX IF NOT EXISTS dlq_events_error_code_idx ON dlq_audit.dlq_events(error_code);
CREATE INDEX IF NOT EXISTS dlq_events_created_at_idx ON dlq_audit.dlq_events(created_at);
CREATE INDEX IF NOT EXISTS dlq_events_task_id_idx ON dlq_audit.dlq_events(task_id);
