CREATE TABLE IF NOT EXISTS dlq_audit.dlq_retry_history (
    retry_id BIGSERIAL PRIMARY KEY,
    dlq_id UUID NOT NULL REFERENCES dlq_audit.dlq_events(dlq_id) ON DELETE CASCADE,
    operator_id TEXT NOT NULL,
    retry_justification TEXT NOT NULL,
    override_payload JSONB,
    retried_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS dlq_retry_history_dlq_id_idx ON dlq_audit.dlq_retry_history(dlq_id);
CREATE INDEX IF NOT EXISTS dlq_retry_history_retried_at_idx ON dlq_audit.dlq_retry_history(retried_at);
