CREATE TABLE IF NOT EXISTS dlq_audit.dlq_resolution_log (
    resolution_id BIGSERIAL PRIMARY KEY,
    dlq_id UUID NOT NULL REFERENCES dlq_audit.dlq_events(dlq_id) ON DELETE CASCADE,
    operator_id TEXT NOT NULL,
    resolution_notes TEXT NOT NULL,
    resolved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS dlq_resolution_log_dlq_id_idx ON dlq_audit.dlq_resolution_log(dlq_id);
CREATE INDEX IF NOT EXISTS dlq_resolution_log_resolved_at_idx ON dlq_audit.dlq_resolution_log(resolved_at);
