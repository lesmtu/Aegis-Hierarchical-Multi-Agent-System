#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from pathlib import Path


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_contracts() -> dict:
    with (project_root() / "contracts.json").open("r", encoding="utf-8") as handle:
        return json.load(handle)


def service_by_id(contracts: dict, service_id: str) -> dict:
    for service in contracts["services"]:
        if service["service_id"] == service_id:
            return service
    raise KeyError(f"service not found: {service_id}")


def collection_definitions() -> dict[str, dict]:
    contracts = load_contracts()
    qdrant_cluster = service_by_id(contracts, "SVC-16")["high_availability"]["qdrant_cluster"]
    prompt_templates = service_by_id(contracts, "SVC-21")["dependencies"]["storage"]["qdrant"]
    replication_factor = qdrant_cluster["collection_replication_factor"]
    shard_count = qdrant_cluster["shard_count"]

    return {
        "episodic": {
            "vectors": {"size": 1024, "distance": "Cosine"},
            "replication_factor": replication_factor,
            "write_consistency_factor": qdrant_cluster["collection_write_consistency_factor"],
            "shard_number": shard_count,
        },
        "semantic": {
            "vectors": {"size": 1024, "distance": "Cosine"},
            "replication_factor": replication_factor,
            "write_consistency_factor": qdrant_cluster["collection_write_consistency_factor"],
            "shard_number": shard_count,
        },
        "prompt_templates": {
            "vectors": {
                "size": prompt_templates["embedding_dimension"],
                "distance": prompt_templates["distance_metric"].capitalize(),
            },
            "replication_factor": replication_factor,
            "write_consistency_factor": qdrant_cluster["collection_write_consistency_factor"],
            "shard_number": shard_count,
        },
    }


def request(method: str, url: str, payload: dict | None = None) -> tuple[int, str]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            body = response.read().decode("utf-8")
            return response.status, body
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def ensure_collection(base_url: str, name: str, config: dict) -> None:
    status, _ = request("PUT", f"{base_url}/collections/{name}", config)
    if status not in (200, 201):
        raise RuntimeError(f"failed to create or update collection {name}: HTTP {status}")


def main() -> int:
    base_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:6333"
    for collection_name, config in collection_definitions().items():
        ensure_collection(base_url, collection_name, config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
