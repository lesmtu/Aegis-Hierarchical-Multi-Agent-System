#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CONTRACTS_PATH="${PROJECT_ROOT}/contracts.json"
QDRANT_URL="${1:-http://localhost:6333}"

if [[ ! -f "${CONTRACTS_PATH}" ]]; then
  echo "contracts.json not found at ${CONTRACTS_PATH}" >&2
  exit 1
fi

expected_replication_factor="$(python3 - <<'PY' "${CONTRACTS_PATH}"
import json
import sys
from pathlib import Path

contracts = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
for service in contracts["services"]:
    if service["service_id"] == "SVC-16":
        print(service["high_availability"]["qdrant_cluster"]["collection_replication_factor"])
        break
else:
    raise SystemExit("SVC-16 not found in contracts.json")
PY
)"

expected_shard_count="$(python3 - <<'PY' "${CONTRACTS_PATH}"
import json
import sys
from pathlib import Path

contracts = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
for service in contracts["services"]:
    if service["service_id"] == "SVC-16":
        print(service["high_availability"]["qdrant_cluster"]["shard_count"])
        break
else:
    raise SystemExit("SVC-16 not found in contracts.json")
PY
)"

collections_json="$(curl -fsSL "${QDRANT_URL}/collections")"
collection_names="$(printf '%s' "${collections_json}" | python3 - <<'PY'
import json
import sys

payload = json.load(sys.stdin)
for item in payload["result"]["collections"]:
    print(item["name"])
PY
)"

for expected in episodic semantic prompt_templates; do
  grep -qx "${expected}" <<< "${collection_names}" || {
    echo "missing collection: ${expected}" >&2
    exit 1
  }
done

for collection in episodic semantic prompt_templates; do
  detail_json="$(curl -fsSL "${QDRANT_URL}/collections/${collection}")"
  python3 - <<'PY' "${collection}" "${expected_replication_factor}" "${expected_shard_count}" <<< "${detail_json}"
import json
import sys

collection = sys.argv[1]
expected_replication = int(sys.argv[2])
expected_shards = int(sys.argv[3])
payload = json.load(sys.stdin)
config = payload["result"]["config"]["params"]
actual_replication = int(config["replication_factor"])
actual_shards = int(config["shard_number"])
if actual_replication != expected_replication:
    raise SystemExit(f"{collection}: replication_factor={actual_replication} expected={expected_replication}")
if actual_shards != expected_shards:
    raise SystemExit(f"{collection}: shard_number={actual_shards} expected={expected_shards}")
PY
done

echo "Qdrant verification passed"
