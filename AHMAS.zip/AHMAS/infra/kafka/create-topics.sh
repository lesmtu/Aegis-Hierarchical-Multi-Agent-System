#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOPICS_CONFIG_PATH="${SCRIPT_DIR}/topics-config.json"
BOOTSTRAP_SERVER="${BOOTSTRAP_SERVER:-kafka-0.kafka-headless:9092,kafka-1.kafka-headless:9092,kafka-2.kafka-headless:9092}"
KAFKA_TOPICS_BIN="${KAFKA_TOPICS_BIN:-kafka-topics.sh}"

python3 - <<'PY' "${TOPICS_CONFIG_PATH}" | while IFS=$'\t' read -r topic_name partitions replication_factor retention_ms cleanup_policy; do
import json
import sys

topics = json.load(open(sys.argv[1], "r", encoding="utf-8"))
for topic in topics:
    print(
        f"{topic['topic_name']}\t{topic['partitions']}\t{topic['replication_factor']}\t{topic['retention_ms']}\t{topic['cleanup_policy']}"
    )
PY
  "${KAFKA_TOPICS_BIN}" \
    --bootstrap-server "${BOOTSTRAP_SERVER}" \
    --if-not-exists \
    --create \
    --topic "${topic_name}" \
    --partitions "${partitions}" \
    --replication-factor "${replication_factor}" \
    --config "retention.ms=${retention_ms}" \
    --config "cleanup.policy=${cleanup_policy}"
done
