#!/usr/bin/env python3
import json
import sys
from pathlib import Path

CONTRACTS_PATH = Path(__file__).resolve().parent.parent.parent / "contracts.json"
TOPICS_CONFIG_PATH = Path(__file__).resolve().parent / "topics-config.json"
REQUIRED_FIELDS = (
    "topic_name",
    "partitions",
    "replication_factor",
    "retention_ms",
    "cleanup_policy",
)


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def build_expected_topics(contracts):
    topics = contracts["global"]["topics"]
    return [
        {field: topic[field] for field in REQUIRED_FIELDS}
        for topic in topics.values()
    ]


def main():
    contracts = load_json(CONTRACTS_PATH)
    configured_topics = load_json(TOPICS_CONFIG_PATH)
    expected_topics = build_expected_topics(contracts)

    if len(expected_topics) != 25:
        raise AssertionError(f"Expected 25 topics in /contracts.json, found {len(expected_topics)}")
    if len(configured_topics) != 25:
        raise AssertionError(f"Expected 25 topics in topics-config.json, found {len(configured_topics)}")

    expected_by_name = {topic["topic_name"]: topic for topic in expected_topics}
    configured_by_name = {topic["topic_name"]: topic for topic in configured_topics}

    if set(expected_by_name) != set(configured_by_name):
        missing = sorted(set(expected_by_name) - set(configured_by_name))
        extra = sorted(set(configured_by_name) - set(expected_by_name))
        raise AssertionError(
            json.dumps(
                {
                    "missing_topics": missing,
                    "extra_topics": extra,
                },
                indent=2,
            )
        )

    for topic_name, expected in expected_by_name.items():
        actual = configured_by_name[topic_name]
        if tuple(actual.keys()) != REQUIRED_FIELDS:
            raise AssertionError(
                f"Topic {topic_name} fields must match exactly {REQUIRED_FIELDS}, found {tuple(actual.keys())}"
            )
        if actual != expected:
            raise AssertionError(
                json.dumps(
                    {
                        "topic_name": topic_name,
                        "expected": expected,
                        "actual": actual,
                    },
                    indent=2,
                )
            )
        if actual["cleanup_policy"] != "delete":
            raise AssertionError(f"Topic {topic_name} cleanup_policy must be delete")

    sys.stdout.write("OK\n")


if __name__ == "__main__":
    main()
