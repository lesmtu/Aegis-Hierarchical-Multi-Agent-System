#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path
from urllib import request


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONTRACTS_PATH = PROJECT_ROOT / "contracts.json"
REGISTRY_URL = os.environ.get("SCHEMA_REGISTRY_URL", "http://schema-registry:8081").rstrip("/")


def load_contracts() -> dict:
    with CONTRACTS_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def register_schema(subject: str, schema: dict) -> None:
    payload = json.dumps(
        {
            "schemaType": "JSON",
            "schema": json.dumps(schema, separators=(",", ":")),
        }
    ).encode("utf-8")
    req = request.Request(
        f"{REGISTRY_URL}/subjects/{subject}/versions",
        data=payload,
        headers={"Content-Type": "application/vnd.schemaregistry.v1+json"},
        method="POST",
    )
    with request.urlopen(req) as response:
        if response.status not in {200, 201}:
            raise RuntimeError(f"Schema registration failed for {subject}: HTTP {response.status}")


def main() -> int:
    contracts = load_contracts()
    register_schema("AegisCanonicalEventEnvelope-value", contracts["global"]["event_schema"])
    for schema_name, schema in contracts["global"]["shared_schemas"].items():
        register_schema(f"{schema_name}-value", schema)
    sys.stdout.write("OK\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
