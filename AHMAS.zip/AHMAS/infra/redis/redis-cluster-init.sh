#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CONTRACTS_PATH="${PROJECT_ROOT}/contracts.json"
REDIS_CLI_BIN="${REDIS_CLI_BIN:-redis-cli}"

python3 - <<'PY' "${CONTRACTS_PATH}" >/dev/null
import json
import sys

contracts = json.load(open(sys.argv[1], "r", encoding="utf-8"))
assert contracts["global"]["idempotency_policy"]["ttl_seconds"] == 86400
PY

"${REDIS_CLI_BIN}" --cluster create \
  redis-cluster-0.redis-cluster:6379 \
  redis-cluster-1.redis-cluster:6379 \
  redis-cluster-2.redis-cluster:6379 \
  redis-cluster-3.redis-cluster:6379 \
  redis-cluster-4.redis-cluster:6379 \
  redis-cluster-5.redis-cluster:6379 \
  --cluster-replicas 1 \
  --cluster-yes
