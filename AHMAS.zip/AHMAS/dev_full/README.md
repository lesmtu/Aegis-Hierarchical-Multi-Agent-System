# Full Dev Deployment

Run:

```bash
docker compose -f dev_full/docker-compose.full.yml up --build
```

For `svc-21`, the dev stack includes an `ollama-proxy` sidecar on the WSL host.
Keep your local Ollama running on `127.0.0.1:11434`; containers will reach it through
`host.docker.internal:11435`.
