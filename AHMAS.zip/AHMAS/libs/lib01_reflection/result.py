from dataclasses import dataclass
from typing import List


@dataclass
class ReflectionResult:
    confidence_score: float
    identified_gaps: List[str]
    correction_suggestions: List[str]
    should_retry: bool
    should_escalate: bool

    def __post_init__(self) -> None:
        assert 0.0 <= self.confidence_score <= 1.0, (
            f"confidence_score must be [0.0, 1.0], got {self.confidence_score}"
        )
        assert isinstance(self.identified_gaps, list)
        assert isinstance(self.correction_suggestions, list)
        assert all(isinstance(gap, str) for gap in self.identified_gaps)
        assert all(isinstance(suggestion, str) for suggestion in self.correction_suggestions)
        assert isinstance(self.should_retry, bool)
        assert isinstance(self.should_escalate, bool)

    def to_dict(self) -> dict:
        return {
            "confidence_score": self.confidence_score,
            "identified_gaps": self.identified_gaps,
            "correction_suggestions": self.correction_suggestions,
            "should_retry": self.should_retry,
            "should_escalate": self.should_escalate,
        }
