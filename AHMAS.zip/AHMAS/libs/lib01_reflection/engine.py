import json
import logging

from .prompts import build_reflection_prompt
from .result import ReflectionResult

logger = logging.getLogger(__name__)

REFLECTION_THRESHOLD = 0.75
ESCALATION_THRESHOLD = 0.375


class ReflectionEngine:
    def __init__(self, llm_client, threshold: float = REFLECTION_THRESHOLD):
        self.llm = llm_client
        self.threshold = threshold

    def evaluate(
        self,
        task_description: str,
        output: str,
        context: dict,
    ) -> ReflectionResult:
        prompt = build_reflection_prompt(task_description, output, context)

        try:
            response = self.llm.complete(
                prompt=prompt,
                response_format={"type": "json_object"},
                max_tokens=2048,
                temperature=0.0,
            )
            raw = json.loads(response.text)
            confidence_score = float(raw["confidence_score"])
            identified_gaps = raw["identified_gaps"]
            correction_suggestions = raw["correction_suggestions"]
            should_retry = confidence_score < self.threshold
            should_escalate = confidence_score < ESCALATION_THRESHOLD
            return ReflectionResult(
                confidence_score=confidence_score,
                identified_gaps=identified_gaps,
                correction_suggestions=correction_suggestions,
                should_retry=should_retry,
                should_escalate=should_escalate,
            )
        except Exception as exc:
            logger.error("LIB-01 LLM call failed: %s", exc)
            return ReflectionResult(
                confidence_score=0.0,
                identified_gaps=["Reflection engine LLM call failed"],
                correction_suggestions=["Retry with fresh context"],
                should_retry=True,
                should_escalate=True,
            )
