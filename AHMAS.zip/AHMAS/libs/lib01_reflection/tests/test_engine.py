import json
import sys
from dataclasses import fields
from pathlib import Path

import pytest


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


sys.path.insert(0, str(_project_root()))

from libs.lib01_reflection.engine import ReflectionEngine
from libs.lib01_reflection.prompts import build_reflection_prompt
from libs.lib01_reflection.result import ReflectionResult


def _contracts() -> dict:
    return json.loads((_project_root() / "contracts.json").read_text(encoding="utf-8"))


class FakeResponse:
    def __init__(self, text: str):
        self.text = text


class FakeLLM:
    def __init__(self, payload=None, error: Exception | None = None):
        self.payload = payload
        self.error = error
        self.calls = []

    def complete(self, **kwargs):
        self.calls.append(kwargs)
        if self.error is not None:
            raise self.error
        return FakeResponse(json.dumps(self.payload))


def test_reflection_result_schema_compliance():
    result = ReflectionResult(
        confidence_score=0.85,
        identified_gaps=["gap1"],
        correction_suggestions=["fix1"],
        should_retry=False,
        should_escalate=False,
    )
    data = result.to_dict()
    expected = _contracts()["global"]["shared_schemas"]["ReflectionResult"]
    required = expected["required"]
    assert [field.name for field in fields(ReflectionResult)] == required
    assert all(key in data for key in required)
    assert set(data.keys()) == set(required)
    assert expected["additionalProperties"] is False


def test_confidence_bounds_enforced():
    with pytest.raises(AssertionError):
        ReflectionResult(
            confidence_score=1.5,
            identified_gaps=[],
            correction_suggestions=[],
            should_retry=False,
            should_escalate=False,
        )
    with pytest.raises(AssertionError):
        ReflectionResult(
            confidence_score=-0.1,
            identified_gaps=[],
            correction_suggestions=[],
            should_retry=True,
            should_escalate=True,
        )


def test_reflection_result_item_and_boolean_types_enforced():
    with pytest.raises(AssertionError):
        ReflectionResult(
            confidence_score=0.5,
            identified_gaps=[1],
            correction_suggestions=[],
            should_retry=True,
            should_escalate=False,
        )
    with pytest.raises(AssertionError):
        ReflectionResult(
            confidence_score=0.5,
            identified_gaps=[],
            correction_suggestions=[1],
            should_retry=True,
            should_escalate=False,
        )
    with pytest.raises(AssertionError):
        ReflectionResult(
            confidence_score=0.5,
            identified_gaps=[],
            correction_suggestions=[],
            should_retry=1,
            should_escalate=False,
        )


@pytest.mark.parametrize(
    ("confidence_score", "should_retry"),
    [(0.74, True), (0.75, False), (1.0, False)],
)
def test_should_retry_logic(confidence_score: float, should_retry: bool):
    llm = FakeLLM(
        payload={
            "confidence_score": confidence_score,
            "identified_gaps": [],
            "correction_suggestions": [],
            "should_retry": False,
            "should_escalate": False,
        }
    )
    result = ReflectionEngine(llm).evaluate("task", "output", {})
    assert result.should_retry is should_retry


@pytest.mark.parametrize(
    ("confidence_score", "should_escalate"),
    [(0.374, True), (0.375, False), (0.9, False)],
)
def test_should_escalate_logic(confidence_score: float, should_escalate: bool):
    llm = FakeLLM(
        payload={
            "confidence_score": confidence_score,
            "identified_gaps": [],
            "correction_suggestions": [],
            "should_retry": False,
            "should_escalate": False,
        }
    )
    result = ReflectionEngine(llm).evaluate("task", "output", {})
    assert result.should_escalate is should_escalate


def test_llm_failure_fallback():
    result = ReflectionEngine(FakeLLM(error=RuntimeError("failure"))).evaluate("task", "output", {})
    assert result.confidence_score == 0.0
    assert result.should_retry is True
    assert result.should_escalate is True


def test_prompt_enforces_strict_json_output_schema():
    prompt = build_reflection_prompt("task", "output", {"key": "value"})
    assert "Respond ONLY with valid JSON matching this exact schema" in prompt
    assert '"confidence_score": <float 0.0-1.0>' in prompt
    assert '"identified_gaps": [<string>, ...]' in prompt
    assert '"correction_suggestions": [<string>, ...]' in prompt
    assert '"should_retry": <boolean>' in prompt
    assert '"should_escalate": <boolean>' in prompt
