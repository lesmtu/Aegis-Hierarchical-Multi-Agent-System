def build_reflection_prompt(task_description: str, output: str, context: dict) -> str:
    return f"""You are a critical evaluator. Assess the quality of this output.

TASK DESCRIPTION:
{task_description}

OUTPUT TO EVALUATE:
{output}

CONTEXT:
{context}

Respond ONLY with valid JSON matching this exact schema:
{{
  "confidence_score": <float 0.0-1.0>,
  "identified_gaps": [<string>, ...],
  "correction_suggestions": [<string>, ...],
  "should_retry": <boolean>,
  "should_escalate": <boolean>
}}

Ask:
- Given this task description and this output, identify any errors, gaps, inconsistencies, or missing elements

Evaluation criteria:
- confidence_score: How well does the output fulfill the task description? (0.0=completely wrong, 1.0=perfect)
- identified_gaps: List specific errors, missing elements, logical inconsistencies
- correction_suggestions: Specific actionable improvements
- should_retry: true if confidence_score < 0.75
- should_escalate: true if confidence_score < 0.375

Output ONLY the JSON object. No other text."""
