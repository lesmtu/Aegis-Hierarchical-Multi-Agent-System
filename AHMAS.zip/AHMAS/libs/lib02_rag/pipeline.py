import logging

import httpx

from .context import RAGContext

logger = logging.getLogger(__name__)


class RAGPipeline:
    def __init__(self, svc16_base_url: str, timeout_seconds: float = 10.0):
        self.base_url = svc16_base_url.rstrip("/")
        self.timeout = timeout_seconds
        self.client = httpx.Client(timeout=timeout_seconds)

    def retrieve_and_inject(
        self,
        query: str,
        session_id: str,
        task_id: str,
        top_k: int = 5,
    ) -> RAGContext:
        request_body = {
            "query": query,
            "session_id": session_id,
            "task_id": task_id,
            "top_k": max(1, min(top_k, 10)),
            "memory_types": ["episodic", "semantic", "working"],
        }

        try:
            response = self.client.post(
                f"{self.base_url}/memory/retrieve",
                json=request_body,
            )
            response.raise_for_status()
            data = response.json()
            return RAGContext(
                context_chunks=data["context_chunks"],
                source_ids=data["source_ids"],
                retrieval_scores=data["retrieval_scores"],
                degraded_mode=data["degraded_mode"],
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            logger.warning("LIB-02: Memory Service unavailable: %s", exc)
            return RAGContext.empty_degraded()
        except httpx.HTTPStatusError as exc:
            logger.error("LIB-02: SVC-16 returned HTTP error: %s", exc)
            return RAGContext.empty_degraded()
        except Exception as exc:
            logger.error("LIB-02: Unexpected error calling SVC-16: %s", exc)
            return RAGContext.empty_degraded()
