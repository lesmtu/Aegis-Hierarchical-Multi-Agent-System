import json
import sys
from dataclasses import fields
from pathlib import Path
from uuid import uuid4

import httpx
import pytest


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


sys.path.insert(0, str(_project_root()))

from libs.lib02_rag.context import RAGContext
from libs.lib02_rag.pipeline import RAGPipeline


def _contracts() -> dict:
    return json.loads((_project_root() / "contracts.json").read_text(encoding="utf-8"))


class FakeResponse:
    def __init__(self, payload: dict):
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict:
        return self._payload


def test_ragcontext_schema_compliance():
    ctx = RAGContext(["chunk1"], ["id1"], [0.9], False)
    data = ctx.to_dict()
    expected = _contracts()["global"]["shared_schemas"]["RAGContext"]
    required = expected["required"]
    assert [field.name for field in fields(RAGContext)] == required
    assert set(data.keys()) == set(required)
    assert expected["additionalProperties"] is False
    with pytest.raises(AttributeError):
        ctx.extra_field = "forbidden"


def test_context_chunks_max_10():
    with pytest.raises(AssertionError):
        RAGContext(["c"] * 11, ["id"] * 11, [0.5] * 11, False)


@pytest.mark.parametrize("score", [-0.1, 1.1])
def test_retrieval_scores_range_enforced(score: float):
    with pytest.raises(AssertionError):
        RAGContext(["chunk"], ["id"], [score], False)


def test_source_ids_and_scores_lengths_match():
    with pytest.raises(AssertionError):
        RAGContext(["chunk"], ["id1", "id2"], [0.5], False)


def test_ragcontext_item_and_boolean_types_enforced():
    with pytest.raises(AssertionError):
        RAGContext([1], ["id1"], [0.5], False)
    with pytest.raises(AssertionError):
        RAGContext(["chunk"], [1], [0.5], False)
    with pytest.raises(AssertionError):
        RAGContext(["chunk"], ["id1"], [0.5], 1)


def test_svc16_call_correctness_and_top_k_cap():
    session_id = str(uuid4())
    task_id = str(uuid4())
    calls = []
    pipeline = RAGPipeline("http://svc16.local")

    def fake_post(url: str, json: dict):
        calls.append((url, json))
        return FakeResponse(
            {
                "context_chunks": ["chunk1", "chunk2"],
                "source_ids": [str(uuid4()), str(uuid4())],
                "retrieval_scores": [0.8, 0.6],
                "degraded_mode": False,
            }
        )

    pipeline.client.post = fake_post
    ctx = pipeline.retrieve_and_inject(
        query="find prior work",
        session_id=session_id,
        task_id=task_id,
        top_k=50,
    )

    expected_request = _contracts()["global"]["shared_schemas"]["MemoryRetrieveRequest"]
    assert calls[0][0] == "http://svc16.local/memory/retrieve"
    assert set(calls[0][1].keys()) == set(expected_request["required"])
    assert calls[0][1]["query"] == "find prior work"
    assert calls[0][1]["session_id"] == session_id
    assert calls[0][1]["task_id"] == task_id
    assert calls[0][1]["top_k"] == 10
    assert calls[0][1]["memory_types"] == ["episodic", "semantic", "working"]
    assert ctx.degraded_mode is False


def test_top_k_minimum_enforced():
    session_id = str(uuid4())
    task_id = str(uuid4())
    calls = []
    pipeline = RAGPipeline("http://svc16.local")

    def fake_post(url: str, json: dict):
        calls.append((url, json))
        return FakeResponse(
            {
                "context_chunks": [],
                "source_ids": [],
                "retrieval_scores": [],
                "degraded_mode": False,
            }
        )

    pipeline.client.post = fake_post
    pipeline.retrieve_and_inject(
        query="find prior work",
        session_id=session_id,
        task_id=task_id,
        top_k=0,
    )

    assert calls[0][1]["top_k"] == 1


@pytest.mark.parametrize(
    "error",
    [
        httpx.TimeoutException("timeout"),
        httpx.ConnectError("connect", request=httpx.Request("POST", "http://svc16.local/memory/retrieve")),
        httpx.HTTPStatusError(
            "server error",
            request=httpx.Request("POST", "http://svc16.local/memory/retrieve"),
            response=httpx.Response(500),
        ),
        RuntimeError("unexpected"),
    ],
)
def test_degraded_mode_on_any_svc16_failure(error: Exception):
    pipeline = RAGPipeline("http://svc16.local")

    def fake_post(url: str, json: dict):
        raise error

    pipeline.client.post = fake_post
    ctx = pipeline.retrieve_and_inject(
        query="test",
        session_id=str(uuid4()),
        task_id=str(uuid4()),
    )

    assert ctx == RAGContext.empty_degraded()
