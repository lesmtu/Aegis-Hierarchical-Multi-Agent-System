from dataclasses import asdict, dataclass


@dataclass(slots=True)
class RAGContext:
    context_chunks: list[str]
    source_ids: list[str]
    retrieval_scores: list[float]
    degraded_mode: bool

    def __post_init__(self) -> None:
        assert len(self.context_chunks) <= 10, (
            "context_chunks maxItems is 10 per contracts.json RAGContext schema"
        )
        assert all(isinstance(chunk, str) for chunk in self.context_chunks), (
            "context_chunks items must be strings"
        )
        assert all(isinstance(source_id, str) for source_id in self.source_ids), (
            "source_ids items must be strings"
        )
        assert len(self.source_ids) == len(self.retrieval_scores), (
            "source_ids and retrieval_scores must have identical lengths"
        )
        assert all(0.0 <= score <= 1.0 for score in self.retrieval_scores), (
            "retrieval_scores values must be within [0.0, 1.0]"
        )
        assert isinstance(self.degraded_mode, bool), (
            "degraded_mode must be a boolean"
        )

    @classmethod
    def empty_degraded(cls) -> "RAGContext":
        return cls(
            context_chunks=[],
            source_ids=[],
            retrieval_scores=[],
            degraded_mode=True,
        )

    def to_dict(self) -> dict:
        return asdict(self)
