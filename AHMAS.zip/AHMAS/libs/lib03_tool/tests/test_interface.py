import json
import logging
import sys
from dataclasses import fields
from pathlib import Path
from typing import Any

import pytest


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


sys.path.insert(0, str(_project_root()))

from libs.lib03_tool.interface import ToolInterface
from libs.lib03_tool.models import ToolResult, ToolSpec


def _contracts() -> dict:
    return json.loads((_project_root() / "contracts.json").read_text(encoding="utf-8"))


class FakeResponse:
    def __init__(self, payload: dict[str, Any], status_code: int = 200, error: Exception | None = None):
        self._payload = payload
        self.status_code = status_code
        self._error = error

    def raise_for_status(self) -> None:
        if self._error is not None:
            raise self._error

    def json(self) -> dict[str, Any]:
        return self._payload


class FakeClient:
    def __init__(self):
        self.calls: list[tuple[str, str, Any]] = []
        self.get_responses: list[Any] = []
        self.post_responses: list[Any] = []
        self.patch_responses: list[Any] = []

    def get(self, url: str):
        self.calls.append(("GET", url, None))
        response = self.get_responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def post(self, url: str, json: dict[str, Any]):
        self.calls.append(("POST", url, json))
        response = self.post_responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def patch(self, url: str):
        self.calls.append(("PATCH", url, None))
        response = self.patch_responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def _tool_entry(tool_id: str, capability_type: str = "analysis", runtime: str = "python") -> dict[str, Any]:
    return {
        "tool_id": tool_id,
        "name": "tool-name",
        "description": "tool-description",
        "capability_type": capability_type,
        "interface": {
            "input_schema": {"type": "object"},
            "output_schema": {"type": "object"},
        },
        "runtime": runtime,
        "code_path": "/tmp/tool.py",
        "version": "1.0.0",
        "created_by": "SVC-11",
        "sandbox_test_results": {
            "passed": True,
            "unit_tests_passed": True,
            "integration_tests_passed": True,
            "static_analysis_passed": True,
            "execution_time_ms": 10,
        },
        "usage_count": 0,
        "created_at": "2026-03-30T00:00:00Z",
    }


def test_toolspec_matches_toolregistryentry_schema():
    expected = _contracts()["global"]["shared_schemas"]["ToolRegistryEntry"]
    required = expected["required"]
    spec = ToolSpec.from_registry_entry(_tool_entry("tool-1"))
    assert [field.name for field in fields(ToolSpec)] == required
    assert spec.to_registry_entry() == _tool_entry("tool-1")
    assert expected["additionalProperties"] is False


def test_list_available_tools_calls_get_tools_and_filters_capability_type():
    client = FakeClient()
    client.get_responses.append(
        FakeResponse(
            {
                "tools": [
                    _tool_entry("tool-1", capability_type="analysis"),
                    _tool_entry("tool-2", capability_type="research"),
                ],
                "total": 2,
            }
        )
    )
    interface = ToolInterface("http://svc19.local")
    interface.client = client

    tools = interface.list_available_tools("analysis")

    assert client.calls == [("GET", "http://svc19.local/tools", None)]
    assert [tool.tool_id for tool in tools] == ["tool-1"]


def test_register_tool_calls_post_tools_register():
    client = FakeClient()
    client.post_responses.append(
        FakeResponse({"tool_id": "tool-registered", "registered_at": "2026-03-30T00:00:00Z"}, status_code=201)
    )
    interface = ToolInterface("http://svc19.local")
    interface.client = client
    tool_spec = ToolSpec.from_registry_entry(_tool_entry("tool-registered"))

    tool_id = interface.register_tool(tool_spec)

    assert tool_id == "tool-registered"
    assert client.calls == [
        ("POST", "http://svc19.local/tools/register", tool_spec.to_registry_entry())
    ]


def test_invoke_tool_calls_get_tool_and_patches_usage_on_success():
    client = FakeClient()
    client.get_responses.append(FakeResponse(_tool_entry("tool-123")))
    client.patch_responses.append(FakeResponse({"tool_id": "tool-123", "usage_count": 1}))
    interface = ToolInterface("http://svc19.local")
    interface.client = client
    interface._execute_tool = lambda tool_entry, input_data, runtime: ToolResult(
        success=True,
        output={"ok": True},
        error=None,
    )

    result = interface.invoke_tool("tool-123", {"input": "test"})

    assert result == ToolResult(success=True, output={"ok": True}, error=None)
    assert client.calls == [
        ("GET", "http://svc19.local/tools/tool-123", None),
        ("PATCH", "http://svc19.local/tools/tool-123/usage", None),
    ]


def test_invoke_tool_does_not_patch_usage_on_failure():
    client = FakeClient()
    client.get_responses.append(FakeResponse(_tool_entry("tool-123")))
    interface = ToolInterface("http://svc19.local")
    interface.client = client
    interface._execute_tool = lambda tool_entry, input_data, runtime: ToolResult(
        success=False,
        output=None,
        error="failed",
    )

    result = interface.invoke_tool("tool-123", {"input": "test"})

    assert result == ToolResult(success=False, output=None, error="failed")
    assert client.calls == [("GET", "http://svc19.local/tools/tool-123", None)]


def test_patch_failure_logs_warning_and_does_not_raise(caplog: pytest.LogCaptureFixture):
    client = FakeClient()
    client.get_responses.append(FakeResponse(_tool_entry("tool-123")))
    client.patch_responses.append(RuntimeError("patch failed"))
    interface = ToolInterface("http://svc19.local")
    interface.client = client
    interface._execute_tool = lambda tool_entry, input_data, runtime: ToolResult(
        success=True,
        output={"ok": True},
        error=None,
    )

    with caplog.at_level(logging.WARNING):
        result = interface.invoke_tool("tool-123", {"input": "test"})

    assert result == ToolResult(success=True, output={"ok": True}, error=None)
    assert client.calls == [
        ("GET", "http://svc19.local/tools/tool-123", None),
        ("PATCH", "http://svc19.local/tools/tool-123/usage", None),
    ]
    assert "Usage increment failed (non-critical) for tool-123: patch failed" in caplog.text
