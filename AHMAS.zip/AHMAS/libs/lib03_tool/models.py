from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class ToolSpec:
    tool_id: str
    name: str
    description: str
    capability_type: str
    interface: dict[str, Any]
    runtime: str
    code_path: str
    version: str
    created_by: str
    sandbox_test_results: dict[str, Any]
    usage_count: int
    created_at: str

    @classmethod
    def from_registry_entry(cls, entry: dict[str, Any]) -> "ToolSpec":
        return cls(
            tool_id=entry["tool_id"],
            name=entry["name"],
            description=entry["description"],
            capability_type=entry["capability_type"],
            interface=entry["interface"],
            runtime=entry["runtime"],
            code_path=entry["code_path"],
            version=entry["version"],
            created_by=entry["created_by"],
            sandbox_test_results=entry["sandbox_test_results"],
            usage_count=entry["usage_count"],
            created_at=entry["created_at"],
        )

    def to_registry_entry(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ToolResult:
    success: bool
    output: Any
    error: str | None
