import importlib.util
import json
import logging
import subprocess
from typing import Any

import httpx

from .models import ToolResult, ToolSpec


logger = logging.getLogger(__name__)


class ToolInterface:
    def __init__(self, svc19_base_url: str, timeout_seconds: float = 10.0):
        self.base_url = svc19_base_url.rstrip("/")
        self.timeout = timeout_seconds
        self.client = httpx.Client(timeout=timeout_seconds)

    def list_available_tools(self, capability_type: str) -> list[ToolSpec]:
        try:
            response = self.client.get(f"{self.base_url}/tools")
            response.raise_for_status()
            data = response.json()
            return [
                ToolSpec.from_registry_entry(tool_entry)
                for tool_entry in data["tools"]
                if tool_entry.get("capability_type") == capability_type
            ]
        except Exception as exc:
            logger.error("LIB-03: Failed to list tools from SVC-19: %s", exc)
            return []

    def invoke_tool(self, tool_id: str, input_data: dict[str, Any]) -> ToolResult:
        try:
            response = self.client.get(f"{self.base_url}/tools/{tool_id}")
            response.raise_for_status()
            tool_entry = response.json()
        except Exception as exc:
            logger.error("LIB-03: Failed to get tool %s from SVC-19: %s", tool_id, exc)
            return ToolResult(success=False, output=None, error=str(exc))

        runtime = tool_entry["runtime"]
        last_error: str | None = None
        for _ in range(2):
            try:
                result = self._execute_tool(tool_entry, input_data, runtime)
                if result.success:
                    self._increment_usage(tool_id)
                    return result
                last_error = result.error or f"Tool execution failed for {tool_id}"
            except Exception as exc:
                last_error = str(exc)

        logger.error("LIB-03: Tool execution failed for %s: %s", tool_id, last_error)
        return ToolResult(success=False, output=None, error=last_error)

    def register_tool(self, tool_spec: ToolSpec) -> str:
        try:
            response = self.client.post(
                f"{self.base_url}/tools/register",
                json=tool_spec.to_registry_entry(),
            )
            response.raise_for_status()
            data = response.json()
            return data["tool_id"]
        except Exception as exc:
            logger.error("LIB-03: Failed to register tool in SVC-19: %s", exc)
            raise

    def _increment_usage(self, tool_id: str) -> None:
        try:
            response = self.client.patch(f"{self.base_url}/tools/{tool_id}/usage")
            if response.status_code != 200:
                logger.warning(
                    "LIB-03: Usage increment failed for %s: %s",
                    tool_id,
                    response.status_code,
                )
        except Exception as exc:
            logger.warning(
                "LIB-03: Usage increment failed (non-critical) for %s: %s",
                tool_id,
                exc,
            )

    def _execute_tool(
        self,
        tool_entry: dict[str, Any],
        input_data: dict[str, Any],
        runtime: str,
    ) -> ToolResult:
        if runtime == "python":
            return self._execute_python(tool_entry, input_data)
        if runtime == "http":
            return self._execute_http(tool_entry, input_data)
        if runtime == "bash":
            return self._execute_bash(tool_entry, input_data)
        raise NotImplementedError(f"Runtime {runtime} execution pending implementation")

    def _execute_python(self, tool_entry: dict[str, Any], input_data: dict[str, Any]) -> ToolResult:
        code_path = tool_entry["code_path"]
        spec = importlib.util.spec_from_file_location("lib03_tool_runtime", code_path)
        if spec is None or spec.loader is None:
            return ToolResult(
                success=False,
                output=None,
                error=f"Unable to load python tool from {code_path}",
            )

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        for handler_name in ("run", "invoke", "main"):
            handler = getattr(module, handler_name, None)
            if callable(handler):
                output = handler(input_data)
                if isinstance(output, ToolResult):
                    return output
                return ToolResult(success=True, output=output, error=None)

        return ToolResult(
            success=False,
            output=None,
            error=f"Python tool at {code_path} does not expose run, invoke, or main",
        )

    def _execute_http(self, tool_entry: dict[str, Any], input_data: dict[str, Any]) -> ToolResult:
        response = self.client.post(tool_entry["code_path"], json=input_data)
        response.raise_for_status()
        try:
            output: Any = response.json()
        except ValueError:
            output = response.text
        return ToolResult(success=True, output=output, error=None)

    def _execute_bash(self, tool_entry: dict[str, Any], input_data: dict[str, Any]) -> ToolResult:
        command = tool_entry["code_path"]
        completed = subprocess.run(
            [command],
            input=json.dumps(input_data),
            capture_output=True,
            text=True,
            timeout=self.timeout,
            check=False,
        )
        if completed.returncode != 0:
            return ToolResult(
                success=False,
                output=completed.stdout or None,
                error=completed.stderr.strip() or f"Command exited with code {completed.returncode}",
            )
        stdout = completed.stdout.strip()
        if not stdout:
            return ToolResult(success=True, output=None, error=None)
        try:
            output: Any = json.loads(stdout)
        except json.JSONDecodeError:
            output = stdout
        return ToolResult(success=True, output=output, error=None)
